declare class AchieveItemSkin extends eui.Skin{
}
declare class BrickArrayComponentSkin extends eui.Skin{
}
declare class CharmRankItemSkin extends eui.Skin{
}
declare class EndlessRankItemSkin extends eui.Skin{
}
declare class EndlessRewardSkin extends eui.Skin{
}
declare class EndlessScoreUISkin extends eui.Skin{
}
declare class FirstChargeItemSkin extends eui.Skin{
}
declare class FriendAddItemSkin extends eui.Skin{
}
declare class FriendAlienItemSkin extends eui.Skin{
}
declare class FriendItemSkin extends eui.Skin{
}
declare class FriendMailItemSkin extends eui.Skin{
}
declare class GiftItemSkin extends eui.Skin{
}
declare class GoodsItemSkin extends eui.Skin{
}
declare class LevelItemSkin extends eui.Skin{
}
declare class LevelRewardSkin extends eui.Skin{
}
declare class MailRewardSkin extends eui.Skin{
}
declare class MissionRankItemSkin extends eui.Skin{
}
declare class MultiRankItemSkin extends eui.Skin{
}
declare class NPCSkin extends eui.Skin{
}
declare class OnlineRewardItemSkin extends eui.Skin{
}
declare class PropsComponentSkin extends eui.Skin{
}
declare class PropsItemButtonSkin extends eui.Skin{
}
declare class ScreenShotUISkin extends eui.Skin{
}
declare class SevenDayItemSkin extends eui.Skin{
}
declare class ShopItemSkin extends eui.Skin{
}
declare class ShopPriceItemSkin extends eui.Skin{
}
declare class ShopRoleItemSkin extends eui.Skin{
}
declare class SingItemSkin extends eui.Skin{
}
declare class SkillButtonSkin extends eui.Skin{
}
declare class SkillLineUISkin extends eui.Skin{
}
declare class SoundSliderSkin extends eui.Skin{
}
declare class SystemMailItemSkin extends eui.Skin{
}
declare class ToastTipSkin extends eui.Skin{
}
declare module skins{
	class ButtonSkin extends eui.Skin{
	}
}
declare module skins{
	class CheckBoxSkin extends eui.Skin{
	}
}
declare module skins{
	class HScrollBarSkin extends eui.Skin{
	}
}
declare module skins{
	class HSliderSkin extends eui.Skin{
	}
}
declare module skins{
	class ItemRendererSkin extends eui.Skin{
	}
}
declare class LevelChooseScrollItemSkin extends eui.Skin{
}
declare module skins{
	class PanelSkin extends eui.Skin{
	}
}
declare module skins{
	class ProgressBarSkin extends eui.Skin{
	}
}
declare module skins{
	class RadioButtonSkin extends eui.Skin{
	}
}
declare class RoleSkillBtnSkin extends eui.Skin{
}
declare module skins{
	class ScrollerSkin extends eui.Skin{
	}
}
declare module skins{
	class TextInputSkin extends eui.Skin{
	}
}
declare module skins{
	class ToggleSwitchSkin extends eui.Skin{
	}
}
declare module skins{
	class VScrollBarSkin extends eui.Skin{
	}
}
declare module skins{
	class VSliderSkin extends eui.Skin{
	}
}
declare class GameComponetSKin extends eui.Skin{
}
declare class panel_EndlessResult extends eui.Skin{
}
declare class panel_endless extends eui.Skin{
}
declare class panel_endlessRank extends eui.Skin{
}
declare class panel_game extends eui.Skin{
}
declare class panel_gameMultiresult extends eui.Skin{
}
declare class panel_gameShare extends eui.Skin{
}
declare class panel_gameResult extends eui.Skin{
}
declare class panel_levelChoose extends eui.Skin{
}
declare class panel_levelInfo extends eui.Skin{
}
declare class panel_match extends eui.Skin{
}
declare class panel_roleChoose extends eui.Skin{
}
declare class panel_roundResult extends eui.Skin{
}
declare class Panel_ChangeNickName extends eui.Skin{
}
declare class Panel_activity extends eui.Skin{
}
declare class mask extends eui.Skin{
}
declare class panel_achieve extends eui.Skin{
}
declare class Panel_GetNewAcheive extends eui.Skin{
}
declare class panel_friend extends eui.Skin{
}
declare class panel_hall extends eui.Skin{
}
declare class panel_levelup extends eui.Skin{
}
declare class panel_mail extends eui.Skin{
}
declare class panel_netLoading extends eui.Skin{
}
declare class panel_package extends eui.Skin{
}
declare class panel_personal extends eui.Skin{
}
declare class panel_rank extends eui.Skin{
}
declare class panel_setting extends eui.Skin{
}
declare class panel_share extends eui.Skin{
}
declare class panel_sign extends eui.Skin{
}
declare class panel_LoginChoice extends eui.Skin{
}
declare class panel_ThirdLogin extends eui.Skin{
}
declare class panel_findPSW extends eui.Skin{
}
declare class panel_register extends eui.Skin{
}
declare class panel_start extends eui.Skin{
}
declare class panel_RewardList extends eui.Skin{
}
declare class panel_guide extends eui.Skin{
}
declare class panel_shop extends eui.Skin{
}
declare class panel_tips extends eui.Skin{
}
declare class Panel_Load extends eui.Skin{
}
declare class panel_Edit extends eui.Skin{
}
declare class panel_EditSolution extends eui.Skin{
}
declare class panel_test extends eui.Skin{
}
declare class CounDownUISkin extends eui.Skin{
}
declare class NextBlockUISkin extends eui.Skin{
}
declare class RayCheckSkin extends eui.Skin{
}
declare class SkillComponentSkin extends eui.Skin{
}
declare class Guide101Skin extends eui.Skin{
}
declare class Guide103Skin extends eui.Skin{
}
declare class Guide201Skin extends eui.Skin{
}
declare class Guide401Skin extends eui.Skin{
}
declare class Guide501Skin extends eui.Skin{
}
declare class Guide701Skin extends eui.Skin{
}
declare class Guide801Skin extends eui.Skin{
}
declare class GuideStoryBoxSkin extends eui.Skin{
}
