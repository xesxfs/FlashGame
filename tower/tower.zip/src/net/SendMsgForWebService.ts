/**
 *
 * @author 
 *
 */
class SendMsgForWebService {
    
    
	public constructor() {
    	
	}
	
    public static setWSData(params,methodName,cb: Function){
        HttpSever.getInstance().request(params,methodName,cb);
	}
	
    public static GetData_ServerIp(sbc:Function){
        var a = {};
        a["channel"] = GlobalClass.GameInfoForConfig.UniqueSerial;
        SendMsgForWebService.setWSData(a,"servers",sbc);
    }

    public static Login(mobile,psw,sbc:Function){
        var a = {};
        a["channel"] = "000000";
        a["mobile"] = mobile;
        a["password"] = psw;
        a["publisher"] = "001";
        a["version"] = "001";
        SendMsgForWebService.setWSData(a,"login",sbc);
    }

    public static Register(mobile,psw,sms_code,sbc:Function){
        var a = {};
        let platform = 3;
        if(DeviceUtils.IsIos){
            platform = 1;
        }else if(DeviceUtils.IsAndroid){
            platform = 2;
        }else{
            platform = 3;
        }
        // a["channel"] = GlobalClass.GameInfoForConfig.UniqueSerial;
        a["channel"] = "000000";
        a["device_id"] = GlobalClass.GameInfoForConfig.deviceID;
        a["mobile"] = mobile;
        a["password"] = psw;
        a["platform"] = platform;
        a["publisher"] = "001";
        a["sms_code"] = sms_code;
        a["version"] = "001";
        SendMsgForWebService.setWSData(a,"register",sbc);
    }

    public static GetMSMCode(mobile,type,sbc:Function){
        var a = {};
        let platform = 3;
        if(DeviceUtils.IsIos){
            platform = 1;
        }else if(DeviceUtils.IsAndroid){
            platform = 2;
        }else{
            platform = 3;
        }
        a["channel"] = "000000";
        a["mobile"] = mobile;
        a["sms_type"] = type;
        a["platform"] = platform;
        a["publisher"] = "001";
        a["version"] = "001";
        SendMsgForWebService.setWSData(a,"sms",sbc);
    }

    public static FindPSW(mobile,psw,sms_code,sbc:Function){
        var a = {};
        a["channel"] = "000000";
        a["mobile"] = mobile;
        a["password"] = psw;
        a["publisher"] = "001";
        a["sms_code"] = sms_code;
        a["version"] = "001";
        SendMsgForWebService.setWSData(a,"find/password",sbc);
    }

    public static ApplePay(goods_id,tradeNo,receipt,sbc:Function){
        var a = {};
        a["goods_id"] = goods_id;
        a["trade_no"] = tradeNo;
        a["receipt"] = receipt;
        SendMsgForWebService.setWSData(a,"notifies/iap",sbc);
    }

    public static GuestLogin(device_id,sbc:Function){
        let platform = 3;
        if(DeviceUtils.IsIos){
            platform = 1;
        }else if(DeviceUtils.IsAndroid){
            platform = 2;
        }else{
            platform = 3;
        }
        var a = {};
        a["channel"] = "000000";
        a["device_id"] = device_id;
        a["platform"] = platform;
        a["publisher"] = "001";
        a["version"] = "001";
        SendMsgForWebService.setWSData(a,"login/visitor",sbc);
    }

    public static DataReport(sbc:Function){
        var a = {};
        a["uniqueSerial"] = GlobalClass.GameInfoForConfig.UniqueSerial;
        SendMsgForWebService.setWSData(a,"packages/update/full",sbc);
    }

    public static Login3rd(userID,token,sbc:Function){
        let platform = 3;
        if(DeviceUtils.IsIos){
            platform = 1;
        }else if(DeviceUtils.IsAndroid){
            platform = 2;
        }else{
            platform = 3;
        }
        
        var a = {};
        a["device_id"] = GlobalClass.GameInfoForConfig.deviceID;
        a["platform"] = platform;
        a["token"] = token;
        a["uniqueSerial"] = GlobalClass.GameInfoForConfig.UniqueSerial;
        a["userID"] = userID;
        
        SendMsgForWebService.setWSData(a,"login/u8",sbc);
    }
    
}
