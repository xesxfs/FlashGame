/**
 *
 * @author steven
 * 用户的操作数据包
 *
 */
class UserControMSG {
    private MainID:number = 0 ;
    
    private Data: egret.ByteArray ;
    
	public constructor() {
        this.Data = new egret.ByteArray();
	}
	
	public writeData(){
        
    }
}
