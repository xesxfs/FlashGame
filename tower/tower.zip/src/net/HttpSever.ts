/**
 *
 * @author http服务器
 * 发送数据为json,json中的s
 *
 */
class HttpSever {
    
    private ServiceKey = "abcabcabcabcabcabcabcabc";
    private url = "";
    private timeoutTime = 6000;
    private IsTimeout = false;
    private isFInish = false;

    private  getURL():string{
        if(egret.getOption("server")=="2"){
            return "http://192.168.1.133:8777/";
        }
        if(egret.getOption("server")=="3"){//邹健服务器
            return  "http://192.168.2.11:8888/";
        }
        if(GlobalClass.GameInfoForConfig.loginServer==GameServer.NST03){
            return "https://"+GlobalClass.GameInfoForConfig.wsURL+"/";
        }else{
            return "http://"+GlobalClass.GameInfoForConfig.wsURL+"/";
        }
    }

    public static getInstance(){
        return new HttpSever();
    }

    //params为一个JsonObj method为请求的方法
    public request(params,method,cb:Function,waitTime = 6000){
        let keys = new Array();
        for(let key in params){    
            keys.push(key);
            // keys.sort((a,b)=>{
            //     return a-b;
            // })
       }
       params["sign"] = this.SignParms(params,keys);
       let url = this.getURL()+method;

        let request = new egret.HttpRequest();
        request.responseType = egret.HttpResponseType.TEXT;
        //设置为 POST 请求
        request.open(url,egret.HttpMethod.POST);
        request.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
        request.send(JSON.stringify(params));

        request.addEventListener(egret.IOErrorEvent.IO_ERROR,(event:egret.IOErrorEvent) => {
            this.isFInish = true;
            console.log("httpServer post error : "+event.data);
            if(!this.IsTimeout){
                cb("post error : ");
            }
        },this);
        
        request.addEventListener(egret.Event.COMPLETE,(event: egret.IOErrorEvent)=>{
            this.isFInish = true;
            var request = <egret.HttpRequest>event.currentTarget;
            // console.log("post data : "+(<string>request.response));
            if(request.response==null||request.response==""){
                console.log("no result");
                return;
            }
            try{
                if(!this.IsTimeout){
                    let responeTxt =  <string>request.response;
                    responeTxt = decodeURIComponent(responeTxt);
                    cb(responeTxt);
                }
            }catch(err){
                // KFControllerMgr.showTips("神话级的错误就是："+err.description , 2);
            }
        },this);
        
        //添加超时功能
        this.timeoutTime = waitTime;
        let timeOut = new egret.Timer(this.timeoutTime,1);  
        timeOut.addEventListener(egret.TimerEvent.TIMER,()=>{
            if(!this.isFInish){
                console.log("ServiceWS TimerOUt " );
                cb("postTimeout");
                this.IsTimeout = true;
            }
        },this);  
        timeOut.start(); 
	}

    private static onPostComplete(event:egret.Event):void {
        let request = <egret.HttpRequest>event.currentTarget;
        console.log("post data : ",request.response);
    }

    private static onPostIOError(event:egret.IOErrorEvent):void {
        console.log("post error : " + event);
    }

    //生成签名方法 传入json
    private SignParms(data,keys):string{
       let  signStr = Object.keys(data).map(function(key){
            return key + '=' + data[key];
        }).join('&');

        // let signStr = "";
        // keys.forEach(element => {
        //     signStr = element+"="+data[element]+"&";
        // });
        // signStr = signStr.substring(0,signStr.length-2);

        let outStr = CommonFuc.AESEncryptBase64(signStr,this.ServiceKey);

        // guLKMCRwtW55dkPsb9XMAg==

         let a = CommonFuc.AESEncryptBase64("testtest",this.ServiceKey);
        
        return CommonFuc.AESEncryptBase64(signStr,this.ServiceKey);
    }
	
}
