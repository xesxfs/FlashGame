/**
 *
 * @author 
 *
 */
class MsgID {
    public static getMsgEvent(MsgIDType: MsgID): string {
        return MsgIDType + "_event";
    }

    public static GAMEPlay
    = {
        //游戏数据上报
        GameOperate: 100302,
        //游戏开始广播
        GameStart: 100303,
        //服务器广播操作帧
        GrameFrameData: 100304,
        //请求某个网络帧
        RequireFrameData: 100305,
        //快照数据上报
        SendGameStateData: 100306,
        //上报游戏结果
        SendGameResult: 100307,
        //对战游戏结束
        GameOver: 100308,

        //对战游戏结束
        RoundOver: 100310,
    }


    public static GAME
    = {
        //重连
        Reconnect: 100003,
        //获取玩家当前通关信息
        GetCurrentLevelInfos: 100005,
        //获取关卡信息
        GetLevelInfo: 100006,
        //关卡结算上报
        LevelFinish: 100007,
        //获取关卡基本信息
        GetLevelBrief: 100008,
        //使用道具
        UseProps: 100009,
        //快速匹配
        QuickMatch: 100200,
        //取消匹配
        CancelMatch: 100201,
        //多人玩法中玩家已准备好
        GameReady: 100203,
        // 进入游戏
        OpenGame: 100301,
        //测试网络延时
        GetPing: 111111,
        //获取无尽关卡 拼图模式 信息
        EndlessJigsawInfo: 100900,
        //无尽关卡结算
        EndlessFinish: 100901,
        //周末赛权限检查
        EndlessPermission: 100902,
        //周末赛入场券
        EndlessBuyTicker: 100903,
        //周末赛奖励
        EndlessWeekendAward: 100904,
        //获取拼图游戏答案
        GetJigsawSolution: 100011,
        //使用技能
        OnUseSkill: 100012,
    }

    public static HALL = {

        //成就配置信息
        AchieventInfos: 100204,
        //获取当前玩家成就详情
        GetPlayerAchieveInfos: 100205,
        //领取成就奖励
        GetAchieve: 100206,

        //成就达成
        AchieveGeted: 100207,

        //获取商品列表
        GetGoodsInfos: 100400,

        //购买商品
        BuyGoods: 100401,

        //钻石充值
        BuyDiamond: 100402,

        //获取签到列表
        GetSignInfos: 100500,

        //玩家签到
        PlayerSign: 100501,

        //获取排行信息
        GetRankInfos: 100600,

        //玩家系统邮件列表
        GetMailInfos: 100700,

        //玩家好友邮件列表
        GetFriendMailInfos: 102012,

        //领取玩家好友邮件
        GetFriendMail: 102013,

        //一键领取玩家好友邮件
        GetAllFriendMail: 102014,

        //标记邮件已读
        SetMailReaded: 100701,

        //领取邮件附件
        GetMailItems: 100702,

        //删除邮件
        DelectMail: 100703,

        //删除所有邮件
        DeleteAllMail: 100704,

        //领取所有邮件
        GetAllMail: 100705,

        //账号抢登
        ANOTHER_LOCATION_LOGIN: 110000,

        //获得成就
        GET_NEWACHIVEMENT: 100207,

        //获取订单
        GetPayOrder: 100800,

        //切换NPC
        ChangeNPC: 100010,

        //获取角色配置
        GetRoleInfos: 103000,

        //获取技能配置
        GetSkillInfos: 104000,

        //修改昵称
        ChangeNickName: 100050,

        //随机获取昵称 
        GetNickNames: 100051,
        /***获取所有关卡详情 */
        GetAllLevelDetailInfo: 103001,
        /***获取当前用户通关存档*/
        GetUserSaveLevelData: 100020,
        /**新手引导步骤***/
        GetGuideStep: 100021
    }

    public static PACKAGE = {
        //获取背包信息
        GetPackage: 100004,

        //使用体验卡
        UseRoleCard: 100017,

        //出售物品
        SellGoods: 100016,

        //升级角色
        NPCLevelup: 100018,
    }

    //活动
    public static ACTIVITY = {
        //获取在线金币奖励
        GetOnlineMoney: 101000,

        //使用兑换码
        UseRedeemCode: 100060,

        //七日礼包
        SevenDayGiftRecord: 100061,

        //获取配置
        SevenDayGiftConfig: 100062,

        //获取所有礼包配置
        getGiftInfos: 105000,

        //礼包购买记录
        GiftUsedInfo: 106001,
    }

    public static FRIEND = {
        /// 所有好友列表
        AllFriendList: 102000,
        /// 申请添加好友
        ApplyAddFrind: 102001,
        /// 搜索好友 (通过ID或者名字)
        SearchFriend: 102002,
        /// 送鲜花
        SendFlower: 102003,
        /// 送体力
        SendPhysics: 102004,
        /// 同意申请
        AgreeApply: 102005,
        /// 拒绝申请
        RefuseApply: 102006,
        /// 申请好友列表
        ApplyList: 102007,
        /// 删除好友
        DeleteFriend: 102008,
        /// 同意全部申请
        AllAgree: 102009,
        /// 拒绝全部申请
        AllRefuse: 102010,
        /// 服务器推荐
        ServerRecommand: 102011,
    }

    public static USER = {
        /// 登录服务器成功回调_90001
        SERVER_LOGINSUCCESS: 90001,
        /// 用户登录信息
        Login: 100002,

        /// 获取用户信息
        GETUSERINFO: 100001,

        /// 获取玩家背包信息
        GETBagInfo: 100004,

        //完成新手引导
        FinishGuide: 100013,

        //获取所有关卡类型
        GetAllLevelTypes: 100014,

        //获取用户通关存档
        GetUserSave: 100020
    }

    //客户端内部的消息
    public static CLIENT = {

        //收到网络帧
        ReceiveNetMSG: 1001,

        //游戏层上报游戏结果
        GameComponetResult: 1002,

        //支付结束消息
        PayOver: 1003,
        //被抢登账号
        AnotherLogin: 1004,

        //刷新个人信息
        RefreshUserInfo: 1005,

        //无尽模式下一关
        EndlessNextLevel: 1006,

        //引导结算,开始游戏
        FinishGuideAndStart: 1007,

        //邮件已读
        MailHaveRead: 1008,

        //获取短信验证码成功
        GetSMSCode: 1009,

        //刷新获取验证码按钮
        ResetCodeButton: 1010,
    }
}
