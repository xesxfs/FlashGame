//当前砖块恢复掉落
class ResumeMSG extends MSGBase{
    protected initData(){
        this.type = PlayerMSGType.Resume;
    }

    public packageData(){
        super.packageData();
    }

    public unpackageData(oriData:egret.ByteArray):any{
        return "";
    }

    public toString():string{
        let result = "isResume";
        return result;
    }
}