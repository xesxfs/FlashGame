class ItemMSG extends MSGBase{
    private mItemType:number;
    protected initData(){
        this.type = PlayerMSGType.UseItem;
    }

     public parseData(itemType:PropsID){
        this.mItemType = itemType;
        this.packageData();
    }

     public packageData(){
        super.packageData();
        let a:egret.ByteArray;
        let i = this.getData().readInt();
        i = i|((this.mItemType<<16)&0xF0000);
        this.getData().position = 0;
        this.getData().writeInt(i);
    }

     public unpackageData(value):any{
        this.mItemType = (value >> 16) & 0xF;
    }

    public getItemType():number{
        return this.mItemType;
    }

    public toString():string{
        let result = "mItemType="+this.mItemType;
        return result;
    }
}