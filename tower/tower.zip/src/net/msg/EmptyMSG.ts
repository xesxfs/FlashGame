class EmptyMSG extends MSGBase{
    private playNum = 1;
    public parseData(PlayerNum){
        // this.playNum = PlayerNum;
        // this.packageData();
    }

    public packageData(){
        super.packageData();
        this.getData().position = 4;
        for(let i=0;i<GlobalClass.Game.PlayerNum-1;i++){
            this.getData().writeInt(0);
        }
    }

    public unpackageData(oriData:egret.ByteArray):any{
        return "";
    }

    protected initData(){
        super.initData();
        this.type = PlayerMSGType.Empty;

        this.packageData();
    }

    public toString():string{
        let result = "isEmpty";
        return result;
    }
}