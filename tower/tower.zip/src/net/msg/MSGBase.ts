class MSGBase{
    
     private MainID:number = 0 ;
     private Data: egret.ByteArray ;
     private DataStr:string;
     protected type:number = -1;//数据类型 对应PlayerMSGType

     public constructor() {
        this.Data = new egret.ByteArray();
        this.Data.endian = egret.Endian.LITTLE_ENDIAN;
        this.initData();
	}
	
	public setMainID(id:number){
    	this.MainID = id;
	}
    
    public getMainID() :number{
       return this.MainID ;
    }

    public setDataStr(str:string){
    	this.DataStr =str;
	}
    
    public getDataStr() :string{
       return this.DataStr ;
    }
	
    
    public setData(mData: egret.ByteArray) {
        this.Data = mData; 
    }

    public getData(): egret.ByteArray {
        return this.Data;
    }

    public isSame(MSGBase):boolean{
        if(this.type!=MSGBase.type){
            return false;
        }else{
            return true;
        }
    }

    protected initData(){
        
    }

    public getType(){
        return  this.type;
    }

    //data中
    public packageData(){
        let i = 0;
        i = i|((this.type<<28)&0xF0000000);
        this.getData().writeInt(i);
        this.getData().position = 0;
    }

    public unpackageData(oriData):any{
        return "";
    }

    public static unpackMSG(oriData):any{
        let msg:MSGBase;
        oriData.position = 0;
        let dataArr = [];
        let len = oriData.length;
        let dataNum = Math.floor(len/4);
        for(let i=0;i<dataNum;i++){
            
            let value = oriData.readInt();
            let type = (value >> 28) & 0xF;
            switch (type){
                case PlayerMSGType.Move:
                    msg = new MoveMSG();
                break;
                case PlayerMSGType.Pause:
                    msg = new PauseMSG();
                break;
                case PlayerMSGType.Resume:
                    msg = new ResumeMSG();
                break;
                case PlayerMSGType.UseSKill:
                    msg = new SkillMSG();
                break;
                case PlayerMSGType.UseItem:
                    msg = new ItemMSG();
                break;
                case PlayerMSGType.Empty:
                    msg = new EmptyMSG();
                break;
            }
            msg.unpackageData(value);
            dataArr.push(msg);
        }
        return dataArr;
    }

    public toString():string{
        return "";
    }
}