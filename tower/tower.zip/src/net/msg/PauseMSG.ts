//当前砖块停止掉落
class PauseMSG extends MSGBase{
    protected initData(){
        this.type = PlayerMSGType.Pause;
    }

    public toString():string{
        let result = "isPause";
        return result;
    }
}