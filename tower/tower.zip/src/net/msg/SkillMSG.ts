class SkillMSG extends MSGBase{
    private senderID:number;
    private receiverID:number;
    private skillID:number;
    private state:number;//是buff还是debuff

    public getSkillID():number{
        return this.skillID;
    }

    public getsenderID():number{
        return this.senderID;
    }

    public getreceiverID():number{
        return this.receiverID;
    }

    public getState():number{
        return this.state;
    }

    protected initData(){
        this.type = PlayerMSGType.UseSKill;
    }

    public parseData(skill:number,sender:number,receiver:number,state:number){
        this.skillID = skill;
        this.senderID = sender;
        this.receiverID = receiver;
        this.state = state;
        this.packageData();
    }

    public packageData(){
        super.packageData();
        let a:egret.ByteArray;
        let i = this.getData().readInt();
        i = i|(this.senderID&0x0F);
        i = i|((this.receiverID<<4)&0xF0);
        i = i|((this.skillID<<8)&0xFF00);
        i = i|((this.state<<16)&0xF0000);
        this.getData().position = 0;
        this.getData().writeInt(i);
    }

    public unpackageData(value):any{
        this.senderID = value & 0x0F;
        this.receiverID = (value >> 4) & 0xF;
        this.skillID = (value >> 8) & 0xFF;
        this.state = (value >> 16) & 0xF;
    }

    public toString():string{
        let result = "senderID="+this.senderID+"receiverID="+this.receiverID;+"skillID="+this.skillID;+"state="+this.state;;
        return result;
    }
}