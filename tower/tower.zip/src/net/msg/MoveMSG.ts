/*
    用户屏幕的触摸移动操作，data由一个INT 32位标识 
    1.移动的位移 16~31位决定 单位为整形 分别由两个八位的二进制标识 前八位表示X 后八位表示Y
    2.移动类型  二进制12~15决定  
    3.操作类型 8~11位标识 0为移动  1为使用技能 2为暂停 3为恢复游戏
    \\

    解码从服务器发来的请求时 为INT数组 [id1,data1,id2,data2,id3,data3]
    数组中每一个INT标识一个玩家的操作数据
    INT中的位操作和编码时一样
*/
class MoveMSG extends MSGBase{

    private mtype:number;
    private posx:number;
    private posy:number;
    private blockIndex:number;

    public parseData(type,posX,posY,blockIndex){
        this.mtype = type;
        this.posx = posX;
        this.posy = posY;
        this.blockIndex = blockIndex;
        this.packageData();
    }

    public getMoveType():number{
        return this.mtype;
    }

    public getPosX():number{
        return this.posx;
    }

    public getPosY():number{
        return this.posy;
    }

    public getBlockIndex():number{
        return this.blockIndex
    }

    protected initData(){
        this.type = PlayerMSGType.Move;
    }

    public packageData(){
        super.packageData();
        let a:egret.ByteArray;
        let i = this.getData().readInt();
        i = i|(this.posy&0xFF);
        i = i|((this.posx<<8)&0xFF00);
        i = i|((this.mtype<<16)&0xF0000);
        i = i|((this.blockIndex<<20)&0xF00000);
        this.getData().position = 0;
        this.getData().writeInt(i);
    }
    public unpackageData(value):any{

        this.posy = value & 0xFF;
        this.posx = (value >> 8) & 0xFF;
        this.mtype = (value >> 16) & 0xF;
        this.blockIndex = (value >> 20) & 0xF;
    }

    public isSame(MSGBase):boolean{
        if(super.isSame(MSGBase)){
            if(this.mtype!=MSGBase.mtype){
                return false;
            }
            if(this.posx!=MSGBase.posx){
                return false;
            }
            if(this.posy!=MSGBase.posy){
                return false;
            }
        }else{
            return false;
        }
      
        return true;
    }

    public toString():string{
        let result = "type="+this.type+" x="+this.posx+" y="+this.posy
        return result;
    }
    
}