enum goodsType {
	diamond = 0,//钻石 燃料
	exp,//经验
	props,//道具
	spirit,//体力
	role,//角色
	gold,//金币
	piece,//角色碎片
	flower,//鲜花
	brick,//砖块皮肤
	roleCard,//角色体验卡
	entryCard,//周末入场券
}

enum currencyType {//货币类型
	diamond = 0,//钻石
	coin = 5,//金币
	chip = 6,//碎片
}

enum friendSource {//好友申请来源
	fromSearch = 0,//好友搜索添加
	fromChallenge = 1,//从对战添加
	fromRank = 2,//从排行榜
}

enum packageType {//背包类型
	prop = 0,//钻石
	role,//npc 
	skin,//皮肤
	card,//碎片
}

enum activityType {//活动类型
	oneDollar = 0,//一元礼包
	festival,//节日礼包
	firstCharge,//首充
}

//获取验证码的不同地方
enum getCodeType {
	register = 0,//注册的时候
	findPSW,//找回密码的时候
}

enum GameServer {
	NST01,//开发服务器
	NST02,//测试服务器
	NST03,//正式服务器
}

enum ChannelNames {
	DeFault,//网页调试
	Native,//原生包渠道
	IM,
	WanBa, //QQ玩吧
}

enum PropsID {
	/***时光倒流 */
	TimeBack = 301,
	/***解谜镜 */
	SolutionMirror,
	/***强心剂 */
	Cordial
}

enum rankType {
	missionRank = 0,//每日排行 闯关排行
	multiRank,//对战排行
	endlessJigsaw,//无尽拼图排行
	endlessSurvival,//无尽生存排行
	flower,//鲜花数排行
}

enum skeletonType {
	daojishi,//倒计时
	jiguang,//激光
	pengzhuang,//碰撞点灰尘
	shengli,//成功
	shibai,//失败
	zhuankuaidiaoluo,//掉落动画
	jineng,//技能释放动画
	hunluan,//混乱
	beijingguang,//背景光
	chuxian,//出现
	daoju,//道具
	jianxie,//减血
	jiaxie,//加血
	lingqu,//领取
	xinjilu,//新记录
	heart,//NPC血块
	chuangguanmoshi,//闯关按钮特效
	shangdian,//商店
	wujinmoshi,//无尽模式按钮
	duizhanmoshi,//对战模式按钮
	shengjila,//生级啦
	xuanyun,//眩晕
	suduxian,//速度线
}

enum GameDifficulty {
	simple = 0,//容易
	normal,//正常
	hard,//困难
}

enum GameMode {
	speed = 0,//竞速模式
	survival,//生存
	jigsaw,//拼图
}

enum roleAni {
	Idle,//空闲状态
	Skill,//使用技能
	Jump,//跳跃 包含位移
	Jump_1,//跳跃 不包含位移
}

enum sceneAni {
	newAnimation,
}

enum PlayerMSGType {
	Empty = 0,//空数据帧
	Move,
	UseSKill,
	UseItem,
	Pause,
	Resume,
}

enum PayType {
	AliPay = 0,//	支付宝APP
	WxPay,//微信
	AppStore,//苹果支付
}



class GameConstant {
	public static GameTitle = {
		"1": "登录中...",
		"2": "登录中...",
		"3": "登录中...",
		"4": "登录中...",
		"5": "登录中...",
	}

	public static getItemImg(propType, propId): string {
		let sourc = "";
		switch (propType) {
			case goodsType.diamond:
				sourc = "Shop_json.Img_fuel0" + propId;
				break;
			case goodsType.brick:
				sourc = "CommonAtlas_json.Img_item303";
				break;
			case goodsType.props:
				sourc = "CommonAtlas_json.Img_item" + propId;
				break;
			case goodsType.role:
				sourc = "CommonAtlas_json.to" + propId;
				break;
			case goodsType.spirit:
				sourc = "Shop_json.Img_spirit0" + (propId-8);//商品id 为 9,10,11  
				break;
			case goodsType.flower:
				sourc = "CommonAtlas_json.UI_flower_btn";
				break;
			case goodsType.piece:
				sourc = "CommonAtlas_json.Img_Piece";
				break;
			case goodsType.roleCard:
				sourc = "CommonAtlas_json.to" + propId;
				break;
			case goodsType.gold:
				sourc = "CommonAtlas_json.UI_coin_1";
				break;
		}
		return sourc;
	}

}


