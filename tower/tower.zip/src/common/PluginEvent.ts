// enum SendPlugins {
// 	PAYCallBack = 1000,
// 	PAY_One = 1001,
// 	PAY_Two = 1002,
// 	PAY_Three = 1003,
// 	LoginCallBack = 3000,
// 	Login_One = 3001,
// 	Login_Two = 3002,
// 	Login_Three = 3003,
// 	Share_One = 2001,
// 	Share_Two = 2002,
// 	SHare_Three = 2003,
// 	Login_guest = 6001,
// 	SwithAccount = 6002,//切换账号
// 	CloseAccount = 6003,//注销游戏
// 	ExitGame = 6004,//退出游戏 调出SDK退出逻辑
// 	GetSDKParams = 6005,//获取游戏参数(获取渠道标识符)
// 	KeyBack = 6006,//返回键
// 	FinishGame = 6007,//直接结束游戏
// 	GetChannelParams = 6008,//直接结束游戏
// 	HotUpdate = 7001,//热更新
// 	ForceUpdate = 7002,//强制更新
// }

// enum SDKPayType {
// 	PAY_One = 1001,
// 	PAY_Two,
// 	PAY_Three,
// }

// class PluginEvent {
// 	public static executePluginsEvents(eventType:SendPlugins,data){
// 		console.log("egret executePluginsEvents data="+data);
// 		let js = {
//                 eventType:eventType+"",
// 				data:data,
//             };
// 		if(DeviceUtils.IsNative){
// 			egret.ExternalInterface.call("executePulginsEvent",JSON.stringify(js));
// 		}
// 	}

// 	public static AddPulginsEventCallBack(){
// 		egret.ExternalInterface.addCallback("executePulginsEventCB",(value:string)=>{
// 				console.log("executePulginsEventCB:"+value);
// 				let js = JSON.parse(value);
// 				let eventID = js["eventID"];
// 				let data = js["data"];
// 				PluginEvent.executePluginCB(eventID,data);
// 		});
// 	}

// 	public static executePluginCB(eventID,data){
// 		console.log("executePluginCB data="+data);
// 		switch(eventID){
// 			case SendPlugins.GetSDKParams:
// 				PluginEvent.initGame(data);
// 			case SendPlugins.LoginCallBack://登录原生回调
// 				PluginEvent.Login3rd(data);
// 			break;
// 			case SendPlugins.KeyBack://原生返回键
// 				PluginEvent.onKeyBack();
// 			break;
// 			case SendPlugins.PAYCallBack://支付回调
// 				PluginEvent.PayCB(data);
// 			break;
// 			case SendPlugins.SwithAccount://登录原生回调
// 				PluginEvent.SwitchAccout(data);
// 			break;
// 			case SendPlugins.ExitGame://登录原生回调
// 				PluginEvent.FinishGame();
// 			break;
// 			case SendPlugins.GetChannelParams://获取渠道参数
// 				PluginEvent.initChannelParams(data);
// 			break;
// 		}
// 	}

// 	public static initChannelParams(data){
// 		console.log("initChannelParams data="+data);
// 		let js =  JSON.parse(data["channelStr"]);
// 		let info = js["info"];
// 		GlobalClass.GameInfoForConfig.loginType = info["login_cofig"]["buttons"];
// 		GlobalClass.GameInfoForConfig.payType = info["pay_config"]["paytypes"];
// 		GlobalClass.GameInfoForConfig.isNeedSDKExit = info["sdk_config"]["channel_quit"];
// 		GlobalClass.GameInfoForConfig.isNeedSDKLogout = info["sdk_config"]["channel_logout"];

// 		console.log("loginType="+GlobalClass.GameInfoForConfig.loginType.toString());
// 		console.log("payType="+GlobalClass.GameInfoForConfig.payType.toString());
// 	}

// 	public static initGame(data){
// 		GlobalClass.GameInfoForConfig.UniqueSerial = data["UniqueSerial"];
// 		if(data["Server"]=="NST01"){
// 			GlobalClass.GameInfoForConfig.loginServer = GameServer.NST01;
// 		}
// 		if(data["Server"]=="NST02"){
// 			GlobalClass.GameInfoForConfig.loginServer = GameServer.NST02;
// 		}
// 		if(data["Server"]=="NST03"){
// 			GlobalClass.GameInfoForConfig.loginServer = GameServer.NST03;
// 		}
// 		GameStartLogic.getInstance().initUniqueSerial();
// 	}

// 	public static Login3rd(data){
// 		if(data["code"]==0){//登录成功
// 			SendMsgForWebService.Login3rd(data["userID"],data["token"],(result)=>{
// 				console.log(result);
// 				let jsObj = JSON.parse(result);
// 				if (jsObj["code"] == 200) {
// 					let pswhash = jsObj["info"]["password_hash"];
// 					let accid = jsObj["info"]["account_id"];
// 					let js = {
// 						account_id: accid,
// 						password_hash: pswhash
// 					}
// 					WebSocketMgr.getInstance().SendOneceMsg(MsgID.USER.Login, JSON.stringify(js));
// 				} else {
// 					KFControllerMgr.showTips(jsObj["info"]);
// 				}
// 			});
// 		}else{
// 			KFControllerMgr.showTips("登录失败 "+data["info"]);
// 		}
// 	}

// 	public static PayCB(data){
// 		if(data["code"]==0){//支付成功
// 			KFControllerMgr.showTips("支付成功");
// 		}else if(data["code"]==1){ //支付取消
// 			KFControllerMgr.showTips("支付取消");
// 		}else{
// 			KFControllerMgr.showTips("支付失败"+data["info"]);
// 		}
// 	}

// 	public static SwitchAccout(data){
// 		GlobalClass.Login.isSwitchingAccount = true;
// 		GlobalClass.Login.SwitchAccountData = data;
// 		 KFControllerMgr.showTips("切换账号...",1,0,()=>{
//              WebSocketMgr.getInstance().closeSocket();
//         });
// 	}

// 	public static onKeyBack(){

// 		KFControllerMgr.showTips("是否要退出游戏！", 0, 2, () => {
// 				PluginEvent.FinishGame();
// 		});
// 	}

// 	public static CloseGame(){
//         PluginEvent.executePluginsEvents(SendPlugins.ExitGame,"");
// 	}

// 	public static FinishGame(){
//         PluginEvent.executePluginsEvents(SendPlugins.FinishGame,"");
// 	}

// 	//支付函数 
// 	// transNo 订单号
// 	// productID 商品ID
// 	// productName 商品名
// 	// productDesc 商品介绍
// 	// userID 用户ID
// 	// Amount 下单金额
// 	public static BuyProduct(payType:SDKPayType,transNo,productID,productName,productDesc,userID,Amount){
// 		let js = {
// 			transNo:transNo,
// 			goods_id:productID,
// 			user_id:userID,
// 			goods_desc:productDesc,
// 			amount:Amount,
// 			goods_name:productName,
// 		}
// 		switch(payType){
// 			case SDKPayType.PAY_One:
// 				PluginEvent.executePluginsEvents(SendPlugins.PAY_One,js);
// 			break;
// 			case SDKPayType.PAY_Two:
// 				PluginEvent.executePluginsEvents(SendPlugins.PAY_Two,js);
// 			break;
// 			case SDKPayType.PAY_Three:
// 				PluginEvent.executePluginsEvents(SendPlugins.PAY_Three,js);
// 			break;
// 		}
// 	}

// 	//分享功能
// 	public static share(){

// 	}
// }