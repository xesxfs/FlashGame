/**
 *
 * @author 
 *
 */
class GlobalClass {

	public static CurrentUser: PlayerInfo = new PlayerInfo();

	public static CurrentStage: StageInfo = new StageInfo();

	public static NPCInfos = {};//游戏NPC信息

	public static SkillInfos = {};//游戏技能信息

	public static SkillInfosByID = {};//游戏技能信息 skillID为主键

	public static AchieveInfos = {};//游戏成就信息

	public static GoodsInfos = {};//游戏商品信息 

	public static SignInfos = {};//游戏签到信息

	public static SevenDayInfos = {};//七日礼包的配置信息

	public static ItemInfos = {};//背包所有物品的配置信息

	/**技能匹配表 */
	public static SkillMatchCode = {
		10101: SkillType.SpeedUp,
		10202: SkillType.Fog1,
		10203: SkillType.Locked,
		10204: SkillType.Ice,
		10205: SkillType.Grow,
		10302: SkillType.Transform,
		20203: SkillType.AddBlood,
		20101: SkillType.Cement,
		20204: SkillType.Vine,
		20201: SkillType.Lightning,
		20202: SkillType.Platform1,
		10103: SkillType.Disorder,
		90101: SkillType.Laser1,
		90102: SkillType.Laser2,
		90103: SkillType.Laser3,
		90104: SkillType.Laser4,
		90201: SkillType.Fog1,
		90202: SkillType.Fog2,
		90203: SkillType.Fog3,
		90204: SkillType.Fog4,
		90301: SkillType.Platform1,
		90302: SkillType.Platform2,
		90303: SkillType.Platform3,
		90304: SkillType.Platform4,
		90401: SkillType.Cement,
		90402: SkillType.Cement,
		90403: SkillType.Cement,
		90404: SkillType.SuperCement,
		// 20102: SkillType.SuperCement,
		90501: SkillType.Lightning,
		90502: SkillType.Lightning,
		90503: SkillType.Lightning,
		90504: SkillType.Lightning,
		90601: SkillType.Laugh1,
		90602: SkillType.Laugh2,
		90603: SkillType.Laugh3,
		90604: SkillType.Laugh4,
	}

	/***技能type找No */
	public static getSkillNOByType(skillValue: SkillType): number {
		let skillKey;
		for (let key in GlobalClass.SkillMatchCode) {
			if (GlobalClass.SkillMatchCode[key] == skillValue) {
				skillKey = key;
				break;
			}
		}
		return skillKey;
	}

	public static GameInfoForConfig = {//当前的渠道
		currentChannel: ChannelNames.Native,
		loginServer: GameServer.NST03,
		wsURL: "",
		UniqueSerial: "000000-001-001",
		factor: 20,
		stageWidth: 720,
		stageHeight: 1280,
		blockUnitWidth: 40,
		netFrameInterval: 16,//网络帧之间间隔
		controlRate: 66,//玩家操作采样频率
		worldUpdateRate: 60,//物理世界刷新频率
		deviceID: "ab1234",
		GuildStep: 7,//新手引导步骤
		blockOffsize: 10,
		gameConfig: {},

		isNeedSDKExit: true,
		isNeedSDKLogout: false,

		loginType: [],
		payType: [],
	}

	public static Login = {
		RegisterAccount: "",
		RegisterPSW: "",
		SwitchAccountData: {},
		isSwitchingAccount: false,
	}

	public static Game = {
		isDebug: true,//是否为调试模式
		GameMode: 1,//游戏类型 1 为单机 2位多人对战 3为无尽模式
		CurrentLevel: 1,//单人游戏的当前星球 1~5
		CurrentMission: 1,//单人游戏的当前关卡 1~50
		LevelInfos: [],
		ShowInfoLevel: 1,//显示简介的关卡
		priceInfos: [],//结算奖励信息
		MissionComplete: false,//完成关卡 刚刚通过一关，用于选关界面动画
		PlayerNum: 1,//玩家数
		currentPropInfos: [],//当前玩家的道具信息

		MultiPlayers: [],//多人游戏中的玩家信息
		PlayerSettings: [],//多人游戏中玩家设置

		PlayerSeatIDInfos: [],
		PlayerSeatID: 0,//多人对战中的座位号

		PlayerRandomSeeds: [],//多人游戏中玩家随机种子数

		currentNetFrameNum: 0,//网络帧当前帧数 每收到一个网络帧则加一

		localFrameNum: 0,//本地的帧数，每分钟执行60次本地帧迭代

		lasteSupplyFrameNum: 0,//补帧时快照的起始帧数

		MultiGameResult: {},//多人对战结果

		currentShowPlayer: 0,//当前全屏展示的玩家画面，在多人对战时使用

		isReloadGame: false,//当前是否是断线重连

		gameResetData: "",//快照数据

		winnerSeatID: -1,//每小局的胜利者座位号

		readyPlayers: [],//本局已经准备好的玩家 用于断线重连

		gameRoundResults: [],//局数输赢总信息，根据座位号排序，每个座位号赢一局则在相应位置的数据

		currentRound: 1,//多人对战当前回合数

		gameIsOver: false,//对战游戏是否已经结束，用于断线重连时标识状态

		isNewRecord: false,//创造了新纪录

		historyScore: 0,//无尽模式最高分

		currentScore: 0,//无尽模式当前分数

		jigsawSolution: "",//拼图模式答案

		allLevelTypeInfos: [],//关卡类型

	}

	public static Hall = {
		isFirst: 0,
		//当前的成就情况
		currentAchievement: {},

		//今天签到的天数
		SignDay: 1,

		//今天签到的天数 1表示已经签到 0表示未签到
		TodayHaveSign: 1,

		//今日排行榜，包括每日排行和无尽排行
		RankInfos: {},

		//今日玩家自己的排行信息
		SelfRankInfos: {},

		//今日邮件信息
		MailInfos: [],

		//今日邮件信息
		FriendMailInfos: [],

		//新达成的成就，用于做成就达成的弹窗
		newAchievement: [],

		//背包信息
		packageInfos: [],

		//当前使用的角色信息
		currentRole: null,

		//当前NPC等级
		npcLevel: 1,
		/**周末赛 */
		isOpenWeekend: false,

		/**获得的物品清单 */
		RewardList: [],

		/**一元礼包配置 */
		oneDollarGiftConfig: {},

		/**首充礼包配置 */
		chargeGiftConfig: [],

		/**周末赛礼包配置 */
		weekendGiftConfig: [],

		/**礼包领取记录 */
		giftRecord: {},

		/**拥有的NPC */
		OwnedNPCList: [],

		allLevelDetailInfo: [],//所有关卡信息详情

		userSave:{},
	}

	public static UserInfo = {
		/// <summary>
		/// 第三方登录openid
		/// </summary>
		openid: "",
	}
}
