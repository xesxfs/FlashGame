/**
 *
 * @author 
 *
 */
class GameStartLogic {

    private str_WebNameList: Array<string> = null;

    private _WebPort: string = "";

    private index: number = 0;

    private static instance: GameStartLogic;
    public static getInstance(): GameStartLogic {
        if (this.instance == null) {
            this.instance = new GameStartLogic();
        }
        return this.instance;
    }

    public constructor() {

    }

    public initUniqueSerial() {
        console.log("initUniqueSerial");
        GlobalClass.GameInfoForConfig.UniqueSerial = ChannelManager.getInstance().getSDK().getUniqueSerial();
        switch (GlobalClass.GameInfoForConfig.loginServer) {
            case GameServer.NST01:
                this.str_WebNameList = [
                    "192.168.1.249"];
                this._WebPort = ":8888";
                break;
            case GameServer.NST02:
                this.str_WebNameList = ["120.79.22.239"];
                this._WebPort = ":80";
                break;
            case GameServer.NST03:
                this.str_WebNameList = ["web.wpgame.com"];
                this._WebPort = ":40002";
                break;
        }

        console.log("UniqueSerial=" + GlobalClass.GameInfoForConfig.UniqueSerial + " loginServer=" + GlobalClass.GameInfoForConfig.loginServer);
        this.startConnect();
    }

    private mStage;
    public startGame(stage) {
        this.initUniqueSerial();
        this.mStage = stage;
        KFSceneManager.getInstance(this.mStage).replaceScene(SceneName.Login);
    }

    private getWebName() {
        if (this.index == this.str_WebNameList.length) { this.index = 0; }
        let item: string = this.str_WebNameList[this.index];
        GlobalClass.GameInfoForConfig.wsURL = item + this._WebPort;
        this.index++;
    }

    public startConnect() {
        this.getWebName();
        this.getIP();
    }

    private getIP() {
        SendMsgForWebService.GetData_ServerIp((result) => {
            console.log("getIP result=" + result);
            if (CommonFuc.strContains(result, "post error") || CommonFuc.strContains(result, "postTimeout")) {
                console.log("GetData_ServerIp error");
                this.showReconnect();
            } else {
                let jsobj = JSON.parse(result);
                if (jsobj["code"] == 200) {
                    KFControllerMgr.showTips("连接中");
                    let a: string;
                    let server = jsobj["info"]["server"].split(":");
                    console.log("server:",server);
                    WebSocketMgr.getInstance().createSocket(server[0], server[1], () => {
                        console.log("连接超时");
                        KFControllerMgr.showTips("连接超时！");
                    });
                } else {

                }
            }
        });
    }

    public showReconnect() {
        KFControllerMgr.showTips(LocalizationMgr.getText("连接失败，是否重连?"), 0, 2, () => {
            this.startConnect();
        }, "提示", () => {
            if (!DeviceUtils.IsWeb) {
                DeviceUtils.CloseGame();
            } else {
                this.startConnect();
            }

        });
    }

}
