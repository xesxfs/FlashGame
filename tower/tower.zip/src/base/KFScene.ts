/**
 *
 * @author 
 *
 */
class KFScene extends eui.Component {

    protected PanelAdded: Array<KFPanel> = null;
    protected TAG: string = ";"
    public constructor() {
        super();
        this.PanelAdded = new Array<KFPanel>();
        this.percentHeight = 100;
        this.percentWidth = 100;
        this.init();
    }

    protected init() {
    }

     private on10002_event(event: egret.Event): void {
        console.log("on10002_event");
        NetEventMgr.getInstance().clientMsg(MsgID.CLIENT.AnotherLogin, "");
        KFControllerMgr.showTips("账号在其他地方登录,请注意账号的安全",2,1,()=>{
            WebSocketMgr.getInstance().closeSocket();
        },"╮(╯﹏╰)╭");
    }
    private on100207_event(event: egret.Event): void {
        //该推送可能会一次推几次，每次推不同成就类型的所有刚达成的成就称号
        console.log("on100207_event");
        let msg: MSGBase = <MSGBase>event.data;
        let dataStr = msg.getDataStr();
        // dataStr = '{"data": [{"achievement_id": 3, "reward_diamond": 10, "name": "\u725b\u5200\u5c0f\u8bd5", "target": 10, "achievement_type": 2, "achievement_number": 80201, "level": 1, "description": "\u901a\u5173\u6570"}], "command_id": 100207}';
        let jsObj = JSON.parse(dataStr);
        let data = jsObj["data"];
        GlobalClass.Hall.newAchievement.push(data);
        if(KFSceneManager.getInstance().getRuningSceneName()=="FightScene"){
            
        }else{
            KFControllerMgr.getCtl(PanelName.NewAchievementPanel).show();
        }
    }

    private on1003_event(event: egret.Event): void {
        console.log("on1003_event");
        var result = <string>event.data;
         console.log("on1003_event"+result);
         let jsobj = JSON.parse(result);
         let code = jsobj["code"];
        if(code=="200"){
            KFControllerMgr.showTips("订单支付成功!");
            this.PaySuccess(result);
            // WebSocketMgr.getInstance().SendOneceMsg(MsgID.USER.GETUSERINFO,"");
        }else if(code=="201"){
            KFControllerMgr.showTips("订单支付失败!");
        }else if(code=="202"){
            KFControllerMgr.showTips("交易取消!");
        }else{
            
        }
    }

    private PaySuccess(_str_message:string){
        let dataArr = _str_message.split('#');

        let goods_id = dataArr[0];
        let tradeNo = dataArr[1];
        let receipt = dataArr[2];

        SendMsgForWebService.ApplePay(goods_id,tradeNo,receipt,(result)=>{
            console.log("result="+result);
            let js = JSON.parse(result);
            if(js["code"]==200){
                KFControllerMgr.showTips("支付成功，稍后到账");
                WebSocketMgr.getInstance().SendOneceMsg(MsgID.USER.GETUSERINFO,JSON.stringify({}));
            }else{
                KFControllerMgr.showTips(js["info"]);
            }
        });
    }

    public onAddToStage() {
         NetEventMgr.getInstance().addEventListener("110000_event",this.on10002_event,this);
        NetEventMgr.getInstance().addEventListener("100207_event",this.on100207_event,this);
        NetEventMgr.getInstance().addEventListener("1003_event",this.on1003_event,this);
    }

    public onDestroy() {
        for (var i = 0; i < this.PanelAdded.length; i++) {
            if (this.PanelAdded[i] != null) {
                // this.PanelAdded[i].remove();
                this.PanelAdded[i].removeFromScene();
            }
        }
        this.PanelAdded = null;

        NetEventMgr.getInstance().removeEventListener("110000_event",this.on10002_event,this);
        NetEventMgr.getInstance().removeEventListener("100207_event",this.on100207_event,this);
        NetEventMgr.getInstance().removeEventListener("1003_event",this.on1003_event,this);
    }

    public clear() {
        for (var i = 0; i < this.PanelAdded.length; i++) {
            if (this.PanelAdded[i] != null) {
                this.PanelAdded[i].removeFromScene();
            }
        }
        this.PanelAdded = new Array<KFPanel>();
    }

    public getPanel(className) {
        if (this.PanelAdded != null && this.PanelAdded.length > 0) {
            for (var i = 0; i < this.PanelAdded.length; i++) {
                if (className == egret.getQualifiedClassName(this.PanelAdded[i])) {
                    this.removeChild(this.PanelAdded[i]);
                    return this.PanelAdded[i];
                }
            }
        }

        var panel = new className();
        this.PanelAdded.push(panel);
        return panel;
    }

    public openPanel(panel: KFPanel) {
        if (panel.$parent == this) {
            this.removeChild(panel);
        }
        this.addChild(panel);
        if ("DialogPanel" != egret.getQualifiedClassName(panel)) {

            this.resetChatPanel();
        }
        panel.show();
    }

    private resetChatPanel() {
        var panel;
        for (var i = 0; i < this.PanelAdded.length; i++) {
            if ("ChatPanel" == egret.getQualifiedClassName(this.PanelAdded[i])) {
                panel = this.PanelAdded[i];
            }
        }
        if (panel != null) {
            // this.setChildIndex(panel,99);
            this.removeChild(panel);
            this.addChild(panel);
        }
    }

    public removePanel(panel: KFPanel) {
        for (var i = 0; i < this.PanelAdded.length; i++) {
            if (egret.getQualifiedClassName(panel) == egret.getQualifiedClassName(this.PanelAdded[i])) {
                this.PanelAdded[i] = null;
                this.removeChild(panel);
                break;
            }
        }
    }

    public getTag() {
        return this.TAG;
    }
}
