/***影片剪辑管理 */

class MovieClipMgr {
	public static Instance = new MovieClipMgr();
	public constructor() {
		if (MovieClipMgr.Instance) {
			return MovieClipMgr.Instance;
		}
	}
	private movieClipFactorys: Array<egret.MovieClipDataFactory> = [];

	/***json 和 texture名字一样,不带后缀 */
	public getMCFactory(factoryName: string): egret.MovieClipDataFactory {
		if (this.movieClipFactorys[factoryName]) {
			return this.movieClipFactorys[factoryName]
		}
		let data = RES.getRes(factoryName + "_json");
		let texture = RES.getRes(factoryName + "_png");
		let factory = new egret.MovieClipDataFactory(data, texture);
		this.movieClipFactorys[factoryName] = factory;
		return this.movieClipFactorys[factoryName]
	}
	/**清除影片剪辑工厂 */
	public destoryFactory(fName: string) {
		if (this.movieClipFactorys[fName]) {
			let factory = this.movieClipFactorys[fName]
			this.movieClipFactorys[fName] = null;
			factory.clearCache();
		}
	}

	/**取得一个影片剪辑 */
	public getMovieClip(fName: string, mcName: string): egret.MovieClip {
		let fac = this.getMCFactory(fName);
		let mc = new egret.MovieClip(fac.generateMovieClipData(mcName));
		return mc;
	}

}
enum MovieFactory {
	role_skill
}

enum MovieClip {
	jiguang,
	shuandian,
}