class SoundMgr extends SingleClass {

	public constructor() {
		super();
		let a = egret.localStorage.getItem("SoundPercet");
		let b = egret.localStorage.getItem("EffectPercet");
		if (!a || a.trim() == "") {
			a = "0";
		}
		if (!b || b.trim() == "") {
			b = "0";
		}
		this._bgmVolume = parseFloat(a);
		if (this._bgmVolume < 0) {
			this._bgmVolume = 0;
		}
		if (isNaN(this._bgmVolume) || this._bgmVolume > 1) {
			this._bgmVolume = 1;
		}
		this._effectVolume = parseFloat(b);
		if (this._effectVolume < 0) {
			this._effectVolume = 0;
		}
		if (isNaN(this._effectVolume) || this._effectVolume > 1) {
			this._effectVolume = 1;
		}
	}
	public static get Instance(): SoundMgr {
		return this.getInstance();
	}

	private bgmChannel: egret.SoundChannel;
	private bgmChannel2: egret.SoundChannel;
	private _allowPlayEffect: boolean = true;
	private _allowPlayBGM: boolean = true;
	private _bgmVolume: number = 1;
	private _effectVolume: number = 1;
	private suffix: string = "mp3"

	///////////////BGM//////////////////
	public static jigsawbgm: string = "jigsaw_mp3";
	public static speedbgm: string = "speed_mp3";
	public static survivalbgm: string = "survival_mp3";
	public static mainbgm: string = "main_mp3";
	//////////////Effect/////////////////////

	public static brickCollider = "brickCollider_mp3";
	public static fail = "fail_mp3";
	public static win = "win_mp3";
	public static getSkill = "getSound_mp3";
	public static buttonEffect = "button_mp3";
	public static chooseEffect = "choose_mp3";
	public static useSkillEffect = "useSkill_mp3";

	public playBGM(bgmName: string, startTime: number = 0, loops: number = Number.MAX_VALUE) {
		//不允许播放 或者 正在播放
		// if(!this.allowPlayBGM||this.bgmChannel)return;	
		if (!this.allowPlayBGM) return;
		if (this.bgmChannel) {
			this.stopBGM();
		}
		var bgm: egret.Sound = RES.getRes(bgmName);
		if (bgm) {
			bgm.type = egret.Sound.MUSIC;
			this.bgmChannel = bgm.play(startTime, loops);
			this.bgmChannel.volume = this.bgmVolume;
		}
	}

	public stopBGM() {
		if (this.bgmChannel) {
			this.bgmChannel.stop();
			this.bgmChannel = null;
		}
	}

	public playEffect(soundName: string, startTime: number = 0, loops: number = 1) {

		if (!this.allowPlayEffect) return;
		var sound: egret.Sound = RES.getRes(soundName);
		if (sound) {
			sound.type = egret.Sound.EFFECT;

			sound.play(startTime, loops).volume = this.effectVolume;

		}
	}

	public set allowPlayBGM(bAllow: boolean) {
		this._allowPlayBGM = bAllow;
		if (this.allowPlayBGM) {
			this.playBGM(SoundMgr.speedbgm);
		} else {
			this.stopBGM();
		}
		LocalStorageUtil.Instance.allowMusic = bAllow;
	}

	public get allowPlayBGM(): boolean {
		return this._allowPlayBGM;
	}

	public set allowPlayEffect(bAllow: boolean) {
		this._allowPlayEffect = bAllow;
		LocalStorageUtil.Instance.allowEffect = bAllow;
	}

	public get allowPlayEffect(): boolean {
		return this._allowPlayEffect
	}

	public get bgmVolume(): number {
		return this._bgmVolume;
	}

	public set bgmVolume(nVolume: number) {
		this._bgmVolume = nVolume;
		if (this.bgmChannel) {
			this.bgmChannel.volume = nVolume;
		}
		egret.localStorage.setItem("SoundPercet", nVolume + "");
	}

	public set effectVolume(nVolume: number) {
		this._effectVolume = nVolume;
		egret.localStorage.setItem("EffectPercet", nVolume + "");
	}

	public get effectVolume(): number {
		return this._effectVolume;
	}

	public set musicToggle(value: boolean) {
		var a = Number(value);
		egret.localStorage.setItem("Toggle_Music", a + "");
	}

	public get musicToggle(): boolean {
		var a = egret.localStorage.getItem("Toggle_Music");
		this.allowPlayBGM = !!!a
		return this.allowPlayBGM;
	}

	public set effectToggle(value: boolean) {
		var a = Number(value);
		egret.localStorage.setItem("Toggle_Effect", a + "");
	}

	public get effectToggle(): boolean {
		var a = egret.localStorage.getItem("Toggle_Effect");
		this.allowPlayEffect = a == "1" ? true : false;
		return this.allowPlayEffect;
	}

}