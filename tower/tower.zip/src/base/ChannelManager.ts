
class ChannelManager{

	private static instance: ChannelManager;
	private  sdkInstance:KFChannel;
	public static getInstance(): ChannelManager {
        if(this.instance == null) {
            this.instance = new ChannelManager();
			this.instance.getSDKCls();
        }
        return this.instance;
    }
	
	private getSDKCls() {
		let type = GlobalClass.GameInfoForConfig.currentChannel;
		var  ChannelName = ChannelNames[type];
		var className = egret.getDefinitionByName(ChannelName+"SDK");
		this.sdkInstance = new className();
	}

	public getSDK():KFChannel{
		return this.sdkInstance;
	}

	public static Login(data){
		ChannelManager.getInstance().getSDK().SDKLogin(data);
	}

	public static Pay(data){
		ChannelManager.getInstance().getSDK().SDKPay(data);
	}

	public static autoLogin():boolean{
		return ChannelManager.getInstance().getSDK().isAutoLogin();
	}
}