enum PanelName {
    GamePanel,
    StartPanel,
    LoginPanel,
    HallPanel,
    TipsPanel,
    LevelChoosePanel,
    LevelInfoPanel,
    GameResultPanel,
    GameSharePanel,
    RoleChoosePanel,
    GameMatchPanel,
    MultiGameResultPanel,
    RoundResultPanel,
    ShopPanel,
    AchieveMentPanel,
    InventoryPanel,
    MailPanel,
    RankPanel,
    SignPenel,
    EndlessRankPanel,
    EndlessPanel,
    ThirdLoginPanel,
    RegisterPanel,
    FindPSWPanel,
    EditPanel,
    GuidePanel,
    EndlessResultPanel,
    NewAchievementPanel,
    FriendPanel,
    ActivityPanel,
    SettingPanel,
    PersonalPanel,
    ChangeNickNamePanel,
    RewardListPanel,
    LoginChoicePanel,
    TestPanel,
    EditSolutionPanel,
    LevelUpPanel,
    NetLoadingPanel,
}


enum Language {
    "简体中文",
    "繁体中文",
    "英语",
    "西班牙语",
    "日语",
}
class KFPanelManager {
    private localizedData: any = null;
    private localizedLanguage: string = "简体中文";
    private needPopupPanels = [];
    private static instance: KFPanelManager;
    public static getInstance(): KFPanelManager {
        if (this.instance == null) {
            this.instance = new KFPanelManager();
        }
        return this.instance;
    }
    public constructor() {
        this.needPopupPanels = [
            "TipsPanel",
            "LevelInfoPanel",
            "ShopPanel",
            "AchieveMentPanel",
            "InventoryPanel",
            "MailPanel",
            "RankPanel",
            "SignPenel",
            "NewAchievementPanel",
            "MultiGameResultPanel",
        ];
    }

    public setLocalizedDatas(data: any) {
        this.localizedData = data;
    }

    public getLocalisedString(panel: string, key: string): string {
        return this.localizedData[panel][key][this.localizedLanguage];
    }

    public setLanguage(lanType: Language) {
        this.localizedLanguage = Language[lanType];
    }

    public isPopUpPanel(name): boolean {
        let ispopUp = false;
        this.needPopupPanels.forEach(element => {
            if (element == name) {
                ispopUp = true;
            }
        });
        return ispopUp;
    }

}