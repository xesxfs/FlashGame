

class AnimationMgr {
	private static instance: AnimationMgr;

	private dragonFactory: dragonBones.EgretFactory;

	private roleFactorys = [];

	private sceneFactorys = [];

	private chestFactory: dragonBones.EgretFactory;

	public static getInstance(): AnimationMgr {
		if (this.instance == null) {
			this.instance = new AnimationMgr();
		}
		return this.instance;
	}

	private skeletonCB;
	private skeletonHaveRead = false;
	public loadSkeleton(cb?: Function, thisobj?: any) {
		if (!this.skeletonHaveRead) {
			this.skeletonCB = (event: RES.ResourceEvent) => {
				if (event.groupName == "skeleton") {
					RES.removeEventListener(RES.ResourceEvent.GROUP_COMPLETE, this.skeletonCB, this);
					this.skeletonCB = null;
					this.dragonFactory = new dragonBones.EgretFactory();
					this.dragonFactory.addDragonBonesData(dragonBones.DataParser.parseDragonBonesData(RES.getRes("NXT_ske_json")));
					this.dragonFactory.addTextureAtlasData(new dragonBones.EgretTextureAtlas(RES.getRes("NXT_tex_png"), RES.getRes("NXT_tex_json")));
					this.skeletonHaveRead = true;
					if (cb != null) {
						cb.call(thisobj);
					}
				}
			};
			RES.addEventListener(RES.ResourceEvent.GROUP_COMPLETE, this.skeletonCB, this);

			RES.loadGroup("skeleton");
		} else {
			if (cb != null) {
				cb.call(thisobj);
			}
		}

		// egret.Ticker.getInstance().register(
		// 	this.skeletonTickeFun,this
		// 	);
	}

	public startTick() {
		egret.Ticker.getInstance().register(
			this.skeletonTickeFun, this
		);
	}

	public stopTick() {
		egret.Ticker.getInstance().unregister(this.skeletonTickeFun, this);
	}

	private skeletonTickeFun(frameTime: number) {
		dragonBones.WorldClock.clock.advanceTime(0.02);
	}

	public unloadSkeleton() {
		this.dragonFactory = null;
		this.skeletonHaveRead = false;
	}

	public clenSkeleton(armature: dragonBones.Armature) {

		if (!armature || !armature.animation || !(armature instanceof dragonBones.Armature)) {
			return;
		}
		/**回收CPU */
		armature.animation.reset();
		/**回收内存 */
		armature.dispose();
		armature.display.parent && armature.display.parent.removeChild(armature.display)
	}

	public getSkeleton(Type: skeletonType, posx: number = 0, posy: number = 0, FastMode: boolean = true): dragonBones.Armature {
		// var name = skeletonType[Type];
		// var armature = this.dragonFactory.buildArmature(name);
		// armature.cacheFrameRate = 30;
		// dragonBones.WorldClock.clock.add(armature);
		// var clip = armature.display;
		// clip.x = posx;
		// clip.y = posy;
		let name = skeletonType[Type];
		let Factory = new dragonBones.EgretFactory();
		Factory.addDragonBonesData(dragonBones.DataParser.parseDragonBonesData(RES.getRes(name + "_ske_json")));
		Factory.addTextureAtlasData(new dragonBones.EgretTextureAtlas(RES.getRes(name + "_tex_png"), RES.getRes(name + "_tex_json")));
		let armature = Factory.buildArmature(name);
		// armature.cacheFrameRate = 30;
		dragonBones.WorldClock.clock.add(armature);
		var clip = armature.display;
		clip.x = posx;
		clip.y = posy;
		return armature;
	}

	private roleCB;
	private roleHaveRead = false;
	public loadRoleSkeleton(cb?: Function, thisobj?: any) {
		if (!this.roleHaveRead) {
			this.roleCB = (event: RES.ResourceEvent) => {
				if (event.groupName == "roleSke") {
					RES.removeEventListener(RES.ResourceEvent.GROUP_COMPLETE, this.roleCB, this);
					this.roleCB = null;
					for (let i = 1; i <= 5; i++) {
						let skeName = "js" + i + "_ske_json";
						let texName = "js" + i + "_tex_json";
						let pngName = "js" + i + "_tex_png";
						let fct = new dragonBones.EgretFactory();
						fct.addDragonBonesData(dragonBones.DataParser.parseDragonBonesData(RES.getRes(skeName)));
						fct.addTextureAtlasData(new dragonBones.EgretTextureAtlas(RES.getRes(pngName), RES.getRes(texName)));
						this.roleFactorys.push(fct);
					}
					this.roleHaveRead = true;
					if (cb != null) {
						cb.call(thisobj);
					}
				}
			};
			RES.addEventListener(RES.ResourceEvent.GROUP_COMPLETE, this.roleCB, this);
			RES.loadGroup("roleSke");
		}
	}

	public getRoleSke(roleID: number, Type: roleAni, posx: number = 0, posy: number = 0, FastMode: boolean = true): dragonBones.Armature {
		var name = roleAni[Type];
		var armature = this.roleFactorys[roleID].buildArmature("armatureName");
		armature.cacheFrameRate = 30;
		armature.animation.gotoAndStop(name, -1);
		dragonBones.WorldClock.clock.add(armature);
		var clip = armature.display;
		clip.x = posx;
		clip.y = posy;
		return armature;
	}

	private chestCB;
	private chestHaveRead = false;
	public loadChestSkeleton(cb?: Function, thisobj?: any) {
		if (!this.chestHaveRead) {
			this.chestCB = (event: RES.ResourceEvent) => {
				if (event.groupName == "chestSke") {
					RES.removeEventListener(RES.ResourceEvent.GROUP_COMPLETE, this.skeletonCB, this);
					this.chestCB = null;
					let skeName = "box_ske_json";
					let texName = "box_tex_json";
					let pngName = "box_tex_png";
					this.chestFactory = new dragonBones.EgretFactory();
					this.chestFactory.addDragonBonesData(dragonBones.DataParser.parseDragonBonesData(RES.getRes(skeName)));
					this.chestFactory.addTextureAtlasData(new dragonBones.EgretTextureAtlas(RES.getRes(pngName), RES.getRes(texName)));
					this.chestHaveRead = true;
					if (cb != null) {
						cb.call(thisobj);
					}
				}
			};
			RES.addEventListener(RES.ResourceEvent.GROUP_COMPLETE, this.chestCB, this);
			RES.loadGroup("chestSke");
		}
	}

	public unloadChestSkeleton() {
		this.chestFactory = null;
		this.chestCB = null;
		this.chestHaveRead = false;
	}

	public getChestSke(posx: number = 0, posy: number = 0): dragonBones.Armature {
		var armature = this.chestFactory.buildArmature("Armature");
		armature.cacheFrameRate = 30;
		armature.animation.gotoAndStop("box", 0);
		dragonBones.WorldClock.clock.add(armature);
		var clip = armature.display;
		clip.x = posx;
		clip.y = posy;
		return armature;
	}


	private sceneCB;
	private sceneHaveRead = false;
	public loadSceneSkeleton(cb?: Function, thisobj?: any) {
		if (!this.sceneHaveRead) {
			this.sceneCB = (event: RES.ResourceEvent) => {
				if (event.groupName == "sceneSke") {
					RES.removeEventListener(RES.ResourceEvent.GROUP_COMPLETE, this.skeletonCB, this);
					this.sceneCB = null;
					for (let i = 1; i <= 1; i++) {
						let skeName = "scene" + i + "_ske_json";
						let texName = "scene" + i + "_tex_json";
						let pngName = "scene" + i + "_tex_png";
						let fct = new dragonBones.EgretFactory();
						fct.addDragonBonesData(dragonBones.DataParser.parseDragonBonesData(RES.getRes(skeName)));
						fct.addTextureAtlasData(new dragonBones.EgretTextureAtlas(RES.getRes(pngName), RES.getRes(texName)));
						this.sceneFactorys.push(fct);
					}
					this.sceneHaveRead = true;
					if (cb != null) {
						cb.call(thisobj);
					}
				}
			};
			RES.addEventListener(RES.ResourceEvent.GROUP_COMPLETE, this.sceneCB, this);
			RES.loadGroup("sceneSke");
		}
	}

	public getSceneSke(sceneID: number, Type: sceneAni, posx: number = 0, posy: number = 0, FastMode: boolean = true): dragonBones.Armature {
		var name = sceneAni[Type];
		var armature = this.sceneFactorys[sceneID - 1].buildArmature("armatureName");
		armature.cacheFrameRate = 30;
		armature.animation.gotoAndStop(name, -1);
		dragonBones.WorldClock.clock.add(armature);
		var clip = armature.display;
		clip.x = posx;
		clip.y = posy;
		return armature;
	}
}