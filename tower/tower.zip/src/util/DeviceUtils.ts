enum PanelName {
	/// <summary>
    /// Pay0 单支付固定此接口
    /// </summary>
    PAY_ALIPAY = 1001,
    /// <summary>
    /// Pay1
    /// </summary>
    PAY_BAIDUPAY = 1002,
    /// <summary>
    /// Pay2
    /// </summary>
    PAY_360PAY = 1003,
}
class DeviceUtils extends SingleClass{
	private static keyBackCodeCall = "keyBack";
	private static closeGameCall = "closeGame";
	private static closeStartViewCall ="closeStartView";
	private static showFloadCall = "showFload";	 
	private static setClipboardCall ="setClipboard";
	private static phoneMessageCall = "phoneInfo";
	private static getChannelCall = "getChannel";

	// private static GetphoneDeviceID = "phoneInfo";

	private static phoneInfoData;
	private static clipboardData:string;
	private static gameId = "10001";
	
	public static Init(){
		//监听返回键
		this._getPhoneInfoCallBack();
		this._getPhoneInfo();
		this.payResultCallBack();
		this.SetLoginMsg3rdCB();
		this._getPhoneInfoCallBack();
		this._getPhoneInfo();
		this.SetGuestLoginCB();
	}

	public static payData={
		amount:0,
    	order_id:"",
    	pay_type:0,
    	process_type: 0,
    	subject: "",
		app_id:4,
		accid:110,
		attach:"",
		notify_url:"",
		source:10001,
		goods_type:1,
	}



	public static get IsWeb(){
		return (egret.Capabilities.runtimeType == egret.RuntimeType.WEB);
	}
	
	public static get IsNative(){
		return (egret.Capabilities.runtimeType == egret.RuntimeType.NATIVE);
	}
	
	public static get IsIos(){
	    return (egret.Capabilities.os=="iOS")
	}
	
	public static get IsAndroid(){
        return (egret.Capabilities.os == "Android")
	}

	//关闭游戏
	public static CloseGame(){
		// SoundMgr.Instance.stopBGM();
		egret.ExternalInterface.call(DeviceUtils.closeGameCall,"");
	}
	//关闭启动画面
	public static CloseStartView(){
		 egret.ExternalInterface.call(DeviceUtils.closeStartViewCall,"");
	}
	//Android 特用
	public static ShowFload(){
		if(this.IsAndroid){
			 egret.ExternalInterface.call(DeviceUtils.showFloadCall,"");
		}
	}

	//onResume
   private static onResume(){
	   	egret.ExternalInterface.addCallback("onResume",()=>{
			//    WebSocketMgr.getInstance().SendOneceMsg(0,"");
			   let heart = new egret.Timer(5000,0);
				heart.addEventListener(egret.TimerEvent.TIMER,()=>{

					if(WebSocketMgr.getInstance().isClose()){
						return;
					}
					// if(!GlobalClass.LoginClass.isHeartReturn){
					// 	egret.log("没收到心跳，断线");
					// 	KFControllerMgr.showTips("连接已断开...",1.5,0,()=>{
					// 		WebSocketMgr.getInstance().closeSocket();
					// 		// GlobalClass.LoginClass.isFirstHeart = true;
					// 	});
					// 		return;
					// }else{
					// 		// GlobalClass.LoginClass.isHeartReturn = false;
					// }	
					// WebSocketMgr.getInstance().SendOneceMsg(0,"");
				},this);
			});
   }

	private static _getPhoneInfo(){
		egret.ExternalInterface.call(DeviceUtils.phoneMessageCall,"");
	}

	private static _getPhoneInfoCallBack(){
		egret.ExternalInterface.addCallback(DeviceUtils.phoneMessageCall,(value:string)=>{
				console.log("rev phoneInfo:"+value);	
				GlobalClass.GameInfoForConfig.deviceID = value;			
			});
	}
	
	

	public static keyboardChange(foucusIN){
		let data = "";
		if(foucusIN){
			data = "openKeyboard";
		}else{
			data = "closeKeyboard";
		}
		egret.ExternalInterface.call("keyboardChange",data);
	}

	//手机的唯一标识
	public static getPhoneImei():string{
		if(this.phoneInfoData){
			//每次调用刷新一下
			this._getPhoneInfo();
			return this.phoneInfoData;
		}
		return "";
	}

	// 分享 (share 0,朋际，1，qq，2，微信，3，朋友圈)
	public static shareUrl(title:string,url:string,imageUrl:string,description:string,share:number=0,gameName:string="宝石风暴"){

		var data = {
			title:title,
			url:url,
			gameId:this.gameId,
			imageUrl:imageUrl,
			share:share,	
			gameName:gameName,
			description:description
		}
		egret.ExternalInterface.call("ShareUrl",JSON.stringify(data));
	}

	//设置剪切板
	public static setClipboard(copyData:string){
		this.clipboardData = copyData
		egret.ExternalInterface.call(DeviceUtils.setClipboardCall,this.clipboardData);
	}
	//获取剪切板
	public static getClipboard():string{
		if(this.clipboardData){
			return this.clipboardData;
		}
		return "";
	}

	//支付返回
	public static payResultCallBack(){
		//value 失败0  成功1
		egret.ExternalInterface.addCallback("PayResult",(value:string)=>{
			console.log("PayResult"+value);
			NetEventMgr.getInstance().clientMsg(MsgID.CLIENT.PayOver,value);
		});
	}

	public static SetLoginMsg3rdCB(){
		egret.ExternalInterface.addCallback("LoginMsg3rd",(_str:string)=>{
			DeviceUtils.LoginMsg3rd(_str);
		});
	}

	public static SetGuestLoginCB(){
		egret.ExternalInterface.addCallback("GuestLogin",(_str:string)=>{
			this.GuestLogin(_str);
		});
	}

	public static LoginMsg3rd(_str){

	}

	public static GuestLogin(_str){
		SendMsgForWebService.GuestLogin(_str,(result)=>{
			let jsObj = JSON.parse(result);
            if(jsObj["code"]==200){
				egret.localStorage.setItem("guestAccount", _str);
				KFControllerMgr.showTips("登录中",0);
                let pswhash = jsObj["info"]["password_hash"];
                let accid = jsObj["info"]["account_id"];
            	let js = {
                        account_id:accid,
                        password_hash:pswhash
                }
                WebSocketMgr.getInstance().SendOneceMsg(MsgID.USER.Login,JSON.stringify(js));
            }else{
                KFControllerMgr.showTips(jsObj["info"]);
            }
		});	
	}
}