class ShakeEffect {

	public constructor() {
		if (ShakeEffect.Instance) return ShakeEffect.Instance;
	}
	public static Instance: ShakeEffect = new ShakeEffect();

	public startShake(target: egret.DisplayObject, repead: number, maxDis: number, rate: number) {
		let originX = target.x;
		let originY = target.y;
		function shake() {
			if (repead < 0) {
				target.x = originX;
				target.y = originY;
			} else {
				repead--;
				egret.Tween.get(target).
					to({ x: target.x += (Math.random() - 0.5) * maxDis, y: target.y += (Math.random() - 0.5) * maxDis }, rate).
					to({ x: originX, y: originY }, rate).
					call(shake, this)
			}

		}
		shake();
	}

	public shakeBody(target: Box2D.Dynamics.b2Body, repead: number, maxDis: number, rate: number) {
		let position = target.GetPosition();
		maxDis/=GlobalClass.GameInfoForConfig.factor;
		function shake() {
			if (repead < 0) {
				target.SetPosition(position)
			} else {
				repead--;
				egret.Tween.get(target).
					call(() => {
						let temp = target.GetPosition();
						temp.x += (Math.random() - 0.5) * maxDis,
						// temp.y += (Math.random() - 0.5) * maxDis
						target.SetPosition(temp)
					}, this)
					.wait(rate)				
					.call(shake, this)
			}

		}
		shake();

	}
}

