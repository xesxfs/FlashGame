/**
 * 根据网络帧的计时器
 */
class NetTimer extends egret.EventDispatcher {
    private accTime: number;    //累计时间
    public delay: number;       //每帧耗时
    private needFrame = 0;
    private currentFrame = 0;
    private isPause: boolean = false;
    private repeatCount = 0;
    private CBFun;
    private timeCB;

    public constructor(delay: number, repeatCount: number = 1,cb,thisObj,timeHandler = null) {
        super();
        this.delay = delay;
        this.needFrame = Math.ceil(delay/GlobalClass.GameInfoForConfig.netFrameInterval) ;
        this.repeatCount = repeatCount;
        this.CBFun = ()=>{
            cb.call(thisObj);
        };
        if(timeHandler!=null){
            this.timeCB = ()=>{
                timeHandler.call(thisObj);
            }
        }
       
    }

    public start() {
         NetEventMgr.getInstance().addEventListener("1001_event", this.on1001_event, this);
    }

    public reset() {
    }

    public stop() {
        NetEventMgr.getInstance().removeEventListener("1001_event", this.on1001_event, this);
        this.isPause = true;
        this.CBFun = null;
    }

    // public netTimerStep(){
    //     this.currentFrame ++;
    //     if(this.currentFrame == this.needFrame){
    //         this.CBFun();
    //         if(this.repeatCount!=0){
    //             this.repeatCount--;
    //             if(this.repeatCount==0){
    //                 this.stop();
    //             }
    //         }else{
    //             this.currentFrame = 0;
    //         }
    //     }
    // }

    public pause() {
        this.isPause = true;
    }

    public resume() {
        this.isPause = false;
    }

    private update(): boolean {
        if (this.isPause) return;
        return false;
    }

    private on1001_event(event: egret.Event): void {
        // console.log("on1001_event");
        this.currentFrame ++;
        if(this.currentFrame == this.needFrame){
            this.CBFun();
            if(this.repeatCount!=0){
                this.repeatCount--;
                if(this.repeatCount==0){
                    this.stop();
                }
            }else{
                this.currentFrame = 0;
            }
        }
        if(!this.isPause&&this.timeCB!=null){
            this.timeCB();
        }
    }
}