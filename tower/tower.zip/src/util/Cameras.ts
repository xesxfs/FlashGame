class Cameras {
	private destX: number = 0;
	private destY: number = 0;
	private destZ: number = 1;

	private x: number = 0;
	private y: number = 0;
	private z: number = 1;

	private centerPoint: egret.Point;
	private worldLayer: Array<egret.DisplayObject>;
	public constructor() {
		this.worldLayer = [];
	}

	public attachWorld(world: egret.DisplayObject) {
		this.centerPoint = new egret.Point(0, 0);
		this.worldLayer.push(world);
	}

	public moveX(X: number) {
		this.destX += X;
	}

	public moveY(Y: number) {
		this.destY += Y;
	}

	public moveZ(Z: number, centerPoint: egret.Point) {
		this.destZ += Z;
	}

	public moveXTo(X: number) {
		this.destX = X;
	}

	public moveYTo(Y: number) {
		this.destY = Y;
	}

	public moveZTo(Z: number) {
		this.destZ = Z;
	}

	private speed: number = 10;

	public update() {
		let distant = this.destX - this.x;
		if (distant) {
			this.updateX(distant);
		}

		distant = this.destY - this.y;
		if (distant) {
			this.updateY(distant);
		}


		distant = this.destZ - this.z;
		if (distant) {
			this.updateZ(distant);
		}
	}


	private updateX(xDistant: number) {
		let offsize = xDistant / this.speed;
		if (Math.abs(offsize) < 0.1) {
			this.x = this.destX;
		} else {
			this.x += offsize;
		}

		this.worldLayer.forEach((layer) => {
			layer.x += offsize;
		})

	}

	private updateY(yDistant: number) {
		let offsize = yDistant / this.speed;
		if (Math.abs(offsize) < 0.1) {
			this.y = this.destY;
		} else {
			this.y += offsize;
		}
		this.worldLayer.forEach((layer) => {
			layer.y += offsize;
		})

	}

	private updateZ(zDistant: number) {
		let offsize = zDistant / this.speed;
		if (Math.abs(offsize) < 0.1) {
			this.z = this.destZ;
		} else {
			this.z += offsize;
		}

		this.worldLayer.forEach((layer) => {
			// let originX = layer.anchorOffsetX;
			// let originY = layer.anchorOffsetY;
			layer.anchorOffsetX = this.centerPoint.x;//layer.width / 2;
			layer.anchorOffsetY = this.centerPoint.y;//layer.height / 2;
			layer.scaleX += offsize;
			layer.scaleY += offsize;
			// layer.anchorOffsetX = originX;
			// layer.anchorOffsetY = originY;
		})

	}





}