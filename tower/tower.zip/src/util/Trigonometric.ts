class Trigonometric {
	public constructor() {
	}
	/***角度 */
	public static angle(p1: egret.Point, p2: egret.Point): number {
		return Math.atan2((p2.y - p1.y), (p2.x - p1.x)) * 180 / Math.PI;
	}
}