class Typewriting {
	private typeStr: string;
	private lab: egret.TextField;
	private interKey: number;
	private htmlParse: egret.HtmlTextParser;
	private tempTF: Array<egret.ITextElement>;
	private curTf: Array<egret.ITextElement>;
	public endCall: Function;

	public constructor() {
		this.htmlParse = new egret.HtmlTextParser();
	}

	public init(str: string, lab: egret.TextField) {
		this.typeStr = str;
		this.lab = lab;
		this.curTf = [];
		this.parseTextFlow();
	}

	private parseTextFlow() {
		this.tempTF = this.htmlParse.parser(this.typeStr);
		let p = this.tempTF;
		for (let i = 0; i < p.length; i++) {
			let tf = { text: "", style: p[i].style };
			this.curTf.push(tf);
		}
	}

	private concatLetter(): boolean {
		for (let i = 0; i < this.tempTF.length; i++) {
			if (this.tempTF[i].text !== "") {
				let text = this.tempTF[i].text;
				let ch = text.substr(0, 1);
				this.tempTF[i].text = text.substr(1, text.length);
				this.curTf[i].text += ch;
				return false;
			}
		}
		return true;

	}


	private addLetter() {
		egret.clearInterval(this.interKey);
		let isend = this.concatLetter();
		this.lab.textFlow = this.curTf;
		if (isend) {
			egret.clearInterval(this.interKey);
			this.endCall && this.endCall();
		} else {
			this.interKey = egret.setInterval(this.addLetter, this, 25 + Math.random() * 100);
		}

	}

	public start() {
		this.interKey = egret.setInterval(this.addLetter, this, 25 + Math.random() * 100);
		// this.addLetter();
	}

}