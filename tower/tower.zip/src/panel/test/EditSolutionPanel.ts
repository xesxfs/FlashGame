/**
 *
 * @author 
 *
 */
class EditSolutionPanel extends KFPanel {

    protected init() {
        this.skinName = "panel_EditSolution";
        super.init();
    }

    protected onAddToStage() {
        super.onAddToStage();
        console.log("onAddToStage" + this.TAG);

    }

    protected onRemovefromStage() {
        console.log("onRemovefromStage");
    }
}
