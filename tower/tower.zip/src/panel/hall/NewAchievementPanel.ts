/**
 *
 * @author 
 *
 */
class NewAchievementPanel extends KFPanel {

    protected init() {
        this.skinName = "Panel_GetNewAcheive";
        super.init();
    }

    protected onAddToStage() {
        super.onAddToStage();
        console.log("onAddToStage" + this.TAG);
    }

    protected onRemovefromStage() {
        console.log("onRemovefromStage");
    }
}
