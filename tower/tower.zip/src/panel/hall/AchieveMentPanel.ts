/**
 *
 * @author 
 *
 */
class AchieveMentPanel extends KFPanel {
    private Itemlist:eui.List;
    protected init() {
        this.skinName = "panel_achieve";
        super.init();
    }

    protected onAddToStage() {
        super.onAddToStage();
        console.log("onAddToStage" + this.TAG);
        this.Itemlist.itemRenderer = AchieveItem;
    }

    protected onRemovefromStage() {
        console.log("onRemovefromStage");
    }
}
