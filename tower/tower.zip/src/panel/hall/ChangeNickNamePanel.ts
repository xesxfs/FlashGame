/**
 *
 * @author 
 *
 */
class ChangeNickNamePanel extends KFPanel {

    protected init() {
        this.skinName = "Panel_ChangeNickName";
        super.init();
    }

    protected onAddToStage() {
        super.onAddToStage();
        console.log("onAddToStage" + this.TAG);

    }

    protected onRemovefromStage() {
        console.log("onRemovefromStage");
    }
}
