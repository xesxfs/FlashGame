/**
 *
 * @author 
 *
 */
class SignPenel extends KFPanel {
    private rewardList:eui.List;
    protected init() {
        this.skinName = "panel_sign";
        super.init();
    }

    protected onAddToStage() {
        super.onAddToStage();
        console.log("onAddToStage" + this.TAG);
        
    }

    protected onRemovefromStage() {
        console.log("onRemovefromStage");
    }
}
