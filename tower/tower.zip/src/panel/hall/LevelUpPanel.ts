class LevelUpPanel extends KFPanel {
	public constructor() {
		super();
	}
	protected init() {
		this.skinName = "panel_levelup";
		super.init();
	}

	protected onAddToStage() {
		super.onAddToStage();
		this.addEventListener("touchTap", () => { this.hide(); }, this)
		console.log("onAddToStage" + this.TAG);
		this.oldLv.text = GlobalClass.CurrentUser.level;
		this.newLv.text = GlobalClass.CurrentUser.level + 1;
		this.showLevelUpEffect();
	}

	protected onRemovefromStage() {
		console.log("onRemovefromStage");
		this.cleanLevelUpEffect();
	}
	public oldLv: eui.BitmapLabel;
	public newLv: eui.BitmapLabel;
	private levelUpEffect: dragonBones.Armature;
	public showLevelUpEffect() {
		this.levelUpEffect = AnimationMgr.getInstance().getSkeleton(skeletonType.shengjila);
		this.addChildAt(this.levelUpEffect.display, 1);
		this.levelUpEffect.display.x = this.width >> 1;
		this.levelUpEffect.display.y = (this.height >> 1) - 100;
		this.levelUpEffect.addEventListener(dragonBones.AnimationEvent.COMPLETE, () => {
			// this.hide();
			// this.cleanLevelUpEffect();
		}, this);
		this.levelUpEffect.animation.play("", 1);
	}

	public cleanLevelUpEffect() {
		if (!this.levelUpEffect) return;
		AnimationMgr.getInstance().clenSkeleton(this.levelUpEffect);
		this.levelUpEffect = null;
	}

}