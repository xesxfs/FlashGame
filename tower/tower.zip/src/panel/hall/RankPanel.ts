/**
 *
 * @author 
 *
 */
class RankPanel extends KFPanel {

    protected init() {
        this.skinName = "panel_rank";
        super.init();
    }

    protected onAddToStage() {
        super.onAddToStage();
        console.log("onAddToStage" + this.TAG);
    }

    protected onRemovefromStage() {
        console.log("onRemovefromStage");
    }
}
