/**
 *
 * @author 
 *
 */
class EndlessRankPanel extends KFPanel {

    protected init() {
        this.skinName = "panel_endlessRank";
    }

    protected onAddToStage() {
        super.onAddToStage();
        console.log("onAddToStage" + this.TAG);
    }

    protected onRemovefromStage() {
        console.log("onRemovefromStage");
    }
}
