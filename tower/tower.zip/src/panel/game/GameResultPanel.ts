/**
 *
 * @author 
 *
 */
class GameResultPanel extends KFPanel {

    protected init() {
        this.skinName = "panel_gameResult";
        super.init();
    }

    protected onAddToStage() {
        super.onAddToStage();
        console.log("onAddToStage" + this.TAG);
    }

    protected onRemovefromStage() {
        console.log("onRemovefromStage");
    }
}
