/**
 *
 * @author 
 *
 */
class GamePanel extends KFPanel {

    private localGame: GameComponent;
    private netGame: GameComponent;
    protected init() {
        this.percentWidth = 100;
        this.percentHeight = 100;
        this.skinName = "panel_game";
        super.init();
    }

    protected onAddToStage() {
        super.onAddToStage();
        console.log("onAddToStage" + this.TAG);
    }

    protected onRemovefromStage() {
        console.log("onRemovefromStage");
        GameTouchListener.getInstance().removerlistener(this);
    }

}


