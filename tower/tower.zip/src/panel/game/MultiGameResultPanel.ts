/**
 *
 * @author 
 *
 */
class MultiGameResultPanel extends KFPanel {

    protected init() {
        this.skinName = "panel_gameMultiresult";
        super.init();
    }

    protected onAddToStage() {
        super.onAddToStage();
        console.log("onAddToStage" + this.TAG);
    }

    protected onRemovefromStage() {
        console.log("onRemovefromStage");
    }
}
