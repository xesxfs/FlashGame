/**
 *
 * @author 
 *
 */
class ShopPanel extends KFPanel {
    private ShopList:eui.List;
    protected init() {
        this.skinName = "panel_shop";
        super.init();
    }

    protected onAddToStage() {
        super.onAddToStage();
        console.log("onAddToStage" + this.TAG);
    }

    protected onRemovefromStage() {
        console.log("onRemovefromStage");
    }
}
