//成就实体
class SkillInfo {
	public skill_id;//数据库主键
	public skill_number;//技能编号
	public name;//技能名
	public description;//描述
	public need_point;//技能点
	public skill_type;//技能类型
	public valid_times;//有效次数
	public need_level;//技能开启等级


	//解析服务器发出的json数据
	public parseData(data){
		this.skill_id = data["skill_id"];
        this.skill_number = data["skill_number"];
        this.name = data["name"];
        this.description = data["description"];
        this.skill_type = data["skill_type"];
		this.need_point = data["need_point"];
		this.valid_times = data["valid_times"];
        this.need_level = data["need_level"];
		return this;
	}
}