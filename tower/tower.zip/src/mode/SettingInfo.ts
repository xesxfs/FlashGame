//玩家实体
class SettingInfo {
	public npc_type;//玩家npc类型
	public brick_type;//玩家砖块类型
	//解析服务器发出的json数据
	public parseData(data){
		this.npc_type = data["npc_type"];
        this.brick_type = data["brick_type"];
		return this;
	}
}