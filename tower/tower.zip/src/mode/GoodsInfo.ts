//商品实体
class GoodsInfo {
	public good_id;//	数据库主键
	public is_online;// 是否有效

	public price_rmb;//人民币价格
	public price_coin;//金币价格
	public price_diamond ;//燃料价格
	public price_chip ;//碎片价格

	public discount_rmb;//人民币折扣
	public discount_rmb_online;//人民币折扣开始日期
	public discount_rmb_offline;//人民币折扣结束日期

	public discount_coin;//金币折扣
	public discount_coin_online;//金币折扣开始日期
	public discount_coin_offline;//金币折扣结束日期

	public discount_diamond;//燃料折扣
	public discount_diamond_online;//燃料折扣开始日期
	public discount_diamond_offline;//燃料折扣结束日期

	public discount_chip;//碎片折扣
	public discount_chip_online;//碎片折扣开始日期
	public discount_chip_offline;//碎片折扣结束日期

	public category;//类型
	public current_price_rmb;//打折后的人民币价格
	public current_price_diamond;//打折后的燃料价格
	public current_price_chip;//打折后的碎片价格
	public current_price_coin;//打折后的金币价格
	public descr;//描述
	public offline_date;//下架时间
	public online_date;//上架时间
	public prop;//物品实体
	public prop_id;//物品ID
	public active;//是否激活
	public name;//商品名
	public quantity;//商品数量
	//解析服务器发出的json数据
	public parseData(data){
		this.category = this.resetData(this.category, data["category"]);
        this.current_price_rmb = this.resetData(this.current_price_rmb, data["current_price_rmb"]);
        this.current_price_diamond = this.resetData(this.current_price_diamond, data["current_price_diamond"]);
        this.current_price_chip = this.resetData(this.current_price_chip, data["current_price_chip"]);
        this.current_price_coin = this.resetData(this.current_price_coin, data["current_price_coin"]);
        this.descr = this.resetData(this.descr, data["descr"]);

		this.offline_date = this.resetData(this.offline_date, data["offline_date"]);
        this.online_date = this.resetData(this.online_date, data["online_date"]);
        this.prop = this.resetData(this.prop, data["prop"]);
        this.prop_id = this.resetData(this.prop_id, data["prop_id"]);
        this.active = this.resetData(this.active, data["active"]);
		this.name = this.resetData(this.name, data["name"]);
        this.quantity = this.resetData(this.quantity, data["quantity"]);

		this.good_id = this.resetData(this.good_id, data["good_id"]);
        this.is_online = this.resetData(this.is_online, data["is_online"]);
        this.price_rmb = this.resetData(this.price_rmb, data["price_rmb"]);
        this.price_coin = this.resetData(this.price_coin, data["price_coin"]);
        this.price_diamond = this.resetData(this.price_diamond, data["price_diamond"]);
        this.price_chip = this.resetData(this.price_chip, data["price_chip"]);
        this.discount_rmb = this.resetData(this.discount_rmb, data["discount_rmb"]);
		this.discount_rmb_online = this.resetData(this.discount_rmb_online, data["discount_rmb_online"]);
		this.discount_rmb_offline = this.resetData(this.discount_rmb_offline, data["discount_rmb_offline"]);
		this.discount_coin = this.resetData(this.discount_coin, data["discount_coin"]);
		this.discount_coin_online = this.resetData(this.discount_coin_online, data["discount_coin_online"]);
		this.discount_coin_offline = this.resetData(this.discount_coin_offline, data["discount_coin_offline"]);
		this.discount_diamond = this.resetData(this.discount_diamond, data["discount_diamond"]);
		this.discount_diamond_online = this.resetData(this.discount_diamond_online, data["discount_diamond_online"]);
		this.discount_diamond_offline = this.resetData(this.discount_diamond_offline, data["discount_diamond_offline"]);
		this.discount_chip = this.resetData(this.discount_chip, data["discount_chip"]);
		this.discount_chip_online = this.resetData(this.discount_chip_online, data["discount_chip_online"]);
		this.discount_chip_offline = this.resetData(this.discount_chip_offline, data["discount_chip_offline"]);
		return this;
	}

	private resetData(target,source):any{
		if(source==null){
			return target;
		}else{
			return source;
		}
	}
}