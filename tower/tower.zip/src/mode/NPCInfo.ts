//成就实体
class NPCInfo {
	public role_id;//数据库主键
	public role_number;//角色编号
	public name;//角色名
	public description;//描述
	public skills;//技能数组
	public skills_upgrade_expend_coin;//升级技能所耗费金币
	public skills_upgrade_expend_diamond;//升级技能所耗费钻石	

	//解析服务器发出的json数据
	public parseData(data) {
		this.role_id = data["role_id"];
		this.role_number = data["role_number"];
		this.name = data["name"];
		this.description = data["description"];
		this.skills = data["skills"];
		this.skills_upgrade_expend_coin = data["skills_upgrade_expend_coin"];
		this.skills_upgrade_expend_diamond = data["skills_upgrade_expend_diamond"];
		return this;
	}
}