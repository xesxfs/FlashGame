//玩家实体
class PlayerInfo {
	public diamond;//玩家燃料
	public energy;//玩家体力
	public experience;//玩家经验
	public nick;//玩家昵称
	public score;//玩家分数
	public session_id;//玩家sessionID
	public player_id;//玩家ID
	public avatar;//玩家头像地址
	public hasAchieveReward;//有可领取的成就奖励
	public reconnect;//是否需要断线重连
	public level;//玩家等级
	public battle_level;//称号等级
	public next_level_experience;//下一次的经验
	public chara_skin;//玩家所拥有的皮肤 一个数组，一次标识每种皮肤是否拥有
	public endless_splice_highest_score;//无尽拼图模式最高分
	public endless_alive_highest_score;//无尽生存模式最高分
	public battle_win_count;//对战胜局
	public current_chara_skin;//当前皮肤
	public skinArr = [];
	public get_energy_remaining_seconds;//获取下一体力剩余时间
	public coin;//金币数
	public can_receive_online_coin_award_count;//可以获取的在线奖励次数
	public read_guide;//false 为新手
	public online_seconds;//在线时长
	public get_coin_remaining_seconds;//获取金币剩余时间

	public coin_remaining_interval;//获取金币间隔时间 秒
	public energy_remaining_interval;//获取体力间隔时间 秒
	public mobile;//绑定手机号码

	public login_prize;//是否已经领取当日的登录礼包
	public days;//七天登录礼包天数
	public guide_status: number;
	//解析服务器发出的json数据
	public parseData(data) {
		this.diamond = this.resetData(this.diamond, data["diamond"]);
		this.avatar = this.resetData(this.avatar, data["avatar"]);
		this.energy = this.resetData(this.energy, data["energy"]);
		this.experience = this.resetData(this.experience, data["experience"]);
		this.nick = this.resetData(this.nick, data["nick"]);
		this.player_id = this.resetData(this.player_id, data["player_id"]);
		this.score = this.resetData(this.score, data["score"]);
		this.hasAchieveReward = this.resetData(this.hasAchieveReward, data["hasAchieveReward"]);
		this.reconnect = this.resetData(this.reconnect, data["reconnect"]);
		this.level = this.resetData(this.level, data["level"]);
		this.next_level_experience = this.resetData(this.next_level_experience, data["next_level_experience"]);
		this.read_guide = this.resetData(this.read_guide, data["read_guide"]);
		this.coin = this.resetData(this.read_guide, data["coin"]);
		this.can_receive_online_coin_award_count = this.resetData(this.read_guide, data["can_receive_online_coin_award_count"]);

		this.endless_splice_highest_score = this.resetData(this.endless_splice_highest_score, data["endless_splice_highest_score"]);
		this.endless_alive_highest_score = this.resetData(this.endless_alive_highest_score, data["endless_alive_highest_score"]);
		this.battle_win_count = this.resetData(this.battle_win_count, data["battle_win_count"]);
		this.current_chara_skin = this.resetData(this.current_chara_skin, data["current_chara_skin"]);
		this.chara_skin = this.resetData(this.chara_skin, data["chara_skin"]);
		this.battle_level = this.resetData(this.battle_level, data["battle_level"]);
		this.get_energy_remaining_seconds = this.resetData(this.get_energy_remaining_seconds, data["get_energy_remaining_seconds"]);

		this.coin_remaining_interval = this.resetData(this.coin_remaining_interval, data["coin_remaining_interval"]);
		this.energy_remaining_interval = this.resetData(this.energy_remaining_interval, data["energy_remaining_interval"]);
		this.mobile = this.resetData(this.mobile, data["mobile"]);

		this.login_prize = this.resetData(this.login_prize, data["login_prize"]);
		this.days = this.resetData(this.days, data["days"]);
		this.guide_status = this.resetData(this.days, data["guide_status"]);
		for (let i = 0; i < 5; i++) {
			let state = this.chara_skin >> i & 0x1;
			this.skinArr.push(state);
		}
		return this;
	}

	private resetData(target, source): any {
		if (source == null) {
			return target;
		} else {
			return source;
		}
	}
}