//成就实体
class AchieveInfo {
	public achievement_id;//数据库主键
	public achievement_number;//成就编号
	public name;//成就名
	public description;//描述
	public achievement_type;//成就类型
	public target;//目标值
	public currentValue=0;//当前已达到的值
	public reward_diamond;//	奖励钻石数量

	public starNum = 1;//星级

	//解析服务器发出的json数据
	public parseData(data){
		this.achievement_id = data["achievement_id"];
        this.achievement_number = data["achievement_number"];
        this.name = data["name"];
        this.description = data["description"];
        this.achievement_type = data["achievement_type"];
        this.target = data["target"];
		this.reward_diamond = data["reward_diamond"];
		return this;
	}
}