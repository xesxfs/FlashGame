//玩家实体
class StageInfo {
	public StageNumber;//显示的关卡
	public StageType = 1;//关卡类型  {0: 竞速模式, 1: 生存模式, 2: 拼图模式}
	public LimitTime;//限制时间
	public BricksQuantity;//砖块数量
	public BricksList;//	砖块序列
	public BaseShape;//底座信息
	public LaserHeight;//激光线高度
	public TargetHeight;//目标高度
	public WeatherNumber;//天气编号
	public WeatherStartTime;//天气发动时间(游戏第N秒时发动) 单位秒
	public Difficulty;//关卡难度 {0: 简单, 1: 中等, 2: 困难}
	public Background;//背景
	public Description;//描述
	public random_skills;//关卡技能
	public sortId;
	//解析服务器发出的json数据
	public parseData(data) {
		this.StageNumber = data["stage_number"];
		this.StageType = data["stage_type"];
		this.LimitTime = data["limit_time"];
		this.BricksQuantity = data["bricks_quantity"];
		this.BaseShape = data["shapes"];
		this.LaserHeight = data["laser_line_height"];
		this.TargetHeight = data["target_height"];
		this.random_skills = data["random_skills"];
		this.BricksList = data["bricks_list"];
		this.WeatherNumber = data["weather_number"];
		this.WeatherStartTime = data["weather_start_time"];
		this.Difficulty = data["difficulty"];
		this.Background = data["background"];
		this.Description = data["description"];
		this.sortId = data["sortId"];
		return this;
	}
}