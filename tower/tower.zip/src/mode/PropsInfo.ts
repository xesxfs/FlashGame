//道具实体
class PropsInfo {
	public prop_id;//	数据库主键
	public name;//道具名
	public description;//描述
	public pic_url;//图片地址
	public prop_number;//道具编号
	public stage_type;//可用关卡类型
	//解析服务器发出的json数据
	public parseData(data){
		this.prop_id = data["prop_id"];
        this.name = data["name"];
        this.description = data["description"];
        this.pic_url = data["pic_url"];
        this.prop_number = data["prop_number"];
        this.stage_type = data["stage_type"];
		return this;
	}
}