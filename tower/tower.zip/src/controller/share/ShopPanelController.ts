/**
 *
 * @author 
 *
 */

class ShopPanelController extends KFController {

    private currentPropNum = 1;

    private maximun = 10;//道具最多能购买的数量
    private showGoodID = 0;
    private infoPanelType = 0;//0为展示一般商品的界面 2为展示角色商品的界面
    protected init() {
        super.init();
        this.ListenObjList = [{
            event: egret.TouchEvent.TOUCH_END, items: {
                "Btn_Close": "",
                "Btn_CloseRole": "",
                "Btn_CloseProps": "",
                "Btn_BuyProps": "",
                "Btn_addProp": "",
                "Btn_minusProp": "",

                "Btn_BuyRole": "",
                "Btn_CloseRole_Pay": "",
                "Btn_BuyRolePiece": "",
                "Btn_BuyRoleGold": "",
                "Btn_BuyRoleFuel": "",
            },
        },
        ];//添加btn名为key，值为冷却时间，然后在类中添加btn名+Click的函数，即可自动注册btn事件 ,如 Btn_MyBankClick为函数名
        this.EventsList = [
                MsgID.HALL.GetGoodsInfos,
                MsgID.HALL.BuyGoods,
                MsgID.HALL.ChangeNPC,
                MsgID.CLIENT.RefreshUserInfo,
                MsgID.HALL.GetPayOrder,
            ];
	}
	

    protected onReady() {
        WebSocketMgr.getInstance().SendOneceMsg(MsgID.HALL.GetGoodsInfos, JSON.stringify({}));
    }

    protected onShow() {//在界面上显示出来
        this.mPanel.Panel_buyRole.visible = false;
        this.mPanel.Panel_buyRoleType.visible = false;
        this.mPanel.Panel_buyProps.visible = false;
        this.showGoods(this.showCataLogy);
    }

    private on100400_event(event: egret.Event): void {
        console.log("on100400_event");
        let msg: MSGBase = <MSGBase>event.data;
        let dataStr = msg.getDataStr();

        let jsObj = JSON.parse(dataStr);
        if (jsObj["code"] == 200) {
            GlobalClass.GoodsInfos = jsObj["info"];
            this.showGoods(this.currentCataLogy);
        }
    }

    private on100401_event(event: egret.Event): void {
        console.log("on100401_event");
        let msg: MSGBase = <MSGBase>event.data;
        let dataStr = msg.getDataStr();

        let jsObj = JSON.parse(dataStr);
        if (jsObj["code"] == 200) {//刷新燃料数
            KFControllerMgr.showToast("购买成功", this.mPanel);
            if (this.infoPanelType == 0) {
                this.hidePropPanel();
            } else {
                this.hideRolePanel();
            }
            WebSocketMgr.getInstance().SendOneceMsg(MsgID.USER.GETUSERINFO, JSON.stringify({}));
        } else {
            KFControllerMgr.showTips(jsObj["info"]);
        }
    }

    private on100800_event(event: egret.Event): void {
        console.log("on100800_event");
        let msg: MSGBase = <MSGBase>event.data;
        let dataStr = msg.getDataStr();

        let jsObj = JSON.parse(dataStr);
        if (jsObj["code"] == 200) {//刷新燃料数
            KFControllerMgr.showTips("支付中", 7);

            let data = jsObj["info"];
            
            let trade_no = data["trade_no"];
            let goods_name = data["goods_name"];
            let amount = data["amount"];
            let user_id = data["user_id"];
            let desc = data["goods_name"];
            let goods_id = data["goods_id"];

            // PluginEvent.BuyProduct(SDKPayType.PAY_One,trade_no,goods_id,goods_name,desc,user_id,amount);
        }
    }

    private on100010_event(event: egret.Event): void {
        console.log("on100010_event");
        let msg: MSGBase = <MSGBase>event.data;
        let dataStr = msg.getDataStr();

        let jsObj = JSON.parse(dataStr);
        if (jsObj["code"] == 200) {//刷新燃料数
            KFControllerMgr.showTips("切换成功");
            WebSocketMgr.getInstance().SendOneceMsg(MsgID.USER.GETUSERINFO, JSON.stringify({}));
        }
    }

    //刷新个人信息
    private on1005_event(event: egret.Event): void {
        console.log("on1005_event");
        this.showGoods(this.currentCataLogy);
    }

    protected setOnClickListener() {
        this.AddClickEvent(this.mPanel.Btn_Close, egret.TouchEvent.TOUCH_END, this.Btn_CloseClick, this);
        for (let i = 0; i < 5; i++) {
            let but = this.mPanel.shopButtons.getChildAt(i);
            this.AddClickEvent(but, egret.TouchEvent.TOUCH_END, this.shopButCLick, this);
        }
    }

    protected removeOnClickListener() {
        this.RemoveClickEvent(this.mPanel.Btn_Close, egret.TouchEvent.TOUCH_END, this.Btn_CloseClick, this);
        for (let i = 0; i < 5; i++) {
            let but = this.mPanel.shopButtons.getChildAt(i);
            this.RemoveClickEvent(but, egret.TouchEvent.TOUCH_END, this.shopButCLick, this);
        }
    }

    private shopButCLick(event: egret.Event) {
        var but = <eui.Button>event.target;
        if (but == this.mPanel.Toggle_shop0) {
            this.showGoods(goodsType.diamond);
        }
        if (but == this.mPanel.Toggle_shop1) {
            this.showGoods(goodsType.spirit);
        }
        if (but == this.mPanel.Toggle_shop2) {
            this.showGoods(goodsType.props);
        }
        if (but == this.mPanel.Toggle_shop3) {
            this.showGoods(goodsType.role);
        }
        if (but == this.mPanel.Toggle_shop4) {
            this.showGoods(goodsType.brick);
        }
    }

    private currentCataLogy = 0;
    //展示商品
    private showGoods(catalogy) {
        this.currentCataLogy = catalogy;
        let index = 0;
        switch (catalogy) {
            case goodsType.diamond:
                index = 0;
                break;
            case goodsType.spirit:
                index = 1;
                break;
            case goodsType.props:
                index = 2;
                break;
            case goodsType.role:
                index = 3;
                break;
            case goodsType.brick:
                index = 4;
                break;
        }
        this.mPanel.shopButtons.getChildAt(index).selected = true;
        var dataArr = [];
        let a = GlobalClass.GoodsInfos;
        let infos = GlobalClass.GoodsInfos[catalogy];
        if (catalogy == goodsType.role) {
            this.showRoleItems(infos);
        } else {
            this.changeList(infos);
        }
    }

    private showRoleItems(datas) {
        this.mPanel.ShopScroller.visible = false;
        this.mPanel.RoleScroller.visible = true;
        var collection = new eui.ArrayCollection();
        collection.source = datas;
        this.mPanel.RoleList.dataProvider = collection;
    }

    private changeList(datas) {
        this.mPanel.ShopScroller.visible = true;
        this.mPanel.RoleScroller.visible = false;
        var collection = new eui.ArrayCollection();
        collection.source = datas;
        this.mPanel.ShopList.dataProvider = collection;
    }

    private Btn_CloseRoleClick() {
        this.hideRolePanel();
    }

    private Btn_BuyRoleClick() {//购买角色
        //  let totalPrice = parseInt(this.mPanel.Btn_BuyRole.getChildAt(2).text) ;
        // if(totalPrice>GlobalClass.CurrentUser.diamond){
        //     KFControllerMgr.showTips("用户燃料不足");
        //     return;
        // }
        //  let js = {
        //     good_id:this.showGoodID,
        //     quantity:this.currentPropNum,
        // };
        // WebSocketMgr.getInstance().SendOneceMsg(MsgID.HALL.BuyGoods,JSON.stringify(js));

        this.mPanel.roleName_pay.text.text = "";
        let posx = 360;
        let posy = 450;
        this.roleAni = AnimationMgr.getInstance().getRoleSke(this.showRoleID, roleAni.Idle, posx, posy);
        this.roleAni.display.y = posy + this.roleAni.display.height / 3;
        this.mPanel.Panel_buyRoleType.addChild(this.roleAni.display);
        this.roleAni.animation.play();
        this.roleAni.addEventListener(dragonBones.AnimationEvent.LOOP_COMPLETE, () => {
            if (!this.isIdle) {
                this.isIdle = true;
                this.playIdleEffect();
            }
        }, this);
        this.roleAni.display.addEventListener("touchTap", this.playSkillEffect, this);
        this.mPanel.Panel_buyRoleType.visible = true;
    }

    private Btn_ClosePropsClick() {
        this.mPanel.Panel_buyProps.visible = false;
    }

    private Btn_BuyPropsClick() {//购买道具
        let totalPrice = this.currentPrice * this.currentPropNum;
        if (totalPrice > GlobalClass.CurrentUser.diamond) {

            KFControllerMgr.showTips("你的燃料不足,请前往商店购买！", 0, 2, () => {
                this.hidePropPanel();
                this.showGoods(goodsType.diamond);
            }, "", () => {
            }, "取消", "前往充值");
            return;
        }
        let js = {
            good_id: this.showGoodID,
            quantity: this.currentPropNum,
            currency_type: currencyType.diamond,
        };
        WebSocketMgr.getInstance().SendOneceMsg(MsgID.HALL.BuyGoods, JSON.stringify(js));
    }

    private Btn_CloseClick() {
        this.mPanel.hide();
    }

    private Btn_addPropClick() {
        if (this.currentPropNum >= this.maximun) {
            return;
        }
        this.currentPropNum++;
        if (this.currentPropNum == this.maximun) {
            this.disableBut(this.mPanel.Btn_addProp);
        }
        this.enableBut(this.mPanel.Btn_minusProp);
        this.mPanel.propsNum.text = this.currentPropNum + "";
        this.refreshBtn();
    }

    private Btn_BuyRolePieceClick() {
        let totalPrice = parseInt(this.mPanel.Btn_BuyRolePiece.getChildAt(2).text);
        if (totalPrice > GlobalClass.CurrentUser.coin) {
            this.mPanel.Panel_buyRoleType.visible = false;
            KFControllerMgr.showTips("你的角色碎片不足,请前往商店购买！", 0, 2, () => {
                this.showGoods(goodsType.role);
            }, "", () => {
            }, "取消", "前往充值");

            return;
        }
        let js = {
            good_id: this.showGoodID,
            quantity: this.currentPropNum,
            currency_type: currencyType.chip,
        };
        WebSocketMgr.getInstance().SendOneceMsg(MsgID.HALL.BuyGoods, JSON.stringify(js));
    }

    private Btn_BuyRoleGoldClick() {
        let totalPrice = parseInt(this.mPanel.Btn_BuyRoleGold.getChildAt(2).text);
        if (totalPrice > GlobalClass.CurrentUser.coin) {
            this.mPanel.Panel_buyRoleType.visible = false;
            KFControllerMgr.showTips("你的金币不足,请前往商店购买！", 0, 2, () => {
                this.showGoods(goodsType.gold);
            }, "", () => {
            }, "取消", "前往充值");

            return;
        }
        let js = {
            good_id: this.showGoodID,
            quantity: this.currentPropNum,
            currency_type: currencyType.coin,
        };
        WebSocketMgr.getInstance().SendOneceMsg(MsgID.HALL.BuyGoods, JSON.stringify(js));
    }
    private Btn_BuyRoleFuelClick() {

        let totalPrice = parseInt(this.mPanel.Btn_BuyRoleFuel.getChildAt(2).text);
        if (totalPrice > GlobalClass.CurrentUser.diamond) {
            this.mPanel.Panel_buyRoleType.visible = false;
            KFControllerMgr.showTips("你的钻石不足,请前往商店购买！", 0, 2, () => {
                this.showGoods(goodsType.diamond);
            }, "", () => {
            }, "取消", "前往充值");
            return;
        }
        let js = {
            good_id: this.showGoodID,
            quantity: this.currentPropNum,
            currency_type: currencyType.diamond,
        };
        WebSocketMgr.getInstance().SendOneceMsg(MsgID.HALL.BuyGoods, JSON.stringify(js));
    }
    private Btn_CloseRole_PayClick() {
        this.mPanel.Panel_buyRoleType.visible = false;
    }

    private Btn_minusPropClick() {
        if (this.currentPropNum <= 1) {
            return;
        }
        this.currentPropNum--;
        if (this.currentPropNum == 1) {
            this.disableBut(this.mPanel.Btn_minusProp);
        }
        this.enableBut(this.mPanel.Btn_addProp);
        this.mPanel.propsNum.text = this.currentPropNum + "";
        this.refreshBtn();
    }

    private refreshBtn() {
        let totalPrice = this.currentPrice * this.currentPropNum;
        this.mPanel.Btn_BuyProps.getChildAt(1).text = totalPrice + "";
    }

    private currentPrice = 0;
    public showPropPanel(data, imgSource) {
        this.infoPanelType = 0;
        this.currentPrice = data.current_price_diamond;
        this.maximun = Math.floor(GlobalClass.CurrentUser.diamond / this.currentPrice);
        this.mPanel.propImg.source = RES.getRes(imgSource);
        this.currentPropNum = 1;
        this.mPanel.propsNum.text = this.currentPropNum + "";
        this.mPanel.PropName.text = data.name;
        this.showGoodID = data.good_id;
        this.mPanel.Panel_buyProps.visible = true;
        this.mPanel.Btn_BuyProps.getChildAt(1).text = this.currentPrice;
        this.disableBut(this.mPanel.Btn_minusProp);
    }

    private hidePropPanel() {
        this.mPanel.Panel_buyProps.visible = false;
        this.enableBut(this.mPanel.Btn_minusProp);
        this.enableBut(this.mPanel.Btn_addProp);
    }

    private hideRolePanel() {
        this.mPanel.Panel_buyRole.visible = false;
        if (this.roleAni != null) {
            this.roleAni.display.removeEventListener("touchTap", this.playSkillEffect, this);
            this.mPanel.Panel_buyRoleType.removeChild(this.roleAni.display);
            this.roleAni = null;
        }
    }

    private roleAni;
    private showRoleID = 0;
    public showRolePanel(data) {
        this.infoPanelType = 1;
        this.currentPropNum = 1;
        this.showGoodID = data.good_id;
        this.showRoleID = data.prop.role_number - 900 - 1;
        this.initRoleView(data)
        this.mPanel.Panel_buyRole.visible = true;

    }

    private currentRoleID;
    private initRoleView(data) {
        this.currentRoleID = data.prop.role_number;
        let Npcdata = GlobalClass.NPCInfos[this.currentRoleID];
        this.mPanel.RoleName.text = Npcdata.name;
        this.mPanel.roleDesc.text = Npcdata.description;
        let a = "CommonAtlas_json.img_npchead0" + (this.currentRoleID - 900 + 1);
        this.mPanel.roleImg.source = "CommonAtlas_json.img_npchead0" + (this.currentRoleID - 900);
        this.mPanel.fuelRequest.text = data.current_price_diamond == -1 ? "---" : data.current_price_diamond;
        this.mPanel.goldRequest.text = data.current_price_coin == -1 ? "---" : data.current_price_coin;
        this.mPanel.pieceRequest.text = data.current_price_chip == -1 ? "---" : data.current_price_chip;

        let skillArr = Npcdata.skills[GlobalClass.Hall.npcLevel - 1];
        for (let i = 0; i < 2; i++) {
            let skillGroup = this.mPanel.Skills.getChildAt(i);
            if (i < skillArr.length) {
                skillGroup.visible = true;
                let skillInfo = GlobalClass.SkillInfosByID[skillArr[i]];

                skillGroup.getChildAt(0).source = "skill_icon_json.skill_icon_" + skillInfo.skill_number;
                skillGroup.getChildAt(1).text = skillInfo.description;
            } else {
                skillGroup.visible = false;
            }
        }

        this.mPanel.roleName_pay.text = Npcdata.name;
        this.mPanel.Btn_BuyRoleGold.getChildAt(2).text = this.mPanel.goldRequest.text
        this.mPanel.Btn_BuyRoleFuel.getChildAt(2).text = this.mPanel.fuelRequest.text;
        this.mPanel.Btn_BuyRolePiece.getChildAt(2).text = this.mPanel.pieceRequest.text;
        
    }

    private tidyBuyBtn(btns: Array<egret.DisplayObject | egret.DisplayObjectContainer>, beginX: number, width: number) {
        if (!btns && !btns.length) return
        let length = btns.length;
        let perX = (width - btns[0].width * length) / length;
        let idx = 0;
        btns.forEach((btn) => {
            btn.x = beginX + idx * perX;
            idx++;
        })
    }



    private isIdle = true;
    private playIdleEffect() {
        this.isIdle = false;
        var name = roleAni[roleAni.Idle];
        this.roleAni.animation.gotoAndStop(name, -1);
        this.roleAni.animation.play();
    }

    private playSkillEffect() {
        var name = roleAni[roleAni.Skill];
        this.roleAni.animation.gotoAndStop(name, -1);
        this.roleAni.animation.play();

    }

    private showCataLogy = goodsType.diamond;
    public show(catalogy = goodsType.diamond) {
        this.showCataLogy = catalogy;
        super.show();
    }



}