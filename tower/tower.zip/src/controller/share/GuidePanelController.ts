/**
 *
 * @author 
 *
 */
class GuidePanelController extends KFController{ 
    
	
	protected init(){
    	super.init();
         this.ListenObjList = [ {event:egret.TouchEvent.TOUCH_END,items:{
                                                                    "Btn_Mission":""
                                                    },},
                            ];//添加btn名为key，值为冷却时间，然后在类中添加btn名+Click的函数，即可自动注册btn事件 ,如 Btn_MyBankClick为函数名
        this.EventsList = [
            ];
	}
	
    protected onReady() {
        
    }

    protected destroy(){
        if(this.fingerAni!=null){
            AnimationMgr.getInstance().clenSkeleton(this.fingerAni);
        }
        super.destroy();
    }

    protected onShow(){//在界面上显示出来
        this.initView();
    }

    private loadAni() {
        RES.addEventListener(RES.ResourceEvent.GROUP_COMPLETE, this.loadAniCB, this);
        RES.loadGroup("finger");
    }

    private Factory:dragonBones.EgretFactory;
    private fingerAni:dragonBones.Armature;
    private loadAniCB(event: RES.ResourceEvent) {
        if (event.groupName == "finger") {
            RES.removeEventListener(RES.ResourceEvent.GROUP_COMPLETE, this.loadAniCB, this);
            let skeName = "finger_ske_json";
            let texName = "finger_tex_json";
            let pngName = "finger_tex_png";
            this.Factory = new dragonBones.EgretFactory();
            this.Factory.addDragonBonesData(dragonBones.DataParser.parseDragonBonesData(RES.getRes(skeName)));
            this.Factory.addTextureAtlasData(new dragonBones.EgretTextureAtlas(RES.getRes(pngName), RES.getRes(texName)));
            this.initAni();
        }
    }

    private initAni() {
        this.fingerAni = this.Factory.buildArmature("Armature");
        this.fingerAni.animation.play();        
        dragonBones.WorldClock.clock.add(this.fingerAni);
        this.fingerAni.animation.timeScale = 0.5;
        var clip = this.fingerAni.display;
        this.mPanel.addChild(clip);
        clip.x = this.fingleX;
        clip.y = this.fingleY;
    }

    private Btn_MissionClick(){
        GlobalClass.Game.GameMode = 1;
        let js = {};
        WebSocketMgr.getInstance().SendOneceMsg(MsgID.GAME.GetCurrentLevelInfos,JSON.stringify(js));
    }

    private step ;

    private initView(){
        this.stopHandAni();
        this.mPanel.hand.touchEnabled = false;
        let stepKey = GlobalClass.CurrentUser.player_id+"guideStep";
         this.step = egret.localStorage.getItem(stepKey);
         if(this.step==null){
             this.step = "0";
         }
         this.mPanel.guild1.visible = false;
         this.mPanel.guild2.visible = false;
         this.mPanel.guild3.visible = false;

         this.mPanel.step1.visible = false;
         this.mPanel.step2.visible = false;
         this.mPanel.step3.visible = false;
         this.mPanel.blockImg.visible = false;
         this.mPanel.hand.visible  = false;

         let stepValue = parseInt(this.step);
         if(KFSceneManager.getInstance().getRuningSceneName()=="HallScene"){
             if(stepValue>2){
                 this.removeFromScene();
                 return;
             }
         }
         if(KFSceneManager.getInstance().getRuningSceneName()=="GameScene"){
             if(stepValue>4){
                 this.removeFromScene();
                 return;
             }
         }
         switch (this.step){
             case "0":
                this.mPanel.guild1.visible = true;
                this.mPanel.tipContent.text = "你好"+GlobalClass.CurrentUser.nick+"，\n欢迎加入X-666星舰队！";
             break;
             case "1":
                this.mPanel.guild1.visible = true;
                this.mPanel.tipContent.text = "希望你尽快熟悉堆塔技术,\n为我们星球\n找到更多能源";
             break;
             case "2":
                this.mPanel.guild2.visible = true;
                this.step0Ani();
             break;
             case "3":
                this.mPanel.guild1.visible = true;
                this.mPanel.tipContent.text = "你已经到达第一颗外星球，马上开启你的星球探索之旅吧！";
             break;
             case "4"://选关界面引导
                this.mPanel.guild3.visible = true;
                this.step1Ani();
             break;
             case "5":
                this.mPanel.guild3.visible = true;
                this.step2Ani();
             break;
             case "6":
                this.mPanel.guild3.visible = true;
                this.step3Ani();
             break;
            case "7":
                this.mPanel.guild3.visible = true;
                this.step4Ani();
             break;
         }
    }
    
    protected setOnClickListener() {
        this.AddClickEvent(this.mPanel,egret.TouchEvent.TOUCH_END,this.panelClick,this);
    }

    protected removeOnClickListener() {
        this.RemoveClickEvent(this.mPanel,egret.TouchEvent.TOUCH_END,this.panelClick,this);
    }
    
    private dialogTime = 0;

    private panelClick(){
        let nextStep = parseInt(this.step)+1+""
        let stepKey = GlobalClass.CurrentUser.player_id+"guideStep";
        egret.localStorage.setItem(stepKey,nextStep);
        switch(this.step){
             case "2":
             case "4":
             break;
             case "0":
             case "1":
             case "3":
             case "5":
             case "6":
                this.showNextStep();
             break;
             case "7":
                WebSocketMgr.getInstance().SendOneceMsg(MsgID.USER.FinishGuide,JSON.stringify({}));
                NetEventMgr.getInstance().clientMsg(MsgID.CLIENT.FinishGuideAndStart,"");
                this.removeFromScene();
            break;
        }
        
    }

    private showNextStep(){
        this.initView();
    }
    
    private step0Ani(){
        // this.mPanel.hand.x = 342;
        // this.mPanel.hand.y = 437;
        // this.mPanel.hand.visible = true;

        this.fingleX = 490;
        this.fingleY = 500;
        this.loadAni();
    }

    private fingleX = 0;
    private fingleY = 0;
    private step1Ani(){
        // this.mPanel.hand.visible = true;
        // this.mPanel.hand.x = 510;
        // this.mPanel.hand.y = 1150;
        this.fingleX = 640;
        this.fingleY = 1250;
        this.loadAni();
        this.mPanel.Gametip.text = "点击进入关卡！";
        let a = new LevelItem(100,[120,120],false,true);
        a.x = 540;
        a.y = 1180;
        this.mPanel.butGroup.addChild(a);
    }

    private step2Ani(){
        // this.mPanel.hand.visible = true;
        this.mPanel.step1.visible = true;
        this.mPanel.blockImg.visible = true;
        // this.mPanel.hand.x = 360;
        // this.mPanel.hand.y = 400;


        this.fingleX = 490;
        this.fingleY = 500;
        this.loadAni();
        this.mPanel.Gametip.text = "点击屏幕旋转砖块";
    }

    private step3Ani(){
        this.mPanel.hand.visible = true;
        this.mPanel.step2.visible = true;
        this.mPanel.blockImg.visible = true;
        this.mPanel.hand.x = 360;
        this.mPanel.hand.y = 400;
        this.mPanel.Gametip.text = "向下移动快速掉落";
        this.handStep = 1;
        this.playHandAni();
    }

    private step4Ani(){
        this.mPanel.hand.visible = true;
        this.mPanel.step3.visible = true;
        this.mPanel.blockImg.visible = true;
        this.mPanel.hand.x = 360;
        this.mPanel.hand.y = 420;
        this.mPanel.Gametip.text = "左右滑动控制砖块方向";
        this.handStep = 2;
        this.playHandAni();
    }


    private handStep;
    private playHandAni(){
        if(this.handStep==1){
            egret.Tween.get(this.mPanel.hand).to({ y: 550 }, 400).to({ y: 550 }, 400).call(function () {
                this.mPanel.hand.y = 400;
                this.playHandAni();
            }, this);
        }else if(this.handStep==2){
              egret.Tween.get(this.mPanel.hand).to({ x: 620 }, 400).wait(400).call(function () {
                this.mPanel.hand.x = 360;
                this.playHandAni();
            }, this)
        }
    }

    private stopHandAni(){
        egret.Tween.removeTweens(this.mPanel.hand);
        if(this.fingerAni!=null){
            AnimationMgr.getInstance().clenSkeleton(this.fingerAni);
            this.fingerAni = null;
        }
    }

}