/**
 *
 * @author 
 *
 */
class RewardListPanelController extends KFController{ 
    
	
	protected init(){
    	super.init();
         this.ListenObjList = [ {event:egret.TouchEvent.TOUCH_END,items:{
                                                            "Btn_Sure":"",
                                                    },},
                            
                            ];//添加btn名为key，值为冷却时间，然后在类中添加btn名+Click的函数，即可自动注册btn事件 ,如 Btn_MyBankClick为函数名
        this.EventsList = [

            ];
        
	}
	
    protected onReady() {

    }

    protected onShow(){//在界面上显示出来
        let items = GlobalClass.Hall.RewardList;
        this.createItems(items);
    }

    private Btn_SureClick(){
        this.mPanel.hide();
    }

    private createItems(items){
        this.mPanel.ItemGroup.removeChildren();
        let a = items.length;
        for(let i=0;i<items.length;i++){
            let item = new LevelReward(items[i]["quantity"],items[i]["propid"],items[i]["category"]);
            this.mPanel.ItemGroup.addChild(item);
        }
    }
}