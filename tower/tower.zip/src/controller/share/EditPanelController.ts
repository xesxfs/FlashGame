/**
 *
 * @author 
 *
 */
class EditPanelController extends KFController{ 
    
	
	protected init(){
    	super.init();
         this.ListenObjList = [ {event:egret.TouchEvent.TOUCH_END,items:{
                                                                        "Btn_Test":"",
                                                                        "Btn_Refresh":"",
                                                    },},
                            
                            ];//添加btn名为key，值为冷却时间，然后在类中添加btn名+Click的函数，即可自动注册btn事件 ,如 Btn_MyBankClick为函数名
        this.EventsList = [
            ];
        
	}
	
    protected onReady() {
        
    }

    protected onShow(){//在界面上显示出来
        this.initView();
    }

    private allBricks = [];

    private imgs = [];
    
    private initView(){
        let widthNum = this.mPanel.width/GlobalClass.GameInfoForConfig.blockUnitWidth;
        let heightNum = this.mPanel.height/GlobalClass.GameInfoForConfig.blockUnitWidth;
        for(let i=0;i<widthNum;i++){
            let arr = [];
            for(let j=0;j<heightNum;j++){
                let img = new eui.Image("Game_json.Img_platformblock02");
                this.mPanel.brockSgroup.addChild(img);
                img.x = i*GlobalClass.GameInfoForConfig.blockUnitWidth;
                img.y = j*GlobalClass.GameInfoForConfig.blockUnitWidth;
                img.name = i+"_"+j;
                img.addEventListener(egret.TouchEvent.TOUCH_END,(event)=>{
                    let a = event.target.source.toString();
                    let numArr = img.name.split("_");
                    let x = parseInt(numArr[0]);
                    let y = parseInt(numArr[1]);
                    if(a=="Game_json.Img_platformblock02"){
                        event.target.source = "Game_json.Img_platformblock01";
                        this.allBricks[x][y] = 1;
                    }
                    if(a=="Game_json.Img_platformblock01"){
                        event.target.source = "Game_json.Img_platformblock02";
                        this.allBricks[x][y] = 0;
                    }
                },this);
                this.imgs.push(img);
               arr.push(0);
            }
             this.allBricks.push(arr);
        }
    }

    private seletedBrock = [];
    private Btn_TestClick(){
        
        this.calculateMi();
        let a = JSON.stringify(this.finalList);
        alert(a+" x="+this.posX +" y="+this.posY);
        console.log(a);
        
    }

    private Btn_RefreshClick(){
        this.refresh();
    }

    private refresh(){
        this.imgs.forEach(element => {
            element.source = "Game_json.Img_platformblock02";
        });
        let widthNum = this.mPanel.width/GlobalClass.GameInfoForConfig.blockUnitWidth;
        let heightNum = this.mPanel.height/GlobalClass.GameInfoForConfig.blockUnitWidth;
          for(let i=0;i<widthNum;i++){
            for(let j=0;j<heightNum;j++){
                this.allBricks[i][j] = 0;
               
            }
          }
        this.seletedBrock = [];
        this.finalList = [];
    }

    private posX = 0;
    private posY = 0;
    private calculateMi(){
        let minX = -1;
        let minY = -1;
        let maxX = -1;
        let maxY = -1;
        let widthNum = this.mPanel.width/GlobalClass.GameInfoForConfig.blockUnitWidth;
        let heightNum = this.mPanel.height/GlobalClass.GameInfoForConfig.blockUnitWidth;
          for(let i=0;i<widthNum;i++){
            for(let j=0;j<heightNum;j++){
                if(this.allBricks[i][j] == 1){
                    this.seletedBrock.push(i+"_"+j);
                    if(minX==-1){
                        minX = i;
                        minY = j;
                        maxX = i;
                        maxY = j;
                    }
                    if(j<minY){
                        minY = j;
                    }else if(j>=maxY){
                        maxY = j;
                    }
                    if(i<minX){
                        minX = i;
                    }else if(i>=maxX){
                        maxX = i;
                    }
                }
            }
          }
        let middleX = (minX+maxX)/2;
        let middleY = (minY+maxY)/2;
        this.posX = middleX*2+1;
        this.posY = middleY*2+1;

        this.seletedBrock.forEach(element => {
            let numArr = element.split("_");
            let x = parseInt(numArr[0]);
            let y = parseInt(numArr[1]);
            this.finalList.push([x-middleX,(y-middleY)]);
        });


    }

    private finalList = [];
}