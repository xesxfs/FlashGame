/**
 *
 * @author 
 *
 */
class HallPanelController extends KFController {
    protected init() {
        super.init();
        this.ListenObjList = [{
            event: egret.TouchEvent.TOUCH_END, items: {
                "Btn_ddg": "",
                "Btn_sdx": "",
                "Btn_fjg": "",
            },
        },
        ];//添加btn名为key，值为冷却时间，然后在类中添加btn名+Click的函数，即可自动注册btn事件 ,如 Btn_MyBankClick为函数名
        this.EventsList = [
            // MsgID.GAME.GetCurrentLevelInfos,
            // MsgID.HALL.AchieventInfos,
            // MsgID.HALL.GetSignInfos,
            // MsgID.HALL.GetRankInfos,
            // MsgID.GAME.Reconnect,
            MsgID.USER.GETUSERINFO,
            // MsgID.USER.GetAllLevelTypes,
            // MsgID.HALL.GetRoleInfos,
            // MsgID.HALL.GetSkillInfos,
            // MsgID.FRIEND.ApplyList,
            // MsgID.HALL.GetMailInfos,
            // MsgID.HALL.GetFriendMailInfos,
            // MsgID.HALL.GetPlayerAchieveInfos,
            // MsgID.ACTIVITY.getGiftInfos,
            // MsgID.ACTIVITY.GiftUsedInfo,
            // MsgID.GAME.EndlessWeekendAward,
            // MsgID.PACKAGE.GetPackage,
            MsgID.HALL.GetAllLevelDetailInfo,
            MsgID.HALL.GetUserSaveLevelData,

        ];
    }

    protected onReady() {
        if (!GlobalClass.Hall.isFirst) {
            // WebSocketMgr.getInstance().SendOneceMsg(MsgID.HALL.AchieventInfos, JSON.stringify({}));
            // WebSocketMgr.getInstance().SendOneceMsg(MsgID.HALL.GetSignInfos, JSON.stringify({}));
            // WebSocketMgr.getInstance().SendOneceMsg(MsgID.HALL.GetRankInfos, JSON.stringify({}));
            WebSocketMgr.getInstance().SendOneceMsg(MsgID.USER.GETUSERINFO, JSON.stringify({}));
            // WebSocketMgr.getInstance().SendOneceMsg(MsgID.USER.GetUserSave, JSON.stringify({}));
            // WebSocketMgr.getInstance().SendOneceMsg(MsgID.USER.GetAllLevelTypes, JSON.stringify({}));
            // WebSocketMgr.getInstance().SendOneceMsg(MsgID.HALL.GetRoleInfos, JSON.stringify({}));
            // WebSocketMgr.getInstance().SendOneceMsg(MsgID.HALL.GetSkillInfos, JSON.stringify({}));
            // WebSocketMgr.getInstance().SendOneceMsg(MsgID.FRIEND.ApplyList, JSON.stringify({}));
            // WebSocketMgr.getInstance().SendOneceMsg(MsgID.HALL.GetMailInfos, JSON.stringify({}));
            // WebSocketMgr.getInstance().SendOneceMsg(MsgID.HALL.GetFriendMailInfos, JSON.stringify({}));
            // WebSocketMgr.getInstance().SendOneceMsg(MsgID.HALL.GetPlayerAchieveInfos, JSON.stringify({}));
            // WebSocketMgr.getInstance().SendOneceMsg(MsgID.ACTIVITY.getGiftInfos, JSON.stringify({}));
            // WebSocketMgr.getInstance().SendOneceMsg(MsgID.ACTIVITY.GiftUsedInfo, JSON.stringify({}));
            // WebSocketMgr.getInstance().SendOneceMsg(MsgID.HALL.GetAllLevelDetailInfo, JSON.stringify({}));
            WebSocketMgr.getInstance().SendOneceMsg(MsgID.HALL.GetUserSaveLevelData, JSON.stringify({}));
            this.getAllLevelDetailInfo();
            KFControllerMgr.getCtl(PanelName.NetLoadingPanel).show();
            // WebSocketMgr.getInstance().SendOneceMsg(MsgID.GAME.EndlessWeekendAward, JSON.stringify({}));
            // WebSocketMgr.getInstance().SendOneceMsg(MsgID.PACKAGE.GetPackage, JSON.stringify({}));
            // this.playSpaceLight();
        }
        GlobalClass.Hall.isFirst = 1;
    }

    public getAllLevelDetailInfo() {
        let _self_ = this;
        var callBack = function (data) {
            let jsObj = JSON.parse(data);
            if (jsObj["info"]) {
                for (let i = 0; i < 3; i++) {
                    let stageTypeData = _self_.getStageDataById(i, jsObj["info"]);
                    GlobalClass.Hall.allLevelDetailInfo.push(stageTypeData);
                }
            }
            KFControllerMgr.getCtl(PanelName.NetLoadingPanel).hide();
        }

        SendMsgForWebService.setWSData({}, "configs/stages", callBack);
    }

    protected onShow() {//在界面上显示出来
        AnimationMgr.getInstance().loadRoleSkeleton(() => {
            AnimationMgr.getInstance().startTick();
            this.skeletonHaveLoaded();
        }, this);
        SoundMgr.Instance.playBGM(SoundMgr.mainbgm);

        // AnimationMgr.getInstance().loadSkeleton(() => {
        //     AnimationMgr.getInstance().startTick();
        //     this.initButtonAni();
        // }, this);

        // this.initView();
        // this.checkNickName();
        Guide.init();
        // Guide.step201To204(this.mPanel);
        // Guide.step103To105(this.mPanel);
        // egret.setTimeout(this.loadAni, this, 1000);
    }

    // private checkNickName() {
    //     let a = GlobalClass.CurrentUser;
    //     if (GlobalClass.CurrentUser.nick == null) {
    //         KFControllerMgr.getCtl(PanelName.ChangeNickNamePanel).show(true);
    //     } else {
    //         this.checkGuide();
    //     }
    // }

    private skeletonHaveLoaded() {
        if (GlobalClass.Game.isReloadGame) {//如果是重连游戏
            KFControllerMgr.showTips("断线重连中", 0);
            WebSocketMgr.getInstance().SendOneceMsg(MsgID.GAME.Reconnect, JSON.stringify({}));
        }
    }

    // private initView() {
    // this.mPanel.Btn_Friend.getChildAt(1).visible = false;
    // this.mPanel.Btn_Friend.getChildAt(2).visible = false;

    // this.mPanel.Btn_Achieve.getChildAt(1).visible = false;
    // this.mPanel.Btn_Achieve.getChildAt(2).visible = false;

    // this.mPanel.Btn_Mail.getChildAt(1).visible = false;
    // this.mPanel.Btn_Mail.getChildAt(2).visible = false;

    //     this.refreshView();
    // }

    // public checkGuide() {
    //     if (GlobalClass.CurrentUser.read_guide) {
    //         return;
    //     }
    //     let stepKey = GlobalClass.CurrentUser.player_id + "guideStep";
    //     //  egret.localStorage.setItem(stepKey,"0");
    //     let step = egret.localStorage.getItem(stepKey);
    //     if (step == null) {
    //         step = "0";
    //     }
    //     let stepValue = parseInt(step);
    //     if (stepValue <= GlobalClass.GameInfoForConfig.GuildStep) {//未进行新手引导
    //         KFControllerMgr.getCtl(PanelName.GuidePanel).show();
    //     }
    // }

    // private on106001_event(event: egret.Event): void {
    //     console.log("on106001_event");
    //     let msg: MSGBase = <MSGBase>event.data;
    //     let dataStr = msg.getDataStr();

    //     // dataStr = '{"info": {"0": [], "1": [], "2": [2]}, "code": 200, "command_id": null}'
    //     let jsObj = JSON.parse(dataStr);
    //     if (jsObj["code"] == 200) {
    //         GlobalClass.Hall.giftRecord = jsObj["info"];
    //     }
    // }
    /***获取用户信息 */
    private on100001_event(event: egret.Event): void {
        console.log("on100001_event");
        let msg: MSGBase = <MSGBase>event.data;
        let dataStr = msg.getDataStr();

        let jsObj = JSON.parse(dataStr);
        if (jsObj["code"] == 200) {
            GlobalClass.CurrentUser = new PlayerInfo().parseData(jsObj["info"]);
            // this.refreshView();
            NetEventMgr.getInstance().clientMsg(MsgID.CLIENT.RefreshUserInfo, "");

        }
    }

    /**获取所有关卡详情 */
    private on103001_event(event: egret.Event): void {
        console.log("on103001_event");
        let msg: MSGBase = <MSGBase>event.data;
        let dataStr = msg.getDataStr();
        let jsObj = JSON.parse(dataStr);
        if (jsObj["code"] == 200) {
            for (let i = 0; i < 3; i++) {
                let stageTypeData = this.getStageDataById(i, jsObj["info"]);
                GlobalClass.Hall.allLevelDetailInfo.push(stageTypeData);
            }
        }
    }

    public getStageDataById(stage_id: number, info: Array<Object>): Array<Object> {
        let stageData = info;
        if (!stageData) return null;
        let stageTypeData = [];
        for (let i = 0; i < stageData.length; i++) {
            let data = stageData[i];
            if (data["stage_type"] == stage_id) {
                data["sortId"] = stageTypeData.length;
                stageTypeData.push(data);
            }
        }
        return stageTypeData;
    }

    /**获取用户通关数据 */
    private on100020_event(event: egret.Event): void {
        console.log("on100020_event");
        let msg: MSGBase = <MSGBase>event.data;
        let dataStr = msg.getDataStr();
        let jsObj = JSON.parse(dataStr);
        if (jsObj["code"] == 200) {
            GlobalClass.Hall.userSave = jsObj["info"]
        }
    }


    private on100005_event(event: egret.Event): void {
        console.log("on100005_event");
        let msg: MSGBase = <MSGBase>event.data;
        let dataStr = msg.getDataStr();
        let jsObj = JSON.parse(dataStr);
        if (jsObj["code"] == 200) {
            if (jsObj["info"]["current_stage"] == null) {
                GlobalClass.Game.CurrentMission = 100;
            } else {
                GlobalClass.Game.CurrentMission = jsObj["info"]["current_stage"];
            }
            GlobalClass.Game.LevelInfos = jsObj["info"]["friend_stages"];
            KFSceneManager.getInstance().replaceScene(SceneName.Game);
        }
    }


    // private on100004_event(event: egret.Event): void {
    //     console.log("on100004_event");
    //     let msg: MSGBase = <MSGBase>event.data;
    //     let dataStr = msg.getDataStr();
    //     let jsObj = JSON.parse(dataStr);
    //     if (jsObj["code"] == 200) {
    //         GlobalClass.Hall.packageInfos = jsObj["info"]["backpack"];
    //         GlobalClass.Hall.OwnedNPCList = [];
    //         GlobalClass.Hall.packageInfos[1].forEach(element => {
    //             GlobalClass.Hall.OwnedNPCList.push(element.prop.role_number);
    //         });
    //         let a = GlobalClass.Hall.OwnedNPCList;
    //         console.log("afaf");
    //     }
    // }

    // private on105000_event(event: egret.Event): void {
    //     console.log("on105000_event");
    //     let msg: MSGBase = <MSGBase>event.data;
    //     let dataStr = msg.getDataStr();
    //     let jsObj = JSON.parse(dataStr);
    //     if (jsObj["code"] == 200) {
    //         jsObj["info"].forEach(element => {
    //             if (element.type == activityType.oneDollar) {
    //                 GlobalClass.Hall.oneDollarGiftConfig = element;
    //             } else if (element.type == activityType.firstCharge) {
    //                 GlobalClass.Hall.chargeGiftConfig.push(element);
    //             }
    //         });
    //     }
    // }

    // private achievementNum = 0;
    // private on100205_event(event: egret.Event): void {
    //     console.log("on100205_event");
    //     let msg: MSGBase = <MSGBase>event.data;
    //     let dataStr = msg.getDataStr();
    //     let jsObj = JSON.parse(dataStr);
    //     if (jsObj["code"] == 200) {
    //         this.achievementNum = 0;
    //         // jsObj["info"].forEach(element => {
    //         //     let rewarded_numbers = element["rewarded_numbers"].length;
    //         //     let reached_numbers = element["reached_numbers"].length;
    //         //     this.achievementNum = this.achievementNum + reached_numbers - rewarded_numbers;
    //         // });
    //         // this.mPanel.Btn_Achieve.getChildAt(2).text = this.achievementNum + "";
    //         // if (this.achievementNum > 0) {
    //         //     this.mPanel.Btn_Achieve.getChildAt(1).visible = true;
    //         //     this.mPanel.Btn_Achieve.getChildAt(2).visible = true;
    //         // } else {
    //         //     this.mPanel.Btn_Achieve.getChildAt(1).visible = false;
    //         //     this.mPanel.Btn_Achieve.getChildAt(2).visible = false;
    //         // }
    //     }
    // }

    // private systemMailNum = 0;
    // private friendMailNum = 0;
    // private on100700_event(event: egret.Event): void {
    //     console.log("on100700_event");
    //     let msg: MSGBase = <MSGBase>event.data;
    //     let dataStr = msg.getDataStr();

    //     let jsObj = JSON.parse(dataStr);
    //     this.systemMailNum = 0;
    //     if (jsObj["code"] == 200) {
    //         jsObj["info"].forEach(element => {
    //             if (!element.has_read) {
    //                 this.systemMailNum++;
    //             }
    //         });
    //         this.refreshMailNum();
    //     }
    // }

    // private on102012_event(event: egret.Event): void {
    //     console.log("on102012_event");
    //     let msg: MSGBase = <MSGBase>event.data;
    //     let dataStr = msg.getDataStr();

    //     let jsObj = JSON.parse(dataStr);
    //     this.friendMailNum = 0;
    //     if (jsObj["code"] == 200) {
    //         jsObj["info"].forEach(element => {
    //             if (!element.has_read) {
    //                 this.friendMailNum++;
    //             }
    //         });
    //         this.refreshMailNum();
    //     }
    // }

    // private refreshMailNum() {
    // let totalNum = this.systemMailNum + this.friendMailNum;
    // this.mPanel.Btn_Mail.getChildAt(2).text = "" + totalNum;
    // if (totalNum > 0) {
    //     this.mPanel.Btn_Mail.getChildAt(1).visible = true;
    //     this.mPanel.Btn_Mail.getChildAt(2).visible = true;
    // } else {
    //     this.mPanel.Btn_Mail.getChildAt(1).visible = false;
    //     this.mPanel.Btn_Mail.getChildAt(2).visible = false;
    // }
    // }

    // private on103000_event(event: egret.Event): void {
    //     console.log("on103000_event");
    //     let msg: MSGBase = <MSGBase>event.data;
    //     let dataStr = msg.getDataStr();

    //     let jsObj = JSON.parse(dataStr);
    //     if (jsObj["code"] == 200) {
    //         jsObj["info"].forEach(element => {
    //             GlobalClass.NPCInfos[element["role_number"]] = new NPCInfo().parseData(element);
    //         });
    //         jsObj["info"].forEach(element => {
    //             if (element.role_id == GlobalClass.CurrentUser.current_chara_skin) {
    //                 GlobalClass.Hall.currentRole = element;
    //             }
    //         });
    //         let a = GlobalClass.Hall.currentRole;
    //         console.log("");
    //     }
    // }

    // private on102007_event(event: egret.Event): void {
    //     console.log("on102007_event");
    //     let msg: MSGBase = <MSGBase>event.data;
    //     let dataStr = msg.getDataStr();

    //     let jsObj = JSON.parse(dataStr);
    //     if (jsObj["code"] == 200) {
    //         let len = jsObj["info"].length;
    //         // this.mPanel.Btn_Friend.getChildAt(2).text = "" + len;
    //         // if (len > 0) {
    //         //     this.mPanel.Btn_Friend.getChildAt(1).visible = true;
    //         //     this.mPanel.Btn_Friend.getChildAt(2).visible = true;
    //         // } else {
    //         //     this.mPanel.Btn_Friend.getChildAt(1).visible = false;
    //         //     this.mPanel.Btn_Friend.getChildAt(2).visible = false;
    //         // }
    //     }
    // }

    // private on104000_event(event: egret.Event): void {
    //     console.log("on104000_event");
    //     let msg: MSGBase = <MSGBase>event.data;
    //     let dataStr = msg.getDataStr();

    //     let jsObj = JSON.parse(dataStr);
    //     if (jsObj["code"] == 200) {
    //         jsObj["info"].forEach(element => {
    //             GlobalClass.SkillInfos[element["skill_number"]] = new SkillInfo().parseData(element);
    //             GlobalClass.SkillInfosByID[element["skill_id"]] = new SkillInfo().parseData(element);
    //         });
    //     }
    // }

    // private AniList = [];
    // private initButtonAni() {
    // let missionAni = AnimationMgr.getInstance().getSkeleton(skeletonType.chuangguanmoshi);
    // this.mPanel.addChild(missionAni.display);
    // missionAni.display.x = 375;
    // missionAni.display.y = 423;
    // missionAni.animation.play();
    // missionAni.display.touchEnabled = false;

    // let endlessAni = AnimationMgr.getInstance().getSkeleton(skeletonType.wujinmoshi);
    // this.mPanel.addChild(endlessAni.display);
    // endlessAni.display.x = 220;
    // endlessAni.display.y = 695;
    // endlessAni.animation.play();
    // endlessAni.display.touchEnabled = false;

    // let FightAni = AnimationMgr.getInstance().getSkeleton(skeletonType.duizhanmoshi);
    // this.mPanel.addChild(FightAni.display);
    // FightAni.display.x = 490;
    // FightAni.display.y = 688;
    // FightAni.animation.play();
    // FightAni.display.touchEnabled = false;

    // let ShopAni = AnimationMgr.getInstance().getSkeleton(skeletonType.shangdian);
    // this.mPanel.addChild(ShopAni.display);
    // ShopAni.display.x = 188;
    // ShopAni.display.y = 1000;
    // ShopAni.animation.play();
    // ShopAni.display.touchEnabled = false;

    // this.AniList.push(missionAni);
    // this.AniList.push(endlessAni);
    // this.AniList.push(FightAni);
    // this.AniList.push(ShopAni);
    // }

    // private refreshView() {
    // this.mPanel.FuelNum.text = GlobalClass.CurrentUser.diamond;
    // this.mPanel.heartNum.text = GlobalClass.CurrentUser.energy + "/" + this.maxSpirit;
    // this.mPanel.goldNum.text = GlobalClass.CurrentUser.coin;
    // this.mPanel.levelPercent.value = 100 * GlobalClass.CurrentUser.experience / GlobalClass.CurrentUser.next_level_experience;
    // this.mPanel.level.text = GlobalClass.CurrentUser.level;
    // let energy = this.maxSpirit - GlobalClass.CurrentUser.energy - 1;
    // this.leftSecond = GlobalClass.CurrentUser.get_energy_remaining_seconds + GlobalClass.CurrentUser.energy_remaining_interval * energy;
    // this.mPanel.titleName.source = "HallAtlas_json.img_hallLevel0" + (GlobalClass.CurrentUser.battle_level + 1);
    // this.refrestTime();

    // this.mPanel.moreButGroup.visible = false;
    // this.mPanel.moreButGroup.scaleX = 0;


    // }

    // private leftSecond;
    // private maxSpirit = 30;
    // private spiritTimer;
    // private refrestTime() {
    // if (this.leftSecond <= 0) {
    //     this.mPanel.leftTime.text = "00:00";
    //     this.mPanel.leftTime.visible = false;
    //     this.mPanel.timeGroup.visible = false;
    //     return;
    // } else {
    //     this.mPanel.timeGroup.visible = true;
    //     this.mPanel.leftTime.visible = true;
    //     this.mPanel.leftTime.text = this.formatSeconds(this.leftSecond);
    //     this.invoke(1, this.updateSecond, this);
    // }
    // }

    // private formatSeconds(value: number) {
    //     if (value < 0) return "00:00";

    //     var second = (value);// 秒
    //     var min = 0;// 分      
    //     if (second > 60) {
    //         min = ((second / 60) >> 0);
    //         second = second % 60;
    //     }
    //     var result = "" + (second);
    //     if (min > 0) {
    //         result = "" + (min) + ":" + result;
    //     }

    //     return result;
    // }


    // private updateSecond() {
    //     this.leftSecond--;
    //     if (this.leftSecond == 0) {
    //         WebSocketMgr.getInstance().SendOneceMsg(MsgID.USER.GETUSERINFO, JSON.stringify({}));
    //     } else {
    //         this.refrestTime();
    //     }
    // }

    // private playSpaceLight() {
    // egret.Tween.get(this.mPanel.spaceShipLight, { loop: true }).to({ alpha: 0.3 }, 800).to({ alpha: 1 }, 800);
    // let BGLight = this.mPanel.Btn_Gift.getChildAt(0);
    // egret.Tween.get(BGLight, { loop: true }).to({ rotation: BGLight.rotation + 360 }, 3500).to({ rotation: BGLight.rotation }, 0);
    // }

    // private on100003_event(event: egret.Event): void {
    //     console.log("on100003_event");
    //     let msg: MSGBase = <MSGBase>event.data;
    //     let dataStr = msg.getDataStr();

    //     let jsObj = JSON.parse(dataStr);
    //     if (jsObj["code"] == 200) {
    //         console.log(dataStr);
    //         let playerInfos = jsObj["info"]["player_info"];
    //         let stageInfo = jsObj["info"]["stage"];
    //         let settingInfo = jsObj["info"]["settings"];

    //         GlobalClass.Game.PlayerSettings = [];
    //         GlobalClass.Game.MultiPlayers = [];
    //         GlobalClass.CurrentStage = new StageInfo().parseData(jsObj["info"]["stage"]);
    //         playerInfos.forEach(element => {
    //             GlobalClass.Game.MultiPlayers.push(new PlayerInfo().parseData(element));
    //         });
    //         settingInfo.forEach(element => {
    //             GlobalClass.Game.PlayerSettings.push(new SettingInfo().parseData(element));
    //         });
    //         GlobalClass.Game.PlayerRandomSeeds = jsObj["info"]["random_seeds"];
    //         GlobalClass.Game.gameIsOver = jsObj["info"]["is_game_over"] == 0 ? false : true;
    //         if (jsObj["info"]["client_status_data"] != null) {
    //             GlobalClass.Game.gameResetData = jsObj["info"]["client_status_data"][1];//恢复数据
    //             GlobalClass.Game.localFrameNum = jsObj["info"]["client_status_data"][0] + 1;//恢复数据开始帧数
    //         }
    //         GlobalClass.Game.readyPlayers = jsObj["info"]["ready_players"];
    //         GlobalClass.Game.gameRoundResults = jsObj["info"]["win_record"];

    //         //移除当前面板
    //         GlobalClass.Game.isDebug = false;
    //         GlobalClass.Game.GameMode = 2;
    //         KFSceneManager.getInstance().replaceScene(SceneName.Fight);
    //     }
    // }

    // private on100014_event(event: egret.Event): void {
    //     console.log("on100014_event");
    //     let msg: MSGBase = <MSGBase>event.data;
    //     let dataStr = msg.getDataStr();

    //     let jsObj = JSON.parse(dataStr);
    //     if (jsObj["code"] == 200) {
    //         GlobalClass.Game.allLevelTypeInfos = jsObj["info"];
    //     }
    // }



    // private on100500_event(event: egret.Event): void {
    //     console.log("on100500_event");
    //     let msg: MSGBase = <MSGBase>event.data;
    //     let dataStr = msg.getDataStr();

    //     let jsObj = JSON.parse(dataStr);
    //     if (jsObj["code"] == 200) {
    //         GlobalClass.SignInfos = jsObj["info"]["checkin_config"];
    //         GlobalClass.Hall.SignDay = jsObj["info"]["checkin_record"]["can_checkin_day"];
    //         GlobalClass.Hall.TodayHaveSign = jsObj["info"]["checkin_record"]["today_is_checkin"];
    //     }
    // }

    // private on100600_event(event: egret.Event): void {
    //     console.log("on100600_event");
    //     let msg: MSGBase = <MSGBase>event.data;
    //     let dataStr = msg.getDataStr();
    //     let jsObj = JSON.parse(dataStr);
    //     if (jsObj["code"] == 200) {
    //         GlobalClass.Hall.RankInfos = jsObj["info"]["all_ranking"];
    //         let a = GlobalClass.Hall.RankInfos;
    //         GlobalClass.Hall.SelfRankInfos = jsObj["info"]["player_ranking"];
    //     }
    // }

    // //获取周末赛奖励
    // private on100904_event(event: egret.Event): void {
    //     console.log("on100904_event");
    //     let msg: MSGBase = <MSGBase>event.data;
    //     let dataStr = msg.getDataStr();
    //     let jsObj = JSON.parse(dataStr);
    //     if (jsObj["code"] != 200) {

    //         GlobalClass.Hall.weekendGiftConfig = jsObj["info"];
    //         console.log("");
    //     }
    // }

    // private on100204_event(event: egret.Event): void {
    //     console.log("on100204_event");
    //     let msg: MSGBase = <MSGBase>event.data;
    //     let dataStr = msg.getDataStr();
    //     let jsObj = JSON.parse(dataStr);
    //     if (jsObj["code"] == 200) {
    //         GlobalClass.AchieveInfos = jsObj["info"];
    //     }
    // }

    // protected setOnClickListener() {
    //     this.mPanel.avatar.addEventListener(egret.TouchEvent.TOUCH_END, this.avatarClick, this);
    // }

    // protected removeOnClickListener() {
    //     this.mPanel.avatar.removeEventListener(egret.TouchEvent.TOUCH_END, this.avatarClick, this);
    // }

    private Btn_ddgClick() {
        this.toGame(0);
    }

    private Btn_sdxClick() {
        this.toGame(1);
    }

    private Btn_fjgClick() {
        this.toGame(2);
    }

    private toGame(stageType: number) {
        GlobalClass.CurrentStage.StageType = stageType;
        GlobalClass.Game.GameMode = 1;
        KFSceneManager.getInstance().replaceScene(SceneName.Game);
        // let js = {};
        // WebSocketMgr.getInstance().SendOneceMsg(MsgID.GAME.GetCurrentLevelInfos, JSON.stringify(js));

    }


    // private Btn_EndlessClick() {
    //     GlobalClass.Game.GameMode = 3;
    //     KFSceneManager.getInstance().replaceScene(SceneName.Game);
    //     // KFControllerMgr.showTips("敬请期待!");
    // }
    // private Btn_MultiClick() {
    //     GlobalClass.Game.GameMode = 2;
    //     KFSceneManager.getInstance().replaceScene(SceneName.Game);
    //     // KFControllerMgr.showTips("敬请期待!");
    // }
    // private Btn_MissionClick() {
    //     GlobalClass.Game.GameMode = 1;
    //     let js = {};
    //     WebSocketMgr.getInstance().SendOneceMsg(MsgID.GAME.GetCurrentLevelInfos, JSON.stringify(js));
    // }



    private startLoad(): void {
        // // 创建 URLLoader 对象
        // var loader:egret.URLLoader = new egret.URLLoader();
        // //设置加载方式为纹理
        // loader.dataFormat = egret.URLLoaderDataFormat.TEXTURE;
        // //添加加载完成侦听
        // loader.addEventListener(egret.Event.COMPLETE, this.onLoadComplete, this);
        // //添加加载失败侦听
        // loader.addEventListener(egret.IOErrorEvent.IO_ERROR, this.onLoadError, this);
        // var url:string = "http://ohcoder.com/assets/images/angle_two_boxes.jpg";
        // var request:egret.URLRequest = new egret.URLRequest(url);
        // // request.requestHeaders = [new egret.URLRequestHeader("Content-Type", "application/x-www-form-urlencoded;charset=UTF-8")];
        // //开始加载
        // loader.load(request);

        // RES.getResByUrl("https://ss0.bdstatic.com/5aV1bjqh_Q23odCf/static/superman/img/logo/bd_logo1_31bdc765.png",(data)=>{
        //     this.mPanel.avatar.source = data;
        // },this,RES.ResourceItem.TYPE_IMAGE);
    }

    private onLoadComplete(event: egret.Event): void {
        // console.log("onLoadComplete");
        // var loader: egret.URLLoader = <egret.URLLoader>event.target;
        // //获取加载到的纹理对象
        // var texture: egret.Texture = <egret.Texture>loader.data;
        // this.mPanel.avatar = texture;
        // console.log(texture);
    }

    private onLoadError(event: egret.Event): void {
        console.log("onLoadError" + event.data);
    }

    protected destroy() {
        // AnimationMgr.getInstance().unloadSkeleton();
        // AnimationMgr.getInstance().stopTick();
        // for (let i = 0; i < this.AniList.length; i++) {
        //     let ani = this.AniList.shift();
        //     AnimationMgr.getInstance().clenSkeleton(ani);
        // }
        // this.AniList = [];

        egret.Tween.removeAllTweens();
        super.destroy();
    }
}