/**
 *
 * @author 
 *
 */
class SignPenelController extends KFController{ 
    
	
	protected init(){
    	super.init();
         this.ListenObjList = [ {event:egret.TouchEvent.TOUCH_END,items:{
                                                                                "Btn_Close":"",
                                                                                "Btn_Get":""
                                                    },},
                            ];//添加btn名为key，值为冷却时间，然后在类中添加btn名+Click的函数，即可自动注册btn事件 ,如 Btn_MyBankClick为函数名
        this.EventsList = [
            MsgID.HALL.PlayerSign,
            ];
	}
	
    protected onReady() {
        
    }

    protected onShow(){//在界面上显示出来
        this.initView();
    }
	
    private initView(){
        for(let i=0;i<7;i++){
            let item = this.mPanel.SingItems.getChildAt(i);
            let a = GlobalClass.SignInfos;
            let day = i+1;
            let infos = GlobalClass.SignInfos[day];
            let signIcon;
            if(i<6){//前六天只会送一种商品
                item.getChildAt(0).source = this.getItemImg(infos[0])
                item.getChildAt(2).text = infos[0]["quantity"]+"";
                signIcon = item.getChildAt(1);
            }else{//最后一天会送多种商品
                 var collection = new eui.ArrayCollection();
                collection.source = infos;
                this.mPanel.rewardList.dataProvider = collection;
                signIcon = item.getChildAt(1);
            }
            if(GlobalClass.Hall.SignDay==day){
                if(GlobalClass.Hall.TodayHaveSign==0){
                    signIcon.visible = false;
                    this.enableBut(this.mPanel.Btn_Get);
                }else{
                    signIcon.visible = true;
                    this.disableBut(this.mPanel.Btn_Get);
                }
                this.mPanel.currentDay.y = item.y;
                this.mPanel.currentDay.x = item.x-25;
            }else if(day>GlobalClass.Hall.SignDay){
                signIcon.visible = false;
                 item.touchEnable = false;
            }else{
                signIcon.visible = true;
                item.touchEnable = false;
            }
            
        }
    }

    private Btn_GetClick(){
          if(GlobalClass.Hall.TodayHaveSign){
            return;
        }
        let js = {day:GlobalClass.Hall.SignDay};
        WebSocketMgr.getInstance().SendOneceMsg(MsgID.HALL.PlayerSign,JSON.stringify(js));
    }

    private getItemImg(data):string{
        let imgSource = "";
        switch(data.category){
            case goodsType.diamond:
                imgSource = "Shop_json.Img_fuel01";
            break;
            case goodsType.brick:

            break;
            case goodsType.exp:
            break;
            case goodsType.props:
                imgSource = "CommonAtlas_json.Img_item"+data["props"]["prop_number"];
            break;
            case goodsType.role:
            break;
            case goodsType.spirit:
                imgSource = "CommonAtlas_json.Img_item303";
            break;
        }
        return imgSource;
    }

    private Btn_CloseClick(){
        this.mPanel.hide();
    }

    private on100501_event(event: egret.Event): void {
        console.log("on100501_event");
        let msg:MSGBase = <MSGBase>event.data;
        let dataStr = msg.getDataStr();
        
        let jsObj = JSON.parse(dataStr);
        if(jsObj["code"]==200){
            WebSocketMgr.getInstance().SendOneceMsg(MsgID.USER.GETUSERINFO,JSON.stringify({}));
            KFControllerMgr.showTips("签到成功");
            this.getRewardItems();
            GlobalClass.Hall.TodayHaveSign = 1;
            this.initView();
        }
    }

    private getRewardItems(){
        let arr = [];
        let info = GlobalClass.SignInfos[GlobalClass.Hall.SignDay];
        info.forEach(element => {
            let itemB = {
                quantity:element["quantity"],
                propid:element["prop_id"],
                category:element["category"],
            };
            arr.push(itemB);
        });
        
        GlobalClass.Hall.RewardList = arr;
        
    }
}