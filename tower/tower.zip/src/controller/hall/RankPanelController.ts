/**
 *
 * @author 
 *
 */
class RankPanelController extends KFController{ 
    
	
	protected init(){
    	super.init();
         this.ListenObjList = [ {event:egret.TouchEvent.TOUCH_END,items:{
                                                                    "Btn_Close":"",
                                                                    "Toggle_mission":"",
                                                                    "Toggle_multi":"",
                                                                    "Toggle_charm":"",
                                                    },},
                            
                            ];//添加btn名为key，值为冷却时间，然后在类中添加btn名+Click的函数，即可自动注册btn事件 ,如 Btn_MyBankClick为函数名
        this.EventsList = [
            ];
        
	}
	
    protected onReady() {

    }

    protected onShow(){//在界面上显示出来
        
        this.initView();
        this.Toggle_missionClick();
    }
    

    private Btn_CloseClick(){
        this.mPanel.hide();
    }

    private resetView(){
        this.mPanel.missionRank.visible = false;
        this.mPanel.multiRank.visible = false;
        this.mPanel.charmRank.visible = false;
       this.resetSelfView();
    }   

    private resetSelfView(){
         this.mPanel.selfMultiInfo.visible = false;
        this.mPanel.selfMissionInfo.visible = false;
        this.mPanel.selfCharmInfo.visible = false;
        this.mPanel.selfEmptyInfo.visible = false;
    }

    private Toggle_charmClick(){
        this.resetView();
        this.mPanel.charmRank.visible = true;
        this.mPanel.selfCharmInfo.visible = true;
        this.mPanel.ScoreLabel.text = "鲜花数";
        let selfInfo = GlobalClass.Hall.SelfRankInfos[""+rankType.flower];
        if(selfInfo==null){
            this.resetSelfView();
            this.mPanel.selfEmptyInfo.visible = true;
        }else{
            this.resetSelfView();
            this.mPanel.selfCharmInfo.visible = true;
        }
    }

    private Toggle_missionClick(){
        this.resetView();
        this.mPanel.missionRank.visible = true;
        this.mPanel.selfMissionInfo.visible = true;
        this.mPanel.ScoreLabel.text = "通关数";

        let selfInfo = GlobalClass.Hall.SelfRankInfos[""+rankType.missionRank];
        if(selfInfo==null){
            this.resetSelfView();
            this.mPanel.selfEmptyInfo.visible = true;
        }else{
            this.resetSelfView();
            this.mPanel.selfMissionInfo.visible = true;
        }
    }

    private Toggle_multiClick(){
        this.resetView();
        this.mPanel.multiRank.visible = true;
        this.mPanel.selfMultiInfo.visible = true;
        this.mPanel.ScoreLabel.text = "称号";

        let selfInfo = GlobalClass.Hall.SelfRankInfos[""+rankType.multiRank];
        if(selfInfo==null){
            this.resetSelfView();
            this.mPanel.selfEmptyInfo.visible = true;
        }else{
            this.resetSelfView();
            this.mPanel.selfMultiInfo.visible = true;
        }
    }

    private initView(){
        var collection = new eui.ArrayCollection();
        collection.source = GlobalClass.Hall.RankInfos[""+rankType.missionRank];
        this.mPanel.missionRankList.dataProvider = collection;

        var collection2 = new eui.ArrayCollection();
        collection2.source = GlobalClass.Hall.RankInfos[""+rankType.multiRank];
        this.mPanel.multiRankList.dataProvider = collection2;

        var collection3 = new eui.ArrayCollection();
        collection3.source = GlobalClass.Hall.RankInfos[""+rankType.flower];
        this.mPanel.charmRankList.dataProvider = collection3;
        
        let selfMissionInfo = GlobalClass.Hall.SelfRankInfos[""+rankType.missionRank];
        let selfMultiInfo = GlobalClass.Hall.SelfRankInfos[""+rankType.multiRank];
        let selfCharmInfo = GlobalClass.Hall.SelfRankInfos[""+rankType.flower];

        if(selfMissionInfo!=null){
            this.mPanel.selfMissionRank.text = selfMissionInfo["rank"]+"";
            this.mPanel.selfMissionScore.text = selfMissionInfo["rank_score"]+"";
        }

        if(selfMultiInfo!=null){
            this.mPanel.selfMultiRankNum.text = selfMultiInfo["rank"]+"";
            this.mPanel.selfMultiScore.text = selfMultiInfo["rank_score"]+"";
            this.mPanel.selfMultiTitle.source = RES.getRes("Game_json.img_level0"+selfMultiInfo["battle_level"]);
        }

        if(selfCharmInfo!=null){
            this.mPanel.selfCharmName.text = GlobalClass.CurrentUser.nick;
            this.mPanel.selfCharmRankNum.text = selfMultiInfo["rank"]+"";
            this.mPanel.selfCharmScore.text = "x"+selfMultiInfo["rank_score"];
        }
       
    }
}