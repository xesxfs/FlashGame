/**
 *
 * @author 
 *
 */
class PersonalPanelController extends KFController{
	protected init(){
    	super.init();
         this.ListenObjList = [ {event:egret.TouchEvent.TOUCH_END,items:{
                                                                        "Btn_Close":"",
                                                                        "Btn_Exit":"",
                                                                        "Btn_Change":"",
                                                                        "Btn_Switch":"",
                                                    },},
                            ];//添加btn名为key，值为冷却时间，然后在类中添加btn名+Click的函数，即可自动注册btn事件 ,如 Btn_MyBankClick为函数名
        this.EventsList = [
                MsgID.CLIENT.RefreshUserInfo
            ];
	}
	
    protected onReady() {

    }

    protected onShow(){//在界面上显示出来
        this.mPanel.level.text = GlobalClass.CurrentUser.level;
        this.mPanel.nickName.text = GlobalClass.CurrentUser.nick;
        this.mPanel.playerID.text = GlobalClass.CurrentUser.player_id;
        this.mPanel.phoneNum.text = GlobalClass.CurrentUser.mobile;
        this.mPanel.titleName.source = "HallAtlas_json.img_hallLevel0"+(GlobalClass.CurrentUser.battle_level+1);
    }

    //刷新个人信息
    private on1005_event(event: egret.Event): void {
        console.log("on1005_event");
        this.mPanel.nickName.text = GlobalClass.CurrentUser.nick;
    }
    
    private Btn_ExitClick(){
         KFControllerMgr.showTips("断开连接...",1,0,()=>{
             WebSocketMgr.getInstance().closeSocket();
        });
    }

    private Btn_ChangeClick(){

    }
    
    private Btn_SwitchClick(){
        if(DeviceUtils.IsWeb){
            KFControllerMgr.showTips("断开连接...",1,0,()=>{
                WebSocketMgr.getInstance().closeSocket();
            });
        }else{
            // PluginEvent.executePluginsEvents(SendPlugins.CloseAccount,"");
        }
        
    }

    private Btn_CloseClick(){
        this.mPanel.hide();
    }
}