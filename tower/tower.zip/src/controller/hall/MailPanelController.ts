/**
 *
 * @author 
 *
 */
class MailPanelController extends KFController{ 
    
	

    private systemMailCount = 0;
    private friendMailCount = 0;
	protected init(){
    	super.init();
         this.ListenObjList = [ {event:egret.TouchEvent.TOUCH_END,items:{
                                                            "Btn_Close":"",
                                                            "Toggle_system":"",
                                                            "Toggle_friend":"",
                                                            "Btn_DeleteAll":"",
                                                            "Btn_FriendGetAll":"",
                                                            "Btn_GetAll":"",
                                                    },},
                            
                            ];//添加btn名为key，值为冷却时间，然后在类中添加btn名+Click的函数，即可自动注册btn事件 ,如 Btn_MyBankClick为函数名
        this.EventsList = [
                MsgID.HALL.GetMailItems,
                MsgID.HALL.DelectMail,
                MsgID.HALL.SetMailReaded,
                MsgID.HALL.GetMailInfos,
                MsgID.HALL.DeleteAllMail,
                MsgID.HALL.GetAllMail,
                MsgID.HALL.GetFriendMailInfos,
                MsgID.HALL.GetFriendMail,
                MsgID.CLIENT.MailHaveRead,
                MsgID.HALL.GetAllFriendMail,
            ];
        
	}

    private Toggle_systemClick(){
        this.refreshSystemView();
        this.mPanel.SystemGroup.visible = true;
        this.mPanel.friendGroup.visible = false;
    }
    
    private Toggle_friendClick(){
        this.mPanel.SystemGroup.visible = false;
        this.mPanel.friendGroup.visible = true;
    }

    private Btn_DeleteAllClick(){
        if(this.systemMailCount>0){
            WebSocketMgr.getInstance().SendOneceMsg(MsgID.HALL.DeleteAllMail,JSON.stringify({}));
        }
    }

    private Btn_FriendGetAllClick(){
        WebSocketMgr.getInstance().SendOneceMsg(MsgID.HALL.GetAllFriendMail,JSON.stringify({}));
    }

    private Btn_GetAllClick(){
        if(this.systemMailCount>0&&this.haveAttachMail){
            WebSocketMgr.getInstance().SendOneceMsg(MsgID.HALL.GetAllMail,JSON.stringify({}));
        }
    }

    protected onReady() {
       this.ReadedMailList = [];
       this.mPanel.FriendMailList.dataProvider = null;
       this.mPanel.SystemMailList.dataProvider = null;
    }

    protected destroy(){
        this.ReadedMailList = null;
        super.destroy();
    }

     private refreshView(){
        this.refreshSystemView();
        this.refreshFriendView();
     }

     private haveAttachMail = false;
    private refreshSystemView(){
        let arr = [];
        this.haveAttachMail = false;
        // let a = GlobalClass.Hall.MailInfos;
        GlobalClass.Hall.MailInfos.forEach(element => {
            if(element.id in this.ReadedMailList){
                element.haveOpen = true;
            }
            arr.push(element);
            if(element["attaches"].length>0){
                this.haveAttachMail = true;
            }
        });
        this.systemMailCount = arr.length;
        var collection = new eui.ArrayCollection();
        collection.source = arr;
        this.mPanel.SystemMailList.dataProvider = collection;
        // if(this.haveAttachMail){
        //     this.enableBut(this.mPanel.Btn_GetAll);
        // }else{
        //     this.disableBut(this.mPanel.Btn_GetAll);
        // }
    }

    private refreshFriendView(){
        let arr = [];
        GlobalClass.Hall.FriendMailInfos.forEach(element => {
            arr.push(element);
        });
        this.friendMailCount = arr.length;
        var collection = new eui.ArrayCollection();
        collection.source = arr;
        this.mPanel.FriendMailList.dataProvider = collection;
    }

    private ReadedMailList = [];
    private on1008_event(event: egret.Event): void {
        console.log("on1008_event");
        let mailID = <string>event.data;
        this.ReadedMailList.push(mailID);
    }

     private on100700_event(event: egret.Event): void {
        console.log("on100700_event");
        let msg:MSGBase = <MSGBase>event.data;
        let dataStr = msg.getDataStr();
        
        let jsObj = JSON.parse(dataStr);
        if(jsObj["code"]==200){
            GlobalClass.Hall.MailInfos = jsObj["info"];
           this.refreshSystemView();
        }else{
            KFControllerMgr.showToast(jsObj["info"],this.mPanel);
        }
    }

    private on102012_event(event: egret.Event): void {
        console.log("on102012_event");
        let msg:MSGBase = <MSGBase>event.data;
        let dataStr = msg.getDataStr();
        
        let jsObj = JSON.parse(dataStr);
        if(jsObj["code"]==200){
            GlobalClass.Hall.FriendMailInfos = jsObj["info"];
            this.refreshFriendView();
        }else{
            KFControllerMgr.showToast(jsObj["info"],this.mPanel);
        }
    }

    private on102013_event(event: egret.Event): void {
        console.log("on102013_event");
        let msg:MSGBase = <MSGBase>event.data;
        let dataStr = msg.getDataStr();
        
        let jsObj = JSON.parse(dataStr);
        if(jsObj["code"]==200){
            KFControllerMgr.showToast("领取成功！",this.mPanel);
            WebSocketMgr.getInstance().SendOneceMsg(MsgID.USER.GETUSERINFO,JSON.stringify({}));
            WebSocketMgr.getInstance().SendOneceMsg(MsgID.HALL.GetFriendMailInfos,JSON.stringify({}));
        }else{
            KFControllerMgr.showToast(jsObj["info"],this.mPanel);
        }
    }

    private on102014_event(event: egret.Event): void {
        console.log("on102014_event");
        let msg:MSGBase = <MSGBase>event.data;
        let dataStr = msg.getDataStr();
        
        let jsObj = JSON.parse(dataStr);
        if(jsObj["code"]==200){
            KFControllerMgr.showToast("领取成功！",this.mPanel);
            WebSocketMgr.getInstance().SendOneceMsg(MsgID.USER.GETUSERINFO,JSON.stringify({}));
            WebSocketMgr.getInstance().SendOneceMsg(MsgID.HALL.GetFriendMailInfos,JSON.stringify({}));
        }else{
            KFControllerMgr.showToast(jsObj["info"],this.mPanel);
        }
    }

    private on100701_event(event: egret.Event): void {
        console.log("on100701_event");
        let msg:MSGBase = <MSGBase>event.data;
        let dataStr = msg.getDataStr();
        
        let jsObj = JSON.parse(dataStr);
        if(jsObj["code"]==200){
            // WebSocketMgr.getInstance().SendOneceMsg(MsgID.HALL.GetMailInfos,JSON.stringify({}));
        }else{
            // KFControllerMgr.showToast(jsObj["info"],this.mPanel);
        }
    }

    private on100702_event(event: egret.Event): void {
        console.log("on100702_event");
        let msg:MSGBase = <MSGBase>event.data;
        let dataStr = msg.getDataStr();
        
        let jsObj = JSON.parse(dataStr);
        if(jsObj["code"]==200){
            WebSocketMgr.getInstance().SendOneceMsg(MsgID.HALL.GetMailInfos,JSON.stringify({}));
            KFControllerMgr.showToast("领取成功",this.mPanel);
            WebSocketMgr.getInstance().SendOneceMsg(MsgID.USER.GETUSERINFO,JSON.stringify({}));
            KFControllerMgr.getCtl(PanelName.RewardListPanel).show();
        }else{
            KFControllerMgr.showToast(jsObj["info"],this.mPanel);
        }
    }

    private on100703_event(event: egret.Event): void {
        console.log("on100703_event");
        let msg:MSGBase = <MSGBase>event.data;
        let dataStr = msg.getDataStr();
        
        let jsObj = JSON.parse(dataStr);
        if(jsObj["code"]==200){
           WebSocketMgr.getInstance().SendOneceMsg(MsgID.HALL.GetMailInfos,JSON.stringify({}));
            KFControllerMgr.showToast("邮件已删除",this.mPanel);
        }else{
            KFControllerMgr.showToast(jsObj["info"],this.mPanel);
        }
    }

    private on100704_event(event: egret.Event): void {
        console.log("on100704_event");
        let msg:MSGBase = <MSGBase>event.data;
        let dataStr = msg.getDataStr();
        
        let jsObj = JSON.parse(dataStr);
        if(jsObj["code"]==200){
           WebSocketMgr.getInstance().SendOneceMsg(MsgID.HALL.GetMailInfos,JSON.stringify({}));
            KFControllerMgr.showToast("邮件已删除",this.mPanel);
        }else{
            KFControllerMgr.showToast(jsObj["info"],this.mPanel);
        }
    }

    private on100705_event(event: egret.Event): void {
        console.log("on100705_event");
        let msg:MSGBase = <MSGBase>event.data;
        let dataStr = msg.getDataStr();
        
        let jsObj = JSON.parse(dataStr);
        if(jsObj["code"]==200){
           WebSocketMgr.getInstance().SendOneceMsg(MsgID.HALL.GetMailInfos,JSON.stringify({}));
            KFControllerMgr.showToast("领取成功",this.mPanel);
            WebSocketMgr.getInstance().SendOneceMsg(MsgID.USER.GETUSERINFO,JSON.stringify({}));
        }else{
            KFControllerMgr.showToast(jsObj["info"],this.mPanel);
        }
    }

    protected onShow(){//在界面上显示出来
        WebSocketMgr.getInstance().SendOneceMsg(MsgID.HALL.GetMailInfos,JSON.stringify({}));
        WebSocketMgr.getInstance().SendOneceMsg(MsgID.HALL.GetFriendMailInfos,JSON.stringify({}));
        this.initView();
        this.Toggle_systemClick();
    }

    private initView(){
    }

    private Btn_CloseClick(){
        this.mPanel.hide();
    }
}