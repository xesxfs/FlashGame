/**
 *
 * @author 
 *
 */
class NewAchievementPanelController extends KFController{ 
    
	
	protected init(){
    	super.init();
         this.ListenObjList = [ {event:egret.TouchEvent.TOUCH_END,items:{
                                                                    "Btn_Sure":"",
                                                    },},
                            
                            ];//添加btn名为key，值为冷却时间，然后在类中添加btn名+Click的函数，即可自动注册btn事件 ,如 Btn_MyBankClick为函数名
        this.EventsList = [
            ];
        
	}
	
    protected onReady() {

    }

    private currentDatas;
    private index = 0;
    private isShowNewType = true;
    private isShowing = false;
    protected onShow(){//在界面上显示出来
        let a = GlobalClass.Hall.newAchievement;
        if(this.isShowing){
            return;
        }else{
            this.isShowing = true;
        }
        
        for(let i=0;i<3;i++){
            this.mPanel.starts.getChildAt(i).visible = false;
        }
        if(this.isShowNewType){
            this.isShowNewType = false;
            this.currentDatas = GlobalClass.Hall.newAchievement.shift();
        }
        this.showInfo();
    }

    private showInfo(){
        let data = this.currentDatas[this.index];
        this.mPanel.achieveMentName.text = data["name"];
        let startNum = data["level"];
        for(let i=0;i<startNum;i++){
            this.mPanel.starts.getChildAt(i).visible = true;
        }
        this.index++;
    }
	
    private Btn_SureClick(){
        this.isShowing = false;
        this.mPanel.hide();
        if(this.index==this.currentDatas.length){//当前类型 已经展示完
             this.index = 0;
            this.isShowNewType = true;
            if(GlobalClass.Hall.newAchievement.length>0){
                this.show();
            }else{
               
                
            }
        }else{
            this.show();
        }
        
    }
}