/**
 *
 * @author 
 *
 */
class SettingPanelController extends KFController{ 
    
	
	protected init(){
    	super.init();
         this.ListenObjList = [ 
                                {event:egret.TouchEvent.TOUCH_END,items:{
                                                                            "Btn_Close":"",
                                                    },},
                            
                            ];//添加btn名为key，值为冷却时间，然后在类中添加btn名+Click的函数，即可自动注册btn事件 ,如 Btn_MyBankClick为函数名
        this.EventsList = [
            ];
        
	}
	
    protected onReady() {

    }

    protected onShow(){//在界面上显示出来
        this.mPanel.sound.SetChangeCB(this.onSoundChange,this);
        this.mPanel.effect.SetChangeCB(this.onEffectChange,this);

        this.mPanel.sound.pValue = SoundMgr.Instance.bgmVolume;
        this.mPanel.effect.pValue = SoundMgr.Instance.effectVolume;
    }

    private onSoundChange(percent:any){
        SoundMgr.Instance.bgmVolume = percent;
    }

    private onEffectChange(percent:any){
        SoundMgr.Instance.effectVolume = percent;
    }

    private Btn_CloseClick(){
        this.mPanel.hide();
    }
}