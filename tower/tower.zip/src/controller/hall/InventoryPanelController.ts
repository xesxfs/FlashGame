/**
 *
 * @author 
 *
 */
class InventoryPanelController extends KFController {

    private levelDatas;
    private currrentType = 0;
    private lastRefreshDataTime = 0;
    protected init() {
        super.init();
        this.ListenObjList = [{
            event: egret.TouchEvent.TOUCH_END, items: {
                "Btn_Use": "",
                "Btn_Sell": "",
                "Btn_Close": "",
                // "Btn_Buy": "",
                "Btn_LevelUp": "",
                "Btn_Close_buyRole": "",
                "Btn_Buy_buyRole": "",
                "Btn_Close_LevelUp": "",
                "Btn_Buy_LevelUp": "",
                "Btn_Info": "",
                "Toggle_bag1": "",
                "Toggle_bag2": "",
                "Toggle_bag3": "",
                "Toggle_bag4": "",
            },
        },
        ];//添加btn名为key，值为冷却时间，然后在类中添加btn名+Click的函数，即可自动注册btn事件 ,如 Btn_MyBankClick为函数名
        this.EventsList = [
            MsgID.PACKAGE.GetPackage,
            MsgID.PACKAGE.UseRoleCard,
            MsgID.PACKAGE.SellGoods,
            MsgID.PACKAGE.NPCLevelup,
            MsgID.HALL.ChangeNPC,
        ];
    }

    private on100004_event(event: egret.Event): void {
        console.log("on100004_event");
        let msg: MSGBase = <MSGBase>event.data;
        let dataStr = msg.getDataStr();
        let jsObj = JSON.parse(dataStr);
        if (jsObj["code"] == 200) {
            GlobalClass.Hall.packageInfos = jsObj["info"]["backpack"];
            this.lastRefreshDataTime = egret.getTimer();
            switch (this.currrentType) {
                case 0:
                    this.Toggle_bag1Click();
                    break;
                case 1:
                    this.Toggle_bag2Click();
                    break;
                case 2:
                    this.Toggle_bag3Click();
                    break;
                case 3:
                    this.Toggle_bag4Click();
                    break;
            }
        }
    }

    private on100010_event(event: egret.Event): void {
        console.log("on100010_event");
        let msg: MSGBase = <MSGBase>event.data;
        let dataStr = msg.getDataStr();
        let jsObj = JSON.parse(dataStr);
        if (jsObj["code"] == 200) {
            KFControllerMgr.showToast("使用成功", this.mPanel);
            this.refreshData();
        } else {
            KFControllerMgr.showToast(jsObj["info"], this.mPanel);
        }

    }

    private on100017_event(event: egret.Event): void {
        console.log("on100017_event");
        let msg: MSGBase = <MSGBase>event.data;
        let dataStr = msg.getDataStr();
        let jsObj = JSON.parse(dataStr);
        if (jsObj["code"] == 200) {
            KFControllerMgr.showToast("使用成功", this.mPanel);
            this.refreshData();
            WebSocketMgr.getInstance().SendOneceMsg(MsgID.USER.GETUSERINFO, JSON.stringify({}));
        } else {
            KFControllerMgr.showToast(jsObj["info"], this.mPanel);
        }

    }

    private on100016_event(event: egret.Event): void {
        console.log("on100016_event");
        let msg: MSGBase = <MSGBase>event.data;
        let dataStr = msg.getDataStr();
        let jsObj = JSON.parse(dataStr);
        if (jsObj["code"] == 200) {
            KFControllerMgr.showToast("出售成功", this.mPanel);
            this.refreshData();
        }
    }

    private on100018_event(event: egret.Event): void {
        console.log("on100018_event");
        let msg: MSGBase = <MSGBase>event.data;
        let dataStr = msg.getDataStr();
        let jsObj = JSON.parse(dataStr);
        if (jsObj["code"] == 200) {
            KFControllerMgr.showToast("升级成功", this.mPanel);
            this.refreshData();
            this.mPanel.Panel_levelUpRole.visible = false;
        } else {
            KFControllerMgr.showToast(jsObj["info"], this.mPanel);
        }
    }

    private Btn_Close_buyRoleClick() {
        this.mPanel.Panel_buyRole.visible = false;
    }

    private Btn_Buy_buyRoleClick() {
        KFControllerMgr.getCtl(PanelName.ShopPanel).show(goodsType.role);
    }

    private Btn_Close_LevelUpClick() {
        this.mPanel.Panel_levelUpRole.visible = false;
    }

    private Btn_Buy_LevelUpClick() {
        let a = this.lastData;
        let js = {
            role_id: this.lastData.prop.role_id
        }
        WebSocketMgr.getInstance().SendOneceMsg(MsgID.PACKAGE.NPCLevelup, JSON.stringify(js));
    }

    private Toggle_bag1Click() {
        this.mPanel.Toggle_bag1.selected = true;
        this.currrentType = packageType.prop;
        this.refreshList(GlobalClass.Hall.packageInfos[this.currrentType]);
    }

    private Toggle_bag2Click() {
        this.mPanel.Toggle_bag2.selected = true;
        this.currrentType = packageType.role;
        this.refreshList(GlobalClass.Hall.packageInfos[this.currrentType]);
    }

    private Toggle_bag3Click() {
        this.mPanel.Toggle_bag3.selected = true;
        this.currrentType = packageType.skin;
        this.refreshList(GlobalClass.Hall.packageInfos[this.currrentType]);
    }

    private Toggle_bag4Click() {
        this.mPanel.Toggle_bag4.selected = true;
        this.currrentType = packageType.card;
        this.refreshList(GlobalClass.Hall.packageInfos[this.currrentType]);
    }

    private Btn_LevelUpClick() {
        this.mPanel.Panel_levelUpRole.visible = true;
        this.refreshLevelupPanel();
    }

    private roleDatas;
    public resetSeletedItem(data) {
        let datas;
        if (this.currrentType == 1) {//角色
            datas = this.roleDatas;
        } else {
            datas = GlobalClass.Hall.packageInfos[this.currrentType];
        }

        datas.forEach(element => {
            if (element) element.isSeleted = false;
        });
        data.isSeleted = true;
        this.resetSource(datas);
        this.refreshInfoView(data);
    }

    private showData;
    private lastData;
    private Timer: egret.Timer;
    public refreshInfoView(data) {
        this.lastData = data;
        this.mPanel.Btn_Info.visible = false;
        this.mPanel.Btn_LevelUp.visible = false;
        this.mPanel.Btn_Sell.visible = false;
        // this.mPanel.Btn_Buy.visible = false;
        this.mPanel.Btn_Use.visible = false;
        if (!data) {
            this.mPanel.goodsname.text = "- - -";
            this.mPanel.goodsTime.text = "剩余时间:- - -";
            this.mPanel.goodsNum.text = "- - -";
            this.mPanel.goodsDesc.text = "- - - ";
            this.mPanel.goodsImg.source = "";
            this.mPanel.goodsTime.visible = false;
            if (this.Timer) this.Timer.stop();
            return;
        }

        if (!this.configIsLoaded) {
            this.showData = data;
            return;
        }

        let itemData = this.getItemInfos(data);
        this.mPanel.goodsname.text = itemData.name;
        /***时间 */
        if (data.time_limit && data.time_limit != -1) {
            this.mPanel.goodsTime.visible = true;
            let nowtime = egret.getTimer();
            let delTime = Math.floor((nowtime - this.lastRefreshDataTime) / 1000);
            this.leftTime = data.time_limit - delTime;
            this.mPanel.goodsTime.text = "剩余时间:" + this.getTime(this.leftTime);
            if (this.Timer) {
                this.Timer.reset();
                this.Timer.repeatCount = this.leftTime;
                this.Timer.start();
            }

        } else {
            this.mPanel.goodsTime.visible = false;
            this.Timer.stop();
        }

        this.mPanel.goodsNum.text = data.quantity ? data.quantity : "0";
        this.mPanel.goodsDesc.text = itemData.desc;
        this.mPanel.goodsImg.source = itemData.source;
        if (data.category == goodsType.role) {//角色
            this.mPanel.Btn_Info.visible = true;
            this.mPanel.Btn_LevelUp.visible = true;
            this.mPanel.Btn_Use.visible = true;
            this.mPanel.goodsNum.text = "1";
            //未拥有角色
            if (!data.is_forever) {
                this.mPanel.Btn_Info.visible = false;
                this.mPanel.Btn_LevelUp.visible = false;
                this.mPanel.Btn_Use.visible = false;
                this.mPanel.goodsNum.text = "1";
            }
        }


    }

    private getTime(secondleft): string {
        if (secondleft == -1) {
            return "- - -";
        } else {
            let hour = Math.floor(secondleft / 3600);
            let second = secondleft % 60;
            let minute = Math.floor((secondleft - hour * 3600) / 60);
            let hourStr = hour > 10 ? "" + hour : "0" + hour;
            let secondStr = second > 10 ? "" + second : "0" + second;
            let minuteStr = minute > 10 ? "" + minute : "0" + minute;
            return hourStr + ":" + minuteStr + ":" + secondStr;
        }
    }

    protected onReady() {
        this.mPanel.Itemlist.dataProvider = null;
        this.loadInfo();
    }

    private loadInfo() {
        RES.addEventListener(RES.ResourceEvent.CONFIG_COMPLETE, this.onConfigComplete, this);
        RES.addEventListener(RES.ResourceEvent.CONFIG_LOAD_ERROR, this.onConfigLoadErr, this);
        RES.getResByUrl("resource/config/itemsInfo.json", this.onConfigComplete, this, RES.ResourceItem.TYPE_JSON);
    }

    private configIsLoaded = false;
    private onConfigComplete(event: RES.ResourceEvent): void {
        GlobalClass.ItemInfos = event;
        this.configIsLoaded = true;
        // console.log("onConfigComplete");
        let a = GlobalClass.ItemInfos[2];
        if (this.showData) {
            this.refreshInfoView(this.showData);
            this.showData = null;
        }
    }

    private onConfigLoadErr(event: RES.ResourceEvent): void {
        console.log("onConfigLoadErr");
    }

    private resetSource(datas) {
        var collection = new eui.ArrayCollection();
        collection.source = datas;
        this.mPanel.Itemlist.dataProvider = collection;
    }

    private refreshList(datas) {
        if (datas && datas.length > 0) {//该类别有物品
            if (this.currrentType == 1) {
                let arr = [];
                for (let key in GlobalClass.NPCInfos) {
                    let roleData = GlobalClass.NPCInfos[key];
                    let js = {
                        category: goodsType.role,
                        role_number: roleData.role_number,
                        is_expired: false,
                        time_limit: -1,
                        is_forever: false,
                    }
                    let haved = false;
                    datas.forEach(element => {
                        if (element.prop.role_number == roleData.role_number) {//该数据是图鉴数据
                            js["is_expired"] = element["is_expired"];
                            js["time_limit"] = element["time_limit"];
                            js["is_forever"] = element["is_forever"];
                            js["prop"] = element["prop"];
                            haved = true;
                        }
                    });
                    haved ? arr.unshift(js) : arr.push(js);
                }

                datas = arr;
                this.roleDatas = datas;
            }
            if (datas[0]) datas[0].isSeleted = true;
            this.refreshInfoView(datas[0]);
        } else {
            this.refreshInfoView(null);
        }
        this.fullSolts(datas);
        this.resetSource(datas);
    }

    /***填充空槽位 */
    private fullSolts(arr: Array<any>, limtRow: number = 4, limitColumn: number = 4) {
        /**槽位数量 */
        let soltCount = arr ? arr.length : 0;
        /**槽位列数 */
        let soltColumn = limitColumn;
        /**槽位行数 */
        let soltRow = Math.ceil(soltCount / soltColumn)

        if (soltRow < limtRow) {
            /**最低消费行数 */
            soltRow = limtRow;
        }
        soltCount = soltRow * soltColumn;
        let needCount = soltCount - arr.length
        /**不足的补空 */
        for (let i = 0; i < needCount; i++) {
            arr.push(null);
        }

    }

    private refreshData() {
        WebSocketMgr.getInstance().SendOneceMsg(MsgID.PACKAGE.GetPackage, JSON.stringify({}));
    }

    protected destroy() {
        this.Timer.removeEventListener(egret.TimerEvent.TIMER_COMPLETE, null, this);
        this.Timer.removeEventListener(egret.TimerEvent.TIMER, null, this);
        this.Timer.stop();
        this.Timer = null;
        super.destroy();
    }

    protected onShow() {//在界面上显示出来
        this.initTimer();
        this.initView();
        this.currrentType = 0;
        this.refreshData();
        this.mPanel.Panel_buyRole.visible = false;
        this.mPanel.Panel_levelUpRole.visible = false;
    }

    private leftTime
    private initTimer() {
        this.Timer = new egret.Timer(1000, 60);
        this.Timer.addEventListener(egret.TimerEvent.TIMER_COMPLETE, () => {
            this.timeOver();
        }, this);
        this.Timer.addEventListener(egret.TimerEvent.TIMER, () => {
            this.leftTime--;
            this.mPanel.goodsTime.text = "剩余时间:" + this.getTime(this.leftTime);
        }, this);
    }

    private timeOver() {

    }

    private initView() {
        this.mPanel.Itemlist.dataProvider = null;
        this.resetInfo();
    }

    private resetInfo() {
        this.mPanel.goodsname.text = "---";
        this.mPanel.goodsNum.text = "---";
        this.mPanel.goodsDesc.text = "---";
        this.mPanel.goodsname.text = "---";
        // this.disableBut(this.mPanel.Btn_Use);
        // this.disableBut(this.mPanel.Btn_Sell);
        this.mPanel.goodsImg.source = "";
        this.mPanel.Btn_Use.visible = false;
        this.mPanel.Btn_Sell.visible = false;
    }

    private Btn_CloseClick() {
        this.mPanel.hide();
    }

    private Btn_InfoClick() {
        this.mPanel.Panel_levelUpRole.visible = true;
        this.refreshLevelupPanel();
    }

    private Btn_SellClick() {//
        let a = this.lastData;
        let js = {
            prop_id: this.lastData.prop_id,
            // quantity:this.lastData.quantity,
            category: this.lastData.category,
            quantity: 1
        }
        WebSocketMgr.getInstance().SendOneceMsg(MsgID.PACKAGE.SellGoods, JSON.stringify(js));
    }

    private Btn_UseClick() {//使用道具或角色
        if (this.lastData.category == goodsType.role) {//角色
            let Npcdata = GlobalClass.NPCInfos[this.lastData.role_number];
            let a = this.lastData;
            let js = {
                role_id: Npcdata.role_id
            }
            WebSocketMgr.getInstance().SendOneceMsg(MsgID.HALL.ChangeNPC, JSON.stringify(js));
        } else if (this.lastData.category == goodsType.brick) {//砖块

        } else if (this.lastData.category == goodsType.roleCard) {//体验卡
            let js = {
                prop_id: this.lastData.prop_id
            }
            WebSocketMgr.getInstance().SendOneceMsg(MsgID.PACKAGE.UseRoleCard, JSON.stringify(js));
        }
    }

    private Btn_BuyClick() {
        if (this.lastData.category == goodsType.role) {
            this.refreshBuyRolePanel();
            this.mPanel.Panel_buyRole.visible = true;
        } else {
            KFControllerMgr.getCtl(PanelName.ShopPanel).show(goodsType.brick);
        }
    }

    private getItemInfos(data): any {
        let itemInfo;
        let itemId = "";
        let category = data.category;
        switch (category) {
            case goodsType.flower:
                itemId = "1";
                break;
            case goodsType.piece:
                itemId = "1";
                break;
            case goodsType.role:
                itemId = data.role_number;
                break;
            case goodsType.roleCard:
                itemId = data.prop.role_number + "_" + data.prop.days;
                break;
            case goodsType.props:
                itemId = data.prop.prop_number;
                break;
            case goodsType.brick:
                itemId = "1";
                break;
        }
        let a = GlobalClass.ItemInfos;
        itemInfo = GlobalClass.ItemInfos[data.category][itemId];
        if (category == goodsType.roleCard) itemId = data.prop.role_number;
        itemInfo.source = GameConstant.getItemImg(category, itemId);
        return itemInfo;
    }

    private refreshBuyRolePanel() {
        let Npcdata = GlobalClass.NPCInfos[this.lastData.role_number];
        this.mPanel.roleName_buy.text = Npcdata.name;
        this.mPanel.roleDesc_buy.text = Npcdata.description;
        let skillArr = Npcdata.skills[0];
        for (let i = 0; i < 2; i++) {
            let skillGroup = this.mPanel.Skills_buy.getChildAt(i);
            if (i < skillArr.length) {
                skillGroup.visible = true;
                let skillInfo = GlobalClass.SkillInfosByID[skillArr[i]];
                skillGroup.getChildAt(0).source = "skill_icon_json.skill_icon_" + skillInfo.skill_number;
                skillGroup.getChildAt(1).text = skillInfo.description;
                this.mPanel.roleImg_buy.source = "CommonAtlas_json.img_npchead0" + this.lastData.role_number % 100;
            } else {
                skillGroup.visible = false;
            }
        }
        this.mPanel.roleTime_buy.visible = false;
    }

    private refreshLevelupPanel() {
        let Npcdata = GlobalClass.NPCInfos[this.lastData.role_number];
        this.mPanel.roleName_levelUp.text = Npcdata.name;
        this.mPanel.roleDesc_levelUp.text = Npcdata.description;

        let currentLevel = 3;
        let nextLevel = currentLevel + 1;

        let skillArr = Npcdata.skills[currentLevel];
        let nextSkillArr = Npcdata.skills[nextLevel];


        let needMoney = Npcdata.skills_upgrade_expend_coin[currentLevel + 1];


        for (let i = 0; i < 2; i++) {
            let skillGroup = this.mPanel.Skills_levelup.getChildAt(i);
            let nextSkillGroup = this.mPanel.Skills_levelup.getChildAt(2 + i);
            if (i < skillArr.length) {
                skillGroup.visible = true;
                let skillInfo = GlobalClass.SkillInfosByID[skillArr[i]];
                skillGroup.getChildAt(0).source = "skill_icon_json.skill_icon_" + skillInfo.skill_number;
                skillGroup.getChildAt(1).text = skillInfo.description;
                if (needMoney) {
                    this.mPanel.Btn_Buy_LevelUp.getChildAt(3).text = needMoney;
                } else {
                    this.mPanel.Btn_Buy_LevelUp.visible = false;
                }

                this.mPanel.roleImg_levelup.source = "CommonAtlas_json.img_npchead0" + this.lastData.role_number % 100;

                if (nextSkillArr) {
                    nextSkillGroup.visible = true;
                    let nextskillInfo = GlobalClass.SkillInfosByID[nextSkillArr[i]];
                    nextSkillGroup.getChildAt(0).source = "skill_icon_json.skill_icon_" + nextskillInfo.skill_number;
                    nextSkillGroup.getChildAt(1).text = nextskillInfo.description;
                    nextSkillGroup.getChildAt(4).text = "︽lv" + nextLevel;
                } else {
                    nextSkillGroup.visible = false;
                }
            } else {
                skillGroup.visible = false;
                nextSkillGroup.visible = false
            }
        }
    }
}