class LevelUpPanelController extends KFController {
	public constructor() {
		super();
	}

	protected init() {
		super.init();
		this.ListenObjList = [
		];
		this.EventsList = [

		];
	}

}