/**
 *
 * @author 
 *
 */
class NetLoadingPanelController extends KFController {


    protected init() {
        super.init();
        this.ListenObjList = [

        ];//添加btn名为key，值为冷却时间，然后在类中添加btn名+Click的函数，即可自动注册btn事件 ,如 Btn_MyBankClick为函数名
        this.EventsList = [

        ];
    }

    protected onReady() {

    }

    protected onShow() {//在界面上显示出来
        this.mPanel.brickICon.rotation = 45;
        this.mPanel.brickICon.anchorOffsetX = this.mPanel.brickICon.width / 2;
        this.mPanel.brickICon.anchorOffsetY = this.mPanel.brickICon.height / 2;
        this.loadingAnimation();
    }

    private loadingAnimation() {
        egret.Tween.get(this.mPanel.brickICon).to({ rotation: -45 }, 1000, egret.Ease.backOut).to({ rotation: 45 }, 1000, egret.Ease.backOut)
            .call(function () {
                this.loadingAnimation();
            }, this);
    }
}