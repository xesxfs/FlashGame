/**
 *
 * @author 
 *
 */
class FriendPanelController extends KFController{ 
    
	
	protected init(){
    	super.init();
         this.ListenObjList = [ {event:egret.TouchEvent.TOUCH_END,items:{
                                                                        "Toggle_Friends":"",
                                                                        "Toggle_Alien":"",
                                                                        "Toggle_Add":"",
                                                                        "Btn_Close":"",
                                                                        "Btn_SearchFriend":"",
                                                                        "Btn_recommond":"",
                                                                        "Btn_SearchAll":"",
                                                                        "Btn_AllRefuse":"",
                                                                        "Btn_AllAgree":"",
                                                    },},
                            ];//添加btn名为key，值为冷却时间，然后在类中添加btn名+Click的函数，即可自动注册btn事件 ,如 Btn_MyBankClick为函数名
        this.EventsList = [
                MsgID.FRIEND.AllFriendList,
                MsgID.FRIEND.ApplyAddFrind,
                MsgID.FRIEND.SearchFriend,
                MsgID.FRIEND.SendPhysics,
                MsgID.FRIEND.SendFlower,
                MsgID.FRIEND.AgreeApply,
                MsgID.FRIEND.RefuseApply,
                MsgID.FRIEND.ApplyList,
                MsgID.FRIEND.DeleteFriend,
                MsgID.FRIEND.AllAgree,
                MsgID.FRIEND.AllRefuse,
                MsgID.FRIEND.ServerRecommand,
            ];
	}

    private on102000_event(event: egret.Event): void {
        console.log("on102000_event");
        let msg:MSGBase = <MSGBase>event.data;
        let dataStr = msg.getDataStr();
        
        let jsObj = JSON.parse(dataStr);
        if(jsObj["code"]==200){
            var collection = new eui.ArrayCollection();
            collection.source = jsObj["info"];
            this.mPanel.FriendsList.dataProvider = collection;
        }
    }

    private on102001_event(event: egret.Event): void {
        console.log("on102001_event");
        let msg:MSGBase = <MSGBase>event.data;
        let dataStr = msg.getDataStr();
        
        let jsObj = JSON.parse(dataStr);
        if(jsObj["code"]==200){
            KFControllerMgr.showToast("申请已发送",this.mPanel);
        }else{
            KFControllerMgr.showToast("申请发送失败，请重新申请",this.mPanel);
        }
    }

    private on102002_event(event: egret.Event): void {
        console.log("on102002_event");
        let msg:MSGBase = <MSGBase>event.data;
        let dataStr = msg.getDataStr();
        
        let jsObj = JSON.parse(dataStr);
         if(jsObj["code"]==200){
             if(jsObj["info"].length>0){
                var collection = new eui.ArrayCollection();
                collection.source = jsObj["info"];
                this.mPanel.AllList.dataProvider = collection;
             }else{
                  KFControllerMgr.showTips("未搜索到相关好友！");
             }
           
        }else{
            KFControllerMgr.showTips(jsObj["info"]);
        }
    }

    private on102003_event(event: egret.Event): void {
        console.log("on102003_event");
        let msg:MSGBase = <MSGBase>event.data;
        let dataStr = msg.getDataStr();
        
        let jsObj = JSON.parse(dataStr);
        if(jsObj["code"]==200){
            KFControllerMgr.showTips("赠送成功",1);
        }else{
            if(jsObj["code"]==944){
                KFControllerMgr.showTips("超过当日赠送上限");
            }else{
                KFControllerMgr.showTips(jsObj["info"]);
            }
        }
    }

    private on102004_event(event: egret.Event): void {
        console.log("on102004_event");
        let msg:MSGBase = <MSGBase>event.data;
        let dataStr = msg.getDataStr();
        
        let jsObj = JSON.parse(dataStr);
        if(jsObj["code"]==200){
             KFControllerMgr.showTips("赠送成功",1);
        }else{
            if(jsObj["code"]==944){
                KFControllerMgr.showTips("超过当日赠送上限");
            }else{
                KFControllerMgr.showTips(jsObj["info"]);
            }
        }
    }

    private on102005_event(event: egret.Event): void {
        console.log("on102005_event");
        let msg:MSGBase = <MSGBase>event.data;
        let dataStr = msg.getDataStr();
        
        let jsObj = JSON.parse(dataStr);
        if(jsObj["code"]==200){
            this.refreshView();
        }
    }

    private on102006_event(event: egret.Event): void {
        console.log("on102006_event");
        let msg:MSGBase = <MSGBase>event.data;
        let dataStr = msg.getDataStr();
        
        let jsObj = JSON.parse(dataStr);
        if(jsObj["code"]==200){
            this.refreshView();
        }
    }

    private on102007_event(event: egret.Event): void {
        console.log("on102007_event");
        let msg:MSGBase = <MSGBase>event.data;
        let dataStr = msg.getDataStr();
        
        let jsObj = JSON.parse(dataStr);
        if(jsObj["code"]==200){
            var collection = new eui.ArrayCollection();
            collection.source = jsObj["info"];
            this.mPanel.AlienList.dataProvider = collection;
        }
    }

    private on102008_event(event: egret.Event): void {
        console.log("on102008_event");
        let msg:MSGBase = <MSGBase>event.data;
        let dataStr = msg.getDataStr();
        
        let jsObj = JSON.parse(dataStr);
        if(jsObj["code"]==200){
            this.refreshView();
        }
    }

    private on102009_event(event: egret.Event): void {
        console.log("on102009_event");
        let msg:MSGBase = <MSGBase>event.data;
        let dataStr = msg.getDataStr();
        
        let jsObj = JSON.parse(dataStr);
        if(jsObj["code"]==200){
            this.refreshView();
        }
    }

    private on102010_event(event: egret.Event): void {
        console.log("on102010_event");
        let msg:MSGBase = <MSGBase>event.data;
        let dataStr = msg.getDataStr();
        
        let jsObj = JSON.parse(dataStr);
        if(jsObj["code"]==200){
            this.refreshView();
        }
    }

    private on102011_event(event: egret.Event): void {
        console.log("on102011_event");
        let msg:MSGBase = <MSGBase>event.data;
        let dataStr = msg.getDataStr();
        
        let jsObj = JSON.parse(dataStr);
        if(jsObj["code"]==200){
             var collection = new eui.ArrayCollection();
            collection.source = jsObj["info"];
            this.mPanel.AllList.dataProvider = collection;
        }
    }

    private refreshView(){
        WebSocketMgr.getInstance().SendOneceMsg(MsgID.FRIEND.AllFriendList,JSON.stringify({}));
        WebSocketMgr.getInstance().SendOneceMsg(MsgID.FRIEND.ApplyList,JSON.stringify({}));
    }
	
    protected onReady() {
        this.mPanel.AllList.dataProvider = null;

        this.mPanel.AlienList.dataProvider = null;

        this.mPanel.FriendsList.dataProvider = null;
    }

    protected onShow(){//在界面上显示出来
        this.refreshView();
        this.Toggle_FriendsClick();
    }

    private initView(){

    }

    private Toggle_FriendsClick(){
        this.mPanel.Toggle_Friends.seleted = true;
        this.mPanel.AllFriend.visible = true;
        this.mPanel.Alien.visible = false;
        this.mPanel.Recommand.visible = false;
    }

    private Toggle_AlienClick(){
        this.mPanel.Toggle_Alien.seleted = true;
        this.mPanel.AllFriend.visible = false;
        this.mPanel.Alien.visible = true;
        this.mPanel.Recommand.visible = false;
    }

    private Toggle_AddClick(){
        this.mPanel.Toggle_Add.seleted = true;
        this.mPanel.AllFriend.visible = false;
        this.mPanel.Alien.visible = false;
        this.mPanel.Recommand.visible = true;

        WebSocketMgr.getInstance().SendOneceMsg(MsgID.FRIEND.ServerRecommand,JSON.stringify({}));
        
    }

    private Btn_CloseClick(){
        this.mPanel.hide();
    }

    private Btn_recommondClick(){
        WebSocketMgr.getInstance().SendOneceMsg(MsgID.FRIEND.ServerRecommand,JSON.stringify({}));
    }

    private Btn_SearchAllClick(){
        let name = this.mPanel.Input_SearchAllName.text;
        if(name!=""){
             let js = {
                search_type:0,
                value:this.mPanel.Input_SearchAllName.text,
            }
            WebSocketMgr.getInstance().SendOneceMsg(MsgID.FRIEND.SearchFriend,JSON.stringify(js));
        }
    }

    private Btn_SearchFriendClick(){
      
    }

     private Btn_AllRefuseClick(){
         WebSocketMgr.getInstance().SendOneceMsg(MsgID.FRIEND.AllRefuse,JSON.stringify({}));
     }

     private Btn_AllAgreeClick(){
         WebSocketMgr.getInstance().SendOneceMsg(MsgID.FRIEND.AllAgree,JSON.stringify({}));
     }
}