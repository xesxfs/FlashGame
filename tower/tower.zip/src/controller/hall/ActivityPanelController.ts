/**
 *
 * @author 
 *
 */
class ActivityPanelController extends KFController{ 
    
	private showCataLogy = 0;
	protected init(){
    	super.init();
         this.ListenObjList = [ 
                                {event:egret.TouchEvent.TOUCH_END,items:{
                                                                            "Btn_Close":"",
                                                                            "Toggle_FirstCharge":"",
                                                                            "Toggle_Gifts":"",
                                                                            "Toggle_Online":"",
                                                                            "Toggle_Endless":"",
                                                                            "Toggle_Sign":"",
                                                                            "Toggle_RedeemCode":"",
                                                                            "Btn_GotoShop":"",
                                                                            "Btn_GoEndless":"",
                                                                            "Btn_GetGift":"",
                                                                            "Btn_RedeemCode":"",
                                                    },},
                            
                            ];//添加btn名为key，值为冷却时间，然后在类中添加btn名+Click的函数，即可自动注册btn事件 ,如 Btn_MyBankClick为函数名
        this.EventsList = [
                MsgID.ACTIVITY.UseRedeemCode,
                MsgID.HALL.GetPayOrder,
                MsgID.ACTIVITY.SevenDayGiftConfig,
                MsgID.ACTIVITY.SevenDayGiftRecord,
            ];
	}
	
    protected onReady() {
        this.mPanel.chargeList.dataProvider = null;
        WebSocketMgr.getInstance().SendOneceMsg(MsgID.ACTIVITY.SevenDayGiftConfig, JSON.stringify({}));

        WebSocketMgr.getInstance().SendOneceMsg(MsgID.ACTIVITY.SevenDayGiftRecord, JSON.stringify({}));
    }

    protected onShow(){//在界面上显示出来
        this.resetView();
        switch(this.showCataLogy){
            case 0:
                this.Toggle_FirstChargeClick();
            break;
            case 1:
                this.Toggle_GiftsClick();
            break;
            case 2:
                this.Toggle_OnlineClick();
            break;
            case 3:
                this.Toggle_EndlessClick();
            break;
        }


    }



    public show(catalogy=0){
        this.showCataLogy = catalogy;
        super.show();
    }

    private resetView(){
        this.mPanel.Toggle_FirstCharge.selected = false;
        this.mPanel.Toggle_Gifts.selected = false;
        this.mPanel.Toggle_Online.selected = false;
        this.mPanel.Toggle_Endless.selected = false;
        this.mPanel.Toggle_RedeemCode.selected = false;
        this.mPanel.Toggle_Sign.selected = false;
        this.mPanel.FirstChage.visible = false;
        this.mPanel.Gifts.visible = false;
        this.mPanel.EndlessRule.visible = false;
        this.mPanel.Online.visible = false;
        this.mPanel.RedeemCode.visible = false;
        this.mPanel.panel_sign.visible = false;

        this.mPanel.Input_RedeemCode.text = "";
    }

    private Toggle_RedeemCodeClick(){
        this.resetView();
        this.mPanel.Toggle_RedeemCode.selected = true;
        this.mPanel.RedeemCode.visible = true;

    }

    private Toggle_SignClick(){
        this.resetView();
        this.mPanel.Toggle_Sign.selected = true;
        this.mPanel.panel_sign.visible = true;
    }

    private Toggle_FirstChargeClick(){
        this.resetView();
        this.mPanel.Toggle_FirstCharge.selected = true;
        this.mPanel.FirstChage.visible = true;
        this.refreshFirstChargeView();
    }

    private Toggle_GiftsClick(){
        this.resetView();
        this.mPanel.Toggle_Gifts.selected = true;
        this.mPanel.Gifts.visible = true;
        this.refreshGiftView();
    }
    
    private Toggle_OnlineClick(){
        this.resetView();
        this.mPanel.Toggle_Online.selected = true;
        this.mPanel.Online.visible = true;
        this.refreshRewardItems();
    }

    private Toggle_EndlessClick(){
        this.resetView();
        this.mPanel.Toggle_Endless.selected = true;
        this.mPanel.EndlessRule.visible = true;
        this.refreshWeekendView();
    }

    private Btn_RedeemCodeClick(){
        let js = {
            cdkey:this.mPanel.Input_RedeemCode.text,
        }
        WebSocketMgr.getInstance().SendOneceMsg(MsgID.ACTIVITY.UseRedeemCode,JSON.stringify(js));
    }

    private Btn_GotoShopClick(){
        KFControllerMgr.getCtl(PanelName.ShopPanel).show(goodsType.diamond);
    }

    private Btn_GoEndlessClick(){
        GlobalClass.Game.GameMode = 3;
        KFSceneManager.getInstance().replaceScene(SceneName.Game);
    }

    private Btn_GetGiftClick(){
        let b = GlobalClass.Hall.oneDollarGiftConfig;
        let js = {
                good_id:GlobalClass.Hall.oneDollarGiftConfig["id"],
				pay_type:PayType.AliPay,
				is_package:1,
		}
		WebSocketMgr.getInstance().SendOneceMsg(MsgID.HALL.GetPayOrder,JSON.stringify(js));
    }

    private Btn_CloseClick(){
        this.mPanel.hide();
    }

    private refreshRewardItems(){
        let num = GlobalClass.CurrentUser.can_receive_online_coin_award_count;
        for(let i=2;i>=0;i--){
            let item = <OnlineRewardItem>this.mPanel.RewardItems.getChildAt(i);
            let HaveRecieve = num<=0;
            num--;
            item.initView(HaveRecieve,false);
        }
    }

    private on100061_event(event: egret.Event): void {
        console.log("on100061_event");
        let msg:MSGBase = <MSGBase>event.data;
        let dataStr = msg.getDataStr();
        
        let jsObj = JSON.parse(dataStr);
        if(jsObj["code"]==200){
            
        }
    }

    private on100062_event(event: egret.Event): void {
        console.log("on100062_event");
        let msg:MSGBase = <MSGBase>event.data;
        let dataStr = msg.getDataStr();
        
        let jsObj = JSON.parse(dataStr);
        if(jsObj["code"]==200){
            GlobalClass.SevenDayInfos = jsObj["info"]["prize_info"];
            let arr = [];
            for(let i=1;i<=7;i++){
                arr.push(GlobalClass.SevenDayInfos[""+i]);
            }
            var collection = new eui.ArrayCollection();
            collection.source = arr;
            this.mPanel.serverDayList.dataProvider = collection;
        }
    }

    private on100060_event(event: egret.Event): void {
        console.log("on100060_event");
        let msg:MSGBase = <MSGBase>event.data;
        let dataStr = msg.getDataStr();
        
        let jsObj = JSON.parse(dataStr);
        if(jsObj["code"]==200){

            let arr = [];
            jsObj["info"].prize_info.forEach(element => {
                let propid = element["prop_id"];
                if(element["category"]==goodsType.props){
                    propid = element.prop.prop_number;
                }
                if(element["category"]==goodsType.role){
                    propid = element.prop.role_number;
                }
                let itemB = {
                    quantity:element["quantity"],
                    propid:propid,
                    category:element["category"],
                };
                arr.push(itemB);
            });
            GlobalClass.Hall.RewardList = arr;
            KFControllerMgr.getCtl(PanelName.RewardListPanel).show();
            
            WebSocketMgr.getInstance().SendOneceMsg(MsgID.USER.GETUSERINFO,JSON.stringify({}));
        }else{
            KFControllerMgr.showToast(jsObj["info"],this.mPanel);
             this.mPanel.Input_RedeemCode.text = "";
        }
    }

    private on100800_event(event: egret.Event): void {
        console.log("on100800_event");
        let msg:MSGBase = <MSGBase>event.data;
        let dataStr = msg.getDataStr();
        
        let jsObj = JSON.parse(dataStr);
        if(jsObj["code"]==200){//刷新燃料数
            KFControllerMgr.showTips("支付中",7);
            
             let data = jsObj["info"];

            let trade_no = data["trade_no"];
            let goods_name = data["goods_name"];
            let amount = data["amount"];
            let user_id = data["user_id"];
            let desc = data["goods_name"];
            let goods_id = data["goods_id"];

            // PluginEvent.BuyProduct(SDKPayType.PAY_One,trade_no,goods_id,goods_name,desc,user_id,amount);
        }
    }

    private refreshFirstChargeView(){
        let datas = GlobalClass.Hall.chargeGiftConfig;
        GlobalClass.Hall.giftRecord[activityType.firstCharge].forEach(element => {
            datas.forEach(element2 => {
                if(element2.id==element){
                    element2["haveUsed"] = true;
                }
            });
        });

        var collection = new eui.ArrayCollection();
        collection.source = datas;
        this.mPanel.chargeList.dataProvider = collection;
    }

    private refreshGiftView(){
        this.mPanel.GiftGroup.removeChildren();
        GlobalClass.Hall.oneDollarGiftConfig["props"].forEach(element => {
            let item = new GiftItem(element.category,element.description);
            this.mPanel.GiftGroup.addChild(item);
        });
    }

    private refreshWeekendView(){
        this.mPanel.EndlessItemGroup.removeChildren();
        let array = [
            {
                category:goodsType.diamond,
                quantity:50,
            },
            {
                category:goodsType.piece,
                quantity:10,
            },
            {
                category:goodsType.gold,
                quantity:100,
            }
        ]
        array.forEach(element => {
            let item = new EndlessReward(element.category,element.quantity);
            this.mPanel.EndlessItemGroup.addChild(item);
        });
    }
}