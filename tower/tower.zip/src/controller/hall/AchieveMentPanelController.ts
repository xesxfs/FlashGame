/**
 *
 * @author 
 *
 */
class AchieveMentPanelController extends KFController{ 
    
	private lastDataArr = null;
	protected init(){
    	super.init();
         this.ListenObjList = [ {event:egret.TouchEvent.TOUCH_END,items:{"Btn_Close":"",
                                                    },},
                            
                            ];//添加btn名为key，值为冷却时间，然后在类中添加btn名+Click的函数，即可自动注册btn事件 ,如 Btn_MyBankClick为函数名
        this.EventsList = [
                MsgID.HALL.GetAchieve,
                MsgID.HALL.GetPlayerAchieveInfos,
            ];
	}
	
    protected onReady(){
        this.mPanel.Itemlist.dataProvider = null;
        this.lastDataArr = null;
        WebSocketMgr.getInstance().SendOneceMsg(MsgID.HALL.GetPlayerAchieveInfos,JSON.stringify({}));
    }

    protected onShow(){//在界面上显示出来
        
    }

    protected destroy(){
        this.lastDataArr = null;
        super.destroy();
    }

     private on100205_event(event: egret.Event): void {
        console.log("on100205_event");
        let msg:MSGBase = <MSGBase>event.data;
        let dataStr = msg.getDataStr();
        let jsObj = JSON.parse(dataStr);
        if(jsObj["code"]==200){
            GlobalClass.Hall.currentAchievement = {};
            jsObj["info"].forEach(element => {
                GlobalClass.Hall.currentAchievement[element.achievement_type] = element;
            });
            this.initView();
        }
    }

     private on100206_event(event: egret.Event): void {
        console.log("on100206_event");
        let msg:MSGBase = <MSGBase>event.data;
        let dataStr = msg.getDataStr();
        
        let jsObj = JSON.parse(dataStr);
        if(jsObj["code"]==200){
            GlobalClass.Hall.currentAchievement = {};
            jsObj["info"].forEach(element => {
                GlobalClass.Hall.currentAchievement[element.achievement_type] = element;
            });
            // KFControllerMgr.showTips("领取成功");
            WebSocketMgr.getInstance().SendOneceMsg(MsgID.HALL.GetPlayerAchieveInfos,JSON.stringify({}));
            WebSocketMgr.getInstance().SendOneceMsg(MsgID.USER.GETUSERINFO,JSON.stringify({}));
        }
    }
    
    private initView(){
        var dataArr = [];
        let a = GlobalClass.AchieveInfos;
        let b = GlobalClass.Hall.currentAchievement;
        for(let key in GlobalClass.AchieveInfos){
            let info = GlobalClass.AchieveInfos[key]
            let element = GlobalClass.Hall.currentAchievement[key];
            let item ;
            if(element==null){
                item = info[0];
                item.starNum = 0;
                item.currentValue = 0;
                item.open = 0;
            }else{
                let rewarded_numbers = element["rewarded_numbers"].length;
                let reached_numbers = element["reached_numbers"].length;
                let index = rewarded_numbers>=info.length?rewarded_numbers-1:rewarded_numbers;
                item = info[index];
                if(reached_numbers==0){//该类中没有达成的成就 
                    item.open = 0;
                }else if(rewarded_numbers<reached_numbers){//该类中有尚未领取的成就
                    item.open = 1;
                }else{
                    item.open = 0;
                }
                
                 item.starNum = rewarded_numbers;
                item.currentValue = element["current_value"];
            }

            if(this.lastDataArr!=null){//上次的数据不为空，则要比较是否有更新
                let index = parseInt(key)-1;
                let lastItem = this.lastDataArr[index];
                if(lastItem&&lastItem.starNum<item.starNum){//星星数有更新
                    item.isNew = 1;
                }else{
                    item.isNew = 0;
                }
            }else{
                item.isNew = 0;
            }
            dataArr.push(item);
        }

        this.lastDataArr = dataArr;

        let lastScrollV = this.mPanel.Itemlist.scrollV;

        var collection = new eui.ArrayCollection();
        collection.source = dataArr;
        this.mPanel.Itemlist.dataProvider = collection;

        this.mPanel.Itemlist.validateNow ();
        this.mPanel.Itemlist.scrollV = lastScrollV;
    }

    private Btn_CloseClick(){
         let lastScrollV = this.mPanel.Itemlist.scrollV;
        this.mPanel.hide();
    }
}