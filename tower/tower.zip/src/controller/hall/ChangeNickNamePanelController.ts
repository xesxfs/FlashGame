/**
 *
 * @author 
 *
 */
class ChangeNickNamePanelController extends KFController{ 

    private isHideClose = false;
    private nickList = [];
	protected init(){
    	super.init();
         this.ListenObjList = [ {event:egret.TouchEvent.TOUCH_END,items:{
                                                                    "Btn_Close":"",
                                                                    "Btn_GetNicks":"",
                                                                    "Btn_Change":"",
                                                    },},
                            ];//添加btn名为key，值为冷却时间，然后在类中添加btn名+Click的函数，即可自动注册btn事件 ,如 Btn_MyBankClick为函数名
        this.EventsList = [
                MsgID.HALL.GetNickNames,
                MsgID.HALL.ChangeNickName,
            ];
	}
	
    protected onReady() {
        this.nickList = [];
    }

    protected destroy(){
        this.nickList = [];
        this.isHideClose = false;
        super.destroy();
    }

    protected onShow(){//在界面上显示出来
        this.mPanel.usedTip.text = "请选择您的昵称!";
        this.refreshNick();
        if(this.isHideClose){
            this.mPanel.Btn_Close.visible = false;
        }else{
            this.mPanel.Btn_Close.visible = true;
        }
    }
    
    private Btn_GetNicksClick(){
        this.refreshNick();
    }

    private Btn_ChangeClick(){
        this.mPanel.usedTip.visible = false;
        GlobalClass.CurrentUser.nick = this.mPanel.Input_NickName.text;
        let js = {
            nickname:this.mPanel.Input_NickName.text,
        }
        WebSocketMgr.getInstance().SendOneceMsg(MsgID.HALL.ChangeNickName,JSON.stringify(js));

        
    }

    private on100050_event(event: egret.Event): void {
        console.log("on100050_event");
        let msg:MSGBase = <MSGBase>event.data;
        let dataStr = msg.getDataStr();
        
        let jsObj = JSON.parse(dataStr);
        if(jsObj["code"]==200){
            KFControllerMgr.showToast("修改成功",this.mPanel);
            this.hide();
            WebSocketMgr.getInstance().SendOneceMsg(MsgID.USER.GETUSERINFO,JSON.stringify({}));
            KFControllerMgr.getCtl(PanelName.HallPanel).checkGuide();
        }else{
            this.mPanel.usedTip.visible = true;
            this.mPanel.usedTip.text = jsObj["info"];
            if(jsObj["code"]==953){
                this.refreshNick();
            }
        }
     }

     private on100051_event(event: egret.Event): void {
        console.log("on100051_event");
        let msg:MSGBase = <MSGBase>event.data;
        let dataStr = msg.getDataStr();
        
        let jsObj = JSON.parse(dataStr);
        if(jsObj["code"]==200){
            this.nickList = jsObj["info"];
            this.refreshNick();
        }
     }

     private refreshNick(){
         if(this.nickList.length==0){
             WebSocketMgr.getInstance().SendOneceMsg(MsgID.HALL.GetNickNames,JSON.stringify({}));
         }else{
              let nick = this.nickList.shift();
            this.mPanel.Input_NickName.text = nick;
         }
     }

    private Btn_CloseClick(){
        this.mPanel.hide();
    }

    public show(hideClose=false){
        this.isHideClose = hideClose;
        super.show();
    }
}