/**
 *
 * @author 
 *
 */
class EditSolutionPanelController extends KFController{ 
    
	private currentBlockImg:eui.Image;
    private isMoving = false;
    private addBlockList = [];

    private allBricks = [];

    private imgs = [];

	protected init(){
    	super.init();
         this.ListenObjList = [ {event:egret.TouchEvent.TOUCH_END,items:{
                                                            "Btn_platform":"",
                                                            "Btn_solution":"",
                                                            "Btn_Refresh":"",
                                                            "Btn_L":"",
                                                            "Btn_I":"",
                                                            "Btn_J":"",
                                                            "Btn_T":"",
                                                            "Btn_O":"",
                                                            "Btn_S":"",
                                                            "Btn_Z":"",
                                                    },},
                            
                            ];//添加btn名为key，值为冷却时间，然后在类中添加btn名+Click的函数，即可自动注册btn事件 ,如 Btn_MyBankClick为函数名
        this.EventsList = [
            ];
        
	}

    private Btn_LClick(e: egret.TouchEvent){
        this.currentBlockImg.source = "block_json.blockL";
        this.butClick(e);
    }
    private Btn_IClick(e: egret.TouchEvent){
        this.currentBlockImg.source = "block_json.blockI";
        this.butClick(e);
    }
    private Btn_JClick(e: egret.TouchEvent){
        this.currentBlockImg.source = "block_json.blockJ";
        this.butClick(e);
    }
    private Btn_TClick(e: egret.TouchEvent){
        this.currentBlockImg.source = "block_json.blockT";
        this.butClick(e);
    }
    private Btn_OClick(e: egret.TouchEvent){
        this.currentBlockImg.source = "block_json.blockO";
        this.butClick(e);
    }
    private Btn_SClick(e: egret.TouchEvent){
        this.currentBlockImg.source = "block_json.blockS";
        this.butClick(e);
    }
    private Btn_ZClick(e: egret.TouchEvent){
        this.currentBlockImg.source = "block_json.blockZ";
        this.butClick(e);
    }

    private butClick(e){
        e.stopImmediatePropagation();
        this.currentBlockImg.visible = true;
        this.isMoving = true;
        this.addBlockList.forEach(element => {
            element.touchEnabled = false;
        });
    }

    protected onReady() {
        this.currentBlockImg = new eui.Image("block_json.blockL");
        this.currentBlockImg.visible = false;
        this.currentBlockImg.touchEnabled = false;
        mouse.setMouseMoveEnabled(true);
        this.addBlockList = [];
    }

    protected onShow(){//在界面上显示出来
        this.mPanel.addEventListener(mouse.MouseEvent.MOUSE_MOVE, (e: egret.TouchEvent)=>{
            if(e.target.name=="block"){

            }else{
                this.currentBlockImg.x = e.target.x;
                this.currentBlockImg.y = e.target.y;
            }
            
        }, this);

        this.mPanel.addEventListener(egret.TouchEvent.TOUCH_END,this.onPanelClick,this);

        this.initView();
        this.mPanel.addChild(this.currentBlockImg);
    }

    private currentChooseBlock;
    private onPanelClick(){
        if(this.isMoving){
            this.isMoving = false;
            let newImg = new eui.Image(this.currentBlockImg.source);
            this.mPanel.addChild(newImg);
            newImg.x = this.currentBlockImg.x;
            newImg.y = this.currentBlockImg.y;
            newImg.name = "block";
            this.currentBlockImg.visible = false;
            this.addBlockList.push(newImg);

            newImg.addEventListener(egret.TouchEvent.TOUCH_TAP,(e: egret.TouchEvent)=>{
                  this.currentChooseBlock = e.target;
                  KFControllerMgr.showTips(LocalizationMgr.getText("要删除这块砖吗?"),0,2,()=>{
                            this.mPanel.removeChild(this.currentChooseBlock);
                            this.addBlockList.remove(this.currentChooseBlock);
                            this.currentChooseBlock = null;
                            console.log("len="+this.addBlockList.length);
                        },"提示",()=>{

                        });
            },this);
            
            this.addBlockList.forEach(element => {
                element.touchEnabled = true;
            });
        }
    }
    
    private initView(){
        let widthNum = this.mPanel.width/GlobalClass.GameInfoForConfig.blockUnitWidth;
        let heightNum = this.mPanel.height/GlobalClass.GameInfoForConfig.blockUnitWidth;
        for(let i=0;i<widthNum;i++){
            let arr = [];
            for(let j=0;j<heightNum;j++){
                let img = new eui.Image("Game_json.Img_platformblock02");
                this.mPanel.brockSgroup.addChild(img);
                img.x = i*GlobalClass.GameInfoForConfig.blockUnitWidth;
                img.y = j*GlobalClass.GameInfoForConfig.blockUnitWidth;
                img.name = i+"_"+j;
                img.addEventListener(egret.TouchEvent.TOUCH_END,(event)=>{
                    if(!this.isMoving){
                         let a = event.target.source.toString();
                        let numArr = img.name.split("_");
                        let x = parseInt(numArr[0]);
                        let y = parseInt(numArr[1]);
                        if(a=="Game_json.Img_platformblock02"){
                            event.target.source = "Game_json.Img_platformblock01";
                            this.allBricks[x][y] = 1;
                        }
                        if(a=="Game_json.Img_platformblock01"){
                            event.target.source = "Game_json.Img_platformblock02";
                            this.allBricks[x][y] = 0;
                        }
                    }
                   
                },this);
                this.imgs.push(img);
               arr.push(0);
            }
             this.allBricks.push(arr);
        }
    }

    private seletedBrock = [];
    private Btn_platformClick(){
        
        this.calculateMi();
        let a = JSON.stringify(this.finalList);
        alert(a+" x="+this.posX +" y="+this.posY);
        console.log(a);
        
    }

    private Btn_RefreshClick(){
        this.refresh();
    }

    private refresh(){
        this.imgs.forEach(element => {
            element.source = "Game_json.Img_platformblock02";
        });
        let widthNum = this.mPanel.width/GlobalClass.GameInfoForConfig.blockUnitWidth;
        let heightNum = this.mPanel.height/GlobalClass.GameInfoForConfig.blockUnitWidth;
          for(let i=0;i<widthNum;i++){
            for(let j=0;j<heightNum;j++){
                this.allBricks[i][j] = 0;
               
            }
          }
        this.seletedBrock = [];
        this.finalList = [];
    }

    private posX = 0;
    private posY = 0;
    private calculateMi(){
        let minX = -1;
        let minY = -1;
        let maxX = -1;
        let maxY = -1;
        let widthNum = this.mPanel.width/GlobalClass.GameInfoForConfig.blockUnitWidth;
        let heightNum = this.mPanel.height/GlobalClass.GameInfoForConfig.blockUnitWidth;
          for(let i=0;i<widthNum;i++){
            for(let j=0;j<heightNum;j++){
                if(this.allBricks[i][j] == 1){
                    this.seletedBrock.push(i+"_"+j);
                    if(minX==-1){
                        minX = i;
                        minY = j;
                        maxX = i;
                        maxY = j;
                    }
                    if(j<minY){
                        minY = j;
                    }else if(j>=maxY){
                        maxY = j;
                    }
                    if(i<minX){
                        minX = i;
                    }else if(i>=maxX){
                        maxX = i;
                    }
                }
            }
          }
        let middleX = (minX+maxX)/2;
        let middleY = (minY+maxY)/2;
        this.posX = middleX*2+1;
        this.posY = middleY*2+1;

        this.seletedBrock.forEach(element => {
            let numArr = element.split("_");
            let x = parseInt(numArr[0]);
            let y = parseInt(numArr[1]);
            this.finalList.push([x-middleX,(y-middleY)]);
        });


    }

    private finalList = [];
}