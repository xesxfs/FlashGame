/**
 *
 * @author 
 *
 */
class TestPanelController extends KFController{ 
    
	
	protected init(){
    	super.init();
         this.ListenObjList = [ {event:egret.TouchEvent.TOUCH_END,items:{
                                                                    "Btn_Close":"",
                                                                    "Btn_Register":"",
                                                    },},
                            
                            ];//添加btn名为key，值为冷却时间，然后在类中添加btn名+Click的函数，即可自动注册btn事件 ,如 Btn_MyBankClick为函数名
        this.EventsList = [
                MsgID.GAME.EndlessJigsawInfo,
            ];
        
	}
	
    protected onReady() {

    }

    protected onShow(){//在界面上显示出来
        this.mPanel.Input_Score.text = "";
        this.mPanel.Input_round.text = "";
    }

    private Btn_RegisterClick(){
        let score = this.mPanel.Input_Score.text;
        let round = this.mPanel.Input_round.text;

        let js = {
            score:score,
            round:round,
        }
        WebSocketMgr.getInstance().SendOneceMsg(MsgID.GAME.EndlessJigsawInfo,JSON.stringify(js));
    }

     private on100900_event(event: egret.Event): void {
        console.log("on100900_event");
        let msg:MSGBase = <MSGBase>event.data;
        let dataStr = msg.getDataStr();
        
        let jsObj = JSON.parse(dataStr);
        if(jsObj["code"]==200){
            console.log("测试数据=================="+dataStr);
            // KFControllerMgr.showTips("设置")
        }
    }

    private Btn_CloseClick(){
        this.mPanel.hide();
    }
}