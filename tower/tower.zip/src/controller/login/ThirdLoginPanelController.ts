/**
 *
 * @author 
 *
 */
class ThirdLoginPanelController extends KFController {


    protected init() {
        super.init();
        this.ListenObjList = [{
            event: egret.TouchEvent.TOUCH_END, items: {
                "Btn_Login": "",
                "Btn_Register": "",
                "Btn_Find": "",
                "Btn_Close":"",
                "Btn_Guest":"",
            },
        },
        {
            event: egret.TouchEvent.CHANGE, items: {
                "Toggle_Remember": "",
            },
        },

        ];//添加btn名为key，值为冷却时间，然后在类中添加btn名+Click的函数，即可自动注册btn事件 ,如 Btn_MyBankClick为函数名
        this.EventsList = [
            // MsgID.USER.Login,
        ];
    }

    private Btn_GuestClick(){
         let guestAcc = egret.localStorage.getItem("guestAccount");
        if(guestAcc==null||guestAcc==""){
            if(DeviceUtils.IsWeb){
                guestAcc = new Date().getTime()+"";
                DeviceUtils.GuestLogin(guestAcc);
            }else{
                let js = {
                    // eventType:SendPlugins.Login_guest+"",
                };
                ChannelManager.Login(js);
            }
        }else{
            DeviceUtils.GuestLogin(guestAcc);
        }
    }

    private Btn_LoginClick() {
        if (this.mPanel.Input_Account.text == "") {
            KFControllerMgr.showTips("手机号码不能为空", 2, 0);
            return;
        }
        if (this.mPanel.Input_Account.text.length < 11) {
            KFControllerMgr.showTips("手机号码不足11位", 2);
            return;
        }
        if (!CommonFuc.checkePhone(this.mPanel.Input_Account.text)) {
            KFControllerMgr.showTips("手机号码格式不对", 2);
            return;
        }
        if (this.mPanel.Input_PSW.text == "") {
            KFControllerMgr.showTips("密码不能为空", 2, 0);
            return;
        }
        let phone = this.mPanel.Input_Account.text;
        let psw = this.mPanel.Input_PSW.text;

        let pswhash;
        let accid;
        SendMsgForWebService.Login(phone, psw, (result) => {
            console.log(result);
            let jsObj = JSON.parse(result);
            if (jsObj["code"] == 200) {
                pswhash = jsObj["info"]["password_hash"];
                accid = jsObj["info"]["account_id"];
                let js = { 
                    account_id: accid,
                    password_hash: pswhash
                }
                WebSocketMgr.getInstance().SendOneceMsg(MsgID.USER.Login, JSON.stringify(js));
            } else {
                KFControllerMgr.showTips(jsObj["info"]);
            }
        });

        if (this.mPanel.Toggle_Remember.selected) {
            egret.localStorage.setItem("account", phone);
            egret.localStorage.setItem("password", psw);
        } else {
            egret.localStorage.setItem("account", "");
            egret.localStorage.setItem("password", "");
        }
    }

    private Btn_RegisterClick() {
        KFControllerMgr.getCtl(PanelName.RegisterPanel).show();
    }
    private Btn_FindClick() {
        KFControllerMgr.getCtl(PanelName.FindPSWPanel).show();
    }
    private Toggle_RememberClick() {
        if (this.mPanel.Toggle_Remember.selected) {
            egret.localStorage.setItem("rememberAccount", "1");
        } else {
            egret.localStorage.setItem("rememberAccount", "0");
        }
    }

    protected onReady() {
    }

    private loadAccount() {
        this.mPanel.Input_Account.text = egret.localStorage.getItem("account");
        this.mPanel.Input_PSW.text = egret.localStorage.getItem("password");
    }

    protected onShow() {//在界面上显示出来
        let remember = egret.localStorage.getItem("rememberAccount");
        if (remember == null) {
            remember = "0";
        }

        if (remember == "0") {
            this.mPanel.Toggle_Remember.selected = false;
        } else if (remember == "1") {
            this.mPanel.Toggle_Remember.selected = true;
        }
        this.loadAccount();
        // this.loadAni();
     

        // SendMsgForWebService.DataReport((result)=>{
        //     console.log(result);
        // });
    }

    // private on100002_event(event: egret.Event): void {
    //     console.log("on100002_event");
    //     let msg: MSGBase = <MSGBase>event.data;
    //     let dataStr = msg.getDataStr();

    //     let jsObj = JSON.parse(dataStr);
    //     if (jsObj["code"] == 200) {//登录成功
    //         KFControllerMgr.showTips("登录成功", 1);
    //         GlobalClass.CurrentUser = new PlayerInfo().parseData(jsObj["info"]);
    //         GlobalClass.Game.isReloadGame = jsObj["info"]["reconnect"];
    //         KFSceneManager.getInstance().replaceScene(SceneName.Hall);
    //         GlobalClass.Hall.npcLevel = jsObj["info"]["role_level"];
    //     }
    // }

    private Btn_CloseClick() {
        this.mPanel.hide();
    }

    private loadAni() {
        RES.addEventListener(RES.ResourceEvent.GROUP_COMPLETE, this.loadAniCB, this);
        RES.loadGroup("LoginAni");
    }

    private loginFactory: dragonBones.EgretFactory;
    private loadAniCB(event: RES.ResourceEvent) {
        if (event.groupName == "LoginAni") {
            RES.removeEventListener(RES.ResourceEvent.GROUP_COMPLETE, this.loadAniCB, this);
            let skeName = "dl2_ske_json";
            let texName = "dl2_tex_json";
            let pngName = "dl2_tex_png";
            this.loginFactory = new dragonBones.EgretFactory();
            this.loginFactory.addDragonBonesData(dragonBones.DataParser.parseDragonBonesData(RES.getRes(skeName)));
            this.loginFactory.addTextureAtlasData(new dragonBones.EgretTextureAtlas(RES.getRes(pngName), RES.getRes(texName)));
            this.initLogigAni();
        }
    }

    private initLogigAni() {
        var armature = this.loginFactory.buildArmature("armatureName");
        armature.animation.play();
        dragonBones.WorldClock.clock.add(armature);
        var clip = armature.display;
        let a = egret.MainContext.instance.stage.width / 2;
        // clip.x = egret.MainContext.instance.stage.width / 2;
        clip.x = 360
        clip.y = 380;
        this.mPanel.addChild(clip);
    }

    private autoLogin() {
        this.mPanel.Input_Account.text = GlobalClass.Login.RegisterAccount;
        this.mPanel.Input_PSW.text = GlobalClass.Login.RegisterPSW;
        this.mPanel.Toggle_Remember.selected = true;
        this.Btn_LoginClick();
    }

    protected destroy() {
        AnimationMgr.getInstance().stopTick();
        super.destroy();
    }
}