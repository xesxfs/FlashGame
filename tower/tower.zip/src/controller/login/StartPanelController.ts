/**
 *
 * @author 
 *
 */
class StartPanelController extends KFController{ 
    
	
	protected init(){
    	super.init();
         this.ListenObjList = [ 
                            
                            ];//添加btn名为key，值为冷却时间，然后在类中添加btn名+Click的函数，即可自动注册btn事件 ,如 Btn_MyBankClick为函数名
        this.EventsList = [
            MsgID.USER.SERVER_LOGINSUCCESS
            ];
        
	}
	
    protected onReady() {
        let a = [];
        let b = a.shift();
        console.log("");
    }


    protected onShow(){//在界面上显示出来
        let a = [
            "TipsPanel",
            "LevelInfoPanel",
            "ShopPanel",
            "AchieveMentPanel",
            "InventoryPanel",
            "MailPanel",
            "RankPanel",
            "SignPenel"];
        let b = "TipsPanel";
        a.forEach(element => {
            if(element==b){
                console.log("");
            }
        });
    }
	
    private on90001_event(event: egret.Event): void {
        console.log("on90001_event");
        let msg:MSGBase = <MSGBase>event.data;
        msg.getData().position = 0;
        let data = msg.getData();
        console.log("msg="+msg.getDataStr());

        KFSceneManager.getInstance().replaceScene(SceneName.Login);

       
    }
    
    protected setOnClickListener() {
    }

    protected removeOnClickListener() {
    }
    

    private Btn_CloseClick(){
        this.mPanel.hide();
    }
}