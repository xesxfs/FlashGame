/**
 *
 * @author 
 *
 */
class LoginChoicePanelController extends KFController {

    private data;
    private jsonHaveLoaded = false;
    private childrenHaveReady = false;
    private haveInit = false;
    protected init() {
        super.init();
        this.ListenObjList = [{
            event: egret.TouchEvent.TOUCH_END, items: {
                // "Btn_Login1":"",
                "Btn_Login2": "",
                // "Btn_Login3":"",
            },
        },

        ];//添加btn名为key，值为冷却时间，然后在类中添加btn名+Click的函数，即可自动注册btn事件 ,如 Btn_MyBankClick为函数名
        this.EventsList = [
            MsgID.USER.Login,
        ];
    }

    private LoginData;

    protected onReady() {
        let configStr = {
            LoginNum: 3,
            LoginWay: [
                {
                    type: 4
                }, {
                    type: 3
                }, {
                    type: 0
                }
            ]
        }

        GlobalClass.GameInfoForConfig.gameConfig = configStr;
        this.childrenHaveReady = true;
        if (this.jsonHaveLoaded && this.childrenHaveReady) {
            this.initButton();
        }
        this.parseLoginInfoText();
    }

    public parseLoginInfoText() {
        RES.addEventListener(RES.ResourceEvent.CONFIG_COMPLETE, this.onConfigComplete, this);
        RES.addEventListener(RES.ResourceEvent.CONFIG_LOAD_ERROR, this.onConfigLoadErr, this);
        RES.getResByUrl("resource/config/BtnLoginType.json", this.onConfigComplete, this, RES.ResourceItem.TYPE_JSON);
    }

    private onConfigComplete(event: RES.ResourceEvent): void {
        this.data = event;
        this.jsonHaveLoaded = true;
        if (this.jsonHaveLoaded && this.childrenHaveReady) {
            this.initButton();
        }
    }

    private onConfigLoadErr(event: RES.ResourceEvent): void {
        console.log("onConfigLoadErr");
    }

    protected onShow() {//在界面上显示出来
        // egret.setTimeout(this.loadAni, this, 1000);
        this.loadAni();
        // if (GlobalClass.Login.isSwitchingAccount) {
        //     GlobalClass.Login.isSwitchingAccount = false;
        //     SendMsgForWebService.Login3rd(GlobalClass.Login.SwitchAccountData["userID"], GlobalClass.Login.SwitchAccountData["token"], (result) => {
        //         console.log("isSwitchingAccount " + result);
        //         let jsObj = JSON.parse(result);
        //         if (jsObj["code"] == 200) {
        //             let pswhash = jsObj["info"]["password_hash"];
        //             let accid = jsObj["info"]["account_id"];
        //             let js = {
        //                 account_id: accid,
        //                 password_hash: pswhash
        //             }
        //             WebSocketMgr.getInstance().SendOneceMsg(MsgID.USER.Login, JSON.stringify(js));
        //         } else {
        //             KFControllerMgr.showTips(jsObj["info"]);
        //         }
        //     });
        // }
    }

    private resetView() {
        this.mPanel.Btn_Login1.visible = false;
        this.mPanel.Btn_Login2.visible = false;
        this.mPanel.Btn_Login3.visible = false;
    }

    private initButton() {
        if (this.haveInit) {
            return;
        }

        // for(let i=0;i<3;i++){
        //      let but = this.mPanel.buttonGroup.getChildAt(i);
        //     but.visible = false;
        // }

        this.haveInit = true;

        // for (let i = 0; i < GlobalClass.GameInfoForConfig.gameConfig["LoginNum"]; i++) {
        //     let but = this.mPanel.buttonGroup.getChildAt(i);
        //     if (i == 0 || i == 2) { return };
        //     but.visible = true;
        //     let type = GlobalClass.GameInfoForConfig.gameConfig["LoginWay"][i]["type"];//按钮类型
        //     let butData = this.data["ButtonSetting"][type];
        //     but.getChildAt(1).text = butData["BtnName"];

        //     //赋值按钮事件
        //     this.AddClickEvent(but, egret.TouchEvent.TOUCH_TAP, () => {
        //         let funName = butData["BtnAction"];
        //         this[funName]();
        //     }, this);
        // }
    }

    private on100002_event(event: egret.Event): void {
        console.log("on100002_event");
        let msg: MSGBase = <MSGBase>event.data;
        let dataStr = msg.getDataStr();

        let jsObj = JSON.parse(dataStr);
        if (jsObj["code"] == 200) {//登录成功
            KFControllerMgr.showTips("登录成功", 1);
            GlobalClass.CurrentUser = new PlayerInfo().parseData(jsObj["info"]);
            GlobalClass.Game.isReloadGame = jsObj["info"]["reconnect"];
            KFSceneManager.getInstance().replaceScene(SceneName.Hall);
            GlobalClass.Hall.npcLevel = jsObj["info"]["role_level"];
        }
    }

    /// <summary>
    /// 手机登录按钮
    /// </summary>
    /// <param name="_go"></param>
    private OnBtn_PhoneLoginClick() {
        KFControllerMgr.getCtl(PanelName.ThirdLoginPanel).show();
    }

    private loadAni() {
        RES.addEventListener(RES.ResourceEvent.GROUP_COMPLETE, this.loadAniCB, this);
        RES.loadGroup("LoginAni");
    }

    private loginFactory: dragonBones.EgretFactory;
    private loadAniCB(event: RES.ResourceEvent) {
        if (event.groupName == "LoginAni") {
            RES.removeEventListener(RES.ResourceEvent.GROUP_COMPLETE, this.loadAniCB, this);
            let skeName = "dl2_ske_json";
            let texName = "dl2_tex_json";
            let pngName = "dl2_tex_png";
            this.loginFactory = new dragonBones.EgretFactory();
            this.loginFactory.addDragonBonesData(dragonBones.DataParser.parseDragonBonesData(RES.getRes(skeName)));
            this.loginFactory.addTextureAtlasData(new dragonBones.EgretTextureAtlas(RES.getRes(pngName), RES.getRes(texName)));
            this.initLogigAni();
        }
    }

    private initLogigAni() {
        var armature = this.loginFactory.buildArmature("armatureName");
        AnimationMgr.getInstance().startTick();
        dragonBones.WorldClock.clock.add(armature);
        var clip = armature.display;
        // let a = egret.MainContext.instance.stage.width / 2;
        // clip.x = egret.MainContext.instance.stage.width / 2;
        clip.x = 360
        clip.y = 380;
        this.mPanel.addChild(clip);
        armature.animation.gotoAndPlay("newAnimation");
    }


    /// <summary>
    /// 游客登录按钮
    /// </summary>
    /// <param name="_go"></param>
    public Btn_Login2Click() {
        console.log("OnBtn_AnonymousLoginClick");
        let guestAcc = egret.localStorage.getItem("guestAccount");
        if (guestAcc == null || guestAcc == "") {
            // if (DeviceUtils.IsWeb) {
            guestAcc = new Date().getTime() + "";
            DeviceUtils.GuestLogin(guestAcc);
            // } else {
            // let js = {
            //     eventType: SendPlugins.Login_guest + "",
            // };
            // ChannelManager.Login(js);
            // }
        } else {
            DeviceUtils.GuestLogin(guestAcc);
        }
    }



    /// <summary>
    /// 登陆0
    /// </summary>
    /// <param name="go"></param>
    public OnBtn_3001LoginClick() {
        console.log("LoginSend3001 or AnySDK");
        // PluginEvent.executePluginsEvents(SendPlugins.Login_One, "");
    }
    /// <summary>
    /// 登陆1
    /// </summary>
    /// <param name="go"></param>
    public OnBtn_3002LoginClick() {
        console.log("LoginSend3002");
        // PluginEvent.executePluginsEvents(SendPlugins.Login_Two, "");
    }

    /// <summary>
    /// 登陆2
    /// </summary>
    /// <param name="go"></param>
    public OnBtn_3003LoginClick() {
        console.log("LoginSend3003");
        // PluginEvent.executePluginsEvents(SendPlugins.Login_Three, "");
    }
}