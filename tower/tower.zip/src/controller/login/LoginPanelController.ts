/**
 *
 * @author 
 *
 */
class LoginPanelController extends KFController{ 
    
	
	protected init(){
    	super.init();
         this.ListenObjList = [ {event:egret.TouchEvent.TOUCH_END,items:{
                                                                            "Btn_Login":"",
                                                                            "Btn_Guest":"",

                                                    },},
                            
                            ];//添加btn名为key，值为冷却时间，然后在类中添加btn名+Click的函数，即可自动注册btn事件 ,如 Btn_MyBankClick为函数名
        this.EventsList = [
                MsgID.USER.Login,
            ];
        
	}
	
    protected onReady() {

    }

    protected onShow(){//在界面上显示出来
        let a = SkillFactory.getSkill(SkillType.AddBlood);
        console.log();
    }
	
    private on100002_event(event: egret.Event): void {
        console.log("on100002_event");
        let msg:MSGBase = <MSGBase>event.data;
        let dataStr = msg.getDataStr();
        
       let jsObj = JSON.parse(dataStr);
       if(jsObj["code"]==200){//登录成功
            GlobalClass.CurrentUser = new PlayerInfo().parseData(jsObj["info"]);
            GlobalClass.Game.isReloadGame = jsObj["info"]["reconnect"];
           KFControllerMgr.getCtl(PanelName.HallPanel).show();
       }
    }
    
    protected setOnClickListener() {
    }

    protected removeOnClickListener() {
    }
    

    private Btn_LoginClick(){

    }

    private Btn_GuestClick(){
        let phone = "13800138000";
        let psw = "123456";
        let pswhash = "";
        let accid = "";
        SendMsgForWebService.Login(phone,psw,(result)=>{
            console.log(result);

            let jsObj = JSON.parse(result);
            if(jsObj["code"]==200){
                pswhash = jsObj["info"]["password_hash"];
                accid = jsObj["info"]["account_id"];
                
                // accid = '10020';
                // pswhash = 'sha256:10000$lByw1E7t$90194c387f937ce5eb8971f503745953d743d59cb932d7a76a66fe8874cbe844';
                let js = {
                        account_id:accid,
                        password_hash:pswhash
                }
                WebSocketMgr.getInstance().SendOneceMsg(MsgID.USER.Login,JSON.stringify(js));
            }
        });
    }
}