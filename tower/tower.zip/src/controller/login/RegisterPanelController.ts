/**
 *
 * @author 
 *
 */
class RegisterPanelController extends KFController{

    private Timer:egret.Timer;
    private int_SendTime_ori = 60;
    private int_SendTime = 60;
    
    
	protected init(){
    	super.init();
         this.ListenObjList = [ {event:egret.TouchEvent.TOUCH_END,items:{
                                                                    "Btn_Register":"",
                                                                    "Btn_GetCode":"",
                                                                    "Btn_Close":","
                                                    },}
                            
                            ];//添加btn名为key，值为冷却时间，然后在类中添加btn名+Click的函数，即可自动注册btn事件 ,如 Btn_MyBankClick为函数名
        this.EventsList = [
                MsgID.CLIENT.GetSMSCode,
                MsgID.CLIENT.ResetCodeButton,
            ];
        
	}
	
    protected onReady() {
        
    }

    protected onShow(){//在界面上显示出来
        this.resetPanel();
        this.initTimer();
    }

    protected destroy(){
        this.Timer.removeEventListener(egret.TimerEvent.TIMER_COMPLETE,null,this);
        this.Timer.removeEventListener(egret.TimerEvent.TIMER,null,this);
        this.Timer.stop();
        this.Timer = null;
        super.destroy();
    }

    private on1009_event(event: egret.Event): void {
        console.log("on1009_event");
        let code = event.data;
        this.Resend();
     }

     private on1010_event(event: egret.Event): void {
        console.log("on1010_event");
        let code = event.data;
        this.ResendOver();
     }

    private initTimer(){
        this.Timer = new egret.Timer(1000,60);
        this.Timer.addEventListener(egret.TimerEvent.TIMER_COMPLETE,()=>{
            this.ResendOver();
        },this);
        this.Timer.addEventListener(egret.TimerEvent.TIMER,()=>{
            this.int_SendTime--; 
            this.mPanel.Btn_GetCode.getChildAt(1).text = LocalizationMgr.getText("重发(") + this.int_SendTime + ")";
        },this);
    }

    private Resend(){
        this.int_SendTime = this.int_SendTime_ori;
        this.disableBut( this.mPanel.Btn_GetCode);
        this.Timer.start();
    }

    private ResendOver(){
        this.enableBut( this.mPanel.Btn_GetCode);
        this.mPanel.Btn_GetCode.getChildAt(1).text =  LocalizationMgr.getText("获取验证码");
        this.int_SendTime = 0;
        this.Timer.reset();
    }

    private resetPanel(){
        this.mPanel.Input_PhoneNum.text = "";
        this.mPanel.Input_Code.text = "";
        this.mPanel.Input_PSW.text = "";
        this.mPanel.Input_PSWConfirm.text = "";
        this.hideTips();
    }

    private Btn_CloseClick(){
        this.mPanel.hide();
    }

    private hideTips(){
        this.mPanel.Input_PhoneNumTip.visible = false;
        this.mPanel.Input_CodeTip.visible = false;
        this.mPanel.Input_PSWTip.visible = false;
        this.mPanel.Input_PSWConfirmTip.visible = false;
        this.showTips1 = false;
        this.showTips2 = false;
        this.showTips3 = false;
        this.showTips4 = false;
    }

    private showTip(text,type){
        switch(type){
            case 1:
                if(!this.showTips1){
                    this.showTips1 = true;
                    this.mPanel.Input_PhoneNumTip.visible = true;
                    this.mPanel.Input_PhoneNumTip.text = text;
                }
            break;
            case 2:
                if(!this.showTips2){
                    this.showTips2 = true;
                    this.mPanel.Input_CodeTip.visible = true;
                    this.mPanel.Input_CodeTip.text = text;
                }
            break;
            case 3:
                if(!this.showTips3){
                    this.showTips3 = true;
                    this.mPanel.Input_PSWTip.visible = true;
                    this.mPanel.Input_PSWTip.text = text;
                }
            break;
            case 4:
                if(!this.showTips4){
                    this.showTips4 = true;
                    this.mPanel.Input_PSWConfirmTip.visible = true;
                    this.mPanel.Input_PSWConfirmTip.text = text;
                }
            break;

        }
    }

    private showTips1 = false;
    private showTips2 = false;
    private showTips3 = false;
    private showTips4 = false;

    private Btn_RegisterClick(){
        this.hideTips();
        let checkFail = false;
        if(this.mPanel.Input_PhoneNum.text == "") {
          this.showTip("手机号码不能为空",1);
          checkFail = true;
        }
        if (this.mPanel.Input_PhoneNum.text.length< 11)
        {
            this.showTip("手机号码不足11位",1);
            checkFail = true;
        }
        if(!CommonFuc.checkePhone(this.mPanel.Input_PhoneNum.text)){
            this.showTip("手机号码格式不对",1);
            checkFail = true;
        }
        if(this.mPanel.Input_Code.text == "") {
          this.showTip("验证码不能为空",2);
          checkFail = true;
        }
        if(this.mPanel.Input_PSW.text == "") {
          this.showTip("登录密码不能为空",3);
          checkFail = true;
        }
        if(this.mPanel.Input_PSW.text != this.mPanel.Input_PSWConfirm.text ) {
          this.showTip("两次输入密码不同!",3);
          this.showTip("两次输入密码不同!",4);
          checkFail = true;
        }

        if(this.mPanel.Input_PSW.text.length<6 || this.mPanel.Input_PSW.text.length>16){
           this.showTip("密码长度为6-16位!",3);
           this.showTip("密码长度为6-16位!",4);
           checkFail = true;
        }

        if(checkFail){
            return;
        }else{
            this.hideTips();
        }

        let phone = this.mPanel.Input_PhoneNum.text;
        let smsCode = this.mPanel.Input_Code.text;
        let psw = this.mPanel.Input_PSW.text;

        GlobalClass.Login.RegisterAccount = phone;
        GlobalClass.Login.RegisterPSW = psw;

        SendMsgForWebService.Register(phone,psw,smsCode,(result)=>{
            let jsObj = JSON.parse(result);
            if(jsObj["code"]==200){
                KFControllerMgr.showTips("注册成功");
                KFControllerMgr.getCtl(PanelName.ThirdLoginPanel).autoLogin();
                this.hide();
            }else{  
                 KFControllerMgr.showTips(jsObj["info"]);
            }
        });
    }

    private Btn_GetCodeClick(){
        this.hideTips();
        let checkFail = false;
        if(this.mPanel.Input_PhoneNum.text == "") {
          this.showTip("手机号码不能为空",1);
          checkFail = true;
        }
        if (this.mPanel.Input_PhoneNum.text.length< 11)
        {
            this.showTip("手机号码不足11位",1);
            checkFail = true;
        }
        if(!CommonFuc.checkePhone(this.mPanel.Input_PhoneNum.text)){
            this.showTip("手机号码格式不对",1);
            checkFail = true;
        }

        if(checkFail){
            return;
        }else{
            this.hideTips();
        }

        let phone = this.mPanel.Input_PhoneNum.text;

        SendMsgForWebService.GetMSMCode(phone,getCodeType.register,(result)=>{
            console.log(result);
            let jsObj = JSON.parse(result);
            if(jsObj["code"]==200){
                KFControllerMgr.showTips("验证码已发送，请注意查收!",1);
                this.int_SendTime = 60;
                NetEventMgr.getInstance().clientMsg(MsgID.CLIENT.GetSMSCode,"1");
            }else{  
                 KFControllerMgr.showTips(jsObj["info"]);
                NetEventMgr.getInstance().clientMsg(MsgID.CLIENT.ResetCodeButton,"1");
            }
        });
    }
}