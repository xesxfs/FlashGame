/**
 *
 * @author 
 *
 */
class GameSharePanelController extends KFController{ 
    
	
	protected init(){
    	super.init();
         this.ListenObjList = [ {event:egret.TouchEvent.TOUCH_END,items:{
                                                                            "Btn_Close":"",
                                                                            "Btn_WX":"",
                                                                            "Btn_QQ":"",
                                                                            "Btn_Friend":"",
                                                                            "Btn_Brog":"",
                                                    },},
                            
                            ];//添加btn名为key，值为冷却时间，然后在类中添加btn名+Click的函数，即可自动注册btn事件 ,如 Btn_MyBankClick为函数名
        this.EventsList = [
            ];
        
	}
	
    protected onReady() {
        
    }

    protected onShow(){//在界面上显示出来
         let level = Math.floor(GlobalClass.CurrentStage.StageNumber/100-1)*10+GlobalClass.Game.ShowInfoLevel%100;
       this.mPanel.stageNum.text = level+"";
    }

    private Btn_CloseClick(){
        this.mPanel.hide();
    }

    private Btn_WXClick(){
        this.createSharePic();
        
    }

    private Btn_QQClick(){
        //  selectImage(this.selectedHandler,this);
    }

    private Btn_FriendClick(){

    }

    private Btn_BrogClick(){

    }

    private createSharePic(){
        var renderTexture:egret.RenderTexture = new egret.RenderTexture();
        renderTexture.drawToTexture(this.mPanel.winInfo);
        renderTexture.saveToFile("image/png", "a/down.png");
    }

    private selectedHandler(thisRef:any,imgURL:string,file:Blob):void {
        //alert("img selected"+imgURL);
        RES.getResByUrl(imgURL,thisRef.compFunc,thisRef,RES.ResourceItem.TYPE_IMAGE);
        //getImageData(file,thisRef.bytesHandler,thisRef);
    }
    private bytesHandler(thisRef:any,imgBytes:ArrayBuffer):void {
        console.log("大图数据:"+imgBytes);
    }
    private compFunc(texture:egret.Texture):void {
        //alert("compFunc"+texture);
        var imgReview:egret.Bitmap = new egret.Bitmap(texture);
        this.mPanel.winInfo.addChild(imgReview);
    }
}