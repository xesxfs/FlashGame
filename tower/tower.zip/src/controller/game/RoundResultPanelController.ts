/**
 *
 * @author 
 *
 */
class RoundResultPanelController extends KFController{ 
    private NPCAnis = [];
    private chesstAni ;
    private haveShow = false;
	protected init(){
    	super.init();
         this.ListenObjList = [
                            
                            ];//添加btn名为key，值为冷却时间，然后在类中添加btn名+Click的函数，即可自动注册btn事件 ,如 Btn_MyBankClick为函数名
        this.EventsList = [
            ];
	}
	
    protected onReady() {
        
    }

    protected destroy() {
        AnimationMgr.getInstance().unloadChestSkeleton();
        egret.Tween.removeAllTweens();
        super.destroy();
    }

    protected onShow(){//在界面上显示出来
        if(!this.haveShow){
            this.haveShow = true;
            this.initAni();
            this.initState();
            this.invoke(2,this.showRoundWinerAni,this);
            if(GlobalClass.Game.gameIsOver){
                AnimationMgr.getInstance().loadChestSkeleton(()=>{
                    this.initChestANi();
                },this);
            }
        }
    }

    private initState(){
        this.mPanel.planeCombination.x = -500;
        let a = GlobalClass.Game.gameRoundResults;
        console.log("test="+JSON.stringify(a));
        for(let i=0;i<2;i++){
            let winNum = GlobalClass.Game.gameRoundResults[i];
            if(GlobalClass.Game.winnerSeatID==-1){//平局
                winNum = winNum -1;
            }else{
                if(i==GlobalClass.Game.winnerSeatID){
                    winNum = winNum -1;
                }
            }
            
            if(winNum<0){
                winNum = 0;
            }
            this.NPCAnis[i].display.y = this.NPCAnis[i].display.y+(this.dely)*winNum;
            this.NPCAnis[i].display.x = this.NPCAnis[i].display.x+this.NPCAnis[i].display.scaleX *this.delx*winNum;
            let flag = this.mPanel.flagGroup.getChildAt(i);
            flag.y = flag.y+winNum*this.flagDely;

            let nick = new eui.Label(GlobalClass.Game.MultiPlayers[i]["nick"]);
            this.NPCAnis[i].display.addChild(nick);
            nick.anchorOffsetX = nick.width/2;
            nick.anchorOffsetY = nick.height/2;
            nick.y = -this.NPCAnis[i].display.height;
            if(i==0){
                nick.scaleX = -1;
            }

            // this.mPanel.nicks.getChildAt(i).text = GlobalClass.Game.MultiPlayers[i]["nick"];
        }
    }
    private delx = -80;
    private dely = -70;
    private flagDely = -110;

    private initAni(){
        for(let i=0;i<2;i++){
            let type = 2;
            if(GlobalClass.Game.GameMode==2){
                type = GlobalClass.Game.PlayerSettings[i]["npc_type"]-1;
            }
            
            let roleAni = AnimationMgr.getInstance().getRoleSke(type,0,0,0);
            this.mPanel.AniGroup.addChild(roleAni.display);
            
            if(i==0){
                roleAni.display.x = 0+roleAni.display.width/2-20;
                roleAni.display.scaleX = -1;
            }else{
                roleAni.display.x = 580+roleAni.display.width/2+20;
            }
            roleAni.display.y = 1280 - roleAni.display.height/2-30;
            this.NPCAnis.push(roleAni);
            roleAni.addEventListener( dragonBones.AnimationEvent.LOOP_COMPLETE, (event)=>{
                if(roleAni.animation.lastAnimationName=="Jump"){
                    roleAni.display.visible = false;
                    roleAni.display.x = roleAni.display.x + this.delx*roleAni.display.scaleX;
                    roleAni.display.y = roleAni.display.y + this.dely;
                   
                    roleAni.animation.gotoAndStop("Idle",-1);
                    roleAni.display.visible = true;
                    roleAni.animation.play();
                    this.flatMoveUp();
                }
            },this);
            roleAni.animation.play();
        }


        
    }

    private initChestANi(){
        this.chesstAni = AnimationMgr.getInstance().getChestSke();
        this.mPanel.chestGroup.addChild(this.chesstAni.display);
        
        this.chesstAni.display.x = 10+this.chesstAni.display.width;
        this.chesstAni.display.y = 330+this.chesstAni.display.height;

         this.chesstAni.addEventListener( dragonBones.AnimationEvent.LOOP_COMPLETE, (event)=>{
             GlobalClass.Game.currentRound = 1;
             KFControllerMgr.getCtl(PanelName.MultiGameResultPanel).show();
        },this);
    }

    private showRoundWinerAni(){
        if(GlobalClass.Game.winnerSeatID==-1){//打平
            this.NPCAnis.forEach(element => {
                element.animation.gotoAndPlay("Jump",0,0,1);
            });
        }else{
            this.NPCAnis[GlobalClass.Game.winnerSeatID].animation.gotoAndPlay("Jump",0,0,1);
        }
    }

    private flatIsMoving = false;
    private flatMoveUp(){
        if(this.flatIsMoving){
            return ;
        }
        this.flatIsMoving = true;
        let flag;
        if(GlobalClass.Game.winnerSeatID==-1){//打平
            for(let i=0;i<2;i++){
                flag = this.mPanel.flagGroup.getChildAt(i);
                this.flagAni(flag);
            }
        }else{
            flag = this.mPanel.flagGroup.getChildAt(GlobalClass.Game.winnerSeatID);
            this.flagAni(flag);
        }
    }

    private flagAni(flag){
        egret.Tween.get(flag).to({y:flag.y+this.flagDely},1000,egret.Ease.backIn).call(function (){
            if(GlobalClass.Game.gameIsOver){
                this.planeMove();
            }else{
                this.invoke(2,this.gotoNextRound,this);
            }
		},this);
    }

    private planeIsMoving = false;
    private planeMove(){
            if(this.planeIsMoving){
                return ;
            }
            this.planeIsMoving = true;
          egret.Tween.get(this.mPanel.planeCombination).to({x:200},3000,egret.Ease.sineOut).call(function (){

              this.checkFall();
              this.invoke(1,()=>{
                  egret.Tween.get(this.mPanel.PlaneGroup).to({x:500},3000,egret.Ease.sineOut);
              },this);
		},this)
    }

    private checkFall(){
         egret.Tween.get(this.mPanel.chestGroup).to({y:550},1000,egret.Ease.sineOut).call(function (){
            this.chesstAni.animation.play();
		},this);
    }

    private isGoingToNextRound = false;
    private gotoNextRound(){
           if(this.isGoingToNextRound){
                return ;
            }
            this.isGoingToNextRound = true;
        //移除当前面板
        GlobalClass.Game.currentRound++;
       KFSceneManager.getInstance().replaceScene(SceneName.Fight);
    }
}