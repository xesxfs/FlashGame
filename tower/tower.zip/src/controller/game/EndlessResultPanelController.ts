/**
 *
 * @author 
 *
 */
class EndlessResultPanelController extends KFController{ 
    
	
	protected init(){
    	super.init();
         this.ListenObjList = [ {event:egret.TouchEvent.TOUCH_END,items:{
                                                                "Btn_Relive":"",
                                                                "Btn_Back":"",
                                                    },},
                            
                            ];//添加btn名为key，值为冷却时间，然后在类中添加btn名+Click的函数，即可自动注册btn事件 ,如 Btn_MyBankClick为函数名
        this.EventsList = [
            ];
        
	}
	
    protected onReady() {
        // AnimationMgr.getInstance().loadSkeleton(this.skeletonHaveLoad,this);
    }

    // private skeletonHaveLoad(){
    //       this.showRecordAni();
    // }

    protected onShow(){//在界面上显示出来
        this.mPanel.Score.text = GlobalClass.Game.currentScore;
        this.mPanel.historyScore.text = GlobalClass.Game.historyScore;
        if(GlobalClass.Game.isNewRecord){
            this.showRecordAni();
        }

        if(GlobalClass.Hall.newAchievement.length>0){
            KFControllerMgr.getCtl(PanelName.NewAchievementPanel).show();
        }
    }


    private showRecordAni(){
        let ani = AnimationMgr.getInstance().getSkeleton(skeletonType.xinjilu);
		this.mPanel.addChild(ani.display);
		ani.display.x = 360;
		ani.display.y = 360;
		ani.animation.play("play",1);
    }
    private Btn_BackClick(){
        GlobalClass.Game.GameMode = 3;
        KFSceneManager.getInstance().replaceScene(SceneName.Game);
    }

    private Btn_ReliveClick(){
        KFControllerMgr.showTips("复活次数不足");
    }
}