/**
 *
 * @author 
 *
 */
class GameMatchPanelController extends KFController{ 
    
	
	protected init(){
    	super.init();
         this.ListenObjList = [ {event:egret.TouchEvent.TOUCH_END,items:{"Btn_Cancel":"",
                                                    },},
                            
                            ];//添加btn名为key，值为冷却时间，然后在类中添加btn名+Click的函数，即可自动注册btn事件 ,如 Btn_MyBankClick为函数名
        this.EventsList = [
                MsgID.GAME.CancelMatch,
                MsgID.GAME.OpenGame,
            ];
	}
	
    protected onReady() {

    }

    protected onShow(){//在界面上显示出来
        this.mPanel.brickICon.rotation = 45;
        this.mPanel.brickICon.anchorOffsetX = this.mPanel.brickICon.width/2;
        this.mPanel.brickICon.anchorOffsetY = this.mPanel.brickICon.height/2;
        this.loadingAnimation();
    }
	
    private on100201_event(event: egret.Event): void {
        console.log("on100201_event");
        let msg:MSGBase = <MSGBase>event.data;
        let dataStr = msg.getDataStr();
        
        let jsObj = JSON.parse(dataStr);
        if(jsObj["code"]==200){
            KFControllerMgr.showTips("取消匹配成功");
            KFSceneManager.getInstance().replaceScene(SceneName.Hall);
        }
    }

    private on100301_event(event: egret.Event): void {
        console.log("on100301_event");
        let msg:MSGBase = <MSGBase>event.data;
        let dataStr = msg.getDataStr();
        
        let jsObj = JSON.parse(dataStr);
        if(jsObj["code"]==200){
            let playerInfos = jsObj["info"]["player_info"];
            let stageInfo = jsObj["info"]["stage"];
            let settingInfo = jsObj["info"]["settings"];
            
            GlobalClass.Game.PlayerSettings = [];
            GlobalClass.Game.MultiPlayers = [];
            GlobalClass.CurrentStage = new StageInfo().parseData(jsObj["info"]["stage"]);
            playerInfos.forEach(element => {
                GlobalClass.Game.MultiPlayers.push(new PlayerInfo().parseData(element));
            });
            settingInfo.forEach(element => {
                GlobalClass.Game.PlayerSettings.push(new SettingInfo().parseData(element));
            });
            GlobalClass.Game.PlayerRandomSeeds =  jsObj["info"]["random_seeds"];
            
            //移除当前面板
            GlobalClass.Game.isDebug = false;

            //初始化局数输赢信息
            GlobalClass.Game.gameRoundResults = [0,0,0,0];
            
            KFSceneManager.getInstance().replaceScene(SceneName.Fight);
        }
    }

    private loadingAnimation(){
        egret.Tween.get(this.mPanel.brickICon).to({rotation:-45},1000,egret.Ease.backOut).to({rotation:45},1000,egret.Ease.backOut)
        .call(function (){
            this.loadingAnimation();
		},this);
    }
    
    protected setOnClickListener() {
    }

    protected removeOnClickListener() {
    }
    

    private Btn_CancelClick(){
         let js = {
        };
        WebSocketMgr.getInstance().SendOneceMsg(MsgID.GAME.CancelMatch,JSON.stringify(js));
    }
}