/**
 *
 * @author 
 *
 */
class GamePanelController extends KFController {
    public localGame: GameComponent;
    private showGame: GameComponent;//多人对战时展示出来的层，用于接受玩家的及时操作
    private gameList: GameComponent[];//游戏层，第一个为玩家自身的游戏层，剩下的为多人对战时其他玩家的游戏层
    private curretnGame;//当前渲染的游戏层
    private showScreenShot = false;

    private updateLimitTime = 15;//快进时最多一个渲染帧处理多少网络堆积帧

    private isFastForward = false;//正在快进中 快进中不允许操作

    private currentRankList = [];

    private gameResult = [];//玩家的游戏结果,根据座位号排序 0代表输了 1代表赢了

    private screenShots = {}

    private roundIsOver = false;

    private isRestart = false;

    private stageData;//舞台的状态描述数据

    private isSuppling = false;

    //游戏的类型 0为竞速 1位生存 2为拼图
    private gameMode = 0;
    protected init() {
        super.init();
        this.ListenObjList = [{
            event: egret.TouchEvent.TOUCH_END, items: {
                "Btn_Test": "",
                "Toggle_Pause": "",
                "Btn_Resume": "",
                "Btn_Restart": "",
                "Btn_Exit": "",
                "Btn_BlinkLeft": "",
                "Btn_BlinkRight": "",
            },
        },
        ];//添加btn名为key，值为冷却时间，然后在类中添加btn名+Click的函数，即可自动注册btn事件 ,如 Btn_MyBankClick为函数名
        this.EventsList = [
            MsgID.GAME.LevelFinish,
            // MsgID.GAME.GameReady,
            // MsgID.GAMEPlay.GameStart,
            // MsgID.GAMEPlay.SendGameStateData,
            // MsgID.GAMEPlay.SendGameResult,
            MsgID.CLIENT.GameComponetResult,
            // MsgID.CLIENT.ReceiveNetMSG,
            // MsgID.GAMEPlay.GameOver,
            // MsgID.GAME.GetPing,
            // MsgID.CLIENT.AnotherLogin,
            // MsgID.GAME.EndlessFinish,
            // MsgID.GAME.EndlessJigsawInfo,
            // MsgID.GAME.GetJigsawSolution,
            // MsgID.GAME.GetLevelInfo,
            // MsgID.CLIENT.FinishGuideAndStart,
            // MsgID.GAMEPlay.RoundOver,
        ];
    }

    private Btn_BlinkLeftClick() {
        UserControl.getInstance().userMove(BlockControlType.BlinkLeft, 0, 0);
    }

    private Btn_BlinkRightClick() {
        UserControl.getInstance().userMove(BlockControlType.BlinkRight, 0, 0);
    }

    private Btn_ResumeClick() {
        this.resume();
        this.mPanel.pauseGroup.visible = false;
        this.onPauseCdAni();
    }

    private Btn_RestartClick() {
        KFSceneManager.getInstance().replaceScene(SceneName.Fight);
    }

    private Btn_ExitClick() {
        let sceneName = SceneName.Game;
        if (GlobalClass.Game.GameMode == 3) sceneName = SceneName.Hall
        KFSceneManager.getInstance().replaceScene(sceneName);
    }

    private Btn_TestClick() {
        // this.sendGameStateData();

        // WebSocketMgr.getInstance().closeSocket();

        // this.gameList.forEach(element => {
        //     element.testAddHeart();
        // });

        this.seneGameOver(GlobalClass.Game.PlayerSeatID);



    }

    private isPause = false;
    private Toggle_PauseClick(e: egret.Event) {
        this.pause();
        this.mPanel.pauseGroup.visible = true;
        this.onPauseCdAni();
    }

    public pause() {
        this.isPause = true;
        UserControl.getInstance().gamePause();
        this.gameList.forEach(element => {
            element.GamePause(true);
        });
    }

    public resume() {
        this.isPause = false;
        UserControl.getInstance().gameResume();
        this.gameList.forEach(element => {
            element.GamePause(false);
        });
    }

    protected onReady() {
        // GlobalClass.Game.isReloadGame = true;
        this.isPause = true;
        if (GlobalClass.Game.GameMode == 2) {
            GlobalClass.Game.PlayerNum = 2;
        }

        if (GlobalClass.Game.PlayerNum > 1) {
            this.mPanel.Toggle_Pause.visible = false;
            this.mPanel.ScreenGroup.visible = true;
            this.showScreenShot = true;
        } else {
            this.mPanel.Toggle_Pause.visible = true;
            this.mPanel.ScreenGroup.visible = false;
        }
        if (GlobalClass.Game.isDebug) {
            GlobalClass.CurrentStage.StageType = 2;
        }
        this.gameMode = GlobalClass.CurrentStage.StageType;

        GameTouchListener.getInstance().addListener(this.mPanel.GameComponent);

        this.initPlayerInfos();
        this.onInit();

        // if (GlobalClass.Game.GameMode == 1) {//单人闯关才有新手引导
        //     this.checkGuide();
        // }

        // AnimationMgr.getInstance().loadSkeleton(() => {
        //     this.loadFinish();
        //     AnimationMgr.getInstance().startTick();
        // }, this);
        this.loadFinish();
        AnimationMgr.getInstance().startTick();
    }
    private initData() {
        this.currentRankList = [];
        for (let i = 0; i < GlobalClass.Game.PlayerNum; i++) {
            this.currentRankList.push(1);
        }
        this.roundIsOver = false;
    }

    private showLevel() {
        let levelImg = "";
        let modeImg = "";
        switch (GlobalClass.CurrentStage.Difficulty) {
            case GameDifficulty.simple:
                levelImg = "yishuzi_json.jiandan";
                break;
            case GameDifficulty.normal:
                levelImg = "yishuzi_json.putong";
                break;
            case GameDifficulty.hard:
                levelImg = "yishuzi_json.kunnan";
                break;
        }
        switch (GlobalClass.CurrentStage.StageType) {
            case GameMode.speed:
                modeImg = "yishuzi_json.jingsu";
                break;
            case GameMode.survival:
                modeImg = "yishuzi_json.shengcun";
                break;
            case GameMode.jigsaw:
                modeImg = "yishuzi_json.pingtu";
                break;
        }


        this.mPanel.gameLevel.source = RES.getRes(levelImg);
        this.mPanel.gameMode.source = RES.getRes(modeImg);
        this.mPanel.modeGroup.visible = true;
        this.invoke(1, () => {
            egret.Tween.get(this.mPanel.modeGroup).to({ y: -600, alpha: 0 }, 3000, egret.Ease.sineOut).call(function () {
                this.mPanel.modeGroup.visible = false;
            }, this);
        }, this);
    }

    // //初始化座位号等信息
    private initPlayerInfos() {
        let index = 1;
        for (let i = 0; i < GlobalClass.Game.MultiPlayers.length; i++) {
            let element = GlobalClass.Game.MultiPlayers[i];
            if (element.player_id == GlobalClass.CurrentUser.player_id) {//当前玩家
                GlobalClass.Game.PlayerSeatID = i;
            }
        }
    }

    private loadFinish() {
        this.gameList.forEach(element => {
            element.skeletonHaveLoad();
        });

        if (GlobalClass.Game.isReloadGame && GlobalClass.Game.GameMode == 2) {
            this.StartPlaying();
            if (GlobalClass.Game.gameResetData != null || GlobalClass.Game.gameResetData != "") {
                //做好准备
                let isready = false;
                let a = GlobalClass.Game.readyPlayers;
                GlobalClass.Game.readyPlayers.forEach(element => {
                    if (element == GlobalClass.CurrentUser.player_id) {
                        isready = true;
                    }
                });
                if (!isready) {//如果断线前没有准备，连接回来后要发送准备
                    let js = {};
                    WebSocketMgr.getInstance().SendOneceMsg(MsgID.GAME.GameReady, JSON.stringify(js));
                }
            }
        } else {
            this.startGame();
        }
    }
    private startCDAni: dragonBones.Armature;
    /***显示倒计时 */
    private showStartAni(posx, posy) {
        this.disableBut(this.mPanel.Toggle_Pause);
        this.removeStartCDAni();
        this.startCDAni = AnimationMgr.getInstance().getSkeleton(skeletonType.daojishi, posx, posy);
        this.mPanel.CDownGroup.addChild(this.startCDAni.display);
        this.startCDAni.addEventListener(dragonBones.AnimationEvent.COMPLETE, this.startAniComplete, this);
        this.startCDAni.animation.play(null, 1);
        // if (!this.isPause) this.startCDAni.animation.play(null, 1);
    }

    /**倒计时暂停 */
    private onPauseCdAni() {
        if (this.startCDAni) {
            this.isPause ? this.startCDAni.animation.stop() : this.startCDAni.animation.play(null, 1);
        }
    }
    /***倒计时完成 */
    private startAniComplete() {
        this.enableBut(this.mPanel.Toggle_Pause);
        this.removeStartCDAni();
        //如果是多人游戏 则发送已准备好的消息
        if (GlobalClass.Game.GameMode == 2) {
            let js = {};
            WebSocketMgr.getInstance().SendOneceMsg(MsgID.GAME.GameReady, JSON.stringify(js));
        }
        this.StartPlaying();
    }

    /***清理倒计时 */
    private removeStartCDAni() {
        if (!this.startCDAni) return;
        /** */
        this.startCDAni.animation.reset();
        this.mPanel.CDownGroup.removeChild(this.startCDAni.display);
        this.startCDAni.removeEventListener(dragonBones.AnimationEvent.COMPLETE, this.startAniComplete, this);
        // this.startCDAni = null;
    }

    private StartPlaying() {
        var _self_ = this;
        if (GlobalClass.Game.GameMode != 3) {
            this.showLevel();
        } else {
            this.mPanel.modeGroup.visible = false;
        }
        // var callFunc = function () {
        _self_.gameList && _self_.gameList.forEach(element => {
            element.startPlaying();
        });
        UserControl.getInstance().gameStart();
        UserControl.getInstance().startCollectTouch();
        _self_.isPause = false;

        // }
    }

    private startGame() {
        let _self_ = this
        var callResume = function () {
            _self_.gameList.forEach(element => {
                element.beginFirst(() => {
                    _self_.showStartAni(360, 640);
                }, _self_)
            });
        }

        var callFunc2 = function () {
            switch (_self_.gameMode) {
                case 0:
                    Guide.step201To204(_self_, callResume);
                    break;
                case 1:
                    Guide.step401(_self_, callResume);
                    break;
                case 2:
                    Guide.step701(_self_, callResume);
                    break;
            }
        }

        var callFunc1 = function () {
            Guide.step103To105(_self_.mPanel, callFunc2);
        }

        Guide.step101To102(_self_.mPanel, callFunc1);



        this.gameList.forEach(element => {
            element.updateSkin();//第一次先把底座渲染出来
        });
    }

    private onInit() {
        this.gameList = new Array();
        let gameCls;
        if (GlobalClass.Game.GameMode != 3) {
            if (this.gameMode == 0) {
                gameCls = SpeedGame;
            } else if (this.gameMode == 1) {
                gameCls = SurvivalGame;
            } else {
                gameCls = JigsawGame;
            }
        } else {
            if (this.gameMode == 1) {
                gameCls = EndlessSurvivalGame;
            } else if (this.gameMode == 2) {
                gameCls = EndlessJigsawGame;
            }
        }

        for (let i = 0; i < 3; i++) {
            this.mPanel.ScreenGroup.getChildAt(i).visible = false;
        }

        let screetShotNum = 0;
        for (let i = 0; i < GlobalClass.Game.PlayerNum; i++) {
            let game = new gameCls(i);
            this.gameList.push(game);
            game.width = this.mPanel.width;
            game.height = this.mPanel.height;

            if (i == GlobalClass.Game.PlayerSeatID) {//玩家自己的玩家层
                this.localGame = game;

                this.mPanel.GameComponent.addChild(game);

                // if (GlobalClass.Game.GameMode == 2) {//如果是多人，加一个玩家操作层
                //     this.showGame = new gameCls(i);
                //     this.mPanel.GameComponent.addChild(this.showGame);
                //     game.visible = false;
                //     this.localGame.setHide(true);
                //     // let ss = this.mPanel.ScreenGroup.getChildAt(0);
                //     // ss.visible = true;
                //     // ss.init(this.localGame);
                // }
            } else {
                let ss = this.mPanel.ScreenGroup.getChildAt(screetShotNum) as ScreenShotUI;
                ss.visible = true;
                console.log("nick================" + GlobalClass.Game.MultiPlayers[i].nick);
                ss.init(game, GlobalClass.Game.MultiPlayers[i].nick);
                screetShotNum++;
                this.screenShots[i] = ss;
            }
            this.gameResult.push(-1);
        }
        if (this.showGame != null) {
            this.gameList.push(this.showGame);
        }

        GlobalClass.Game.currentShowPlayer = this.localGame.getSeatID();
        // if(this.playerNum==2){
        //     this.mPanel.ScreenGroup.getChildAt(0).scaleX = 1;
        // }else{
        //     this.mPanel.ScreenGroup.getChildAt(0).scaleX = 0.7;
        // }

        if (GlobalClass.Game.GameMode == 2) {
            this.invoke(1, this.CheckRank, this);
        }
        this.mPanel.addEventListener(egret.Event.ENTER_FRAME, this.onEnterFrame, this);

        this.startBGM();
    }

    private startBGM() {
        if (GlobalClass.CurrentStage.StageType == 0) {
            SoundMgr.Instance.playBGM(SoundMgr.speedbgm);
        }
        if (GlobalClass.CurrentStage.StageType == 1) {
            SoundMgr.Instance.playBGM(SoundMgr.survivalbgm);
        }
        if (GlobalClass.CurrentStage.StageType == 2) {
            SoundMgr.Instance.playBGM(SoundMgr.jigsawbgm);
        }
    }

    //渲染帧中做皮肤更新
    private onEnterFrame() {
        if (!this.isPause) {
            this.updatePhysisicsWorld();
            this.gameList.forEach(element => {
                element.updateSkin();
            });
        }
    }

    //由网络帧发动
    private updatePhysisicsWorld() {
        let count = 0;
        //操作队列读取
        while (count < this.updateLimitTime) {
            let msg = UserControl.getInstance().getOneMSG();
            if (msg == null) {
                break;
            }
            let len = this.gameList.length;

            for (let i = 0; i < msg.length; i++) {
                let msgObj: MSGBase = msg[i];
                let gameCom: GameComponent;
                gameCom = this.gameList[i];
                if (gameCom != null) {
                    gameCom.update(msgObj);
                }

                if (GlobalClass.Game.GameMode == 2 && i == GlobalClass.Game.PlayerSeatID) {//玩家自己的玩家层
                    // if(msgObj.getType()!=PlayerMSGType.Empty){
                    //     console.log(msgObj.toString());
                    // }

                    // if (this.showGame != null) {
                    //     this.handleNetMsg(msgObj);
                    // }
                }
            }

            NetEventMgr.getInstance().clientMsg(MsgID.CLIENT.ReceiveNetMSG, "");
            count++;
            //每过30秒 上报一次状态数据 每秒15次
            if (GlobalClass.Game.GameMode == 2 && !this.isSuppling) {//如果是多人游戏 则上报
                if (GlobalClass.Game.localFrameNum != 0 && GlobalClass.Game.localFrameNum % 450 == 0) {
                    this.sendGameStateData();
                }
            }
        }

        if (this.showScreenShot) {
            for (let i = 0; i < GlobalClass.Game.PlayerNum - 1; i++) {
                this.mPanel.ScreenGroup.getChildAt(i).screenShot();
            }
        }
    }

    protected destroy() {
        this.mPanel.removeEventListener(egret.Event.ENTER_FRAME, this.onEnterFrame, this);
        UserControl.getInstance().gameEnd();
        AnimationMgr.getInstance().unloadSkeleton();
        if (this.gameList != null) {
            this.gameList.forEach(element => {
                element.destroy();
                // this.mPanel.GameComponent.removeChild(element);//可能会引起内存泄漏
            });
            this.gameList = null;
        }

        this.localGame = null;
        this.showGame = null;
        this.curretnGame = null;
        this.screenShots = null;
        this.actionArr = null;
        this.actionUsedArr = null;
        this.gameResult = [];
        super.destroy();
      

        GlobalClass.Game.isReloadGame = false;
        GlobalClass.Game.localFrameNum = 0;
    }

    protected onShow() {//在界面上显示出来
        GlobalClass.Game.gameIsOver = false;
        this.actionArr = new Array();
        this.actionUsedArr = new Array();
    }

    private showGuild = false;
    private checkGuide() {


        // if (GlobalClass.CurrentUser.read_guide) {
        //     return;
        // }
        // let stepKey = GlobalClass.CurrentUser.player_id + "guideStep";
        // let step = egret.localStorage.getItem(stepKey);
        // let stepValue = parseInt(step);
        // if (stepValue < GlobalClass.GameInfoForConfig.GuildStep) {//未进行新手引导
        //     this.showGuild = true;
        //     KFControllerMgr.getCtl(PanelName.GuidePanel).show();
        // } else if (stepValue <= 10) {
        //     if (stepValue == 8 && GlobalClass.CurrentStage.StageType == 0) {//竞速模式
        //         this.showGuild = true;
        //         this.localGame.setGuildStep(stepValue);
        //     }
        //     if (stepValue == 9 && GlobalClass.CurrentStage.StageType == 1) {
        //         this.showGuild = true;
        //         this.localGame.setGuildStep(stepValue);
        //     }
        //     if (stepValue == 10 && GlobalClass.CurrentStage.StageType == 2) {
        //         this.showGuild = true;
        //         this.localGame.setGuildStep(stepValue);
        //     }
        // }
    }

    private on1001_event(event: egret.Event): void {
        // this.updatePhysisicsWorld();
    }

    private on1002_event(event: egret.Event): void {
        console.log("on1002_event");
        let data = <string>event.data;
        console.log("data=" + data);
        let jsObj = JSON.parse(data);
        if (!this.roundIsOver) {
            let seatID = jsObj.id;
            this.gameResult[seatID] = jsObj.result;
            let winnerID = -1;
            switch (GlobalClass.CurrentStage.StageType) {
                case GameMode.speed:
                    winnerID = this.speedCheckWinner(jsObj.result);
                    break;
                case GameMode.survival:
                    winnerID = this.survivalCheckWinner();
                    break;
                case GameMode.jigsaw:
                    winnerID = this.jigsawCheckWinner();
                    break;
            }

            //单人时,winner为-1表示失败  多人时winer为-1表示没决出胜负，游戏继续
            if (GlobalClass.Game.GameMode == 1) {
                this.seneGameOver(winnerID);
            } else if (GlobalClass.Game.GameMode == 2) {
                if (winnerID != -2) {
                    this.seneGameOver(winnerID);
                }
            } else {
                this.seneGameOver(winnerID);
            }
        }
    }

    //竞速检测 如果有一个赢，剩下的都输   如果剩下一个没输，则最后一个生存者获胜  如果倒计时到了都没决胜负，则通过高度决胜
    private speedCheckWinner(result): number {
        let winner = -2;
        let liverNum = 0;
        let liver = -1;
        let MaxHeight = 0;
        let winNum = 1;
        let len = this.gameResult.length;
        for (let i = 0; i < len; i++) {
            if (this.gameResult[i] == 1) {
                winner = i;
                break;
            } else if (this.gameResult[i] == -1) {
                liverNum++;
                liver = i;
            }
        }

        if (winner == -1 && liverNum == 1) {
            winner = liver;
        }

        if (result == -1) {//通过高度决胜
            for (let i = 0; i < GlobalClass.Game.PlayerNum; i++) {
                let element = this.gameList[i];
                if (element.GetBricksHigh() > MaxHeight) {
                    MaxHeight = element.GetBricksHigh();
                    winner = element.getSeatID();
                } else if (element.GetBricksHigh() == MaxHeight) {
                    winNum++;
                }
            }
        }

        if (winNum > 1) {
            winner = -1;
        }

        return winner;
    }

    //生存检测 如果有一个赢，剩下的都输   如果剩下一个没输，则最后一个生存者获胜
    private survivalCheckWinner(): number {
        let winner = -2;
        let liverNum = 0;
        let liver = -1;
        let len = this.gameResult.length;
        for (let i = 0; i < len; i++) {
            if (this.gameResult[i] == 1) {
                winner = i;
                break;
            } else if (this.gameResult[i] == -1) {
                liverNum++;
                liver = i;
            }
        }
        if (liverNum == 1) {
            winner = liver;
        }
        return winner;
    }

    //拼图 全部人都结束后，比较谁的数量多 单人玩法时直接判输赢
    private jigsawCheckWinner(): number {
        let winner = -2;
        let winNum = 1;
        //单人玩法时直接判输赢
        if (GlobalClass.Game.GameMode == 1) {
            if (this.gameResult[0] == 1) {
                winner = 0;
            }
        } else if (GlobalClass.Game.GameMode == 2) {
            let liverNum = 0;
            let maxBrickNum = 0;
            let len = this.gameResult.length;
            for (let i = 0; i < len; i++) {
                if (this.gameResult[i] == -1) {
                    liverNum++;
                }
            }
            if (liverNum == 0) {
                this.gameList.forEach(element => {
                    if (element.getusedBricksNum() > maxBrickNum) {
                        maxBrickNum = element.getusedBricksNum();
                        winner = element.getSeatID();
                    } else if (element.getusedBricksNum() == maxBrickNum) {
                        winNum++;
                    }
                });
            }
        }
        if (winNum > 1) {
            winner = -1;
        }
        return winner;
    }

    // private on100006_event(event: egret.Event): void {
    //     console.log("on100006_event");
    //     let msg: MSGBase = <MSGBase>event.data;
    //     let dataStr = msg.getDataStr();
    //     let jsObj = JSON.parse(dataStr);
    //     if (jsObj["code"] == 200) {
    //         GlobalClass.CurrentStage = new StageInfo().parseData(jsObj["info"]);
    //         GlobalClass.Game.isDebug = false;
    //         KFSceneManager.getInstance().replaceScene(SceneName.Fight);
    //     } else {
    //         KFControllerMgr.showTips(jsObj["info"]);
    //     }
    // }

    // private on100310_event(event: egret.Event): void {
    //     console.log("on100310_event");
    //     let msg: MSGBase = <MSGBase>event.data;
    //     let dataStr = msg.getDataStr();
    //     let jsObj = JSON.parse(dataStr);
    //     let gameover = jsObj["data"]["is_game_over"];
    //     if (gameover == 0) {
    //         let playerInfos = jsObj["data"]["player_info"];
    //         let stageInfo = jsObj["data"]["stage"];
    //         let settingInfo = jsObj["data"]["settings"];

    //         GlobalClass.Game.PlayerSettings = [];
    //         GlobalClass.Game.MultiPlayers = [];
    //         GlobalClass.CurrentStage = new StageInfo().parseData(jsObj["data"]["stage"]);
    //         playerInfos.forEach(element => {
    //             GlobalClass.Game.MultiPlayers.push(new PlayerInfo().parseData(element));
    //         });
    //         settingInfo.forEach(element => {
    //             GlobalClass.Game.PlayerSettings.push(new SettingInfo().parseData(element));
    //         });
    //         GlobalClass.Game.PlayerRandomSeeds = jsObj["data"]["random_seeds"];

    //         GlobalClass.Game.winnerSeatID = jsObj["data"]["win_seat_id"];

    //         if (GlobalClass.Game.winnerSeatID == -1) {//打平
    //             for (let i = 0; i < GlobalClass.Game.PlayerNum; i++) {
    //                 GlobalClass.Game.gameRoundResults[i]++;
    //             }
    //         } else {
    //             GlobalClass.Game.gameRoundResults[GlobalClass.Game.winnerSeatID]++;
    //         }

    //         UserControl.getInstance().gameEnd();

    //         this.showResultAni(GlobalClass.Game.winnerSeatID);
    //     }

    // }

    private on100007_event(event: egret.Event): void {
        console.log("on100007_event");
        let msg: MSGBase = <MSGBase>event.data;
        let dataStr = msg.getDataStr();

        let jsObj = JSON.parse(dataStr);
        if (jsObj["code"] == 200) {
            //     GlobalClass.Game.priceInfos = jsObj["info"]["prize_info"];
            // } else {
            //     GlobalClass.Game.priceInfos = null;
        }
        KFControllerMgr.getCtl(PanelName.GameResultPanel).setState(true).show();
    }

    private on100011_event(event: egret.Event): void {
        console.log("on100011_event");
        let msg: MSGBase = <MSGBase>event.data;
        let dataStr = msg.getDataStr();

        let jsObj = JSON.parse(dataStr);
        if (jsObj["code"] == 200) {
            GlobalClass.Game.jigsawSolution = jsObj["info"];
            let game = new JigsawGame(-1);
            this.mPanel.GameComponent.addChild(game);
        }
        // let data = '{"data":[{"blockId":0,"blockType":1,"skin":0,"x":17.99952857876293,"y":52.020204732778254,"angle":0.000052265694462180194,"scale":1,"islocked":false,"isToFeezen":false,"isBindJoint":false,"isDisorder":false,"bodyJointsIdList":[],"isContacted":true,"isCurTet":false},{"blockId":1,"blockType":4,"skin":0,"x":15.99321919503245,"y":49.016208821369915,"angle":1.5703261809084106,"scale":1,"islocked":false,"isToFeezen":false,"isBindJoint":false,"isDisorder":false,"bodyJointsIdList":[],"isContacted":true,"isCurTet":false},{"blockId":2,"blockType":5,"skin":0,"x":20.006442229852293,"y":49.01694191927511,"angle":1.571497925925906,"scale":1,"islocked":false,"isToFeezen":false,"isBindJoint":false,"isDisorder":false,"bodyJointsIdList":[],"isContacted":true,"isCurTet":false},{"blockId":3,"blockType":7,"skin":0,"x":20.01423084840243,"y":45.01210470065424,"angle":1.5715522533032054,"scale":1,"islocked":false,"isToFeezen":false,"isBindJoint":false,"isDisorder":false,"bodyJointsIdList":[],"isContacted":true,"isCurTet":false},{"blockId":4,"blockType":7,"skin":0,"x":15.98630094329906,"y":45.01140760461007,"angle":4.711930496021216,"scale":1,"islocked":false,"isToFeezen":false,"isBindJoint":false,"isDisorder":false,"bodyJointsIdList":[],"isContacted":true,"isCurTet":false},{"blockId":5,"blockType":1,"skin":0,"x":18.001551643302466,"y":42.00589456699479,"angle":-0.00002535212591616255,"scale":1,"islocked":false,"isToFeezen":false,"isBindJoint":false,"isDisorder":false,"bodyJointsIdList":[],"isContacted":true,"isCurTet":false},{"blockId":6,"blockType":7,"skin":0,"x":23.021338523965735,"y":40.01063154715271,"angle":3.143343736333053,"scale":1,"islocked":false,"isToFeezen":false,"isBindJoint":false,"isDisorder":false,"bodyJointsIdList":[],"isContacted":true,"isCurTet":false},{"blockId":7,"blockType":7,"skin":0,"x":12.979144070184434,"y":40.00826270075902,"angle":3.1408139744617816,"scale":1,"islocked":false,"isToFeezen":false,"isBindJoint":false,"isDisorder":false,"bodyJointsIdList":[],"isContacted":true,"isCurTet":false},{"blockId":8,"blockType":6,"skin":0,"x":18.00291743588149,"y":39.00093536907907,"angle":-0.00004500614750074113,"scale":1,"islocked":false,"isToFeezen":false,"isBindJoint":false,"isDisorder":false,"bodyJointsIdList":[],"isContacted":true,"isCurTet":true}]}';

        this.unNormalGame = new JigsawGame(-1);
        this.mPanel.GameComponent.addChild(this.unNormalGame);
        this.mPanel.Toggle_Pause.visible = false;
        this.mPanel.Btn_Test.visible = false;
        this.pause();
    }

    private unNormalGame: GameComponent;

    private on100901_event(event: egret.Event): void {
        console.log("on100901_event");
        let msg: MSGBase = <MSGBase>event.data;
        let dataStr = msg.getDataStr();
        let jsObj = JSON.parse(dataStr);
        if (jsObj["code"] == 200) {
            GlobalClass.Game.historyScore = jsObj["info"]["history_highest_score"];
            if (GlobalClass.Game.currentScore > GlobalClass.Game.historyScore) {
                GlobalClass.Game.isNewRecord = true;
            } else {
                GlobalClass.Game.isNewRecord = false;
            }
            KFControllerMgr.getCtl(PanelName.EndlessResultPanel).show();
            if (!!jsObj["info"]["new_endless_permission"]) {
                KFControllerMgr.showTips("恭喜你获取周末赛资格！！");
            }
        }

    }

    private on100203_event(event: egret.Event): void {
        console.log("on100203_event");
        let msg: MSGBase = <MSGBase>event.data;
        let dataStr = msg.getDataStr();
        let jsObj = JSON.parse(dataStr);
        if (jsObj["code"] == 200) {

        }
    }

    private on100301_event(event: egret.Event): void {
        console.log("on100301_event");
        let msg: MSGBase = <MSGBase>event.data;
        let dataStr = msg.getDataStr();
        let jsObj = JSON.parse(dataStr);
        if (jsObj["code"] == 200) {

        }
    }

    private on100303_event(event: egret.Event): void {
        console.log("on100303_event");
        let msg: MSGBase = <MSGBase>event.data;
        let dataStr = msg.getDataStr();
        let jsObj = JSON.parse(dataStr);
        if (jsObj["code"] == 200) {

        }
    }

    private on100306_event(event: egret.Event): void {
        console.log("on100306_event");
        let msg: MSGBase = <MSGBase>event.data;
        let dataStr = msg.getDataStr();
        let jsObj = JSON.parse(dataStr);
        if (jsObj["code"] == 200) {//上报成功

        } else {//上报不成功 重新上报
            // this.sendGameStateData();
        }
    }

    private on1004_event(event: egret.Event): void {
        console.log("on1004_event");
        this.pause();
    }

    private on1007_event(event: egret.Event): void {
        console.log("on1007_event");
        this.showGuild = false;
        this.checkGuide();
        // this.startGame();
    }

    public hideGuide() {
        this.showGuild = false;
        this.startGame();
    }

    private on111111_event(event: egret.Event): void {
        // console.log("on111111_event");
        let newTime = new Date().getTime();
        let delTime = newTime - this.lastTime;
        this.mPanel.pinglabel.text = "ping:" + delTime + "ms";
        this.mPanel.pinglabel.visible = true;
        if (delTime < 100) {
            this.mPanel.pinglabel.textColor = 0x00ff00;
        } else {
            this.mPanel.pinglabel.textColor = 0xff0000;
        }
    }

    // private on100900_event(event: egret.Event): void {
    //     console.log("on100900_event");
    //     let msg: MSGBase = <MSGBase>event.data;
    //     let dataStr = msg.getDataStr();

    //     let jsObj = JSON.parse(dataStr);
    //     if (jsObj["code"] == 200) {
    //         GlobalClass.CurrentStage = new StageInfo().parseData(jsObj["info"]);
    //         GlobalClass.Game.isDebug = false;
    //         if (this.isRestart) {
    //             KFSceneManager.getInstance().replaceScene(SceneName.Fight);
    //         } else {
    //             NetEventMgr.getInstance().clientMsg(MsgID.CLIENT.EndlessNextLevel, "");
    //         }
    //     }
    // }

    private on100307_event(event: egret.Event): void {
        console.log("on100307_event");
        let msg: MSGBase = <MSGBase>event.data;
        let dataStr = msg.getDataStr();
        let jsObj = JSON.parse(dataStr);
        if (jsObj["code"] == 200) {
        }
    }

    private on100308_event(event: egret.Event): void {
        console.log("on100308_event");
        let msg: MSGBase = <MSGBase>event.data;
        let dataStr = msg.getDataStr();
        let jsObj = JSON.parse(dataStr);
        GlobalClass.Game.MultiGameResult = jsObj.data;
        GlobalClass.Game.gameIsOver = true;
        GlobalClass.Game.winnerSeatID = jsObj["data"]["win_seat_id"];
        if (GlobalClass.Game.winnerSeatID == -1) {//平局
            for (let i = 0; i < GlobalClass.Game.PlayerNum; i++) {
                GlobalClass.Game.gameRoundResults[i]++;
            }
        } else {
            GlobalClass.Game.gameRoundResults[GlobalClass.Game.winnerSeatID]++;
        }
        this.pause();
        this.disableBut(this.mPanel.Toggle_Pause);
        this.roundIsOver = true;
        this.showResultAni(GlobalClass.Game.winnerSeatID);
    }

    private sendGameStateData() {
        let stateDatas = [];
        this.gameList.forEach(element => {
            stateDatas.push(element.getCurrentState());
        });
        let js = { frame_serial: GlobalClass.Game.localFrameNum, frame_data: stateDatas };
        this.stageData = JSON.stringify(js);
        WebSocketMgr.getInstance().SendOneceMsg(MsgID.GAMEPlay.SendGameStateData, this.stageData);
    }

    private testBlockStateDatas() {
        let bb = this.localGame.getBlockStateDatas(false);
        let b = JSON.stringify(bb);
        console.log("魔镜魔镜告诉我，策划到底要什么：" + b);
    }

    private CheckRank() {
        if (!this.roundIsOver) {
            if (this.gameMode == 0) {//根据已推高度判定
                this.checkSpeedRank();
            } else if (this.gameMode == 1) {//根据还剩余的砖块数
                this.checkSurvivalRank();
            } else if (this.gameMode == 2) {//根据已使用的砖块数
                this.checkjiaSawRank();
            }
            this.invoke(1, this.CheckRank, this);
        }
        this.checkPing();
    }

    private lastTime: number;
    private checkPing() {
        this.lastTime = new Date().getTime();
        WebSocketMgr.getInstance().SendOneceMsg(MsgID.GAME.GetPing, JSON.stringify({}), false);
    }

    private seneGameOver(winnerID) {
        this.pause();
        this.disableBut(this.mPanel.Toggle_Pause);
        this.roundIsOver = true;
        //如果是多人对战 上报服务器数据
        if (GlobalClass.Game.GameMode == 2) {
            let notfall = this.localGame.haveBrickFalled() ? 0 : 1;
            let healthy = this.localGame.isNpcHealthy() ? 1 : 0;
            let js = {
                win_seat_id: winnerID,
                jingsubudao: notfall,
                shengcunmanxue: healthy,
                pintuwudiaoluo: notfall,
                round: GlobalClass.Game.currentRound,
            };
            WebSocketMgr.getInstance().SendOneceMsg(MsgID.GAMEPlay.SendGameResult, JSON.stringify(js));
        } else {
            this.showResultAni(winnerID);
        }
    }

    private showResultAni(winnerID) {
        //游戏层展示输赢
        this.gameList.forEach(element => {
            element.finalWiner(winnerID);
        });
    }

    private checkSpeedRank() {
        let infos = [];
        for (let i = 0; i < GlobalClass.Game.PlayerNum; i++) {
            let element = this.gameList[i];
            let js = { height: element.GetBricksHigh(), seatID: i }
            infos.push(js);
        }
        infos.sort((a, b) => {
            return a.height - b.height;
        })
        this.setRankNum(infos);
    }

    private checkSurvivalRank() {
        let infos = [];
        for (let i = 0; i < GlobalClass.Game.PlayerNum; i++) {
            let element = this.gameList[i];
            let js = { leftNum: element.getLeftBricksNum(), seatID: i }
            infos.push(js);
        }
        infos.sort((a, b) => {
            return a.leftNum - b.leftNum;
        })
        this.setRankNum(infos);
    }

    private checkjiaSawRank() {
        let infos = [];
        for (let i = 0; i < GlobalClass.Game.PlayerNum; i++) {
            let element = this.gameList[i];
            let js = { usedNum: element.getusedBricksNum(), seatID: i }
            infos.push(js);
        }
        infos.sort((a, b) => {
            return b.usedNum - a.usedNum;
        })
        this.setRankNum(infos);
    }

    private setRankNum(infos) {
        for (let i = 0; i < GlobalClass.Game.PlayerNum; i++) {
            let info = infos[i];
            if (info["seatID"] != GlobalClass.Game.PlayerSeatID) {
                this.screenShots[info["seatID"]].setScreedId(i + 1);
            }
        }
    }

    private GameReturn() {
        this.mPanel.Toggle_Pause.visible = true;
        this.mPanel.Btn_Test.visible = true;
        this.unNormalGame.destroy();
        this.mPanel.GameComponent.removeChild(this.unNormalGame);
        this.resume();
    }

    public onResultAniC(iswin) {
        KFControllerMgr.getCtl(PanelName.RoundResultPanel).show();
    }

    public updateMoveInstans(msg: MSGBase) {
        console.log("updateMoveInstans");
        this.actionArr.push(msg);

        if (this.showGame != null) {
            this.startCheck();
        }
    }

    private checking = false;
    //1000毫秒内和网络帧逻辑结果不同，则强制同步
    public startCheck() {
        console.log("startCheck");
        this.cancelAllInvoke();
        this.checking = true;
        this.invoke(1, () => {
            if (this.checking && !this.gameIsSame()) {
                this.modifyGame();
            }
        }, this);
    }

    private checkMsgCount = 0;
    private actionArr: MSGBase[];
    private actionUsedArr: MSGBase[];
    //处理网络指令
    public handleNetMsg(msg: MSGBase) {
        if (this.isModify) {//正在恢复状态中
            let oldmsg;
            while (this.actionUsedArr.length > 0) {
                oldmsg = this.actionUsedArr.shift();
                if (oldmsg.isSame(msg)) {
                    break;
                }
            }
            this.showGame.update(msg);
            this.modifyStep = this.actionUsedArr.length;
            if (this.modifyStep <= 0) {//同步结束
                console.log("modifyFinish");
                this.isModify = false;
                this.modifyStep = 0;
                this.resetNetState();
                UserControl.getInstance().startCollect();
            }
        } else {
            if (msg.getType() == PlayerMSGType.Empty) {//如果是空帧 
                if (this.actionArr.length > 0) {
                    let msg2 = this.actionArr.shift();
                    this.actionUsedArr.push(msg2);
                    this.showGame.update(msg2);
                    console.log("local=" + msg2.toString());
                } else {
                    this.showGame.update(msg);
                }
            } else {//如果网络帧有动作 则要跟之前的动作校验
                console.log("net=" + msg.toString());
                if (this.actionUsedArr.length <= 0) {//之前没有动作
                    this.resetGame();
                } else {
                    let oldmsg = this.actionUsedArr.shift();
                    if (!msg.isSame(oldmsg)) {//检测不一致 记录状态
                        while (this.actionUsedArr.length > 0) {
                            oldmsg = this.actionUsedArr.shift();
                            if (oldmsg.isSame(msg)) {
                                break;
                            }
                        }
                    } else {
                        // this.checkMsgCount ++;
                        this.showGame.update(new EmptyMSG());
                        // if(this.checkMsgCount==4){//一个周期检测结束 开始接受玩家操作数据上传
                    }
                    if (this.actionUsedArr.length == 0) {
                        console.log("cycle finish");
                        if (!this.gameIsSame()) {
                            this.resetGame();
                        } else {
                            this.cancelAllInvoke();
                            this.checking = false;
                            UserControl.getInstance().stopWait();
                        }
                    }
                }
            }
        }
    }

    private isModify = false;
    private modifyStep = 0;
    //数据不同步，开始恢复正常的状态 此时不接受玩家操作，同步完后才开始接受玩家操作
    // 同步逻辑为  同步帧数为actionhusedarr的元素数量
    private modifyGame() {
        this.isModify = true;
        this.modifyStep = this.actionUsedArr.length;
        this.actionArr = [];
        this.actionUsedArr = [];
        UserControl.getInstance().fobideCollect();
    }

    private resetNetState() {
        this.checkMsgCount = 0;
        this.checking = false;
        this.cancelAllInvoke();
        UserControl.getInstance().stopWait();
        console.log("finishCheck");
    }

    private resetGame() {
        this.resetNetState();
        this.pause();
        this.showGame.resetState(this.localGame.getCurrentState());
        this.resume();
    }

    private gameIsSame() {
        let showState = this.showGame.getCurrentState();
        let localState = this.localGame.getCurrentState();
        return JSON.stringify(showState) == JSON.stringify(localState);
    }

    private showGameCollideData = null;
    private realGameCollideData = null;
    //当前掉落砖块碰撞时调用 
    public onCollide(isHide) {
    }

    //是否是在补帧状态
    public onSuppling(isSuppling) {
        this.isSuppling = isSuppling;
        if (this.isSuppling) {
            UserControl.getInstance().fobideCollect();
        } else {
            UserControl.getInstance().startCollect();
        }
    }

    public showToast(content) {
        KFControllerMgr.showToast(content, this.mPanel);
    }
}