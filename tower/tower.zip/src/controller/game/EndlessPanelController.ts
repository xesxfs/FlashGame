/**
 *
 * @author 
 *
 */
class EndlessPanelController extends KFController {

    private selectGameFunc: Function;
    protected init() {
        super.init();
        this.ListenObjList = [{
            event: egret.TouchEvent.TOUCH_END, items: {
                "btn_normal_jigsaw": "",
                "btn_normal_survival": "",
                "btn_normal_back": "",
                "btn_normal_rank": "",
                "btn_week_jigsaw": "",
                "btn_week_survival": "",
                "btn_week_back": "",
                "btn_week_award": "",
                "btn_week_rule": "",
                "btn_week_rank": "",
                "btn_box_buy": "",
                "btn_box_cancle": "",
                "btn_box_rule": "",
                "btn_box_close": "",
                "btn_rule_close": "",
                "btn_award_close": "",
            },
        },
        ];//添加btn名为key，值为冷却时间，然后在类中添加btn名+Click的函数，即可自动注册btn事件 ,如 Btn_MyBankClick为函数名
        this.EventsList = [
            MsgID.GAME.EndlessJigsawInfo,
            MsgID.GAME.EndlessPermission,
            MsgID.GAME.EndlessBuyTicker,
            MsgID.GAME.EndlessWeekendAward,
        ];
    }

    protected onReady() {
        let week = new Date().getDay();
        if (week == 0 || week == 6) {
            GlobalClass.Hall.isOpenWeekend = true;
            this.sendGetWeekendAward();
        }
    }

    protected onShow() {//在界面上显示出来
        this.mPanel.panel_normal.visible = !GlobalClass.Hall.isOpenWeekend;
        this.mPanel.panel_weekend.visible = GlobalClass.Hall.isOpenWeekend
        this.mPanel.panel_weekend_award.visible = false;
        this.mPanel.panel_weekend_rule.visible = false;
    }
    private btn_normal_jigsawClick(){
        this.jigsawClick();
    }
    private btn_normal_survivalClick() {
        this.survivalClick();
    }
    private btn_normal_backClick() {
        this.backClick();
    }
    private btn_normal_rankClick() {
        this.rankClick();
    }

    private btn_award_closeClick() {
        this.mPanel.panel_weekend_award.visible = false;
    }
    private btn_week_jigsawClick() {
        this.selectGameFunc = this.jigsawClick;
        this.sendCheckPremition();
    }
    private btn_week_survivalClick() {
        this.selectGameFunc = this.survivalClick;
        this.sendCheckPremition();
    }

    private btn_week_backClick() {
        this.backClick();
    }
    private btn_week_awardClick() {
        this.mPanel.panel_weekend_award.visible = !this.mPanel.panel_weekend_award.visible;
    }
    private btn_week_ruleClick() {
        this.mPanel.panel_weekend_rule.visible = !this.mPanel.panel_weekend_rule.visible;
    }
    private btn_rule_closeClick() {
        this.mPanel.panel_weekend_rule.visible = false;
    }
    private btn_week_rankClick() {
        this.rankClick();
    }
    /***购买入场券 */
    private btn_box_buyClick() {
        WebSocketMgr.getInstance().SendOneceMsg(MsgID.GAME.EndlessBuyTicker, JSON.stringify({}));
    }
    private btn_box_cancleClick() {
        this.mPanel.panel_weekend_box.visible = false;
    }
    private btn_box_closeClick() {
        this.mPanel.panel_weekend_box.visible = false;
    }

    private btn_box_ruleClick() {
        this.mPanel.panel_weekend_box.visible = false;
        this.mPanel.panel_weekend_rule.visible = true;
    }

    /****** 检查是否有权限*/
    private sendCheckPremition() {
        WebSocketMgr.getInstance().SendOneceMsg(MsgID.GAME.EndlessPermission, JSON.stringify({}));
    }
    /***获取周末赛奖励 */
    private sendGetWeekendAward() {
        WebSocketMgr.getInstance().SendOneceMsg(MsgID.GAME.EndlessWeekendAward, JSON.stringify({}));
    }


    private on100904_event(event: egret.Event): void {
        console.log("on100904_event");
        let msg: MSGBase = <MSGBase>event.data;
        let dataStr = msg.getDataStr();
        let jsObj = JSON.parse(dataStr);
        if (jsObj["code"] != 200) {
            KFControllerMgr.showTips((jsObj["info"]));
            return;
        }
        this.buildAwards(jsObj["info"]);
    }


    private buildAwards(awards: Object) {
        let awardPanle = this.mPanel.panel_weekend_award as eui.Group;
        let beginX = 176;
        let beginY = 216;
        let YGap = 60;
        let XGap = 130;
        let idY = 0;
        for (let key in awards) {
            let yoffset = beginY + (idY * YGap);
            let score = key;
            let scoreLab = new eui.Label(score);
            scoreLab.size = 32;
            scoreLab.x = 65;
            scoreLab.y = yoffset;
            awardPanle.addChild(scoreLab);

            let items = [];
            items = awards[key];
            for (let i = 0; i < items.length; i++) {
                let item = items[i];
                let category = item["category"];
                let quantity = item["quantity"];
                let categorySource = "Shop_json.UI_coin_" + category;
                if (!category) {
                    categorySource = "Shop_json.icon_fuel";
                }
                let categoryImg = new eui.Image(RES.getRes(categorySource));
                categoryImg.y = yoffset - 2;
                categoryImg.x = beginX + i * XGap
                let quantityLab = new eui.Label("x" + quantity);
                quantityLab.size = 32;
                quantityLab.x = beginX + i * XGap + 50;
                quantityLab.y = yoffset;
                awardPanle.addChild(categoryImg);
                awardPanle.addChild(quantityLab);
            }

            idY++;

        }

    }

    private on100902_event(event: egret.Event): void {
        console.log("on100902_event");
        let msg: MSGBase = <MSGBase>event.data;
        let dataStr = msg.getDataStr();
        let jsObj = JSON.parse(dataStr);
        if (jsObj["code"] != 200) {
            KFControllerMgr.showTips((jsObj["info"]));
            return;
        }
        if (!!jsObj["info"]["permission"]) {
            this.selectGameFunc && this.selectGameFunc();
            this.selectGameFunc = null
        } else {
            this.mPanel.panel_weekend_box.visible = true;
        }

    }

    private on100903_event(event: egret.Event): void {
        console.log("on100903_event");
        let msg: MSGBase = <MSGBase>event.data;
        let dataStr = msg.getDataStr();
        let jsObj = JSON.parse(dataStr);
        if (jsObj["code"] != 200) {
            KFControllerMgr.showTips((jsObj["info"]));
        } else {
            KFControllerMgr.showTips("购买成功！！~~请进！！");
        }
        this.mPanel.panel_weekend_box.visible = false;

    }


    private on100900_event(event: egret.Event): void {
        console.log("on100900_event");
        let msg: MSGBase = <MSGBase>event.data;
        let dataStr = msg.getDataStr();

        let jsObj = JSON.parse(dataStr);
        if (jsObj["code"] == 200) {

            GlobalClass.CurrentStage = new StageInfo().parseData(jsObj["info"]);

            GlobalClass.Game.isDebug = false;

            KFSceneManager.getInstance().replaceScene(SceneName.Fight);
        }
    }


    private backClick() {
        KFSceneManager.getInstance().replaceScene(SceneName.Hall);
    }

    private rankClick() {
        KFControllerMgr.getCtl(PanelName.EndlessRankPanel).show();
    }

    private jigsawClick() {
        GlobalClass.CurrentStage.StageType = 1;
        let js = {
            round: 0,
        }
        WebSocketMgr.getInstance().SendOneceMsg(MsgID.GAME.EndlessJigsawInfo, JSON.stringify(js));
    }
    private survivalClick() {
        GlobalClass.CurrentStage.StageType = 1;
        GlobalClass.Game.isDebug = false;
        KFSceneManager.getInstance().replaceScene(SceneName.Fight);
    }
}