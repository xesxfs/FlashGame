/**
 *
 * @author 
 *
 */
class LevelChoosePanelController extends KFController {

    private levelDatas;
    private curPage = 1;
    private curMission = 1;
    // private mPlaneIcon:eui.Image;//飞机图标
    protected init() {
        super.init();
        this.ListenObjList = [{
            event: egret.TouchEvent.TOUCH_END, items: {
                "Btn_Back": "",
                "Btn_Before": "",
                "Btn_next": "",
            },
        },
        ];//添加btn名为key，值为冷却时间，然后在类中添加btn名+Click的函数，即可自动注册btn事件,如 Btn_MyBankClick为函数名
        this.EventsList = [
            // MsgID.GAME.GetLevelInfo,
            // MsgID.GAME.GetLevelBrief,
        ];
    }

    protected onReady() {
        // this.loadAni();
        this.loadInfo();
    }

    private test() {
        KFSceneManager.getInstance().replaceScene(SceneName.Hall);

    }



    protected destroy() {
        super.destroy();
        this.levelDatas = null;
        for (let i = 0; i < this.armatrueList.length; i++) {
            let armatrue = this.armatrueList.shift();
            AnimationMgr.getInstance().clenSkeleton(armatrue);
        }
        RES.removeEventListener(RES.ResourceEvent.CONFIG_COMPLETE, this.onConfigComplete, this);
        RES.removeEventListener(RES.ResourceEvent.CONFIG_LOAD_ERROR, this.onConfigLoadErr, this);
    }
    //在界面上显示出来
    protected onShow() {
        SoundMgr.Instance.playBGM(SoundMgr.mainbgm);
    }

    private loadInfo() {
        RES.addEventListener(RES.ResourceEvent.CONFIG_COMPLETE, this.onConfigComplete, this);
        RES.addEventListener(RES.ResourceEvent.CONFIG_LOAD_ERROR, this.onConfigLoadErr, this);
        RES.getResByUrl("resource/config/levelInfo.json", this.onConfigComplete, this, RES.ResourceItem.TYPE_JSON);
    }

    private onConfigComplete(event: RES.ResourceEvent): void {
        this.levelDatas = event;
        console.log("level=" + GlobalClass.Game.CurrentMission);
        this.curPage = Math.floor(GlobalClass.Game.CurrentMission / 100);
        this.curMission = GlobalClass.Game.CurrentMission;
        this.gotoPage(this.curPage);
        let stageTypeData = GlobalClass.Hall.allLevelDetailInfo[GlobalClass.CurrentStage.StageType];
        if (!stageTypeData) return;
        this.mPanel.LevelGroup.removeChildren();
        for (let i = 0; i < Math.ceil(stageTypeData.length / 10); i++) {
            this.createMissionsButton(i, stageTypeData);
        }
        this.mPanel.BGView.validate();
    }


    private onConfigLoadErr(event: RES.ResourceEvent): void {
        console.log("onConfigLoadErr");
    }

    private PlaneTargetX = 0;
    private planeTargetY = 0;
    private createMissionsButton(page, levelInfo) {
        let item = new LevelChooseScrollItem();
        let bgAni = this.getBgAni(GlobalClass.CurrentStage.StageType);
        let curLevel = GlobalClass.Hall.userSave[GlobalClass.CurrentStage.StageType];
        this.mPanel.LevelGroup.addChild(item);
        let missionData = this.levelDatas[0]["missionInfos"];
        for (let i = 0; i < 10; i++) {
            let levelData = levelInfo[page * 10 + i];
            let levelConfig = missionData[i];
            let aPos = [levelConfig["avatarPosx"], levelConfig["avatarPosy"]];
            let iscur: boolean = false;
            let isopen: boolean = true;
            let levelNum = page * 10 + i;
            iscur = (curLevel == (page * 10 + i));
            isopen = (curLevel > (page * 10 + i));
            let a = new LevelItem(levelData, levelNum, aPos, iscur, isopen, GlobalClass.CurrentStage.StageType);
            a.x = levelConfig["posx"];
            a.y = levelConfig["posy"];
            item.addChild(a);
        }
        item.addChildAt(bgAni, 0);
    }



    // private on100006_event(event: egret.Event): void {
    //     console.log("on100006_event");
    //     let msg: MSGBase = <MSGBase>event.data;
    //     let dataStr = msg.getDataStr();
    //     let jsObj = JSON.parse(dataStr);
    //     if (jsObj["code"] == 200) {
    //         GlobalClass.CurrentStage = new StageInfo().parseData(jsObj["info"]);
    //         GlobalClass.Game.isDebug = false;
    //         KFSceneManager.getInstance().replaceScene(SceneName.Fight);
    //     } else {
    //         KFControllerMgr.showTips(jsObj["info"]);
    //     }
    // }

    // private on100008_event(event: egret.Event): void {
    //     console.log("on100008_event");
    //     let msg: MSGBase = <MSGBase>event.data;
    //     let dataStr = msg.getDataStr();

    //     let jsObj = JSON.parse(dataStr);
    //     if (jsObj["code"] == 200) {
    //         KFControllerMgr.getCtl(PanelName.LevelInfoPanel).setData(jsObj["info"]).show();
    //     }
    // }

    private Btn_BackClick() {
        KFSceneManager.getInstance().replaceScene(SceneName.Hall);
    }

    private Btn_BeforeClick() {
        this.curPage = this.getCurPage();
        if (this.curPage <= 1) {
            return;
        }
        this.curPage--;
        this.gotoPage(this.curPage);
    }

    private Btn_nextClick() {
        this.curPage = this.getCurPage();
        if (this.curPage >= 5) {
            return;
        }
        this.curPage++;
        this.gotoPage(this.curPage);
    }

    private gotoPage(pageNum) {
        this.mPanel.BGView.scrollToItem(pageNum - 1);
    }

    private getCurPage(): number {
        return this.mPanel.BGView.getCurNum() + 1;
    }



    private armatrueList = [];
    private getBgAni(i: number): any {
        let prefix = "level";
        let skeName = "_ske_json";
        let texName = "_tex_json";
        let pngName = "_tex_png";
        skeName = prefix + skeName;
        texName = prefix + texName;
        pngName = prefix + pngName;
        let levelFactory = new dragonBones.EgretFactory();
        levelFactory.addDragonBonesData(dragonBones.DataParser.parseDragonBonesData(RES.getRes(skeName)));
        levelFactory.addTextureAtlasData(new dragonBones.EgretTextureAtlas(RES.getRes(pngName), RES.getRes(texName)));
        let armatureName = prefix;
        var armature = levelFactory.buildArmature(armatureName + "1");
        this.armatrueList.push(armature);
        dragonBones.WorldClock.clock.add(armature);
        var clip = armature.display;
        clip.x = 360;
        clip.y = 1280;
        // (clip as egret.DisplayObject).scaleX = egret.MainContext.instance.stage.stageWidth/720;
        AnimationMgr.getInstance().startTick();
        if (i == 1) { i = 2 }
        else if (i == 2) { i = 1 };
        armature.animation.play("play" + i);
        return armature.display;
    }
}