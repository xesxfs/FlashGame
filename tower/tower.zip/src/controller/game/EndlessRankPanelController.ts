/**
 *
 * @author 
 *
 */
class EndlessRankPanelController extends KFController{ 
    
	
	protected init(){
    	super.init();
         this.ListenObjList = [ {event:egret.TouchEvent.TOUCH_END,items:{
                                                            "Btn_Close":"",
                                                            "Toggle_jiasaw":"",
                                                            "Toggle_survival":"",
                                                    },},
                            
                            ];//添加btn名为key，值为冷却时间，然后在类中添加btn名+Click的函数，即可自动注册btn事件 ,如 Btn_MyBankClick为函数名
        this.EventsList = [
            ];
        
	}
	
    protected onReady() {

    }

    protected onShow(){//在界面上显示出来
        console.log("");
        this.Toggle_jiasawClick();
    }



    private Btn_CloseClick(){
        this.mPanel.hide();
    }

    private Toggle_jiasawClick(){
        var collection = new eui.ArrayCollection();
        collection.source = GlobalClass.Hall.RankInfos[""+rankType.endlessJigsaw];
        this.mPanel.rankList.dataProvider = collection;
    }

    private Toggle_survivalClick(){
        var collection = new eui.ArrayCollection();
        collection.source = GlobalClass.Hall.RankInfos[""+rankType.endlessSurvival];
        this.mPanel.rankList.dataProvider = collection;
    }
}