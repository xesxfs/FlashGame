class LevelChooseScrollItem extends eui.Component implements eui.UIComponent {
	public constructor() {
		super();
		// this.percentWidth = 100;
		// this.percentHeight = 100;
	}

	protected partAdded(partName: string, instance: any): void {
		super.partAdded(partName, instance);
	}


	protected childrenCreated(): void {
		// 		this.percentWidth = 100;
		// this.percentHeight = 100;
		super.childrenCreated();
		this.width = this.stage.stageWidth;
	}
}