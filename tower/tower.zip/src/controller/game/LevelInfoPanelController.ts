/**
 *
 * @author 
 *
 */
class LevelInfoPanelController extends KFController {

    private mdata;
    protected init() {
        super.init();
        this.ListenObjList = [{
            event: egret.TouchEvent.TOUCH_END, items: {
                "Btn_Close": "",
                "Btn_Start": "",
            },
        }

        ];//添加btn名为key，值为冷却时间，然后在类中添加btn名+Click的函数，即可自动注册btn事件 ,如 Btn_MyBankClick为函数名
        this.EventsList = [
        ];

    }

    protected onReady() {
        this.mPanel.tip1.visible = false;
        this.mPanel.tip2.visible = false;
        this.mPanel.tip3.visible = false;
    }

    protected onShow() {//在界面上显示出来
        let level = Math.floor(GlobalClass.Game.ShowInfoLevel / 100 - 1) * 10 + GlobalClass.Game.ShowInfoLevel % 100;
        this.mPanel.levelNum.text = level + "";
        this.initView();
    }

    private initView() {
        this.mPanel.tip1.visible = false;
        this.mPanel.tip2.visible = false;
        this.mPanel.tip3.visible = false;
        if (this.mdata["stage_type"] == 0) {//竞速模式
            this.mPanel.tip1.visible = true;
            this.mPanel.floorNum.text = this.mdata["target_height"];
            this.mPanel.hour.text = CommonFuc.formatTime(this.mdata["limit_time"] * 1000);
            this.mPanel.levelImg.source = RES.getRes("Game_json.Img_levelInfo01");
        } else if (this.mdata["stage_type"] == 1) {//生存
            this.mPanel.tip2.visible = true;
            this.mPanel.blockNum.text = this.mdata["bricks_quantity"];
            this.mPanel.levelImg.source = RES.getRes("Game_json.Img_levelInfo02");
        } else {//拼图
            this.mPanel.levelImg.source = RES.getRes("Game_json.Img_levelInfo03");
        }

        // GlobalClass.Game.currentPropInfos = this.mdata["available_props"];
        // this.createItems(this.mdata["available_props"]);
    }

    public setData(datastr): any {
        this.mdata = datastr;
        return this;
    }

    private createItems(items) {
        this.mPanel.ItemGroup.removeChildren();
        let a = items.length;
        for (let i = 0; i < items.length; i++) {
            let item = new LevelReward(items[i]["quantity"], items[i]["prop_number"], goodsType.props);
            this.mPanel.ItemGroup.addChild(item);
        }
    }

    private Btn_CloseClick() {
        this.mPanel.hide();
        egret
    }

    private Btn_StartClick() {
        // let js = {
        // 	 	stage_number:GlobalClass.Game.ShowInfoLevel
        // };
        // WebSocketMgr.getInstance().SendOneceMsg(MsgID.GAME.GetLevelInfo,JSON.stringify(js));
        if (!this.mdata) return;
        GlobalClass.CurrentStage.parseData(this.mdata);
        GlobalClass.Game.isDebug = false;
        KFSceneManager.getInstance().replaceScene(SceneName.Fight);

    }
}