/**
 *
 * @author 
 *
 */
class MultiGameResultPanelController extends KFController{
	protected init(){
    	super.init();
         this.ListenObjList = [ {event:egret.TouchEvent.TOUCH_END,items:{
                                                                    "Btn_Return":"",
                                                                    "Btn_Again":"",
                                                    },},
                            
                            ];//添加btn名为key，值为冷却时间，然后在类中添加btn名+Click的函数，即可自动注册btn事件 ,如 Btn_MyBankClick为函数名
        this.EventsList = [
            ];
	}
	
    protected onReady() {
        this.initView();
    }

    protected onShow(){//在界面上显示出来
        if(GlobalClass.Hall.newAchievement.length>0){
            KFControllerMgr.getCtl(PanelName.NewAchievementPanel).show();
        }
    }

    private initView(){
        // dataStr = "{'data': {'extend_score': {'win': 100, 'round_win': 50, 'shengcunmanxue': 50, 'jingsubudao': 50, 'pintuwudiaoluo': 50}, 'is_win': True, 'next_level_score': 200, 'current_score': 100, 'level': 2, 'diamond': 20, 'exp': 20, 'score': 20}, 'command_id': 100308}";
        
        let data = GlobalClass.Game.MultiGameResult;
        this.mPanel.winGroup.visible = false;
        this.mPanel.lostGroup.visible = false;
         this.mPanel.winScoreGroup.visible = false;
          this.mPanel.failScoreGroup.visible = false;
        if(data["is_win"]==1){
            this.mPanel.winGroup.visible = true;
            this.mPanel.winScoreGroup.visible = true;
        }else{
            this.mPanel.lostGroup.visible = true;
            this.mPanel.failScoreGroup.visible = true;
        }

        let titleSource = "HallAtlas_json.img_hallLevel0"+(data["level"]+1);
        this.mPanel.GameTitle_win.source = RES.getRes(titleSource);
        this.mPanel.GameTitle_fail.source = RES.getRes(titleSource);

        this.mPanel.Label_diamond_win.text = "+"+data["diamond"];
        this.mPanel.Label_diamond_fail.text = "+"+data["diamond"];
        this.mPanel.Label_exp_win.text = "+"+data["exp"];
        this.mPanel.Label_exp_fail.text = "+"+data["exp"];
        this.mPanel.Label_winScore.text = data["is_win"]==1?"+70":"-70";//赢的为+70，输的为-70
        this.mPanel.Label_roundScore.text = "+"+data["extend_score"]["round_win"];
        this.mPanel.Label_speedScore.text = "+"+data["extend_score"]["jingsubudao"];
        this.mPanel.Label_survivalScore.text = "+"+data["extend_score"]["shengcunmanxue"];
        this.mPanel.Label_jigsawScore.text = "+"+data["extend_score"]["pintuwudiaoluo"];
        this.mPanel.Label_gold_win.text = "+"+data["coin"];;
        this.mPanel.Label_Score_win.text = "+"+data["score"];
        this.mPanel.Label_Score_fail.text = ""+data["score"];
        let current_score = data["current_score"];
        if(current_score<0){
            current_score = 0;
        }

        this.mPanel.percent_win.value = 100*current_score/data["next_level_score"];
        this.mPanel.percent_fail.value = 100*current_score/data["next_level_score"];
    }

    private Btn_ReturnClick(){
        KFSceneManager.getInstance().replaceScene(SceneName.Hall);
    }

    private Btn_AgainClick(){
        KFSceneManager.getInstance().replaceScene(SceneName.Game);
    }
}