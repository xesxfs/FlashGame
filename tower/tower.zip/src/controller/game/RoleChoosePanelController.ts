/**
 *
 * @author 
 *
 */
class RoleChoosePanelController extends KFController {
    /***角色Id列表 */
    private roleIdList = [901, 902, 903, 904, 905];
    protected init() {
        super.init();
        this.ListenObjList = [{
            event: egret.TouchEvent.TOUCH_END, items: {
                "Btn_Back": "",
                "Btn_BeforeRole": "",
                "Btn_nextRole": "",
                "Btn_BlockBefore": "",
                "Btn_BlockNext": "",
                "Btn_QuickStart": "",
                "Btn_Invite": "",

            },
        },

        ];//添加btn名为key，值为冷却时间，然后在类中添加btn名+Click的函数，即可自动注册btn事件 ,如 Btn_MyBankClick为函数名
        this.EventsList = [
            MsgID.GAME.QuickMatch,
        ];
    }

    protected onReady() {
        this.mPanel.RoleScoller.setStateBGImg("Game_json.Img_matchRoleBG01", "Game_json.Img_matchRoleBG02");
        this.mPanel.BlockScoller.setStateBGImg("Game_json.Img_matchBlockBG01", "Game_json.Img_matchBlockBG02");
        this.mPanel.BlockScoller.scrollToIndex(0);
        this.setHaveRoleFlag();
        this.setSelectRole();
    }

    /***设置拥有角色标志 */
    private setHaveRoleFlag() {
        let roleItems = this.mPanel.RoleScoller.getChildAt(0) as eui.Group;
        let roleItemLength = roleItems.numChildren;
        for (let i = 0; i < roleItemLength; i++) {
            let roleId = this.roleIdList[i];
            let roleItem = roleItems.getChildAt(i) as eui.Group;
            if (this.checkHaveRole(roleId)) {
                roleItem.getChildAt(2).visible = false;
                roleItem.getChildAt(3).visible = false;
            }

        }
    }

    /**设置拥有的第一个角色，没有默认选择第一个角色 */
    private setSelectRole() {
        let ownerRoleList = GlobalClass.Hall.OwnedNPCList;
        if (ownerRoleList && ownerRoleList.length > 0) {
            this.selectRoleItem(GlobalClass.Hall.OwnedNPCList[0])
        } else {
            this.selectRoleItem(this.roleIdList[0]);
        }
    }

    /***是否有用角色 */
    private checkHaveRole(roleId: number): boolean {
        let ownerRoleList = GlobalClass.Hall.OwnedNPCList;
        if (ownerRoleList.indexOf(roleId) >= 0) {
            return true;
        }
        return false;
    }

    /***选择指定角色 */
    private selectRoleItem(roleId: number) {
        let roleIdx = this.roleIdList.indexOf(roleId);
        if (roleIdx < 0) roleIdx = 0;
        this.mPanel.RoleScoller.scrollToIndex(roleIdx);
    }

    protected onShow() {//在界面上显示出来

    }


    private on100200_event(event: egret.Event): void {
        console.log("on100200_event");
        let msg: MSGBase = <MSGBase>event.data;
        let dataStr = msg.getDataStr();

        let jsObj = JSON.parse(dataStr);
        if (jsObj["code"] == 200) {
            KFControllerMgr.getCtl(PanelName.GameMatchPanel).show();
        }
    }

    protected setOnClickListener() {
    }

    protected removeOnClickListener() {
    }

    private Btn_BackClick() {
        KFSceneManager.getInstance().replaceScene(SceneName.Hall);
    }

    private Btn_BeforeRoleClick() {
        this.mPanel.RoleScoller.scrollToLast();
    }

    private Btn_nextRoleClick() {
        this.mPanel.RoleScoller.scrollToNext();
    }

    private Btn_BlockBeforeClick() {
        this.mPanel.BlockScoller.scrollToLast();
    }

    private Btn_BlockNextClick() {
        this.mPanel.BlockScoller.scrollToNext();
    }

    private Btn_QuickStartClick() {
        /**从1开始 */
        let npc_type = this.mPanel.RoleScoller.getCurrentIndex();

        if (!this.checkHaveRole(this.roleIdList[npc_type - 1])) {
            KFControllerMgr.showToast("你未拥有该角色！！", this.mPanel);
            return;
        }

        let bType = this.mPanel.BlockScoller.getCurrentIndex() % 3;
        let js = {
            brick_type: bType,
            npc_type: npc_type,
        };
        WebSocketMgr.getInstance().SendOneceMsg(MsgID.GAME.QuickMatch, JSON.stringify(js));
    }

    private Btn_InviteClick() {

    }
}