/**
 *
 * @author 
 *
 */
class GameResultPanelController extends KFController {

    private isWin = false;
    private currentExpNum = 0;
    protected init() {
        super.init();
        this.ListenObjList = [{
            event: egret.TouchEvent.TOUCH_END, items: {
                "Btn_CloseWin": "",
                "Btn_CloseFail": "",
                "Btn_Agin": "",
                "Btn_Show": "",
                "Btn_Next": "",
            },
        },
        ];//添加btn名为key，值为冷却时间，然后在类中添加btn名+Click的函数，即可自动注册btn事件 ,如 Btn_MyBankClick为函数名
        this.EventsList = [
            // MsgID.GAME.GetLevelInfo,
            // MsgID.GAME.GetCurrentLevelInfos,
        ];
    }

    protected onReady() {
        this.mPanel.lostInfo.visible = false;
        this.mPanel.winInfo.visible = false;
        if (this.isWin) {
            this.mPanel.winInfo.visible = true;

        } else {
            this.mPanel.lostInfo.visible = true;
        }
    }

    protected destroy() {
        if (this.resultAni != null) {
            AnimationMgr.getInstance().clenSkeleton(this.resultAni);
        }
        super.destroy();
    }

    protected onShow() {//在界面上显示出来
        this.loadAni();      
    }

    public setState(iswin) {
        this.isWin = iswin;
        return this;
    }

    private playGame(stageNO: number) {
        let stageTypeData = GlobalClass.Hall.allLevelDetailInfo[GlobalClass.CurrentStage.StageType];
        GlobalClass.CurrentStage = new StageInfo().parseData(stageTypeData[stageNO]);
        KFSceneManager.getInstance().replaceScene(SceneName.Fight);
    }

    private on100005_event(event: egret.Event): void {
        console.log("on100005_event");
        let msg: MSGBase = <MSGBase>event.data;
        let dataStr = msg.getDataStr();
        let jsObj = JSON.parse(dataStr);
        if (jsObj["code"] == 200) {
            if (jsObj["info"]["current_stage"] == null) {
                GlobalClass.Game.CurrentMission = 100;
            } else {
                GlobalClass.Game.CurrentMission = jsObj["info"]["current_stage"];
            }
            GlobalClass.Game.LevelInfos = jsObj["info"]["friend_stages"];
            KFSceneManager.getInstance().replaceScene(SceneName.Game);
        }
    }

    private Btn_CloseWinClick() {
        if (this.isWin) {
            if (GlobalClass.Hall.userSave[GlobalClass.CurrentStage.StageType] == GlobalClass.CurrentStage.sortId) {
                GlobalClass.Hall.userSave[GlobalClass.CurrentStage.StageType]++;
            }
        }
        KFSceneManager.getInstance().replaceScene(SceneName.Hall);
    }

    private Btn_CloseFailClick() {
        if (this.isWin) {
            if (GlobalClass.Hall.userSave[GlobalClass.CurrentStage.StageType] == GlobalClass.CurrentStage.sortId) {
                GlobalClass.Hall.userSave[GlobalClass.CurrentStage.StageType]++;
            }
        }
        KFSceneManager.getInstance().replaceScene(SceneName.Hall);
    }

    //重玩
    private Btn_AginClick() {
        // let js = {
        //     stage_number: GlobalClass.CurrentStage.StageNumber
        // };
        // WebSocketMgr.getInstance().SendOneceMsg(MsgID.GAME.GetLevelInfo, JSON.stringify(js));
        this.playGame(GlobalClass.CurrentStage.sortId);
    }

    private Btn_ShowClick() {
        KFControllerMgr.getCtl(PanelName.GameSharePanel).show();
    }

    //下一关
    private Btn_NextClick() {
        if (GlobalClass.Hall.userSave[GlobalClass.CurrentStage.StageType] == GlobalClass.CurrentStage.sortId) {
            GlobalClass.Hall.userSave[GlobalClass.CurrentStage.StageType]++;
        }
        this.playGame(GlobalClass.CurrentStage.sortId + 1);
    }



    private loadAni() {
        RES.addEventListener(RES.ResourceEvent.GROUP_COMPLETE, this.loadAniCB, this);
        RES.loadGroup("resultSKe");
    }

    private loginFactory: dragonBones.EgretFactory;
    private loadAniCB(event: RES.ResourceEvent) {
        if (event.groupName == "resultSKe") {
            RES.removeEventListener(RES.ResourceEvent.GROUP_COMPLETE, this.loadAniCB, this);
            let prefix = "";
            if (this.isWin) {
                prefix = "ResultWin";
            } else {
                prefix = "ResultLost";
            }
            let skeName = prefix + "_ske_json";
            let texName = prefix + "_tex_json";
            let pngName = prefix + "_tex_png";
            this.loginFactory = new dragonBones.EgretFactory();
            this.loginFactory.addDragonBonesData(dragonBones.DataParser.parseDragonBonesData(RES.getRes(skeName)));
            this.loginFactory.addTextureAtlasData(new dragonBones.EgretTextureAtlas(RES.getRes(pngName), RES.getRes(texName)));
            this.initAni();
        }
    }

    private resultAni: dragonBones.Armature;
    private initAni() {
        this.resultAni = this.loginFactory.buildArmature("Armature");
        this.resultAni.animation.play("newAnimation", 1);
        dragonBones.WorldClock.clock.add(this.resultAni);
        var clip = this.resultAni.display;
        clip.x = 360;
        clip.y = 620;
        this.mPanel.addChild(clip);
        AnimationMgr.getInstance().startTick();
    }

}