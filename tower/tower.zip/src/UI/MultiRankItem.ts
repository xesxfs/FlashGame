class MultiRankItem extends  eui.ItemRenderer{
	private rankImg:eui.Image;
    private avatar:eui.Image;
	private playerName:eui.Label;
    private score:eui.Label;
	private level:eui.Label;
	private rankLabel:eui.Label;
	private titleImg:eui.Image;
	private isLoadingAvatart = false;
	public constructor(propData) {
		super();
	}

	protected dataChanged(){
		if(this.data.rank_score!=null){
			this.score.text = this.data.rank_score+""
			this.level.text = this.data.player_level+"";
			this.playerName.text = this.data.player_name;
			if(this.data.rank<=3){
				this.rankImg.source = RES.getRes("Game_json.img_rank"+this.data.rank);
				this.rankImg.visible = true;
				this.rankLabel.visible = false;
			}else{
				this.rankImg.visible = false;
				this.rankLabel.visible = true;
				this.rankLabel.text = this.data.rank;
			}
			this.titleImg.source = RES.getRes("Game_json.img_level0"+(this.data.battle_level+1));
		}
	}

	protected childrenCreated(){
	}

	private startLoadAvatar(){
		this.isLoadingAvatart = true;
	}
}