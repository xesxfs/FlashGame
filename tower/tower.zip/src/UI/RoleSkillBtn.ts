class RoleSkillBtn extends eui.Component implements eui.UIComponent {

	public constructor(skill: SkillType, category: SkillCategory) {
		super();
		this.skill = skill;
		this.skillCategory = category;
		this.skinName = RoleSkillBtnSkin;
	}
	/**技能图标 */
	private sIcon: eui.Image;
	/**扇子型进度条 */
	private arcProgress: egret.Shape;
	/**最大技能点 */
	public maxSkillPoint: number = 2;
	/**当前技能点 */
	public curSkillPoint: number = 0;
	/**技能 */
	public skill: SkillType;
	public skillCategory: SkillCategory;

	protected partAdded(partName: string, instance: any): void {
		super.partAdded(partName, instance);
	}

	protected childrenCreated(): void {
		super.childrenCreated();
		this.createArcBar();
		this.initSkillIcon();
	}
	/***初始化技能图标 */
	private initSkillIcon() {
		this.sIcon.source = this.getSkillIcon();
	}
	/***创建扇形进度条 */
	private createArcBar() {
		this.arcProgress = new egret.Shape();
		var angle: number = 0;
		this.addChild(this.arcProgress);
		this.drawArcBar(360);
	}

	/**扇形进度条 */
	private drawArcBar(angle: number) {
		let radius = this.width / 2;
		var shape = this.arcProgress;
		shape.graphics.clear();
		/***从第三象限开始,逆时针画图 */
		angle += 180;
		shape.graphics.beginFill(0x000000, 0.5);
		shape.graphics.moveTo(radius, radius);
		shape.graphics.lineTo(0, radius);
		shape.graphics.drawArc(radius, radius, radius, 180 * Math.PI / 180, angle * Math.PI / 180, true);
		shape.graphics.lineTo(radius, radius);
		shape.graphics.endFill();
	}
	/**增加技能点 */
	public addSkillPoint(point: number = 1) {
		this.curSkillPoint += point;
		if (this.maxSkillPoint < this.curSkillPoint) {
			this.curSkillPoint = this.maxSkillPoint;
		}

		if (this.curSkillPoint < 0) {
			this.curSkillPoint = 0;
		}

		let angle = (360 / this.maxSkillPoint) * this.curSkillPoint;
		angle %= 360;
		this.drawArcBar(angle);
	}

	/**重置技能点 */
	public resetSkillPoint() {
		this.curSkillPoint = 0;
		this.drawArcBar(360);
	}
	/**是否可以使用技能 */
	public isCanUse(): boolean {
		if (this.curSkillPoint >= this.maxSkillPoint) return true;
		return false;
	}
	/**获取技能图标 */
	private getSkillIcon(): string {
		let icon = "skill_icon_json.skill_icon_";

		switch (this.skill) {
			case SkillType.Fog1:
			case SkillType.Fog2:
			case SkillType.Fog3:
			case SkillType.Fog4:
				icon += GlobalClass.getSkillNOByType(SkillType.Fog1);
				break;
			case SkillType.Laser1:
			case SkillType.Laser2:
			case SkillType.Laser3:
			case SkillType.Laser4:
				icon += GlobalClass.getSkillNOByType(SkillType.Laser1);
				break;
			case SkillType.Laugh1:
			case SkillType.Laugh2:
			case SkillType.Laugh3:
			case SkillType.Laugh4:
				icon += GlobalClass.getSkillNOByType(SkillType.Laugh1);
				break;
			case SkillType.Platform1:
			case SkillType.Platform2:
			case SkillType.Platform3:
			case SkillType.Platform4:
				icon += GlobalClass.getSkillNOByType(SkillType.Platform1);
				break;
			case SkillType.Lightning:
				icon += GlobalClass.getSkillNOByType(SkillType.Lightning);
				break;
			case SkillType.SuperCement:
				icon += GlobalClass.getSkillNOByType(SkillType.SuperCement);
				console.log("icon:", icon);
				break;
			default:
				icon += GlobalClass.getSkillNOByType(this.skill);

		}
		return icon;

	}

}