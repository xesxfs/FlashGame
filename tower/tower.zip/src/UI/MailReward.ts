class MailReward extends eui.Component{
	private ItemNum:eui.BitmapLabel;
	private ItemImg:eui.Image;
	private pID:number;
	//初始化参数 level 第几关  
	public constructor(itemNum,propId,propType) {
		super();
		this.skinName =  "MailRewardSkin";
		this.ItemNum.text = itemNum +"";
		this.pID = propId;

		let sourc = "";
		switch (propType) {
			case goodsType.diamond:
				sourc = "HallAtlas_json.UI_dianchi_btn";
				break;
			case goodsType.exp:
				sourc = "HallAtlas_json.UI_dianchi_btn";
				break;
			case goodsType.brick:
				sourc = "CommonAtlas_json.Img_item303";
				break;
			case goodsType.props:
				sourc = "CommonAtlas_json.Img_item" + propId;
				break;
			case goodsType.role:
				sourc = "CommonAtlas_json.img_npchead0" + propId % 100;
				break;
			case goodsType.spirit:
				sourc = "HallAtlas_json.UI_tili_btn";//商品id 为 7,8,9
				break;
			case goodsType.gold:
				sourc = "HallAtlas_json.icon_coin";
				break;
		}
		this.ItemImg.source = sourc;
	}

	private getPropImg(propType,propId):string{
		return "";
	}
}