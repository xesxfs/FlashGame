class ToastTip extends eui.Component{
	private content:eui.Label;
	//初始化参数 level 第几关  
	public constructor(content:string) {
		super();
		this.skinName =  "ToastTipSkin";
		this.content.text = content;

		this.x = GlobalClass.GameInfoForConfig.stageWidth/2-320;
		this.y = GlobalClass.GameInfoForConfig.stageHeight/2-this.height/2;
		let targetY = this.y - 300;
		egret.Tween.get(this).wait(1000).to({alpha:0,y:targetY},1000).call(()=>{
			egret.Tween.removeTweens(this);
			this.parent.removeChild(this);
		},this);
	}

}