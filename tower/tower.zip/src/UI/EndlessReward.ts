class EndlessReward extends eui.Component{
	private ItemImg:eui.Image;
	private ItemNum:eui.Label;
	//初始化参数 level 第几关  
	public constructor(category,itemNum) {
		super();
		this.skinName = "EndlessRewardSkin";
		let source = EndlessReward.getItemImg(category,"1");
		this.ItemImg.source = source;
		this.ItemNum.text = itemNum+"";
	}

	public static getItemImg(propType, propId): string {
		let sourc = "";
		switch (propType) {
			case goodsType.diamond:
				sourc = "Shop_json.icon_fuel";
				break;
			case goodsType.brick:
				sourc = "CommonAtlas_json.Img_item303";
				break;
			case goodsType.props:
				sourc = "CommonAtlas_json.Img_item" + propId;
				break;
			case goodsType.role:
				sourc = "CommonAtlas_json.to" + propId;
				break;
			case goodsType.spirit:
				sourc = "Shop_json.Img_spirit0"+propId;//商品id 为 7,8,9
				break;
			case goodsType.flower:
				sourc = "CommonAtlas_json.UI_flower_btn";
				break;
			case goodsType.piece:
                sourc = "CommonAtlas_json.Img_Piece";
            break;
			case goodsType.roleCard:
				sourc = "CommonAtlas_json.Img_item303";
            break;
			case goodsType.gold:
				sourc = "CommonAtlas_json.UI_coin_1";
            break;
		}
		return sourc;
    }
}