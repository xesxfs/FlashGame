class SignItem extends  eui.ItemRenderer{
	private ItemIcon:eui.Image;
	private ItemNum:eui.BitmapLabel;
	public constructor(propData) {
		super();
	}

	protected dataChanged(){
		this.ItemNum.text = this.data.quantity+"";
		
		let imgSource = "";
		 switch(this.data.category){
            case goodsType.diamond:
                imgSource = "Shop_json.Img_fuel02";
            break;
            case goodsType.brick:
                
            break;
            case goodsType.exp:
            break;
            case goodsType.props:
                imgSource = "CommonAtlas_json.Img_item"+this.data["props"]["prop_number"];
            break;
            case goodsType.role:
            break;
            case goodsType.spirit:
                imgSource = "CommonAtlas_json.Img_item303";
            break;
        }
		this.ItemIcon.source = RES.getRes(imgSource);
	}

	protected childrenCreated(){
	}

	
}