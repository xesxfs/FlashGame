class ShopRoleItem extends  eui.ItemRenderer{
	private RoleImg:eui.Image;
	private RoleName:eui.Label;
	private Btn_Buy:eui.Button;
	private skillGroup:eui.Group;
	private goldIcon:eui.Image;
	private fuelIcon:eui.Image;
	private pieceIcon:eui.Image;
	private PriceGroup:eui.Group;
	public constructor(propData) {
		super();
	}

	protected dataChanged(){
		this.PriceGroup.removeChildren();
		if(this.data.prop_id){
			this.RoleName.text = this.data.name;
			if(this.data.current_price_coin!=-1){
				let item = new ShopPriceItem("Shop_json.UI_coin_4",this.data.current_price_coin);
				this.PriceGroup.addChild(item);
			}
			if(this.data.current_price_diamond!=-1){
				let item = new ShopPriceItem("Shop_json.icon_fuel",this.data.current_price_diamond);
				this.PriceGroup.addChild(item);
			}
			if(this.data.current_price_chip!=-1){
				let item = new ShopPriceItem("Shop_json.UI_coin_6",this.data.current_price_chip);
				this.PriceGroup.addChild(item);
			}
			this.RoleImg.source = GameConstant.getItemImg(this.data.category,this.data.prop.role_number);

			let Npcdata = GlobalClass.NPCInfos[this.data.prop.role_number];
			let skillArr = Npcdata.skills[GlobalClass.Hall.npcLevel-1];
			for(let i=0;i<2;i++){
				let skillIcon:eui.Image = <eui.Image>this.skillGroup.getChildAt(2+i);
				let skillBG:eui.Image = <eui.Image>this.skillGroup.getChildAt(i);
				if(i<skillArr.length){
					skillIcon.visible = true;
					skillBG.visible = true;
					let skillInfo = GlobalClass.SkillInfosByID[skillArr[i]];

					skillIcon.source = "skill_icon_json.skill_icon_"+skillInfo.skill_number;
				}else{
					skillIcon.visible = false;
					skillBG.visible = false;
				}
			}
			this.checkHaveRole();
		}
	}

	protected childrenCreated(){
		 CommonFuc.AddClickEvent(this.Btn_Buy,egret.TouchEvent.TOUCH_END,this.Btn_BuyClick,this);
	}

	private Btn_BuyClick(){
		KFControllerMgr.getCtl(PanelName.ShopPanel).showRolePanel(this.data);
	}

	private checkHaveRole(){
		// let index = this.data.prop_id-900;
		// if(GlobalClass.CurrentUser.skinArr[index-1]==1){//如果已经拥有 则不显示购买按钮 显示替换按钮
		// 	this.Btn_Change.visible = true;
		// 	this.Btn_Buy.visible = false;
		// 	let img = <eui.Image>this.Btn_Change.getChildAt(0);
		// 	let label  = <eui.Label>this.Btn_Change.getChildAt(1);
		// 	if(this.data.prop_id==GlobalClass.CurrentUser.current_chara_skin){//当前选择的皮肤
		// 		this.using.visible = true;
		// 		this.Btn_Buy.visible = false;
		// 		this.Btn_Change.visible = false;
		// 	}else{
		// 		this.using.visible = false;
		// 		this.Btn_Buy.visible = true;
		// 		this.Btn_Change.visible = true;
		// 	}
		// }else{
		// 	this.Btn_Change.visible = false;
		// 	this.Btn_Buy.visible = true;
		// }
	}

}