class OnlineRewardItem extends eui.Component{
	private goldNum:eui.Label;
	private minNum:eui.Label;
	private isFinish:eui.Label;
	private tipPoint:eui.Image;
	private Btn_Get:eui.Button;
	//初始化参数 level 第几关  
	public constructor(level,avatarPos,iscurMission = false,isOpen = false,type=1,friendImg = "") {
		super();
		this.skinName =  "OnlineRewardItemSkin";
		this.goldNum.text = "50";
		this.tipPoint.visible = false;
		this.initButton();
	}

	public initView(haveReceive,isOpen){
		console.log("initView");
		if(haveReceive){//已经领取
			this.isFinish.visible = true;
			this.Btn_Get.visible = false;
		}else{
			this.isFinish.visible = false;
			this.Btn_Get.visible = true;
		}
		if(isOpen){
			this.Btn_Get.enabled = true;
			CommonFuc.butBright(this.Btn_Get);
		}else{
			this.Btn_Get.enabled = false;
			CommonFuc.butFade(this.Btn_Get,0.55);
		}
		
	}

	private initButton(){
		CommonFuc.AddClickEvent(this.Btn_Get,egret.TouchEvent.TOUCH_END,this.Btn_GetClick,this);
	}

	private Btn_GetClick(){

	}
}