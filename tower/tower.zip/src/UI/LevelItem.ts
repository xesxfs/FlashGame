class LevelItem extends eui.Component {
	private Btn_start: eui.Button;
	private missionNum: eui.BitmapLabel;
	private mLevel;//101是第一关 第一个任务
	private isCur = false;
	private Avatar = "";
	private mAvatarPos = null;
	private mIsOpen = false;
	private type = 1;
	private levelData: Object;

	private Icon: eui.Image;
	private lock: eui.Image;
	private BossGroup: eui.Group;
	private gameMode: eui.Image;
	private bottomImg: eui.Image;
	public level10: eui.Image;

	//初始化参数 level 第几关  
	public constructor(levelData, level, avatarPos, iscurMission = false, isOpen = false, type = 1, friendImg = "") {
		super();
		// this.percentWidth = 100;
		// this.percentHeight = 100;
		this.skinName = "LevelItemSkin";
		this.levelData = levelData;
		this.mLevel = level + 1;
		this.isCur = iscurMission;
		this.Avatar = friendImg;
		this.mAvatarPos = avatarPos;
		this.mIsOpen = isOpen;
		this.anchorOffsetX = this.width / 2;
		this.anchorOffsetY = this.height / 2;
		this.type = type;
		this.initView();
	}

	private initView() {
		this.level10.visible = false;
		let Level = this.mLevel;
		this.missionNum.text = Level + "";
		if (Level % 10 == 0) {
			this.Icon.visible = true;
			this.missionNum.visible = false;
		} else {
			this.Icon.visible = false;
			this.missionNum.visible = true;
		}
		if (this.mIsOpen) {
			this.lock.visible = false;
			this.bottomImg.source = "Game_json.passed";
		} else {
			this.lock.visible = true;
			this.bottomImg.source = "Game_json.unpass";
		}
		/**当前关卡 */
		if (this.isCur) {
			this.lock.visible = false;
			this.bottomImg.source = "Game_json.passing";
		}
		this.gameMode.source = "Game_json.Img_Gamemode" + (this.type + 1);
		if (Level % 10 == 0) {
			this.level10.visible = true;
			this.bottomImg.visible = false;
		}

		this.initPos();
		this.initButton();
	}

	//初始化坐标 从本地的配置文件中读取每一关的关卡位置，头像摆放位置
	private initPos() {
		if (this.mAvatarPos != null && this.Avatar != "") {
			let img_avatar = new eui.Image("");
		}


	}

	private initButton() {
		// if(this.mIsOpen){
		// 	this.Btn_start.touchEnabled = true;
		// 	CommonFuc.AddClickEvent(this.Btn_start,egret.TouchEvent.TOUCH_END,this.Btn_startClick,this);
		// }else{
		// 	this.Btn_start.touchEnabled = false;
		// }

		if (this.mIsOpen || this.isCur) {
			this.touchEnabled = true;
			CommonFuc.AddClickEvent(this.BossGroup, egret.TouchEvent.TOUCH_END, this.Btn_startClick, this);
		} else {
			this.touchEnabled = false;
		}
	}

	private Btn_startClick() {
		// let js = {
		// 	stage_number: this.mLevel
		// };
		// WebSocketMgr.getInstance().SendOneceMsg(MsgID.GAME.GetLevelBrief, JSON.stringify(js));
		if (!this.levelData) return;
		GlobalClass.CurrentStage.parseData(this.levelData);
		GlobalClass.Game.isDebug = false;
		// GlobalClass.Game.ShowInfoLevel = this.mLevel
		KFSceneManager.getInstance().replaceScene(SceneName.Fight);;
		// KFControllerMgr.getCtl(PanelName.LevelInfoPanel).setData(this.levelData).show();
	}
}