class EndlessRankItem extends  eui.ItemRenderer{
	private rankImg:eui.Image;
    private levelImg:eui.Image;
	private playerName:eui.Label;
    private score:eui.Label;
	private avatar:eui.Image;
	private rankLabel:eui.Label;
	public constructor(propData) {
		super();

	}

	protected dataChanged(){
		this.score.text = this.data.rank_score+""
		this.playerName.text = CommonFuc.subString(this.data.player_name,10,true);
		if(this.data.rank<=3){
			this.rankImg.source = RES.getRes("Game_json.img_rank"+this.data.rank);
			this.rankImg.visible = true;
			this.rankLabel.visible = false;
		}else{
			this.rankImg.visible = false;
			this.rankLabel.visible = true;
			this.rankLabel.text = this.data.rank;
		}
		this.levelImg.source = RES.getRes("Game_json.img_level0"+(this.data.battle_level+1));
	}

	protected childrenCreated(){
	}

	
}