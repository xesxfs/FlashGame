class ShopItem extends  eui.ItemRenderer{
	private PropImg:eui.Image;
	private PropName:eui.Label;
	private PropDesc:eui.Label;
	private Btn_Buy:eui.Button;
	private discount:eui.Image;
	private ImgSourc:string="";
	private using:eui.Image;
	public constructor(propData) {
		super();
	}

	protected dataChanged(){
		this.using.visible = false;
		this.PropName.text = this.data.name;
		if(this.data.category==goodsType.props){//道具
			this.PropDesc.text = this.data.prop.description;
		}else{
			this.PropDesc.text = this.data.descr==null?"":this.data.descr;
		}
		let propNum = 0;
		if(this.data.prop!=null){
			propNum = this.data.prop.prop_number;
		}else{
			if(this.data.prop_id!=-1){
				propNum = this.data.prop_id;
			}else{
				propNum = this.data.good_id;
			}
		}
		this.ImgSourc = GameConstant.getItemImg(this.data.category,propNum);
		if(this.ImgSourc!=""){
			this.PropImg.source = this.ImgSourc;
		}
		
		let oriNumText = <eui.BitmapLabel>this.Btn_Buy.getChildAt(3);
		let nowNumText = <eui.BitmapLabel>this.Btn_Buy.getChildAt(2);
		nowNumText.visible = false;
		let discount =  1;
		if(this.data.category==goodsType.diamond){
			oriNumText.text = this.data.price_rmb;
			nowNumText.text = this.data.current_price_rmb;
			discount = this.data.discount_rmb;
		}else {
			oriNumText.text = this.data.price_diamond;
			nowNumText.text = this.data.current_price_diamond;
			discount = this.data.discount_diamond;
		}

		if(discount<1){
			this.discount.visible = true;
			let imgName = "Shop_json.Img_discount0"+discount*10;
			this.discount.source = RES.getRes(imgName);
			nowNumText.visible = true;
			oriNumText.y = 30;
		}else{
			this.discount.visible = false;
			oriNumText.y = 22;
			nowNumText.visible = false;
		}

		let img = <eui.Image>this.Btn_Buy.getChildAt(1)
		if(this.data.category==goodsType.diamond){
			img.source = "CommonAtlas_json.Img_money";
		}else{
			img.source = "Shop_json.icon_fuel";
		}
	}

	protected childrenCreated(){
		 CommonFuc.AddClickEvent(this.Btn_Buy,egret.TouchEvent.TOUCH_END,this.Btn_BuyClick,this);
	}

	private Btn_BuyClick(){
		if(this.data.category==goodsType.diamond){//直接发起支付
			let js = {
				good_id:this.data.good_id,
				pay_type:PayType.AliPay,
				is_package:0,
			}
			WebSocketMgr.getInstance().SendOneceMsg(MsgID.HALL.GetPayOrder,JSON.stringify(js));
		}else{//购买物品
			KFControllerMgr.getCtl(PanelName.ShopPanel).showPropPanel(this.data,this.ImgSourc);
		}
	}
}