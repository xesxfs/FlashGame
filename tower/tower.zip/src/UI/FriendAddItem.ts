class FriendAddItem extends  eui.ItemRenderer{
	private avatar:eui.Image;
	private titleName:eui.Image;
	private nickName:eui.Label;
	private level:eui.Label;
	private Btn_AddFriend:eui.Button;
	public constructor(propData) {
		super();
	}

	protected dataChanged(){
		// this.avatar.source = " LV."+this.data.level;
		this.titleName.source = "HallAtlas_json.img_hallLevel0"+(this.data.battle_level+1);
		this.nickName.text = this.data.nick;
		this.level.text = " LV."+this.data.level;
	}

	protected childrenCreated(){
		 CommonFuc.AddClickEvent(this.Btn_AddFriend,egret.TouchEvent.TOUCH_END,this.Btn_AddFriendClick,this);
	}

	private Btn_AddFriendClick(){
		let js = {
			player_id:this.data.player_id,
			source:friendSource.fromSearch,
		}
		WebSocketMgr.getInstance().SendOneceMsg(MsgID.FRIEND.ApplyAddFrind,JSON.stringify(js));
	}
	private onRemoveFromStage(){
		super.$onRemoveFromStage();
		console.log("onRemoveFromStage");
	}

}