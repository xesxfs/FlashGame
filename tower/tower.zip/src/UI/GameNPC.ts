class GameNPC extends eui.Component {

	private npcType;
	private originHeartNum = 0;
	private heartNum = 0;
	private Healthy = true;
	private roleAni: dragonBones.Armature;
	private canDead = true;
	private heartArr: Array<dragonBones.Armature> = [];
	private heartPos = [[35, 182], [90, 193], [145, 182]];
	private skillGroup: eui.Group;
	private roleGroup: eui.Group;
	private skillBtns: Array<RoleSkillBtn> = [];

	//初始化参数 level 第几关  
	public constructor(type, heartNum) {
		super();
		this.skinName = "NPCSkin";
		this.npcType = type;
		this.heartNum = heartNum;
		this.originHeartNum = heartNum;
		this.initView(type);
		if (this.heartNum == 0) {
			this.canDead = false;
		}
	}

	protected childrenCreated() {
		// this.touchEnabled = false;
		if (GlobalClass.Game.GameMode != 2) {
			this.addEventListener(egret.Event.REMOVED_FROM_STAGE, this.onRemove, this);
		}
		this.initRoleSkillBtn();
	}

	private onRemove() {
		console.log("on remove npc ");
		egret.Tween.removeTweens(this);
		this.removeEventListener(egret.Event.REMOVED_FROM_STAGE, this.onRemove, this);
		AnimationMgr.getInstance().clenSkeleton(this.roleAni);
		this.heartArr.forEach((value) => {
			AnimationMgr.getInstance().clenSkeleton(value);
		});
	}

	private isMoving = false;
	private targetPosx;
	public moveLeft() {
		if (!this.isMoving) {
			this.isMoving = true;
			this.targetPosx = 100;
			this.startMove(true);
		}
	}

	public moveRight() {
		if (!this.isMoving) {
			this.isMoving = true;
			this.targetPosx = 550;
			this.startMove(false);
		}
	}
	/**增加技能点 */
	public addSkillPoint() {
		this.skillBtns.forEach((btn) => {
			btn.addSkillPoint();
		})
	}
	/**使用技能 */
	public useRoleSkill(btn: RoleSkillBtn) {
		btn.resetSkillPoint();
		/**派发使用技能事件,在SkillManager监听 */
		this.dispatchEventWith("onRoleSkillAction", false, [btn.skill, btn.skillCategory]);
	}
	/****点击技能按钮 */
	private onTouchRoleSkill(e: egret.TouchEvent) {
		console.log("onTouchRoleSkill");
		let skillBtn = e.currentTarget as RoleSkillBtn;
		if (skillBtn.isCanUse()) {
			this.useRoleSkill(skillBtn);
		} else {
			console.log("不能释放技能");
		}

	}
	/***初始化技能按钮 */
	public initRoleSkillBtn() {
		if (!GlobalClass.Hall.currentRole || !GlobalClass.Hall.currentRole["skills"]) {
			return;
		}
		let skillIDs = [];
		skillIDs = GlobalClass.Hall.currentRole["skills"][GlobalClass.Hall.npcLevel]; //当前的NPC技能
		skillIDs.forEach((skid) => {
			let skillInfo = GlobalClass.SkillInfosByID[skid];
			let skill_number = skillInfo.skill_number;
			let need_point = skillInfo.need_point ? skillInfo.need_point : 10;
			let skillType = GlobalClass.SkillMatchCode[skill_number]
			this.addRoleSkill(skillType, need_point);
		});
		// this.addRoleSkill(SkillType.Fog4);
		// this.addRoleSkill(SkillType.Laser4);
		// this.addRoleSkill(SkillType.Laugh4);
		// this.addRoleSkill(SkillType.Platform1);
		// this.addRoleSkill(SkillType.SuperCement);
		// this.addRoleSkill(SkillType.Lightning);
	}

	public addRoleSkill(skillType: SkillType, needPoint: number = 1) {
		let roleSkillBtn = new RoleSkillBtn(skillType, SkillCategory.Player);
		let len = this.skillGroup.numChildren;
		roleSkillBtn.x = len * (roleSkillBtn.width + 10);
		this.skillGroup.addChild(roleSkillBtn);
		this.skillBtns.push(roleSkillBtn);
		roleSkillBtn.maxSkillPoint = needPoint;
		roleSkillBtn.addEventListener("touchTap", this.onTouchRoleSkill, this);
	}

	private startMove(moveLeft) {
		egret.Tween.get(this).to({ x: this.targetPosx }, 1200, egret.Ease.backOut).call(function () {
			this.isMoving = false;
			if (moveLeft) {
				this.roleAni.display.scaleX = -1;
			} else {
				this.roleAni.display.scaleX = 1;
			}
		}, this);
	}

	private initView(roleID) {
		roleID = roleID - 900 - 1;
		// roleID = 1;
		if (this.originHeartNum == 1) {
			let pos = this.heartPos[1];
			this.initHeart(pos[0], pos[1]);
		} else if (this.originHeartNum == 3) {
			for (let i = 0; i < 3; i++) {
				let pos = this.heartPos[i];
				this.initHeart(pos[0], pos[1]);
			}
		}

		//更换npc的图标
		this.roleAni = AnimationMgr.getInstance().getRoleSke(roleID, roleAni.Idle, 0, 0);
		// let a: eui.Image;
		this.roleGroup.addChild(this.roleAni.display);
		let posx = this.roleGroup.width / 2 + this.roleAni.display.width / 2 + 20;
		let posy = this.roleGroup.height / 2 + 20;
		this.roleAni.display.x = posx;
		this.roleAni.display.y = posy;
		this.roleAni.animation.play();
	}

	private initHeart(x, y) {
		let ani = AnimationMgr.getInstance().getSkeleton(skeletonType.heart, x, y);
		ani.animation.gotoAndStopByFrame("jianxue", 0);
		this.heartArr.push(ani);
		this.roleGroup.addChild(ani.display);

	}

	public minusHeart(): boolean {
		if (!this.canDead || this.heartNum == 0) {
			return;
		}
		this.heartAni(this.originHeartNum - this.heartNum, true);
		this.heartNum--;
		if (this.heartNum == 0) {
			return true;
		}
		this.Healthy = false;
		return false;
	}

	//只有生存模式才能加血
	public addHeart() {
		if (!this.canDead) {
			return;
		}

		if (this.heartNum < this.originHeartNum) {
			this.heartNum++;
		}

		this.heartAni(this.originHeartNum - this.heartNum, false);
	}

	private heartAni(index, isMinus) {
		// egret.Tween.get(sp).to({visible:false},100,egret.Ease.backOut).to({visible:true},100,egret.Ease.backOut)
		// .to({visible:false},100,egret.Ease.backOut).to({visible:true},100,egret.Ease.backOut)
		// .to({visible:false},100,egret.Ease.backOut).to({visible:true},100,egret.Ease.backOut).call(function (){
		// 	sp.visible = false;
		// },this);

		if (isMinus) {
			this.heartArr[index].animation.gotoAndPlay("jianxue", 0, 0, 1);
		} else {
			this.heartArr[index].animation.gotoAndPlay("jiaxue", 0, 0, 1);
		}
	}

	public isHealthy(): boolean {
		return this.Healthy;
	}

	public useSkill() {
		var name = roleAni[roleAni.Skill];
		this.roleAni.animation.gotoAndStop(name, -1);
		this.roleAni.animation.play();
	}

	public idle() {
		var name = roleAni[roleAni.Idle];
		this.roleAni.animation.gotoAndStop(name, -1);
		this.roleAni.animation.play();
	}

	public pack(): any {
		let js = {
			type: this.npcType,
			heartNum: this.heartNum,
		}
		return js;
	}

	//
	public unpack(data) {
		let num = data["heartNum"];
		let del = this.heartNum - num;
		for (let i = 0; i < del; i++) {
			this.minusHeart();
		}
	}

	public heartBlink() {
		this.heartArr.forEach(element => {
			egret.Tween.get(element.display, { loop: true }).to({ scaleY: 1.1, scaleX: 1.1 }, 200).to({ scaleY: 1, scaleX: 1 }, 200);
		});
	}
}