class ShopPriceItem extends eui.Component{
	private goldIcon:eui.Image;
	private goldNum:eui.Label;
	public constructor(iconSource,num) {
		super();
		this.skinName =  "ShopPriceItemSkin";
		this.goldIcon.source = iconSource;
		this.goldNum.text = num;
	}

}