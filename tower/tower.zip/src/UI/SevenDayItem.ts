class SevenDayItem extends eui.ItemRenderer{
	private day:eui.Label;
	private Items:eui.Group;

	protected dataChanged(){
		console.log("");
	}

	protected childrenCreated(){
		 
	}

	private Btn_PayClick(){
		
	}
}