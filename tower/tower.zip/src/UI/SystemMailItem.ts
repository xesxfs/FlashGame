class SystemMailItem extends  eui.ItemRenderer{
	private rankImg:eui.Image;
	private contentGroup:eui.Group;
	private title:eui.Label;
	private Btn_Delete:eui.Button;
	private Btn_Get:eui.Button;
	private content:eui.Label;
	private ItemGroup:eui.Group;
	private bgLine:eui.Image;
	private contentIsShow:boolean = false;
	private redPoint:eui.Image;
	private bgLine0:eui.Image;
	public constructor(propData) {
		super();
		this.contentIsShow = false;
	}

	protected dataChanged(){
		this.contentGroup.scaleY = 0;
		this.contentGroup.visible = false;

		this.title.text = this.data.title;
		this.content.text = this.data.content;

		if(this.data.has_read){
			this.redPoint.visible = false;
		}else{
			this.redPoint.visible = true;
		}


		this.ItemGroup.removeChildren();
		if(this.data.attaches&&this.data.attaches.length>0){
			this.data.attaches.forEach(element => {
				let item = new MailReward(element["quantity"],element["prop_id"],element["category"]);
				item.width = this.ItemGroup.height;
				item.height = this.ItemGroup.height;
				this.ItemGroup.addChild(item);
			});
			this.Btn_Get.visible = true;
			this.Btn_Delete.visible = false;
		}else{
			this.Btn_Get.visible = false;
			this.Btn_Delete.visible = true;
		}

		if(this.contentIsShow){
			this.contentGroup.visible = true;
			this.bgLine0.visible = false;
			this.bgLine.height = 400;
			this.contentGroup.scaleY = 1;
		}else{
			this.contentGroup.visible = false;
			this.contentGroup.scaleY = 0;
			this.bgLine0.visible = true;
			this.bgLine.height = 143;
		}
	}

	protected childrenCreated(){
		CommonFuc.AddClickEvent(this.Btn_Get,egret.TouchEvent.TOUCH_END,this.Btn_GetClick,this,0);
		CommonFuc.AddClickEvent(this.Btn_Delete,egret.TouchEvent.TOUCH_END,this.Btn_DeleteClick,this,0);
		this.addEventListener(egret.TouchEvent.TOUCH_END,this.itemClick,this);
		this.contentGroup.scaleY = 0;
		this.contentIsShow = false;
		this.contentGroup.visible = false;
		this.bgLine.height = 143;

		if(this.data&&this.data.haveOpen){
			this.redPoint.visible = false;
		}else{
			this.redPoint.visible = true;
		}
	}

	private itemClick(){
		if(this.contentIsShow){
			egret.Tween.get(this.contentGroup).to({scaleY : 0},200,egret.Ease.sineOut).call(function (){
				this.contentIsShow = false;
				this.contentGroup.visible = false;
				
			},this);

			this.bgLine0.visible = true;
			this.bgLine.height = 143;
		}else{
			this.contentGroup.visible = true;
			egret.Tween.get(this.contentGroup).to({scaleY : 1},200,egret.Ease.sineOut).call(function (){
				this.contentIsShow = true;
				
			},this);
			this.bgLine0.visible = false;
			this.bgLine.height = 400;
		}
		this.data.haveOpen = true;
		this.redPoint.visible = false;
		WebSocketMgr.getInstance().SendOneceMsg(MsgID.HALL.SetMailReaded,JSON.stringify({mail_id:this.data.id}));
		NetEventMgr.getInstance().clientMsg(MsgID.CLIENT.MailHaveRead,this.data.id);
	}

	private Btn_GetClick(evt){
		evt.stopImmediatePropagation();
		WebSocketMgr.getInstance().SendOneceMsg(MsgID.HALL.GetMailItems,JSON.stringify({mail_id:this.data.id}));

		let arr = [];
		 this.data.attaches.forEach(element => {
            let itemB = {
                quantity:element["quantity"],
                propid:element["prop_id"],
                category:element["category"],
            };
            arr.push(itemB);
		});
        GlobalClass.Hall.RewardList = arr;
	}

	private Btn_DeleteClick(evt){
		evt.stopImmediatePropagation();
		WebSocketMgr.getInstance().SendOneceMsg(MsgID.HALL.DelectMail,JSON.stringify({mail_id:this.data.id}));
	}

	private startLoadAvatar(){
		
	}
}