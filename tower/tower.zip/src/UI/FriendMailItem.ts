class FriendMailItem extends  eui.ItemRenderer{
    private avatar:eui.Image;
	private Btn_Get:eui.Button;
	private FriendName:eui.Label;
	private isLoadingAvatart = false;
	private content:eui.Label;
	private itemImg:eui.Image;
	public constructor(propData) {
		super();
	}

	protected dataChanged(){
		//{"to_id": 10010, "title": "test", "has_read": false, "content": "test", "attaches": [{"category": 7, "prop_id": 701, "quantity": 1, "prop": null}], "id": 56, "from_id": 10009}
		if(this.data.attaches){
			let item = this.data.attaches[0];
			switch (item.category){
				case goodsType.flower://鲜花
					// this.avatar.source = ""
					this.content.text = "向你赠送1朵鲜花";
					this.itemImg.source = "CommonAtlas_json.UI_flower_btn";
				break;
				case goodsType.spirit://体力
					this.content.text = "向你赠送1点体力";
					this.itemImg.source = "HallAtlas_json.icon_fuel_2";
				break;
			}
		}
		this.FriendName.text = this.data.from_player.nick;
	}

	protected childrenCreated(){
		CommonFuc.AddClickEvent(this.Btn_Get,egret.TouchEvent.TOUCH_END,this.Btn_GetClick,this);
	}

	private Btn_GetClick(){
		WebSocketMgr.getInstance().SendOneceMsg(MsgID.HALL.GetFriendMail,JSON.stringify({mail_id:this.data.id}));
	}

	private startLoadAvatar(){
		this.isLoadingAvatart = true;
	}
}