class FirstChargeItem extends eui.ItemRenderer{
	private fuel:eui.Label;
	private gold:eui.Label;
	private Btn_Pay:eui.Button;
	protected dataChanged(){
		CommonFuc.butBright(this.Btn_Pay);
		this.Btn_Pay.touchEnabled = true;
		if(this.data.props){
			this.data.props.forEach(element => {
				if(element.category==goodsType.diamond){
					this.fuel.text = element.quantity;
				}
				if(element.category==goodsType.gold){
					this.gold.text = element.quantity;
				}
			});

			//已经使用
			if(this.data.haveUsed){
				CommonFuc.butFade(this.Btn_Pay,0.5);
				this.Btn_Pay.touchEnabled = false;
			}
		}
	}

	protected childrenCreated(){
		 CommonFuc.AddClickEvent(this.Btn_Pay,egret.TouchEvent.TOUCH_END,this.Btn_PayClick,this);
	}

	private Btn_PayClick(){
		let js = {
				good_id:this.data.id,
				pay_type:PayType.AliPay,
				is_package:0,
		}
		WebSocketMgr.getInstance().SendOneceMsg(MsgID.HALL.GetPayOrder,JSON.stringify(js));
	}
}