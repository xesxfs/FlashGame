class FriendItem extends  eui.ItemRenderer{
	private avatar:eui.Image;
	private titleName:eui.Image;
	private nickName:eui.Label;
	private level:eui.Label;
	private Btn_Delete:eui.Button;
	private Btn_Flower:eui.Button;
	private Btn_Energy:eui.Button;
	public constructor(propData) {
		super();
	}

	protected dataChanged(){
		// this.avatar.source = " LV."+this.data.level;
		this.titleName.source = "HallAtlas_json.img_hallLevel0"+(this.data.battle_level+1);
		this.nickName.text = this.data.nick;
		this.level.text = " LV."+this.data.level;
	}

	protected childrenCreated(){
		 CommonFuc.AddClickEvent(this.Btn_Delete,egret.TouchEvent.TOUCH_END,this.Btn_DeleteClick,this);
		 CommonFuc.AddClickEvent(this.Btn_Flower,egret.TouchEvent.TOUCH_END,this.Btn_FlowerClick,this);
		 CommonFuc.AddClickEvent(this.Btn_Energy,egret.TouchEvent.TOUCH_END,this.Btn_EnergyClick,this);
	}

	private Btn_DeleteClick(){
		KFControllerMgr.showTips("确定要删除该好友吗！", 0, 2, () => {
				let js = {
					player_id:this.data.player_id,
				}
				WebSocketMgr.getInstance().SendOneceMsg(MsgID.FRIEND.DeleteFriend,JSON.stringify(js));
            });
	}

	private Btn_FlowerClick(){
		let js = {
			player_id:this.data.player_id,
		}
		WebSocketMgr.getInstance().SendOneceMsg(MsgID.FRIEND.SendFlower,JSON.stringify(js));
	}

	private Btn_EnergyClick(){
		let js = {
			player_id:this.data.player_id,
		}
		WebSocketMgr.getInstance().SendOneceMsg(MsgID.FRIEND.SendPhysics,JSON.stringify(js));
		// super.$onRemoveFromStage()
	}

	private onRemoveFromStage(){
		super.$onRemoveFromStage();
		console.log("onRemoveFromStage");
	}

}