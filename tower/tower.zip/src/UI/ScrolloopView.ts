/**
*  文 件 名：ItemScroll.ts
*  功    能： 滚动组件
*  内    容： 自定义组件，支持多张图片水平(垂直)切换滚动
* 
* Example:
* 1. 从自定义组件中找到ItemScroller，并拖动到exml上
* 2. 将需要显示对象(图片等)拖动到ItemScroller的Group下
* 3. 设置Group的布局为垂直or水平
*/
class ScrolloopView extends eui.Scroller {
    /**滚动完成*/
    public static EVENT_SCROLL_COMPLETE: string = "EVENT_SCROLL_COMPLETE";
    /**滚动项数量*/
    public itemNum: number;
    /**单个滚动项长度*/
    public itemSize: number;
    /**当前滚动到第几项  0表示第1项*/
    public curItemCount: number = 0;
    /**滚动时间*/
    public delayScroll: number = 250;
    /**是否是水平滚动*/
    public isHScroller: Boolean;
    /**触摸起始位置*/
    private touchStartPos: number;
    /**当前触摸位置和起始触摸位置距离*/
    private touchDist: number;
    /**滚动中*/
    private bScrolling: Boolean = false;

    /**移动间隔超过某个值，则滑动到下一页*/
    private moveDel: number = 0;

    private childGroup: eui.Group;

    //item子项目
    private items;

    //两个Item之间的间隔
    private itemWidth;

    //选择的序号
    private seletedNum;

    //两个Item之间的间隔 不包括Item本身宽度
    private itemInterval;

    private normalImg;
    private selectedImg;

    public constructor() {
        super();
    }

    public setStateBGImg(normalImg, seletedImg) {
        this.normalImg = normalImg;
        this.selectedImg = seletedImg;
        this.setSeletedImg();
    }

    private setSeletedImg() {
        let len = this.items.length;
        for (let i = 0; i < len; i++) {
            let element = this.items[i];
            if (this.curItemCount == i) {
                element.getChildAt(0).source = RES.getRes(this.selectedImg);
            } else {
                element.getChildAt(0).source = RES.getRes(this.normalImg);
            }
        }
    }

    public childrenCreated(): void {

        //立即验证，获取width、height
        this.validateNow();
        this.childGroup = <eui.Group>this.getChildAt(0);
        this.items = this.childGroup.$children;
        this.itemNum = this.items.length;
        this.itemWidth = this.items[0].width;

        //判断是垂直还是水平滚动
        var widthDist: number = this.viewport.contentWidth - this.viewport.width;
        if (widthDist > 0) {
            this.isHScroller = true;
            this.itemSize = this.items[1].x - this.items[0].x;
        } else {
            this.isHScroller = false;
            this.itemSize = this.items[1].y - this.items[0].y;
        }
        this.itemInterval = this.itemSize - this.itemWidth;

        this.moveDel = this.itemSize / 4;
        //滚动容器设置
        this.throwSpeed = 0;
        // this.bounces = true;
        this.addEventListener(eui.UIEvent.CHANGE_START, this.onChangeStartHandler, this);
        this.addEventListener(eui.UIEvent.CHANGE_END, this.onChangeEndHandler, this);

        // this.seletedNum = 3;
        // this.scrollToItem(2,false);
    }

    private resetItems() {
        let posx = this.viewport.scrollH;
        let vWight = this.viewport.contentWidth;
        let ss = posx + this.viewport.width;
        if (posx < this.itemSize) {//滑到左边边界

            let lastItem = this.items.pop();
            let a = [lastItem];
            lastItem.x = 0;
            let len = this.items.length;
            for (let i = 0; i < len; i++) {
                let item = this.items.shift();
                item.x = this.itemSize * (i + 1);
                a.push(item);
            }

            for (let i = 0; i < a.length; i++) {
                this.items.push(a[i]);
            }

            this.scrollToItem(this.curItemCount + 1, false);


        } else if (posx + this.viewport.width > this.viewport.contentWidth - this.itemSize) {//滑到右边边界
            console.log("resetItems");
            let first = this.items.shift();
            let a = [first];
            this.items.push(first);
            let len = this.items.length;
            for (let i = 0; i < len; i++) {
                this.items[i].x = this.itemSize * (i);
            }
            this.scrollToItem(this.curItemCount - 1, false);
        }
    }

    public getCurrentIndex() {
        return this.seletedNum;
    }

    /**可以滚动*/
    public start() {
        this.touchEnabled = true;
        this.touchChildren = true;
    }

    /**禁用滚动*/
    public stop() {
        this.touchEnabled = false;
        this.touchChildren = false;
    }

    /**拖动开始*/
    private onChangeStartHandler() {
        console.log("ItemScroller >> " + "change start");
        if (this.isHScroller) {
            this.touchStartPos = this.viewport.scrollH;
        } else {
            this.touchStartPos = this.viewport.scrollV;
        }
    }

    /**拖动结束*/
    private onChangeEndHandler(): void {
        console.log("ItemScroller >> " + "change end");
        if (this.touchStartPos == -1) { //防点击触发changeend
            return;
        }
        var dict: number;
        if (this.isHScroller) {
            dict = this.viewport.scrollH - this.touchStartPos;
        } else {
            dict = this.viewport.scrollV - this.touchStartPos;
        }
        if (dict > this.moveDel) {
            this.scrollToNext();
        } else if (dict < -this.moveDel) {
            this.scrollToLast();
        } else {
            this.scrollToItem(this.curItemCount);
        }
        this.touchStartPos = -1;
    }

    /**滑动到下一项*/
    public scrollToNext(): void {
        if (this.bScrolling) {
            return;
        }

        var item: number = this.curItemCount;
        if (item < this.itemNum - 1) {
            item++;
        }
        this.scrollToItem(item);

        this.seletedNum++;
        if (this.seletedNum > this.items.length) {
            this.seletedNum = 1;
        }
    }

    /**滑动到上一项*/
    public scrollToLast(): void {
        if (this.bScrolling) {
            return;
        }

        var item: number = this.curItemCount;
        if (item > 0) {
            item--;
        }
        this.scrollToItem(item);

        this.seletedNum--;
        if (this.seletedNum < 1) {
            this.seletedNum = this.items.length;
        }
    }

    /**
     * 滚动到指定项 (0是第一项)
     * @item 指定项
     */
    public scrollToItem(item: number, useAnimation = true): void {
        if (this.bScrolling) {
            return;
        }

        if (item >= 0 && item < this.itemNum) {
            this.bScrolling = true;
            this.disableTouch();
            this.curItemCount = item;
            egret.Tween.removeTweens(this.viewport);
            if (this.isHScroller) {
                let targetX = this.items[item].x + this.itemWidth / 2 - this.viewport.width / 2;
                if (useAnimation) {
                    egret.Tween.get(this.viewport).to({ scrollH: targetX, ease: egret.Ease.quadOut }, this.delayScroll);
                } else {
                    this.viewport.scrollH = targetX;
                }
            } else {
                let targetY = 0;
                if (useAnimation) {
                    egret.Tween.get(this.viewport).to({ scrollV: item * this.itemSize, ease: egret.Ease.quadOut }, this.delayScroll);
                } else {
                    this.viewport.scrollV = targetY;
                }
            }
            egret.Tween.get(this.viewport).wait(this.delayScroll).call(() => {
                this.bScrolling = false;
                this.enableTouch();
                this.dispatchEventWith(ScrolloopView.EVENT_SCROLL_COMPLETE, false, this.curItemCount);
                this.resetItems();
            }, this);
        }
        this.setSeletedImg();
    }

    public scrollToIndex(index: number) {
        this.seletedNum = index + 1;
        if (this.seletedNum > this.items.length || this.seletedNum < 0) {
            this.seletedNum = 1;
            index = 0;
        }
        this.scrollToItem(index, false);
    }

    public enableTouch() {
        this.touchEnabled = true;
        this.touchChildren = true;
    }

    public disableTouch() {
        this.touchChildren = false;
        this.touchEnabled = false;
    }

    /**销毁*/
    public destroy() {

    }

}