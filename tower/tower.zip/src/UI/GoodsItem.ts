class GoodsItem extends eui.ItemRenderer {
	private icon: eui.Image;
	private num: eui.Label;
	private state: eui.Image;

	private seletedImg: eui.Image;
	//初始化参数 level 第几关  
	public constructor(level, avatarPos, iscurMission = false, isOpen = false, friendImg = "") {
		super();
	}

	protected dataChanged() {
		this.hideInfoFlag();
		if (!this.data) { return; };
		let propID = "";
		switch (this.data.category) {
			case goodsType.diamond:
				propID = "";
				break;
			case goodsType.props:
				this.setPropsInfo();
				break;
			case goodsType.spirit:
				propID = "";
				break;
			case goodsType.role:
				this.setRoleInfo();
				break;
			case goodsType.roleCard:
				// propID = this.data.prop.role_number + "_" + this.data.prop.days;
				this.setRoleTicketsInfo();
				break;
			case goodsType.brick:
				propID = this.data.prop.role_number + "";
				this.setBlockSkinInfo();
				break;
			case goodsType.piece:
				this.setPropsInfo();
				break;
			case goodsType.entryCard:

				break;
		}

		this.setChecked();


	}

	private setIcon(propID) {
		this.icon.source = GameConstant.getItemImg(this.data.category, propID);
		this.data["source"] = this.icon.source;
	}

	/***道具*/
	private setPropsInfo() {
		let propID = this.data.prop ? this.data.prop.prop_number : "";
		this.icon.visible = true;
		this.setIcon(propID);
		this.num.visible = true;
		this.num.text = this.data.quantity;
	}

	/**角色 */
	private setRoleInfo() {
		let propID = this.data.role_number;
		this.icon.visible = true;
		this.setIcon(propID);
		/**未拥有该角色*/
		if (!this.data.prop) {
			let percent = 0.5;
			CommonFuc.imgFilterFloat(this.icon, [percent, percent, percent, 1]);
		} else {
			this.setState();
		}
	}

	/**砖块皮肤 */
	private setBlockSkinInfo() {

	}

	/***卡卷 */
	private setTicketsInfo() {
		this.setPropsInfo();

	}
	/***角色体验卡*/
	private setRoleTicketsInfo() {
		let propID = this.data.prop.role_number;
		this.icon.visible = true;
		this.setIcon(propID);
		this.num.visible = true;
		this.num.text = this.data.quantity
		this.state.visible = true;
		this.state.source = "CommonAtlas_json.tiyan";
	}


	/**选中 */
	private setChecked() {
		this.seletedImg.visible = !!this.data.isSeleted;
	}
	/**设置状态 */
	private setState() {
		if (this.data.is_forever) {
			this.state.visible = false;
			return;
		}
		//过期
		if (this.data.is_expired) {
			this.state.source = "CommonAtlas_json.guoqi";
		} else {
			//体验中				
			this.state.source = "CommonAtlas_json.tiyan";
		}
		this.state.visible = true;
	}



	protected childrenCreated() {
		CommonFuc.AddClickEvent(this, egret.TouchEvent.TOUCH_END, this.onClick, this);
	}

	private onClick() {
		if (!this.data) { return; }
		KFControllerMgr.getCtl(PanelName.InventoryPanel).resetSeletedItem(this.data);
	}

	private hideInfoFlag() {
		this.icon.filters = [];
		this.icon.visible = false;
		this.num.visible = false;
		this.state.visible = false;
	}

}