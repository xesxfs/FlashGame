class GiftItem extends eui.Component{
	private Icon:eui.Image;
	private desc:eui.Label;
	//初始化参数 level 第几关  
	public constructor(category,desc) {
		super();
		this.skinName =  "GiftItemSkin";
		this.desc.text = desc;
		let source = "";
		switch(category){
			case goodsType.gold:
				source = "Activity_Atlas_json.UI_coin_1";
			break;
			case goodsType.flower:
				source = "CommonAtlas_json.UI_flower_btn";
			break;
			case goodsType.roleCard:
				source = "CommonAtlas_json.UI_tiyancion";
			break;
			case goodsType.spirit:
				source = "CommonAtlas_json.UI_mail_icon_2";
			break;
		}
		this.Icon.source = source;
	}
}