class SoundSlider extends eui.HSlider{
	private oriWidth = 0;
	private light:eui.ProgressBar;
	private cbfun:Function;
	public constructor() {
		super();
	}

	protected childrenCreated(){
		this.addEventListener(eui.UIEvent.CHANGE, this.changeHandler, this);
		
		this.light.maximum = this.maximum;
		this.light.minimum = this.minimum;
	}

	private changeHandler(evt: eui.UIEvent): void {
		var percent = evt.target.value/this.maximum;
		this.light.value = evt.target.value;
		this.cbfun(percent);
	}

	public SetChangeCB(cb:Function,thisObj:any){
		this.cbfun = (evt: any)=>{
			cb.call(thisObj,evt);
		};
	}

	public set pValue(percent:number){
		this.value = this.maximum*percent;
		this.light.value = this.value;
		this.cbfun(percent);
	}

	public get pValue():number{
		return this.value/this.maximum;
	}
}