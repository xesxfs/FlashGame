class AchieveItem extends eui.ItemRenderer{
	private starts:eui.Group;
	private Btn_Get:eui.Button;
	private title:eui.Label;
	private desc:eui.Label;
	private amount:eui.Label;
	private percent:eui.ProgressBar;
	//初始化参数 level 第几关  
	public constructor(level,avatarPos,iscurMission = false,isOpen = false,friendImg = "") {
		super();
		// this.skinName =  "AchieveItemSkin";
	}

	protected dataChanged(){
		if(this.data.description!=null){
			for(let i=0;i<3;i++){
				this.starts.getChildAt(i).visible = false;
			}
			this.title.text = this.data.name;
			if(this.data.description!=null){
				// this.desc.text = this.data.description; 
				this.desc.textFlow = CommonFuc.parseColorText(this.data.description);
			}
			this.amount.text = this.data.reward_diamond;
			for(let i=0;i<this.data.starNum;i++){
				this.starts.getChildAt(i).visible = true;
			}
			this.percent.value = this.data.currentValue/this.data.target*100;
			if(this.data.open==1){//已达到
				this.Btn_Get.touchEnabled = true;
				CommonFuc.butBright(this.Btn_Get);
				let img = <eui.Image>this.Btn_Get.getChildAt(0);
				img.source = RES.getRes("Shop_json.Img_UIbutton01");
			}else{
				this.Btn_Get.touchEnabled = false;
				CommonFuc.butFade(this.Btn_Get,0.5);
				let img = <eui.Image>this.Btn_Get.getChildAt(0);
				img.source = RES.getRes("Shop_json.Img_UIbutton05");
			}
			let countText = <eui.Label>this.percent.getChildAt(2);
			countText.text = this.data.currentValue+"/"+this.data.target;	
		}

		if(this.data.isNew!=null){
			if(this.data.isNew==1){// 新增一颗星
				let star = this.starts.getChildAt(this.data.starNum-1);
				// star.visible = false;
				star.scaleX = 2;
				star.scaleY = 2;
				egret.Tween.get(star).to({scaleX:1,scaleY:1},700,egret.Ease.sineIn);
			}
		}
		
	}

	protected childrenCreated(){
		CommonFuc.AddClickEvent(this.Btn_Get,egret.TouchEvent.TOUCH_END,this.Btn_GetClick,this);
	}

	private Btn_GetClick(){
		let js = {
				achievement_number: this.data.achievement_number,
			};
			WebSocketMgr.getInstance().SendOneceMsg(MsgID.HALL.GetAchieve, JSON.stringify(js));
	}
}