class FriendAlienItem extends  eui.ItemRenderer{
	private avatar:eui.Image;
	private titleName:eui.Image;
	private nickName:eui.Label;
	private level:eui.Label;
	private Btn_Refuse:eui.Button;
	private Btn_Agree:eui.Button;
	private comefrom:eui.Label;
	public constructor(propData) {
		super();
	}

	protected dataChanged(){
		// this.avatar.source = " LV."+this.data.level;

		this.titleName.source = "HallAtlas_json.img_hallLevel0"+(this.data.battle_level+1);
		this.nickName.text = this.data.nick;
		this.level.text = " LV."+this.data.level;
		if(this.data.source==friendSource.fromSearch){
			this.comefrom.text = "搜索";
		}
		if(this.data.source==friendSource.fromChallenge){
			this.comefrom.text = "对战";
		}
		if(this.data.source==friendSource.fromRank){
			this.comefrom.text = "排行榜";
		}
	}

	protected childrenCreated(){
		 CommonFuc.AddClickEvent(this.Btn_Refuse,egret.TouchEvent.TOUCH_END,this.Btn_RefuseClick,this);
		 CommonFuc.AddClickEvent(this.Btn_Agree,egret.TouchEvent.TOUCH_END,this.Btn_AgreeClick,this);
	}

	private Btn_RefuseClick(){
		let js = {
			player_id:this.data.player_id,
		}
		WebSocketMgr.getInstance().SendOneceMsg(MsgID.FRIEND.RefuseApply,JSON.stringify(js));
	}

	private Btn_AgreeClick(){
		let js = {
			player_id:this.data.player_id,
		}
		WebSocketMgr.getInstance().SendOneceMsg(MsgID.FRIEND.AgreeApply,JSON.stringify(js));
	}

	private onRemoveFromStage(){
		super.$onRemoveFromStage();
		console.log("onRemoveFromStage");
	}

}