class LevelReward extends eui.Component{
	private ItemNum:eui.BitmapLabel;
	private ItemImg:eui.Image;
	private pID:number;
	//初始化参数 level 第几关  
	public constructor(itemNum,propId,propType,hideImg=false) {
		super();
		this.skinName =  "LevelRewardSkin";
		this.ItemNum.text = itemNum +"";
		this.pID = propId;
		let sourc = "";
		switch (propType) {
			case goodsType.diamond:
				sourc = "Shop_json.icon_fuel";
				break;
			case goodsType.exp:
				sourc = "HallAtlas_json.UI_dianchi_btn";
				break;
			case goodsType.brick:
				sourc = "CommonAtlas_json.Img_item303";
				break;
			case goodsType.props:
				sourc = "CommonAtlas_json.Img_item" + propId;
				break;
			case goodsType.role:
				sourc = "CommonAtlas_json.img_npchead0" + propId % 100;
				break;
			case goodsType.spirit:
				sourc = "HallAtlas_json.UI_tili_btn";
				break;
			case goodsType.gold:
				sourc = "HallAtlas_json.icon_coin";
				break;
		}

		this.ItemImg.source = sourc;
		if(hideImg){
			this.ItemImg.visible = false;
		}
	}

	//开始动画
	public startAni(){
		this.ItemImg.scaleX = 2;
		this.ItemImg.scaleY = 2;
		this.ItemImg.visible = true;
		egret.Tween.get(this.ItemImg).to({scaleX:1,scaleY:1},700,egret.Ease.sineIn);
	}
}