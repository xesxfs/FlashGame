// module Game {
// 	export module Modes {
// 		export class PlayMode {
// 			protected maxBlocks: number = 99;
// 			protected curZoomLevel: number = 0;
// 			private _discardAnimationGuide: number = NaN;
// 			protected nextBlockToCome: Game.GameWorld.Block;
// 			protected cameraPanY: number = 10;
// 			// protected camera: WBE.Cameras.wbPlayerCam;
// 			protected minBrickX: number = 1000;
// 			protected currHighestBlockY: number = 0;
// 			protected towerWidthTarget: number = 160;
// 			protected highestBlockY: number = 0;
// 			protected doNextBlock: boolean = false;
// 			// protected messageArea: egret.SwfMovie;
// 			protected topSpacing: number = NaN;
// 			protected startY: any = -30;
// 			protected discardHintGiven: boolean = false;
// 			protected bricksTouchedTowerCounter: number = 0;
// 			protected towerWidthTargetReached: boolean = false;
// 			private _dropAnimationGuide: number = NaN;
// 			protected highestY: number = 0;
// 			protected glowingBlock: Game.GameWorld.Block;
// 			// private glowFilter: flash.GlowFilter;
// 			protected discardingBlock: Game.GameWorld.Block;
// 			protected blocksToRemove: Array<any>;
// 			// protected blocks: flash.Dictionary;
// 			protected blocks = [];
// 			// protected ground: egret.SwfMovie;
// 			protected platformHeight: number = 20;
// 			protected cameraMoved: boolean = false;
// 			protected physicsWorld: Game.GameWorld.PhysicsWorld;
// 			protected currentBlock: Game.GameWorld.Block;
// 			// protected world: Game.GameWorld.World;
// 			protected world: egret.DisplayObjectContainer;
// 			// private discardGlowFilter: flash.GlowFilter;
// 			protected submitHintScoreDiff: number = 100;
// 			protected maxBrickX: number = -1000;
// 			protected allowZoom: boolean = false;
// 			protected firstBlock: boolean = true;
// 			protected zoomFrameNr: number = 0;
// 			protected minSpawnHeight: number = NaN;
// 			protected cameraZ: number = 10000;
// 			// protected line: egret.SwfMovie;
// 			protected submitHintGiven: boolean = false;

// 			public constructor(world: egret.DisplayObjectContainer) {
// 				this.world = world;

// 				var _loc2_: any = undefined;
// 				this.towerWidthTarget = 160;
// 				this.towerWidthTargetReached = false;
// 				this.bricksTouchedTowerCounter = 0;
// 				this.minBrickX = 1000;
// 				this.maxBrickX = -1000;
// 				this.maxBlocks = 99;
// 				this.cameraPanY = 10;
// 				this.cameraZ = 10000;
// 				this.platformHeight = 20;
// 				this.submitHintScoreDiff = 100;
// 				// this.camera = WBE.Cameras.wbPlayerCam.getInstance();
// 				this.curZoomLevel = 0//flash.checkInt(0);
// 				// this.minSpawnHeight = WBE.Managers.wbSettingsManager.getInstance().getWorldSettings("height") + 20;
// 				// this.topSpacing = WBE.Managers.wbSettingsManager.getInstance().getWorldSettings("height") / 2;
// 				this.startY = -30;
// 				this.highestY = 0;
// 				this.highestBlockY = 0;
// 				this.currHighestBlockY = 0;
// 				this.doNextBlock = false;
// 				this.firstBlock = true;
// 				this.submitHintGiven = false;
// 				this.discardHintGiven = false;
// 				this.cameraMoved = false;
// 				// this.world = Game.GameWorld.World.getInstance();
// 				// this.level.init();
// 				// this.ground = (<egret.SwfMovie>(WBE.Managers.wbAssetManager.getInstance().getGraphics("ground")));
// 				// this.world.addChild(this.ground);
// 				// this.ground.y = 0;
// 				// _loc2_ = 1 / this.camera.zToScale(this.cameraZ);
// 				this.allowZoom = true;
// 				// WBE.Managers.wbVarManager.getInstance().setVar("curHeight", 0);
// 				// WBE.Managers.wbVarManager.getInstance().setVar("maxHeight", 0);
// 				// WBE.Managers.wbVarManager.getInstance().setVar("allBricksSaved", true);
// 				// WBE.Managers.wbVarManager.getInstance().setVar("towerHeightIndex", 0);
// 				// WBE.Managers.wbVarManager.getInstance().setVar("bricksSavedIndex", 0);
// 				// WBE.Managers.wbVarManager.getInstance().setVar("blocks", 99);
// 				this.physicsWorld = new Game.GameWorld.PhysicsWorld();
// 				this.world.addChild(this.physicsWorld);
// 				this.blocks = [] //new flash.Dictionary();
// 				// this.messageArea = this.world.getBackgroundByBackgroundID("messageArea");
// 				// this.messageArea["textMC"].textField.selectable = false;
// 				// this.camera.setZ(this.cameraZ);
// 				// this.setCamera(false);
// 				// this.stepFunctions.setItem("play", { "func": flash.bind(this.playStep, this), "type": "loop", "next": "initZoom" });
// 				// this.stepFunctions.setItem("initZoom", { "func": flash.bind(this.initZoom, this), "type": "single", "next": "zoom" });
// 				// this.stepFunctions.setItem("zoom", { "func": flash.bind(this.zoomStep, this), "type": "loop", "next": "end" });
// 				// this.stepFunctions.setItem("end", { "func": flash.bind(this.endMode, this), "type": "stop", "next": "end" });
// 				// this.currentStep = "play";
// 				this.blocksToRemove = new Array();
// 				// WBE.Managers.wbDebugManager.getInstance().startMeasuring();
// 				// WBE.Managers.wbVarManager.getInstance().setVar("nextBlockID", Math.floor(WBE.Managers.wbVarManager.random() * 7));
// 				this.nextBlockID = Math.random() * 7 >> 0;
// 				// WBE.Managers.wbAudioManager.getInstance().playBGM("bgm");
// 				// this.setGameMessage("build the highest tower!", 210, true);
// 			}



// 			public requestAddBlock(): any {
// 				if (this.maxBlocks > 0) {
// 					// this.checkBlockMessage();
// 					this.addBlock();
// 				}
// 				else {
// 					this.currentBlock = null;
// 					// this.determineHighestY();
// 					// this.checkHeight();
// 					// this.nextPhase();
// 				}
// 			}



// 			public playStep() {
// 				var _loc1_: number = 0;
// 				// if (this.firstBlock) {
// 				// 	this.firstBlock = false;
// 				// 	this.addBlock();
// 				// }
// 				// if (this.maxBlocks >= 0) {
// 				// 	this.currentBlock.update();
// 				// }
// 				// this.determineHighestY();
// 				// this.checkHeight();
// 				// this.statsCheckTowerHeight();
// 				// this.physicsWorld.step();
// 				// if (this.doNextBlock) {
// 				// 	this.doNextBlock = false;
// 				// 	this.nextBlock();
// 				// }
// 				// while (_loc1_ < this.blocksToRemove.length) {
// 				// 	this.blockHitBottom(this.blocksToRemove[_loc1_]);
// 				// 	_loc1_++;
// 				// }
// 				// this.blocksToRemove = new Array();
// 			}


// 			protected checkHeight(): any {
// 				// WBE.Managers.wbVarManager.getInstance().setVar("curHeight", Math.floor(this.highestY));
// 				// if (this.highestY > WBE.Managers.wbVarManager.getInstance().getVar("maxHeight")) {
// 				// 	WBE.Managers.wbVarManager.getInstance().setVar("maxHeight", Math.floor(this.highestY));
// 				// }
// 				// if (<any>!this.submitHintGiven) {
// 				// 	if (WBE.Managers.wbVarManager.getInstance().getVar("realCurHeight") < WBE.Managers.wbVarManager.getInstance().getVar("realMaxHeight") - this.submitHintScoreDiff) {
// 				// 		this.setGameMessage("You can submit your score from the pause menu (\'p\' key)");
// 				// 		this.submitHintGiven = true;
// 				// 	}
// 				// }
// 			}

// 			public nextLevel(): any {
// 			}

// 			private removeSelectGlow(): any {
// 			}


// 			public nextBlock() {
// 				this.maxBlocks--;
// 				if (this.currentBlock != null) {
// 					this.playMaterializeAnimation();
// 					this.bricksTouchedTowerCounter++;
// 					this.currentBlock.convertToPhysics();
// 					// this.statsCheckAllBricksSaved();
// 				}
// 				this.requestAddBlock();
// 			}


// 			public contactAdd(param1: any, param2: any) {
// 				if (param1.m_userData == "floor") {
// 					this.blocksToRemove.push(param2.m_userData);
// 				}
// 				else if (param2.m_userData == "floor") {
// 					this.blocksToRemove.push(param2.m_userData);
// 				}
// 				else if (param1.m_userData == this.currentBlock || param2.m_userData == this.currentBlock) {
// 					this.doNextBlock = true;
// 				}
// 			}

// 			private nextBlockID: number = -1;

// 			protected addBlock(): any {
// 				console.log("addBlock")
// 				var _loc1_: any = undefined;
// 				var _loc2_: any = undefined;
// 				this.currentBlock = null;
// 				this.determineHighestY();
// 				_loc1_ = this.highestY + this.topSpacing;
// 				if (_loc1_ < this.minSpawnHeight) {
// 					_loc1_ = this.minSpawnHeight;
// 				}
// 				this.currentBlock = new Game.GameWorld.Block(0, _loc1_, this.nextBlockID, this.physicsWorld);
// 				this.blocks.unshift(this.currentBlock);
// 				// this.world.addStaticObject(this.currentBlock, 1);
// 				// _loc2_ = WBE.UI.wbInterface.getInstance();
// 				if (this.nextBlockToCome != null) {
// 					// _loc2_.removeChild(this.nextBlockToCome);
// 				}
// 				if (this.maxBlocks > 1) {
// 					// WBE.Managers.wbVarManager.getInstance().setVar("nextBlockID", Math.floor(WBE.Managers.wbVarManager.random() * 7));
// 					this.nextBlockID = Math.random() * 7 >> 0
// 					this.nextBlockToCome = new Game.GameWorld.Block(0, 0, this.nextBlockID, this.physicsWorld, 0, false);
// 					this.nextBlockToCome.x = 350;
// 					this.nextBlockToCome.y = 50;
// 					// _loc2_.addChild(this.nextBlockToCome);
// 				}
// 			}

// 			protected statsCheckTowerHeight(): any {
// 				var _loc1_: any = undefined;
// 				// var _loc2_: com.kongregate.as3.client.KongregateAPI = <any>null;
// 				// if (WBE.Managers.wbVarManager.getInstance().getVar("towerHeightIndex") >= 5) {
// 				// 	return;
// 				// }
// 				// _loc1_ = WBE.Managers.wbVarManager.getInstance().getVar("realCurHeight");
// 				// _loc2_ = com.kongregate.as3.client.KongregateAPI.getInstance();
// 				// if (_loc1_ >= WBE.Managers.wbVarManager.getInstance().getVar("towerHeightMark" + WBE.Managers.wbVarManager.getInstance().getVar("towerHeightIndex"))) {
// 				// 	_loc2_.stats["submit"]("height" + WBE.Managers.wbVarManager.getInstance().getVar("towerHeightMark" + WBE.Managers.wbVarManager.getInstance().getVar("towerHeightIndex")), 1);
// 				// 	WBE.Managers.wbVarManager.getInstance().addToVar("towerHeightIndex", 1);
// 				// 	this.statsCheckTowerHeight();
// 				// }
// 			}

// 			public discardBlock(): any {
// 				// if (this.currentStep == "play") {
// 				// 	WBE.Managers.wbVarManager.getInstance().setVar("allBricksSaved", false);
// 				// 	WBE.Managers.wbVarManager.getInstance().addToVar("blocks", -1);
// 				// 	if (this.currentBlock != null) {
// 				// 		this.physicsWorld.m_world.DestroyBody(this.currentBlock.sensor);
// 				// 		if (this.discardingBlock != null) {
// 				// 			this.world.removeStaticObject(this.discardingBlock);
// 				// 		}
// 				// 		this.playDiscardAnimation(this.currentBlock);
// 				// 		this.blocks.delItem(this.currentBlock);
// 				// 	}
// 				// 	this.requestAddBlock();
// 				// }
// 			}

// 			public blockHitBottom(param1: any): any {
// 				// var _loc2_: number = <any>NaN;
// 				// if (this.blocks.getItem(param1) != null) {
// 				// 	_loc2_ = Math.floor(WBE.Managers.wbVarManager.random() * 3) + 1;
// 				// 	WBE.Managers.wbAudioManager.getInstance().playSound("crashSound" + _loc2_);
// 				// 	if (param1 == this.currentBlock) {
// 				// 		this.currentBlock = null;
// 				// 		this.nextBlock();
// 				// 	}
// 				// 	if (param1.sensor != null) {
// 				// 		this.physicsWorld.m_world.DestroyBody(param1.sensor);
// 				// 		if (<any>!this.discardHintGiven) {
// 				// 			this.setGameMessage("Press the \'c\' key to discard a block.");
// 				// 			this.discardHintGiven = true;
// 				// 		}
// 				// 	}
// 				// 	else {
// 				// 		this.physicsWorld.m_world.DestroyBody(param1.physicsObject);
// 				// 	}
// 				// 	this.world.removeStaticObject(param1);
// 				// 	this.blocks.delItem(param1);
// 				// 	WBE.Managers.wbVarManager.getInstance().setVar("allBricksSaved", false);
// 				// }
// 			}

// 			private playMaterializeAnimation(): any {
// 				// this.glowingBlock = this.currentBlock;
// 				// this.glowFilter = new flash.GlowFilter(16777215, 2, 10, 10, 2, 1);
// 				// this.glowingBlock.filters = [this.glowFilter];
// 				// this._dropAnimationGuide = 0;
// 				// caurina.transitions.Tweener.addTween(this, {
// 				// 	"dropAnimationGuide": 1, "time": 15, "useFrames": true, "transition": "easeOutExpo", "onComplete": function () {
// 				// 		this.glowingBlock.filters = [];
// 				// 	}
// 				// });
// 				// WBE.Managers.wbAudioManager.getInstance().playSound("dropSound");
// 			}

// 			protected newStatisticsCreated() {
// 			}


// 			protected determineHighestY() {
// 				var _loc1_: number = <any>NaN;
// 				var _loc2_: any = undefined;
// 				var _loc3_: any = undefined;
// 				this.highestY = 0;
// 				this.highestBlockY = 0;
// 				for (var forinvar__ in this.blocks.map) {
// 					_loc2_ = this.blocks.map[forinvar__][0];
// 					if (_loc2_ != this.currentBlock) {
// 						this.blocks[_loc2_]++;
// 						_loc1_ = _loc2_.getRealHeight();
// 						if (_loc1_ > this.highestY) {
// 							this.highestY = _loc1_;
// 						}
// 						_loc3_ = _loc2_.getRealXbounds();
// 						if (_loc3_.left < this.minBrickX) {
// 							this.minBrickX = _loc3_.left;
// 						}
// 						if (_loc3_.right > this.maxBrickX) {
// 							this.maxBrickX = _loc3_.right;
// 						}
// 					}
// 					this.highestBlockY = this.highestY;
// 					if (this.currentBlock != null) {
// 						_loc1_ = this.currentBlock.getRealHeight();
// 						if (_loc1_ > this.highestBlockY) {
// 							this.highestBlockY = _loc1_;
// 						}
// 					}
// 				}
// 			}

// 			protected updateMessageArea(): any {
// 				// this.messageArea.scaleX = this.messageArea.scaleY = 1 / this.camera.zToScale(this.camera.getZ());
// 			}

// 			protected statsCheckTowerWidth(): any {
// 				// var _loc1_: number = <any>NaN;
// 				// var _loc2_: com.kongregate.as3.client.KongregateAPI = <any>null;
// 				// if (this.towerWidthTargetReached) {
// 				// 	return;
// 				// }
// 				// _loc1_ = (this.maxBrickX - this.minBrickX) / 2;
// 				// _loc2_ = com.kongregate.as3.client.KongregateAPI.getInstance();
// 				// if (_loc1_ >= this.towerWidthTarget) {
// 				// 	this.towerWidthTargetReached = true;
// 				// }
// 			}


// 			public move(param1: any): any {
// 				if (this.currentBlock != null) {
// 					this.currentBlock.move(param1);
// 				}
// 			}

// 			private playDiscardAnimation(param1: Game.GameWorld.Block): any {
// 				// var discardBlock: Game.GameWorld.Block = param1;
// 				// this.discardingBlock = discardBlock;
// 				// this.discardGlowFilter = new flash.GlowFilter(16777215, 2, 10, 10, 2, 1);
// 				// this.discardingBlock.filters = [this.discardGlowFilter];
// 				// this._discardAnimationGuide = 0;
// 				// caurina.transitions.Tweener.addTween(this, {
// 				// 	"discardAnimationGuide": 1, "time": 15, "useFrames": true, "transition": "easeOutExpo", "onComplete": function () {
// 				// 		this.discardingBlock.filters = [];
// 				// 		this.world.removeStaticObject(this.discardingBlock);
// 				// 		this.discardingBlock = null;
// 				// 	}
// 				// });
// 				// WBE.Managers.wbAudioManager.getInstance().playSound("popSound");
// 			}

// 		}
// 	}
// }
