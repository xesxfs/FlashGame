class SkillComponent extends eui.Component {
	public constructor() {
		super();
		this.skillList = [0, 0, 0, 0, 0, 0, 0, 0, 0];
	}

	private skillList: Array<SkillType>;
	private skillUI = [];
	private taps: number = 200;
	private mgr: GameSkillManager;
	private currentSkills = [];
	public childrenCreated() {
		this.addEventListener("touchTap", this.onSkillClick, this);
	}

	public setMgr(manager: GameSkillManager) {
		this.mgr = manager;
	}

	public addSkillList(type: Array<SkillType>, category: Array<SkillCategory>, ly: number) {
		this.cleanAll();
		for (let i = 0; i < type.length; i++) {
			this.addSkill(type[i], category[i], ly)
		}
	}

	private addSkill(type: SkillType, category: SkillCategory, ly: number = 0) {	

		this.skillList[type]++;
		if (this.skillUI[type]) return;
		let skillBtn = new SkillButton(type, category);
		this.skillUI[type] = skillBtn;		
		this.addChild(skillBtn);
		skillBtn.y = ly;
		skillBtn.x = 360;
		this.currentSkills.push({ type: type, category: category });
		egret.Tween.get(skillBtn).wait(200).to({ y: (this.numChildren - 1) * skillBtn.height + this.taps, x: 580 }, 1000, egret.Ease.bounceOut);

	}

	public onUseSkill(type: SkillType): boolean {
		if (this.skillList[type] <= 0) return false;
		this.cleanAll();
		this.skillList[type]--;
		if (this.skillList[type] <= 0 && this.skillUI[type]) {
			this.removeChild(this.skillUI[type]);
			this.skillUI[type] = null;
		}
		return true;
	}

	public getCurrentSkills(): any {
		return this.currentSkills;
	}

	public unpack(data) {
		data.forEach(element => {
			this.addSkill(element["type"], element["category"]);
		});
	}

	public cleanAll() {
		this.skillUI = [];
		this.skillList = [];
		this.removeChildren();
		this.currentSkills = [];
	}

	public onSkillClick(e: egret.TouchEvent) {
		if (e.target instanceof SkillButton) {
			let type = 0;
			let category = 0;
			let skillBtn = e.target as SkillButton;
			type = skillBtn.type;
			category = skillBtn.category;
			this.sendUseSkill(type, category);
		}
	}

	public sendUseSkill(type: SkillType, category: SkillCategory) {
		this.mgr.useSkill(type, category);
	}

}



