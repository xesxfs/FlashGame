class GameComponent extends eui.Component {
	public curTet: Block;
	public nextTet: BlockType;
	public nextBlockUI: NextBlockUI;//下一块砖块的提示组件
	public blockGroup: eui.Group;
	protected footGroup: eui.Group;
	protected UIGroup: eui.Group;
	public platformGroup: eui.Group;
	public baseGroup: eui.Group;
	protected repeatGroup: eui.Group;
	protected NPCGroup: eui.Group;
	protected bricksArray: BrickArrayComponent;
	protected GameTip: eui.Label;
	public skillComponent: SkillComponent;
	protected propsUI: PropsComponent;
	public coundDownUI: CountDownUI;
	public rayCheck: RayCheck;
	protected scoreUI: EndlessScoreUI;
	protected Btn_Return: eui.Button;
	protected tipGroup: eui.Group;
	protected Guidetip: eui.Label;
	private guideTip1: eui.Label;
	private guideTip2: eui.Label;
	private tips: eui.Group;

	public laserShow: egret.DisplayObjectContainer;//激光

	private GameBG: eui.Image;//后背景
	protected GameBG1: eui.Image;// 前背景
	private repeatGameBG: eui.Image;
	public collideGroup: eui.Group;

	protected isPause: boolean = false;//游戏是否暂停
	public m_world: Box2D.Dynamics.b2World;
	public m_sprite: egret.Sprite;//debug模式画线层
	public debugDraw: Box2D.Dynamics.b2DebugDraw;
	public navSprie: egret.Sprite;
	public navDraw: BlockNavigate;
	protected skeletonHaveLoaded = false;
	private fallAni: dragonBones.Armature = null;
	protected createNewBrick = false;

	protected mNPc: GameNPC;//小精灵
	protected gameIsOver = false;//游戏已经结束
	private gamestart = false;

	public platform: Box2D.Dynamics.b2Body;//底座

	protected randomSeed;//随机种子，用于生产砖块时的随机
	public curBlockNum = 0;//当前是第几块砖
	public curUsedBlockNum = 0;//当前有效的是几块砖，已掉落的砖块不算

	public currentBlockList: Array<Block> = [];

	protected seatID = 0;//座位号 多人游戏时候使用

	protected haveBrickFall = false;//有砖块掉落

	private drawSprite: egret.Sprite;//闪电特效层
	private usingSkill = false;

	private netTimer: NetTimer;

	protected platFormHeight = 14;
	protected useSkillNum = 0;
	public Highest = 0;
	//平台上移了几格
	private platFormMoveUpTime = 0;
	//地图上移了多少
	private mapMoveUpDistance = 0;

	public skillMgr: GameSkillManager = null;

	protected itemMgr: GameItemsManager = null;
	/**屏移距离 */
	protected moveScreenDistance: number = 0;

	private isHide = false;

	protected rayHeight = 0;

	private cameras: Cameras;


	//获得场景的快照数据 所有砖块位置，
	public getCurrentState(): any {

		let js = {
			blocks: this.getBlockStateDatas(true),
			platFormMoveUpTime: this.platFormMoveUpTime,
			mapMoveUpDistance: this.mapMoveUpDistance,
			skillMgr: this.skillMgr.packSkillMsg(),
			useSkillNum: this.useSkillNum,
			npcData: this.mNPc.pack(),
			gameIsOver: this.gameIsOver,
			curBlockNum: this.curBlockNum,
			curUsedBlockNum: this.curUsedBlockNum,
			haveBrickFall: this.haveBrickFall,
			skillsInfo: this.skillComponent.getCurrentSkills(),
			leftBricksNum: this.getLeftBricksNum(),
			nextBrick: this.nextTet,
		}
		return js;
	}

	public getBlockStateDatas(isAll) {
		let blockInfos = [];
		this.currentBlockList.forEach(element => {
			//info 为每个砖块的类型 位置 旋转角度 状态（是否混乱,）
			let data = element.pack(isAll);
			blockInfos.push(data);
		});
		return blockInfos;
	}

	public setHide(isHide) {
		this.isHide = isHide;
	}

	public constructor(seatID = 0) {
		super();
		this.percentWidth = 100;
		this.percentHeight = 100;
		this.skinName = "GameComponetSKin";
		this.cameras = new Cameras();
		this.seatID = seatID;
		if (GlobalClass.Game.GameMode == 2) {
			this.randomSeed = GlobalClass.Game.PlayerRandomSeeds[this.seatID];
		} else {
			this.randomSeed = Math.floor(Math.random() * (360));
		}
	}

	private initSkills() {
		this.skillMgr = new GameSkillManager(this);
		this.skillComponent.setMgr(this.skillMgr);
	}

	private replaceScene(sceneId: number): string {
		return "Img_sceneBG0{%d}_png".replace("{%d}", sceneId.toString());
	}

	protected childrenCreated() {
		let bgSource = "";
		let bg1Source = "";
		let bg2Source = "";
		if (GlobalClass.CurrentStage.StageType == GameMode.speed) {
			bgSource = this.replaceScene(11);
			bg1Source = this.replaceScene(12);
			bg2Source = this.replaceScene(13);
		}
		if (GlobalClass.CurrentStage.StageType == GameMode.survival) {
			bgSource = this.replaceScene(21);
			bg1Source = this.replaceScene(22);
			bg2Source = this.replaceScene(23);
		}
		if (GlobalClass.CurrentStage.StageType == GameMode.jigsaw) {
			bgSource = this.replaceScene(31);
			bg1Source = this.replaceScene(32);
			bg2Source = this.replaceScene(33);
		}
		this.GameBG.source = RES.getRes(bgSource);
		this.repeatGameBG.source = RES.getRes(bg1Source)
		this.GameBG1.source = RES.getRes(bg2Source);

		// this.skillLine.visible = false;
		this.scoreUI.visible = false;
		this.coundDownUI.visible = false;
		this.rayCheck.visible = false;
		this.bricksArray.visible = false;
		this.GameTip.visible = false;
		this.Btn_Return.visible = false;
		this.tipGroup.visible = false;
		this.guideTip1.visible = false;
		this.guideTip2.visible = false;
		this.init();

		this.tipGroup.addEventListener(egret.TouchEvent.TOUCH_END, this.guildPanelClick, this);

		// if (GlobalClass.Game.GameMode == 2) {
		// 	this.GameTip.visible = true;
		// 	this.GameTip.text = "Player" + this.seatID;
		// }

		this.cameras.attachWorld(this.repeatGroup);
		this.cameras.attachWorld(this.baseGroup);
		this.cameras.attachWorld(this.blockGroup);
	}

	private initPropsCall() {
		this.addEventListener(PropsComponent.PropsAction, (e: egret.Event) => {
			UserControl.getInstance().useItem(e.data);
		}, this);
	}

	public init() {
		if (this.seatID != -1) {//特殊面板
			this.initSkills();
			this.initPropsCall();
			this.createNav(this.footGroup);
			this.gameIsOver = false;
			this.currentBlockList = [];
			this.createNextBlock();
			this.drawSprite = new egret.Sprite();
			this.blockGroup.addChild(this.drawSprite);
		}
		this.initPyhsics();
		this.createPlatForm();
		this.setPlatFormSkin();
	}

	private initItems() {
		// this.itemMgr = new GameItemsManager(this);
		// this.propsUI.setMgr(this.itemMgr);
	}

	private initNPC() {
		let npcType = 1;
		if (GlobalClass.Game.GameMode == 2) {
			npcType = GlobalClass.Game.PlayerSettings[this.seatID]["npc_type"] + 900;
		} else {
			npcType = GlobalClass.CurrentUser.current_chara_skin + 900;
		}
		if (GlobalClass.Game.isDebug) {
			npcType = 902;
		}
		if (GlobalClass.Game.GameMode == 1) {
			//{0: 竞速模式, 1: 生存模式, 2: 拼图模式}
			if (GlobalClass.CurrentStage.StageType == 1) {
				this.mNPc = new GameNPC(npcType, 3);
			} else if (GlobalClass.CurrentStage.StageType == 2) {
				this.mNPc = new GameNPC(npcType, 1);
			} else {
				this.mNPc = new GameNPC(npcType, 0);
			}
		} else if (GlobalClass.Game.GameMode == 2) {
			//{0: 竞速模式, 1: 生存模式, 2: 拼图模式}
			if (GlobalClass.CurrentStage.StageType == 1) {
				this.mNPc = new GameNPC(npcType, 3);
			} else if (GlobalClass.CurrentStage.StageType == 2) {
				this.mNPc = new GameNPC(npcType, 0);
			} else {
				this.mNPc = new GameNPC(npcType, 0);
			}
		} else if (GlobalClass.Game.GameMode == 3) {
			//{0: 竞速模式, 1: 生存模式, 2: 拼图模式}
			if (GlobalClass.CurrentStage.StageType == 1) {
				this.mNPc = new GameNPC(npcType, 3);
			} else if (GlobalClass.CurrentStage.StageType == 2) {
				this.mNPc = new GameNPC(npcType, 0);
			} else {
				this.mNPc = new GameNPC(npcType, 0);
			}
		}

		if (this.mNPc != null) {
			this.NPCGroup.addChild(this.mNPc);
			this.mNPc.x = this.width * 3 / 4;
			this.mNPc.y = this.height / 2;
			this.lastPosition = 1;

			// this.mNPc.addEventListener("touchTap", () => {
			// 	console.log("I'm npc !! I am god!")
			// 	this.skillMgr.onUseSkill(SkillType.Grow, false, true);
			// }, this);

			/**初始化NPc技能 */
			// this.mNPc.initRoleSkillBtn();
			// this.skillMgr.initNpcSkill();
		}
	}

	private lastPosition = 0;//上次小精灵所在的位置 0为左边 1为右边
	//小精灵左右移动 方块在左边 则npc跑右边 
	private NPCMove(posX) {
		if (posX < this.width / 3) {//上次NPC在左边，且方块刚移到左边 则npc跑右边
			this.lastPosition = 1;
			this.mNPc.moveRight();
		} else if (posX > this.width * 2 / 3) {//上次NPC在右边，且方块刚移到右边 则npc跑左边
			this.lastPosition = 0;
			this.mNPc.moveLeft();
		}
	}

	private beginDraw(beginx, beginy, endx, endy, displace) {
		this.drawSprite.graphics.clear();
		this.drawLighting(beginx, beginy, endx, endy, displace);
		this.drawLighting(beginx, beginy, endx, endy, displace);
	}

	private drawLighting(beginx, beginy, endx, endy, displace, curDetail = 5) {
		if (displace < curDetail) {
			this.drawSprite.graphics.lineStyle(4, 0xfff565);
			this.drawSprite.graphics.moveTo(beginx, beginy);
			this.drawSprite.graphics.lineTo(endx, endy);
			this.drawSprite.graphics.endFill();
		}
		else {
			let mid_x = (endx + beginx) / 2;
			let mid_y = (endy + beginy) / 2;
			mid_x += (Math.random() - 0.5) * displace;
			mid_y += (Math.random() - 0.5) * displace;
			this.drawLighting(beginx, beginy, mid_x, mid_y, displace / 2);
			this.drawLighting(endx, endy, mid_x, mid_y, displace / 2);
		}
	}

	//小精灵减血
	protected NPCMinusHeart() {
		if (GlobalClass.CurrentStage.StageType == 0) {
			return;
		}
		if (this.mNPc == null) {
			return;
		}
		if (this.mNPc.minusHeart()) {//死亡
			this.gameIsOver = true;
			this.onDead();
		}
	}

	public testAddHeart() {
		if (this.mNPc == null) {
			return;
		}
		this.mNPc.addHeart();
	}

	protected onDead() {

	}

	public backCdMove(time: number) {

	}

	public initPyhsics() {
		let gravity = new Box2D.Common.Math.b2Vec2(0, 50);
		this.m_world = new Box2D.Dynamics.b2World(gravity, true);
		// let debugSprite = new egret.Sprite();
		// this.crateDebug(debugSprite);
		// this.addChild(debugSprite);

		let listener = new Box2D.Dynamics.b2ContactListener();
		listener.BeginContact = (contact) => {
			this.onBeginContact(contact);
		};
		listener.EndContact = (contact) => {
			this.onEndContact.call(this, contact);
		};
		listener.PostSolve = (contact, impulse) => {
			this.onPostSolvet.call(this, contact, impulse);
		};
		listener.PreSolve = (contact, oldManifold) => {
			this.onPreSolve.call(this, contact, oldManifold);
		};
		this.m_world.SetContactListener(listener);
	}

	private lastTet: Block;
	private justChangeTet = false;
	private testCount2 = 0;
	public onBeginContact(contact: Box2D.Dynamics.Contacts.b2Contact) {

		this.testCount2++;
		// console.log("onBeginContact0"); 
		// if (this.curTet == null) {
		// 	return;
		// }
		let bodyA = contact.GetFixtureA().GetBody();
		let bodyB = contact.GetFixtureB().GetBody();
		// console.log("onBeginContact"+this.testCount2 +" pox1="+bodyA.GetPosition().x+" poy1="+bodyA.GetPosition().y+" pox2="+bodyB.GetPosition().x+" poy2="+bodyB.GetPosition().y);
		// if (bodyA != this.curTet.getBody() && bodyB != this.curTet.getBody()) {
		// 	return;
		// }
		if (bodyA != this.platform && bodyB != this.platform) {
			let blockA = contact.GetFixtureA().GetBody().GetUserData() as Block;
			let blockB = contact.GetFixtureB().GetBody().GetUserData() as Block;
			if (blockA.isBindJoint && blockB instanceof Block) {
				blockA.addJoinBody(blockB.getBody())
			}

			if (blockB.isBindJoint && blockA instanceof Block) {
				blockB.addJoinBody(blockA.getBody())
			}
		}
		// console.log("onBeginContact2");
		if (this.curTet != null) {
			this.getNPC().addSkillPoint();
			let body = this.getCurBody();
			if (contact.GetFixtureA().GetBody() == body || contact.GetFixtureB().GetBody() == body) {
				this.createNewBrick = true;
				this.onCurTetContact();

				/**避免冲击 */
				body.SetLinearVelocity(new Box2D.Common.Math.b2Vec2(0, 0));
				body.SetAngularVelocity(0);
				/**重新受到重力作用 */
				this.curTet.resetGravity();
				this.curTet.getBody().SetBullet(false);
				this.curTet.onFirstContact();

				this.lastTet = this.curTet;
				this.lastAngleSpeed = null;
				this.justChangeTet = true;

				GameTouchListener.getInstance().touchEnd();
				// ShakeEffect.Instance.startShake(this, 8, 8, 5);

				if (GlobalClass.Game.currentShowPlayer == this.seatID) {
					UserControl.getInstance().BlockChange();
					var manifold: Box2D.Collision.b2WorldManifold = new Box2D.Collision.b2WorldManifold();
					contact.GetWorldManifold(manifold);
					manifold.m_points.forEach(contactPoint => {
						//显示碰撞点的灰尘动画
						this.showCollideAni(contactPoint.x, contactPoint.y);
					});
				}
			}
		}
		// this.updateSkin();//碰撞后立刻刷新图片
	}

	protected haveNextBrick(): boolean {
		return true;
	}

	public onEndContact(contact: Box2D.Dynamics.Contacts.b2Contact) {
		// console.log("onEndContact");
	}

	public onPostSolvet(contact: Box2D.Dynamics.Contacts.b2Contact, impulse: Box2D.Dynamics.b2ContactImpulse) {

	}

	public onPreSolve(contact: Box2D.Dynamics.Contacts.b2Contact, oldManifold: Box2D.Collision.b2Manifold) {

	}

	public crateDebug(sprite: egret.Sprite) {
		this.m_sprite = sprite;
		this.debugDraw = new Box2D.Dynamics.b2DebugDraw();
		this.debugDraw.SetSprite(this.m_sprite);
		this.debugDraw.SetDrawScale(GlobalClass.GameInfoForConfig.factor);
		this.debugDraw.SetLineThickness(1);
		this.debugDraw.SetAlpha(0.8);
		this.debugDraw.SetFillAlpha(0);
		this.debugDraw.SetFlags(Box2D.Dynamics.b2DebugDraw.e_shapeBit | Box2D.Dynamics.b2DebugDraw.e_centerOfMassBit);
		// this.debugDraw.SetFlags(Box2D.Dynamics.b2DebugDraw.e_centerOfMassBit);
		this.m_world.SetDebugDraw(this.debugDraw);
	}

	public createNav(navDisplay?: egret.DisplayObjectContainer) {
		this.navSprie && this.navSprie.parent && this.navSprie.parent.removeChild(this.navSprie);
		this.navSprie = new egret.Sprite();
		if (navDisplay) {
			navDisplay.addChildAt(this.navSprie, 1);
		} else {
			this.addChild(this.navSprie);
		}
		this.navDraw = new BlockNavigate(this.navSprie, GlobalClass.CurrentStage.StageType);
	}

	public reset() {
		// this.initPyhsics();
		// this.removeChildren();
	}

	/**创建砖块,锁定状态不能创建和销毁刚体 */
	public createTet(blockDisplay?: egret.DisplayObjectContainer) {
		if (this.m_world.IsLocked()) return;
		if (this.curTet != null) {
			this.curTet.isCurTet = false;//把旧的砖块状态改变
		}
		this.curTet = BlockFactory.getBlock(this.m_world, this.width / 2, this.moveScreenDistance + 80, this.nextTet);
		this.currentBlockList.push(this.curTet);
		this.curTet.show(this.blockGroup);
		this.curTet.setSeed(this.randomSeed);
		this.curTet.setBlockID(this.curBlockNum);
		this.curTet.isCurTet = true;
		this.curBlockNum++;
		this.curUsedBlockNum++;
		if (GlobalClass.Game.currentShowPlayer == this.seatID) {
			this.showCreateAni(this.curTet.x + 20, this.curTet.y + 20);
		}

		this.onCreateTet();

		if (GlobalClass.Game.PlayerSeatID == this.seatID) {//多人对战，核查数据是否同步
			KFControllerMgr.getCtl(PanelName.GamePanel).onCollide(this.isHide);
		}
	}

	//默认是随机生成 拼图模式或多人模式里为根据列表生成
	public createNextBlock() {
		this.nextTet = this.getBlockType();
		this.nextBlockUI.showBlock(this.nextTet);
	}

	//创建平台，每个模式的勒种具体去创建
	protected createPlatForm() {
		Game.GameWorld.PhysicsWorld.createBox(this.m_world, 0, this.height, this.width, 40, true);
	}

	/**随机砖块类型 */
	protected getBlockType(): number {
		let btype = (CommonFuc.getRandomBySeed(this.randomSeed, this.curBlockNum) * 7 >> 0) + 1;
		return btype;
		// console.log("seed = " + this.randomSeed + " blockNum=" + this.curBlockNum + " type=" + btype);
		// return BlockType.I;
	}

	public updateInstant(msg: any) {
		switch (msg.getType()) {
			case PlayerMSGType.Move:
				if (this.curTet) {
					this.curTet.changeSkin(msg.getMoveType(), msg.getPosX(), msg.getPosY());
				}
				break;
			case PlayerMSGType.UseSKill:
				// this.onLogicUpdate(msg);
				break;
			case PlayerMSGType.UseItem:
				// this.onLogicUpdate(msg);
				break;
			case PlayerMSGType.Empty:
				if (this.curTet) {
					this.curTet.changeSkin(BlockControlType.Empty, 0, 0);
				}
				break;
		}
	}

	/**更新逻辑 */
	public update(msg: any) {
		switch (msg.getType()) {
			case PlayerMSGType.Empty:
				break;
			case PlayerMSGType.Move:
				if (GlobalClass.Game.PlayerSeatID == this.seatID) {//如果是自己的数据，则要校对是否是针对本次砖块的操作信息 如果不是，则丢弃，变成空帧
					if (UserControl.getInstance().getBLockIndex() == msg.getBlockIndex()) {
						this.onMoveUpdate(msg);
					}
				} else {
					this.onMoveUpdate(msg);
				}
				break;
			case PlayerMSGType.UseSKill:
				this.onLogicUpdate(msg);
				let msgs = msg as SkillMSG;
				if (this.seatID == msgs.getsenderID()) {
					this.useSkillNum++;
				}
				break;
			case PlayerMSGType.UseItem:
				this.onLogicUpdate(msg);
				break;
			case PlayerMSGType.Pause:
				break;
			case PlayerMSGType.Resume:
				break;
		}
		this.updatePhysicsWorld();
	}

	protected onMoveUpdate(msg) {
		if (this.curTet && msg.getMoveType() in BlockControlType) {
			this.curTet.changeStates(msg.getMoveType(), msg.getPosX(), msg.getPosY());
			return;
		}
	}

	//跟随每次UI帧 调用一次
	public updatePhysicsWorld() {
		// console.log("updatePhysicsWorld=========================");
		if (this.isPause || this.gameIsOver) {//如果是暂停状态，则不更新
			return;
		}

		this.updateBody();

		//更新物理世界
		this.m_world.Step(1 / GlobalClass.GameInfoForConfig.worldUpdateRate, 10, 10);


		// this.updateSkin();
		// this.m_world.DrawDebugData();

		//生成新的砖块
		if (this.createNewBrick == true) {
			if (this.curTet) {
				this.curTet.rebuildBlock(!this.curTet.isToFreezen);
			}
			if (this.haveNextBrick()) {
				this.createTet();
				this.createNewBrick = false;
			} else {
				this.curTet = null;
			}
		}
		if (this.curTet != null) {
			this.curTet.update();
			this.navDraw.nav(this.curTet.getSkinSprite(), this.curTet.parent);
			let pos = this.getCurBody().GetPosition().Copy();
			let posX = pos.x * GlobalClass.GameInfoForConfig.factor;
			// if (this.mNPc != null) {
			// 	this.NPCMove(posX);
			// }
		}

		//子类中具体实现onUpdate函数，用于不同的通关条件检测
		if (this.gamestart) {
			this.checkAndMoveBlockUpViewport();
			this.onPhysicsUpdate();
		}
	}

	protected onPhysicsUpdate() {

	}

	protected onLogicUpdate(msg: any) {
		if (msg.type == PlayerMSGType.UseSKill) {
			let smsg = <SkillMSG>msg
			this.skillMgr.onUseSkill(msg.getSkillID(), smsg.getState(), this.seatID == smsg.getsenderID(), this.seatID == smsg.getreceiverID());
		}

		if (msg.type == PlayerMSGType.UseItem) {
			let smsg = msg as ItemMSG;
			this.itemMgr.onUseMsg(smsg.getItemType());
		}
	}

	public updateSkin() {
		for (var body = this.m_world.GetBodyList(); body; body = body.GetNext()) {
			if (body.GetUserData() != null) {
				body.GetUserData().x = body.GetPosition().x * GlobalClass.GameInfoForConfig.factor;
				body.GetUserData().y = body.GetPosition().y * GlobalClass.GameInfoForConfig.factor;
				body.GetUserData().rotation = body.GetAngle() * 180 / Math.PI;
			}
			// this.checkBody(body);
		}
		this.updateEffect();
		this.m_world.DrawDebugData();
		if (this.skillMgr != null) {
			this.skillMgr.onGameUpdate();
		}
		this.onUpdateSkin();
	}

	protected onUpdateSkin() {

	}

	private npcPoint: egret.Point;
	private updateEffect() {
		if (this.usingSkill) {
			let tetPoint = this.blockGroup.globalToLocal(this.npcPoint.x, this.npcPoint.y);
			this.beginDraw(tetPoint.x, tetPoint.y, this.curTet.x, this.curTet.y, 200);
		}
	}

	public showBuffEffect() {
		this.npcPoint = new egret.Point(this.mNPc.x, this.mNPc.y + 120);
		this.showSkillEffct();
	}

	public showDebuffEffect() {
		this.npcPoint = new egret.Point(this.debuffNpc.display.x + 75, this.debuffNpc.display.y - 145);
		this.showSkillEffct();
	}

	public showSkillEffct() {
		this.usingSkill = true;
		let timer = new egret.Timer(1000, 1);
		timer.addEventListener(egret.TimerEvent.TIMER, () => {
			this.usingSkill = false;
			this.drawSprite.graphics.clear();
		}, this);
		timer.start();
	}

	public debuffNpc: dragonBones.Armature;
	public debuffNpcCome(callBack: Function, skillType: number): boolean {
		if (this.debuffNpc) {
			this.debuffNpcMoveEndPoint(callBack, skillType);
			return;
		}
		this.debuffNpc = AnimationMgr.getInstance().getRoleSke(0, roleAni.Idle, 0, 0);
		this.NPCGroup.addChild(this.debuffNpc.display);
		this.debuffNpc.display.x = this.width + this.debuffNpc.display.width;
		this.debuffNpc.display.y = this.mNPc.y - 50;
		this.debuffNpc.animation.play();
		this.debuffNpcMoveEndPoint(callBack, skillType);

		return true;
	}

	public debuffNpcMoveEndPoint(callBack: Function, skillType: number) {

		egret.Tween.get(this.debuffNpc.display).to({ x: this.debuffNpc.display.width + 20 }, 300).call(this.npcScale, this).wait(500).call(this.debuffNpcShowSkill, this, [callBack, skillType]);
	}

	private npcScale() {
		if (this.debuffNpc.display.scaleX != -1) {
			this.debuffNpc.display.scaleX = -1;
		}
	}
	public debuffNpcShowSkill(callBack: Function, skillType: number) {
		if (!this.debuffNpc) {
			this.skillMgr.showSkillEffect(skillType);
			return
		};
		var name = roleAni[roleAni.Skill];
		this.debuffNpc.animation.gotoAndStop(name, 1);
		this.debuffNpc.animation.play();
		this.showDebuffEffect();
		this.debuffNpc.addEventListener(dragonBones.AnimationEvent.COMPLETE, this.debuffNpcLeave, this);
		this.skillMgr.showSkillEffect(skillType);
	}

	private debuffNpcLeave() {
		if (!this.debuffNpc) return;
		var name = roleAni[roleAni.Idle];
		this.debuffNpc.animation.gotoAndStop(name, -1);
		this.debuffNpc.animation.play();
		this.debuffNpc.removeEventListener(dragonBones.AnimationEvent.COMPLETE, this.debuffNpcLeave, this);
		egret.Tween.get(this.debuffNpc.display).wait(800).to({ x: this.width + this.debuffNpc.display.width }, 300).call(this.detoryDebufNpc, this);
	}

	private detoryDebufNpc() {
		// if (this.debuffNpc) {
		// 	AnimationMgr.getInstance().clenSkeleton(this.debuffNpc);
		// }
		// this.debuffNpc = null;
	}

	private lastAngleSpeed = null;
	protected updateBody() {
		let tempHighest = this.UIGroup.height;
		for (var body = this.m_world.GetBodyList(); body; body = body.GetNext()) {
			//检测是否越界
			let pos = body.GetPosition().Copy();
			let posX = pos.x * GlobalClass.GameInfoForConfig.factor;
			let posY = pos.y * GlobalClass.GameInfoForConfig.factor;
			if (posY > this.stage.stageHeight - 30 || posX < -100 || posX > this.stage.stageWidth + 100) {
				this.haveBrickFall = true;
				this.onFall(body);
				if (posY > this.stage.stageHeight - 30) {//往下掉才出灰尘
					if (GlobalClass.Game.currentShowPlayer == this.seatID) {
						this.showFallAni(posX, posY);
					}
				}
				this.removeBody(body);
				continue;
			}

			tempHighest = this.compareHeightest(body, tempHighest);
			this.checkBody(body);

			// if (GlobalClass.Game.GameMode == 1 && GlobalClass.CurrentStage.StageType == 2) {
				if (body.GetLinearVelocity().LengthSquared() < 0.01 && body.GetAngularVelocity() < 0.01) {
					if (this.curTet == null || body != this.curTet.getBody()) {
						if (this.lastTet == null || body != this.lastTet.getBody()) {
							body.SetAwake(false);
						} else {
							if (this.justChangeTet) {
								this.justChangeTet = false;
								return;
							}
							let lastBody = this.lastTet.getBody();
							if (this.lastAngleSpeed == null) {
								this.lastAngleSpeed = lastBody.GetAngularVelocity();
							} else {
								let delAngel = Math.abs(lastBody.GetAngularVelocity() - this.lastAngleSpeed);
								if (delAngel > 0.0001) {

								} else {
									lastBody.SetAwake(false);
								}
							}
						}
						continue;
					}
				}
			// }


		}
		this.Highest = tempHighest;
	}

	protected checkBody(body: Box2D.Dynamics.b2Body) {

	}

	protected getCurBody(): Box2D.Dynamics.b2Body {
		if (!this.curTet) return null
		return this.curTet.getBody()
	}

	private compareHeightest(body: Box2D.Dynamics.b2Body, highest: number) {
		if (this.getCurBody() == body) return highest;
		let bodySprite = body.GetUserData();
		if (!bodySprite || !(bodySprite instanceof Block)) return highest;
		let bounds = bodySprite.getTransformedBounds(bodySprite.parent);
		if (bounds.topLeft.y < highest) {
			highest = bounds.topLeft.y;
		}
		return highest;
	}

	public GamePause(ispause) {
		this.isPause = ispause;
		this.onPause();
	}

	protected onPause() {

	}

	protected onCreateTet() {
		this.createNextBlock();
	}

	protected removeBody(body: Box2D.Dynamics.b2Body) {
		/***有debuff技能的砖块不能丢掉 */
		if (this.curTet && body == this.curTet.getBody() && this.curTet.haveDebuff()) {
			this.curTet.resetState();
			this.curTet.setPosition(new Box2D.Common.Math.b2Vec2(this.width / 2, this.moveScreenDistance));
		} else {
			this.m_world.DestroyBody(body);
			this.currentBlockList.remove(body.GetUserData());
			body.GetUserData().parent && body.GetUserData().parent.removeChild(body.GetUserData());
			this.onBlockRemove(body.GetUserData());
			if (this.curTet && body == this.curTet.getBody()) {
				if (this.haveNextBrick()) {
					// this.createNewBrick = true;
					this.curUsedBlockNum--;
					this.createTet();
				}
			}
		}
	}

	/***移除砖块调用 */
	protected onBlockRemove(block: Block) {

	}


	/**游戏开始之前要做的事 */
	public beginFirst(nextStep: Function, thisObj: any) {
		nextStep.call(thisObj);
	}

	public startPlaying() {
		if (GlobalClass.Game.isReloadGame && GlobalClass.Game.GameMode == 2) {
			// this.setResetData();//测试用

			if (GlobalClass.Game.gameResetData != null && GlobalClass.Game.gameResetData != "") {
				this.isResetGame = true;
				this.resetState(GlobalClass.Game.gameResetData[this.seatID]);
			} else {
				this.createTet();
				KFControllerMgr.getCtl(PanelName.GamePanel).resume();
			}

		} else {
			this.createTet();
		}
		this.onStart();
		this.gamestart = true;
		// if (this.itemMgr != null) {
		// 	this.itemMgr.startUseItem();
		// }

	}


	private skeletonIsLoad = false;
	public skeletonHaveLoad() {
		this.initCollideAni();
		this.initResultAni();
		this.initNPC();
		this.initCreateAni();
		this.skeletonIsLoad = true;
		this.onSkeletonLoaded();
		if (GlobalClass.Game.GameMode == 1) {
			this.initItems();
		}
	}


	//龙骨加载完毕 一些场景中在这个函数中加入龙骨动画
	protected onSkeletonLoaded() {
		this.showGuild();
	}

	protected onStart() {

	}



	private showFallAni(posx, posy) {
		if (this.fallAni == null) {
			this.fallAni = AnimationMgr.getInstance().getSkeleton(skeletonType.zhuankuaidiaoluo, posx, posy);
			this.addChild(this.fallAni.display);
			this.fallAni.addEventListener(dragonBones.AnimationEvent.LOOP_COMPLETE, () => {
				this.fallAni.display.visible = false;
				this.fallAni.animation.stop();
			}, this);
		} else {
			this.fallAni.display.x = posx;
			this.fallAni.display.y = posy;
		}

		this.fallAni.display.visible = true;
		this.fallAni.animation.play();
	}

	protected onFall(body: Box2D.Dynamics.b2Body) {

	}
	protected showStartAni(posx, posy, callBack: Function = null) {
		let s = AnimationMgr.getInstance().getSkeleton(skeletonType.daojishi, posx, posy);
		this.addChild(s.display);
		s.addEventListener(dragonBones.AnimationEvent.LOOP_COMPLETE, () => {
			this.removeChild(s.display);
			s.animation.stop();
			AnimationMgr.getInstance().clenSkeleton(s);
			callBack && callBack.call(this);
		}, this);
		s.animation.play();
	}

	private colliderAni:dragonBones.Armature = null;
	private isPlaying = false;
	private initCollideAni() {
		this.colliderAni = AnimationMgr.getInstance().getSkeleton(skeletonType.pengzhuang, 0, 0);
		this.blockGroup.addChild(this.colliderAni.display);
		this.colliderAni.addEventListener(dragonBones.AnimationEvent.LOOP_COMPLETE, () => {
			this.colliderAni.animation.stop();
			this.colliderAni.display.visible = false;
			this.isPlaying = false;
		}, this);
		this.colliderAni.display.visible = false;
	}

	private createAni: dragonBones.Armature;
	private initCreateAni() {
		this.createAni = AnimationMgr.getInstance().getSkeleton(skeletonType.chuxian, 0, 0);
		this.blockGroup.addChild(this.createAni.display);
		this.createAni.addEventListener(dragonBones.AnimationEvent.LOOP_COMPLETE, () => {
			this.createAni.animation.stop();
			this.createAni.display.visible = false;
			this.isPlaying = false;
		}, this);
		this.createAni.display.visible = false;
	}

	private showCreateAni(posx, posy) {
		this.createAni.display.x = posx;
		this.createAni.display.y = posy;
		this.createAni.display.visible = true;
		this.createAni.animation.play("play", 1);
	}

	private showCollideAni(posx, posy) {
		posx = posx * GlobalClass.GameInfoForConfig.factor;
		posy = posy * GlobalClass.GameInfoForConfig.factor;
		// let point = this.blockGroup.localToGlobal(posx, posy)

		if (!this.isPlaying) {
			this.blockGroup.addChild(this.colliderAni.display);
			this.colliderAni.display.visible = true;
			// this.colliderAni.display.x = point.x;
			// this.colliderAni.display.y = point.y;
			this.colliderAni.display.x = posx;
			this.colliderAni.display.y = posy;
			this.colliderAni.animation.play();
			this.isPlaying = true;
		}

		SoundMgr.Instance.playEffect(SoundMgr.brickCollider);
	}

	protected onResult(bSucceed: boolean, notSure = false) {
		this.gameIsOver = true;
		let result = -1;
		if (!notSure) {
			result = bSucceed ? 1 : 0;
		}
		//上报到GameController
		let js = {
			id: this.seatID,
			result: result,
		}
		NetEventMgr.getInstance().clientMsg(MsgID.CLIENT.GameComponetResult, JSON.stringify(js));
	}

	public finalWiner(winnerSeatID) {
		if (winnerSeatID == -1) {//平局
			this.showWin();
		} else {
			if (winnerSeatID == this.seatID) {//赢了
				this.showWin();
			} else {
				this.showFail();
			}
		}

	}

	private WinAni;
	private LoseAni;
	private initResultAni() {
		let posx = this.width / 2;
		let posy = this.height / 2;

		this.WinAni = AnimationMgr.getInstance().getSkeleton(skeletonType.shengli, posx, posy);
		this.addChild(this.WinAni.display);
		this.WinAni.addEventListener(dragonBones.AnimationEvent.LOOP_COMPLETE, () => {
			this.WinAni.animation.stop();
			this.removeChild(this.WinAni.display);
			this.onWinCB();
		}, this);
		this.WinAni.display.visible = false;

		this.LoseAni = AnimationMgr.getInstance().getSkeleton(skeletonType.shibai, posx, posy);
		this.addChild(this.LoseAni.display);
		this.LoseAni.addEventListener(dragonBones.AnimationEvent.LOOP_COMPLETE, () => {
			this.LoseAni.animation.stop();
			this.removeChild(this.LoseAni.display);
			this.onFailCB();
		}, this);
		this.LoseAni.display.visible = false;
	}

	protected showWin() {
		this.WinAni.display.visible = true;
		this.WinAni.animation.play();
		SoundMgr.Instance.playEffect(SoundMgr.win);
	}

	protected showFail() {
		this.LoseAni.display.visible = true;
		this.LoseAni.animation.play();
		SoundMgr.Instance.playEffect(SoundMgr.fail);
	}

	protected onFailCB() {
		if (GlobalClass.Game.GameMode == 1) {
			KFControllerMgr.getCtl(PanelName.GameResultPanel).setState(false).show();
		}
		if (GlobalClass.Game.GameMode == 3) {
			GlobalClass.Game.currentScore = this.scoreUI.score;
			let js = {
				stage_type: GlobalClass.CurrentStage.StageType,
				score: GlobalClass.Game.currentScore,
				is_weekend: GlobalClass.Hall.isOpenWeekend ? 1 : 0
			};
			WebSocketMgr.getInstance().SendOneceMsg(MsgID.GAME.EndlessFinish, JSON.stringify(js));
		}
		if (GlobalClass.Game.GameMode == 2) {
			KFControllerMgr.getCtl(PanelName.GamePanel).onResultAniC(false);
		}
	}

	protected onWinCB() {
		if (GlobalClass.Game.GameMode == 1) {//单人游戏使用结算上报接口
			let js = {
				stage_number: GlobalClass.CurrentStage.StageNumber,
				skill_use_count: this.useSkillNum,
				state: 1,
			};
			WebSocketMgr.getInstance().SendOneceMsg(MsgID.GAME.LevelFinish, JSON.stringify(js));
		}
		if (GlobalClass.Game.GameMode == 2) {
			KFControllerMgr.getCtl(PanelName.GamePanel).onResultAniC(true);
		}
	}

	protected onCurTetContact() {

	}

	private setPlatFormSkin() {
		if (GlobalClass.CurrentStage.StageType == 2) {
			return;
		}
		let skinName = "Game_json.Img_platform0" + (GlobalClass.CurrentStage.StageType + 1);
		let skin: egret.Bitmap = new egret.Bitmap(RES.getRes(skinName));
		this.platformGroup.addChild(skin);
		this.platform.SetUserData(skin);
		skin.anchorOffsetX = skin.width / 2 + this.getPlatformXShifting();
		skin.anchorOffsetY = skin.height / 2 + this.getPlatformYShifting();
	}

	protected getPlatformXShifting(): number {
		return 0;
	}

	protected getPlatformYShifting(): number {
		return 0;
	}

	public destroy() {
		this.m_world = null;
		this.currentBlockList.forEach(element => {
			element.destory();
		});

		this.currentBlockList = null;
	}

	//当前最高的砖块高度
	public GetBricksHigh(): number {
		this.Highest = this.UIGroup.height;
		for (var body = this.m_world.GetBodyList(); body; body = body.GetNext()) {
			if (this.getCurBody() == body) continue;
			let bodySprite = body.GetUserData();
			if (!bodySprite || !(bodySprite instanceof Block)) continue;
			let bounds = bodySprite.getTransformedBounds(bodySprite.parent);
			if (bounds.topLeft.y < this.Highest) {
				this.Highest = bounds.topLeft.y;
			}
		}
		return this.Highest;
	}

	public getLeftBricksNum(): number {
		return 0;
	}

	public getusedBricksNum(): number {
		return this.curUsedBlockNum;
	}

	public isNpcHealthy(): boolean {
		if (this.mNPc != null) {
			return this.mNPc.isHealthy();
		}
		return true;
	}

	public haveBrickFalled() {
		return this.haveBrickFall;
	}

	public getPlatFromTopHeight(): number {
		return this.platFormHeight;
	}

	/**平台和所有砖块上移一格 */
	public platFormMove() {
		for (var body = this.m_world.GetBodyList(); body; body = body.GetNext()) {
			if (this.getCurBody() && this.getCurBody() == body) continue;
			let vec = body.GetPosition();
			body.SetPosition(new Box2D.Common.Math.b2Vec2(vec.x, vec.y + (-GlobalClass.GameInfoForConfig.blockUnitWidth / GlobalClass.GameInfoForConfig.factor)));
		}
		this.platFormMoveUpTime++;
	}

	public getSeatID(): number {
		return this.seatID;
	}

	// public getSkillLine(): SkillLineUI {
	// 	return this.skillLine;
	// }

	public getSkillComponent(): SkillComponent {
		return this.skillComponent;
	}

	public getRandomSeed(): number {
		return this.randomSeed;
	}

	public getPropsUI(): PropsComponent {
		return this.propsUI;
	}

	public getBrickList(): Array<Block> {
		return this.currentBlockList;
	}

	// private isScrollScreen: boolean = false;
	protected checkAndMoveBlockUpViewport() {
		this.cameras.update();
		let moveLine = this.stage.stageHeight >> 1;
		let higest = this.stage.stageHeight - this.Highest;
		let moveDistance = moveLine - higest;
		if (moveDistance > 0) return;
		if (Math.abs(this.blockGroup.y + moveDistance) < 50) return;
		this.moveScreenDistance = moveDistance;
		this.cameras.moveYTo(-moveDistance);
		this.repeatBg();
	}

	private repeatBg() {
		let moveLine = this.stage.stageHeight >> 1;
		let idx = (-this.moveScreenDistance + moveLine) / 1280;
		let imgNum = this.repeatGroup.numChildren;
		if ((idx >> 0) > imgNum - 2) {
			let imgSource = this.repeatGameBG.source;
			let img = new eui.Image(imgSource);
			img.y = -1280 * imgNum;
			this.repeatGroup.addChildAt(img, 0);
		}

	}

	protected overViewScene(moveDistance: number, call: Function) {
		let moveDelay = Math.abs(moveDistance) / 0.3 >> 0;
		let waitDelay = 600;
		egret.Tween.removeTweens(this.repeatGroup)
		egret.Tween.removeTweens(this.baseGroup)
		// egret.Tween.get(this.blockGroup).to({ y: -moveDistance }, moveDelay).wait(waitDelay).to({ y: 0 }, moveDelay);
		egret.Tween.get(this.repeatGroup).wait(waitDelay).to({ y: -moveDistance }, moveDelay, egret.Ease.quadOut).wait(waitDelay).to({ y: 0 }, moveDelay, egret.Ease.quadOut);
		egret.Tween.get(this.baseGroup).wait(waitDelay).to({ y: -moveDistance }, moveDelay, egret.Ease.quadOut).wait(waitDelay).to({ y: 0 }, moveDelay, egret.Ease.quadOut).call(call, this);

		// let idx = (moveDistance) % 1280 + 1;
		// let imgNum = this.repeatGroup.numChildren;
		// while ((idx >> 0) > imgNum - 2) {
		// 	let imgSource = this.repeatGameBG.source
		// 	let img = new eui.Image(imgSource);
		// 	img.y = -1280 * imgNum;
		// 	this.repeatGroup.addChildAt(img, 0);
		// }
	}

	protected isResetGame = false;
	protected resetData;
	//根据快照数据恢复场景
	private setResetData() {
		let data = '{"frame_serial":0,"frame_data":[{"blocks":[{"blockId":0,"blockType":4,"skin":0,"x":17.9975903944335,"y":50.26850975595682,"angle":1.5722124063706384,"scale":1,"islocked":false,"isToFeezen":false,"isBindJoint":false,"isDisorder":false,"bodyJointsIdList":[],"isContacted":true,"isCurTet":false},{"blockId":1,"blockType":2,"skin":0,"x":20.00567477676032,"y":48.26706501310603,"angle":1.572409459950169,"scale":1,"islocked":false,"isToFeezen":false,"isBindJoint":false,"isDisorder":false,"bodyJointsIdList":[],"isContacted":true,"isCurTet":false},{"blockId":2,"blockType":3,"skin":0,"x":15.99454427932114,"y":48.274949631901364,"angle":4.716191383702696,"scale":1,"islocked":false,"isToFeezen":false,"isBindJoint":false,"isDisorder":false,"bodyJointsIdList":[],"isContacted":true,"isCurTet":false},{"blockId":3,"blockType":4,"skin":0,"x":18,"y":13.500000000000025,"angle":0,"scale":1,"islocked":false,"isToFeezen":false,"isBindJoint":false,"isDisorder":false,"bodyJointsIdList":[],"isContacted":false,"isCurTet":true}],"platFormMoveUpTime":0,"mapMoveUpDistance":0,"skillMgr":{"systemSkillsArr":[[],[{"trigger_args":5,"skill_groups":[{"skill_id":9,"description":"下落的砖块提及变大2倍","skill_number":10205,"skill_type":0,"need_level":1,"valid_times":1,"name":"变大"}],"trigger_type":1}]],"skillsArray":[[{"trigger_args":15,"skill_groups":[{"skill_id":18,"description":"使用者落下的砖块上生成藤蔓，堆砌后，与其接触的2块砖均生成藤蔓，用于加固","skill_number":20204,"skill_type":1,"need_level":1,"valid_times":1,"name":"藤蔓"}],"trigger_type":0}],[]]},"useSkillNum":0,"npcData":{"type":902,"heartNum":3},"gameIsOver":false,"curBlockNum":4,"haveBrickFall":false,"skillsInfo":[],"leftBricksNum":8,"nextBrick":6,"BrickQuantity":12}]}';
		let jsobj = JSON.parse(data);
		GlobalClass.Game.gameResetData = jsobj["frame_data"];
	}

	public resetState(data) {
		this.resetData = data;
		this.useSkillNum = this.resetData["useSkillNum"];
		this.gameIsOver = this.resetData["gameIsOver"];
		this.curBlockNum = this.resetData["curBlockNum"];
		this.curUsedBlockNum = this.resetData["curUsedBlockNum"];
		this.nextTet = this.resetData["nextBrick"];
		this.skillMgr.unpackSkillMsg(this.resetData["skillMgr"]);
		// this.mNPc.unpack(this.resetData["npcData"]);
		this.haveBrickFall = this.resetData["haveBrickFall"];
		this.mapMoveUpDistance = this.resetData["mapMoveUpDistance"];
		this.platFormMoveUpTime = this.resetData["platFormMoveUpTime"];
		this.skillComponent.unpack(this.resetData["skillsInfo"]);
		this.resetUI();

		// this.updateSkin();

	}

	private tempBlockDic = {};
	protected originPlatFromHeight = 0;
	protected resetUI() {
		if (GlobalClass.CurrentStage.StageType == 2) {
			let time = this.platFormMoveUpTime;
			let vec = this.platform.GetPosition();
			this.platform.SetPosition(new Box2D.Common.Math.b2Vec2(vec.x, this.originPlatFromHeight + (-GlobalClass.GameInfoForConfig.blockUnitWidth / GlobalClass.GameInfoForConfig.factor) * time));
		}

		this.nextBlockUI.showBlock(this.nextTet);
		let blockInfos = this.resetData["blocks"]
		// this.changeCurrentList(blockInfos);
	}

	//重新复原砖块的特殊状态， 比如蔓藤
	protected resetBlockState(block: Block) {
		// if(block){
		// }
	}

	public changeCurrentList(brickList: Array<Block>, isneedpack = false) {

		this.currentBlockList.forEach(element => {
			this.m_world.DestroyBody(element.getBody());
			this.blockGroup.removeChild(element);
		}, this);

		this.curTet = null;
		this.lastTet = null;
		this.currentBlockList = [];

		brickList.forEach(element => {
			let offsize = element.isCurTet ? GlobalClass.GameInfoForConfig.blockOffsize : 0;
			let block = BlockFactory.getBlock(this.m_world, 0, 0, element.blockType, offsize);
			if (isneedpack) {
				block.unpack(element.pack());
			} else {
				block.unpack(element);
			}
			if (element.isCurTet) {
				this.curTet = block;
			} else {
				block.resetGravity();
				block.getBody().SetBullet(true);
			}
			this.currentBlockList.push(block);
			this.blockGroup.addChild(block);
			this.tempBlockDic[block.getBlockID()] = block;
		}, this);

		this.currentBlockList.forEach(element => {
			this.resetBlockState(element);
		});
	}

	// protected resetBlocks(blockInfos) {
	// 	blockInfos.forEach(element => {
	// 		let block = BlockFactory.uppack(element, this.m_world);
	// 		this.currentBlockList.push(block);
	// 		block.show(this.blockGroup);
	// 		if (block.isCurTet) {
	// 			this.curTet = block;

	// 		}
	// 		this.tempBlockDic[block.getBlockID()] = block;
	// 	});


	// 	this.currentBlockList.forEach(element => {
	// 		this.resetBlockState(element);
	// 	});
	// }

	public getNPC(): GameNPC {
		return this.mNPc;
	}

	private guildStep = 0;
	public setGuildStep(guildStep) {
		this.guildStep = guildStep;
		if (this.skeletonIsLoad) {
			this.showGuild();
		}
	}
	public showGuild() {


		if (this.guildStep == 8 && GlobalClass.CurrentStage.StageType == 0) {//竞速模式
			this.speedGuideAni();
			this.tipGroup.visible = true;
			this.guideTip1.visible = true;
			this.guideTip2.visible = true;
			this.guideTip1.text = "时间线";
			this.guideTip2.text = "终点线";
			this.guideTip1.x = 50;
			this.guideTip1.y = 925;
			this.guideTip2.x = 200;
			this.guideTip2.y = 608;
			this.Guidetip.text = "规定时间内，将砖块堆至终点线位置";
			this.GameTip.visible = true;
			this.GameTip.text = "竞速玩法";
			this.GameTip.textColor = 0xCCCCFF;
		} else if (this.guildStep == 9 && GlobalClass.CurrentStage.StageType == 1) {
			this.survivalGuideAni();
			this.tipGroup.visible = true;
			this.guideTip1.visible = true;
			this.guideTip2.visible = true;
			this.guideTip1.text = "砖块数";
			this.guideTip2.text = "血量";
			this.guideTip1.x = 30;
			this.guideTip1.y = 200;
			this.guideTip2.x = 580;
			this.guideTip2.y = 750;
			this.Guidetip.text = "三次坍塌机会内，用完所有砖块";
			this.GameTip.visible = true;
			this.GameTip.text = "生存玩法";
			this.GameTip.textColor = 0xCCCCFF;
		} else if (this.guildStep == 10 && GlobalClass.CurrentStage.StageType == 2) {
			this.jigsawGuideAni();
			this.tipGroup.visible = true;
			this.guideTip1.visible = true;
			this.guideTip2.visible = true;
			this.tips.y = 500;
			this.guideTip1.text = "激光线";
			this.guideTip2.text = "砖块序列";
			this.guideTip1.x = 450;
			this.guideTip1.y = 800;
			this.guideTip2.x = 200;
			this.guideTip2.y = 608;
			this.Guidetip.text = "将左边所有砖块堆至激光线以下";
			this.GameTip.visible = true;
			this.GameTip.text = "拼图玩法";
			this.GameTip.textColor = 0xCCCCFF;
		}
	}

	private isShowSkillGuide = false;
	private guildPanelClick() {

		if (this.isShowSkillGuide) {
			this.tipGroup.visible = false;
			KFControllerMgr.getCtl(PanelName.GamePanel).resume();
		} else {
			this.hideGuild();
		}

	}

	protected speedGuideAni() {
		egret.Tween.get(this.coundDownUI, { loop: true }).to({ scaleY: 1.2 }, 200).to({ scaleY: 1 }, 200);
		egret.Tween.get(this.rayCheck, { loop: true }).to({ scaleY: 1.2 }, 200).to({ scaleY: 1 }, 200);
	}

	protected survivalGuideAni() {
		this.nextBlockUI.blink();
		this.mNPc.heartBlink();
	}

	protected jigsawGuideAni() {

	}

	public showSkillGuide() {
		this.isShowSkillGuide = true;
		this.tipGroup.visible = true;
		this.Guidetip.text = "你获得了一个技能“藤蔓”";
		this.tips.y = 450;
		KFControllerMgr.getCtl(PanelName.GamePanel).pause();
	}

	private hideGuild() {
		let nextStep = this.guildStep + 1 + "";
		let stepKey = GlobalClass.CurrentUser.player_id + "guideStep";
		egret.localStorage.setItem(stepKey, nextStep);
		this.tipGroup.visible = false;
		egret.Tween.removeAllTweens();
		KFControllerMgr.getCtl(PanelName.GamePanel).hideGuide();
		this.GameTip.visible = false;
	}

	private testView() {
		this.GameBG1.visible = false;
		let widthNum = 720 / GlobalClass.GameInfoForConfig.blockUnitWidth;
		let heightNum = 1280 / GlobalClass.GameInfoForConfig.blockUnitWidth;
		for (let i = 0; i < widthNum; i++) {
			let arr = [];
			for (let j = 0; j < heightNum; j++) {
				let img = new eui.Image("Game_json.Img_platformblock01");
				this.repeatGroup.addChild(img);
				img.x = i * GlobalClass.GameInfoForConfig.blockUnitWidth;
				img.y = j * GlobalClass.GameInfoForConfig.blockUnitWidth;
				img.name = i + "_" + j;
			}
		}
	}

	public startSkillTime() {

	}

	public stopSkillTime() {

	}

}