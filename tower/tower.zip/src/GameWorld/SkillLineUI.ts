class SkillLineUI extends eui.Component implements eui.UIComponent {
	public constructor() {
		super();
		this.skinName = "SkillLineUISkin";
	}
	public type: Array<SkillType> = [];
	public category: Array<SkillCategory> = [];

	protected partAdded(partName: string, instance: any): void {
		super.partAdded(partName, instance);
	}

	protected childrenCreated(): void {
		super.childrenCreated();
	}

	public get pos() {
		return this.y + this.height;
	}

	// public set pos(y: number) {
	// 	this.y = y + this.height;
	// }

}