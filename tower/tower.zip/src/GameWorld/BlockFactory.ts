
enum BlockType {
	begin,
	O = 1,
	L,
	J,
	Z,
	S,
	I,
	T,
	/******异型砖分割线***** */
	X1,
	X2,
	X3,
	end
}

class BlockFactory {

	public static getBlock(m_world: Box2D.Dynamics.b2World, xPos: number, yPos: number, type: BlockType, offsize: number = GlobalClass.GameInfoForConfig.blockOffsize, isStatic: boolean = false): Block {
		let block: Block;
		let blockSkin: string = "block_json.";
		switch (type) {
			case BlockType.L:
				block = new BlockL(m_world);
				break;
			case BlockType.J:
				block = new BlockJ(m_world);
				break;
			case BlockType.O:
				block = new BlockO(m_world);
				break;
			case BlockType.Z:
				block = new BlockZ(m_world);
				break;
			case BlockType.S:
				block = new BlockS(m_world);
				break;
			case BlockType.T:
				block = new BlockT(m_world);
				break;
			case BlockType.I:
				block = new BlockI(m_world);
				break;
			case BlockType.X1:
				block = new BlockX1(m_world);
				break;
			case BlockType.X2:
				block = new BlockX2(m_world);
				break;
			case BlockType.X3:
				block = new BlockX3(m_world);
				break;
		}
		block.initBody(offsize);
		block.getBody().SetPosition(new Box2D.Common.Math.b2Vec2(xPos / GlobalClass.GameInfoForConfig.factor, yPos / GlobalClass.GameInfoForConfig.factor));
		if (isStatic) {
			block.getBody().SetType(Box2D.Dynamics.b2Body.b2_staticBody);
		} else {
			block.getBody().SetType(Box2D.Dynamics.b2Body.b2_dynamicBody);
		}

		this.setBlockSkin(block);
		return block;
	}

	public static createSinglePlatform(m_world: Box2D.Dynamics.b2World, w: number, h: number, x: number = 0, y: number = 0): Box2D.Dynamics.b2Body {
		return Game.GameWorld.PhysicsWorld.createBox(m_world, x, y, w, h, true);
	}

	public static createSinglePlatformSkin(count: number, source: string = "Game_json.Img_platformblock01"): egret.Sprite {
		let singleSkin = new egret.Sprite();
		for (let i = 0; i < count; i++) {
			let img = new eui.Image(source);
			singleSkin.addChild(img);
			img.x = i * 40;
		}
		singleSkin.anchorOffsetX = 40 * count / 2;
		singleSkin.anchorOffsetY = 40 / 2;
		return singleSkin;
	}
	/**设置皮肤,之前的皮肤会被清空 */
	public static setBlockSkin(block: Block, skinType: number = BlockSkinType.default) {
		block.setSkin(this.getSourceByBlockType(block.blockType, skinType), skinType);
	}
	/***叠加皮肤 */
	public static addBlockSkin(block: Block, skinType: number = BlockSkinType.default) {
		block.addSkin(this.getSourceByBlockType(block.blockType, skinType));
	}

	public static getSourceByBlockType(type: BlockType, skinType: number = BlockSkinType.default): string {
		let blockSkin: string = "block_json.";
		switch (type) {
			case BlockType.L:
				blockSkin += "blockL";
				break;
			case BlockType.J:
				blockSkin += "blockJ";
				break;
			case BlockType.O:
				blockSkin += "blockO";
				break;
			case BlockType.Z:
				blockSkin += "blockZ";
				break;
			case BlockType.S:
				blockSkin += "blockS";
				break;
			case BlockType.T:
				blockSkin += "blockT";
				break;
			case BlockType.I:
				blockSkin += "blockI";
				break;
			case BlockType.X1:
				blockSkin += "blockX1";
				break;
			case BlockType.X2:
				blockSkin += "blockX2";
				break;
			case BlockType.X3:
				blockSkin += "blockX3";
				break;
			default:
				null
		}
		return blockSkin + this.BlockSkinStr[skinType];
	}




	public static BlockSkinStr = [
		"",//默认皮肤
		"_T1",
		"_T2",
		"_T3",
		"_lock",//锁定皮肤
		"_vine",//藤蔓皮肤
		"_cement",//水泥皮肤
		"_ice",//冰块皮肤
	]

	public static uppack(pdata, m_world: Box2D.Dynamics.b2World): Block {
		let block = BlockFactory.getBlock(m_world, 0, 0, pdata["blockType"]);
		block.unpack(pdata);
		return block;
	}
}

enum BlockSkinType {
	default,
	t1,
	t2,
	t3,
	locked,
	vine,
	cement,
	ice
}

