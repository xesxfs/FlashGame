class ScreenShotUI extends eui.Button implements eui.UIComponent {
	public constructor() {
		super();
		this.render = new egret.RenderTexture();
		this.skinName = "ScreenShotUISkin"
	}
	private screeIdLab: eui.BitmapLabel;
	private minShotImg: eui.Image;
	private shotImg: eui.Image;
	private render: egret.RenderTexture;
	private renderOrigin: egret.DisplayObjectContainer;
	private isInit: boolean = false;
	private fullScreenImg: eui.Image;
	private isFull: boolean = false;
	private minGroup: eui.Group;
	private minShotMask: eui.Rect;

	private scaleGroup: eui.Group;
	private fullScreenGroup: eui.Button;

	private showGroup: egret.DisplayObjectContainer;
	private scale: number = 0.2;
	private seatID = 0;

	private playerName:eui.Label;

	protected partAdded(partName: string, instance: any): void {
		super.partAdded(partName, instance);
	}

	public init(origin: egret.DisplayObjectContainer,nickName = "") {
		// this.shotImg = this.minShotImg;
		this.renderOrigin = origin;
		// this.renderOrigin.scaleX = 0.2;
		// this.renderOrigin.scaleY = 0.2;
		console.log("renderOrigin: ", this.renderOrigin.width, this.renderOrigin.height);
		this.renderOrigin.touchEnabled = false;
		this.show();
		let game = <GameComponent>origin;
		this.seatID = game.getSeatID();
		this.playerName.text = nickName;
	}
	public setScreedId(screenId: number) {
		this.screeIdLab.text = screenId.toString();
	}

	protected childrenCreated(): void {
		super.childrenCreated();
		this.scaleGroup.mask=this.minShotMask;
		this.isInit = true;
		this.showGroup = this.scaleGroup;
		this.show();
		this.addEventListener("touchTap", this.changeFullScreen, this);
		this.fullScreenGroup.addEventListener("touchTap", this.changeFullScreen, this);
	}

	// private tempTexture = new egret.Texture();
	public screenShot() {
		// if (!this.isInit && !this.renderOrigin) return;
		// this.render.drawToTexture(this.renderOrigin);
		// this.tempTexture.bitmapData = this.render.bitmapData;
		// this.shotImg.source = this.tempTexture;
		// this.show();
	}

	private show() {
		if (this.isInit && this.renderOrigin) {
			this.renderOrigin.visible = true;
			this.renderOrigin.scaleX = this.scale;
			this.renderOrigin.scaleY = this.scale;
			this.showGroup.addChild(this.renderOrigin);
		}
	}
	private changeFullScreen() {
		this.isFull = !this.isFull;
		// this.minGroup.visible = !this.isFull;
		// this.fullScreenGroup.visible = this.isFull;
		this.showFullScreen(this.isFull);
	}

	private showFullScreen(bFull: boolean) {
		if (bFull) {
			this.showGroup = this.fullScreenGroup;
			this.parent.addChild(this.showGroup);
			this.scale = 1;
			this.scale = 1;
			// this.renderOrigin.height = this.parent.height;
			// this.renderOrigin.width = this.parent.width;
			GlobalClass.Game.currentShowPlayer = this.seatID;
		} else {
			// this.fullScreenGroup.visible = bFull;
			// this.renderOrigin.width = this.scaleGroup.width;
			// this.renderOrigin.height = this.scaleGroup.height;
			this.scale = 0.2;
			this.scale = 0.2;
			this.showGroup = this.scaleGroup;
			GlobalClass.Game.currentShowPlayer = GlobalClass.Game.PlayerSeatID;
		}
	}

}