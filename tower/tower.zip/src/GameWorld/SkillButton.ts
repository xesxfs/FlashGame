class SkillButton extends eui.Button implements eui.UIComponent {
	public constructor(type: SkillType, category: SkillCategory) {
		super();
		this.type = type;
		this.category = category;
		this.skinName = "SkillButtonSkin";
	}
	public type: SkillType;
	public category: SkillCategory;
	private skillIconGroup: eui.Group;

	protected partAdded(partName: string, instance: any): void {
		super.partAdded(partName, instance);
	}


	protected childrenCreated(): void {
		super.childrenCreated();
		this.init();
	}

	private init() {
		this.getChildAt(this.category).visible = true;
		let skillNO = GlobalClass.getSkillNOByType(this.type);
		let icon = "skill_icon_json.skill_icon_" + skillNO;
		let img = new eui.Image(RES.getRes(icon));
		img.width = 52;
		img.height = 52;
		this.skillIconGroup.addChild(img);
		}



}