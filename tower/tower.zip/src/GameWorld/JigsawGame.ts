/*
	1、	拼图模式，系统生成初始地形，地图中有一条“激光线”，玩家需要堆砌所有砖块至激光线下；
	2、	若砖块接触底座或其他砖块后碰到激光线，则通关失败；
	3、	若砖块掉落，则通关失败；
	4、	该模式每关的砖块形状、顺序，底座外形固定，具体每关地图通过地图编辑器编辑。地图编辑器见《地图编辑器需求》。

*/
class JigsawGame extends GameComponent {


	private BlocksToUse: eui.Group;
	private blocksCount = 0;
	private isChecked: boolean = false;
	private isRemoveFromStage: boolean = false;
	public constructor(seatID = 0) {//如果传进的是-1，代表是显示答案
		super(seatID);
		this.addEventListener(egret.Event.REMOVED_FROM_STAGE, this.onRemove, this);
	}

	private onRemove() {
		this.isRemoveFromStage = true;
	}

	protected childrenCreated() {
		super.childrenCreated();
		if (GlobalClass.Game.isDebug) {
			GlobalClass.CurrentStage.BricksList = [1, 2, 3, 4, 5, 6];
		}
		if (GlobalClass.Game.GameMode == 1) {
			this.resetStates();
			this.bricksArray.visible = true;
		}


		if (GlobalClass.Game.isDebug) {
			GlobalClass.CurrentStage.LaserHeight = 30;
		}

		if (this.seatID == -1) {
			this.showSolution();
			this.bricksArray.visible = false;
			this.nextBlockUI.visible = false;
			// this.skillLine.visible = false;

			this.GameTip.visible = true;
			this.GameTip.text = "解题答案";
			this.Btn_Return.visible = true;
			CommonFuc.AddClickEvent(this.Btn_Return, egret.TouchEvent.TOUCH_END, this.Btn_ReturnClick, this);
		}
	}

	private Btn_ReturnClick() {
		KFControllerMgr.getCtl(PanelName.GamePanel).GameReturn();
	}

	protected onSkeletonLoaded() {
		this.createRayCheck(GlobalClass.CurrentStage.LaserHeight);
		this.showGuild();
	}

	private usePropsAction(e: egret.Event) {

	}

	protected haveNextBrick(): boolean {
		if (GlobalClass.Game.GameMode == 1) {
			if (this.curBlockNum < this.blocksCount) {
				return true;
			} else {
				return false;
			}
		} else {
			return true;
		}
	}

	protected onCreateTet() {
		if (GlobalClass.Game.GameMode == 1) {
			this.bricksArray.reduce();
			if (this.curBlockNum < this.blocksCount) {
				this.createNextBlock();
			} else {
				this.nextBlockUI.showBlank();
			}
		} else {
			this.createNextBlock();
		}
	}

	protected getBlockType(): number {
		if (GlobalClass.Game.isDebug) return 1;
		if (GlobalClass.Game.GameMode == 1) {
			return GlobalClass.CurrentStage.BricksList[this.curBlockNum];
		} else {
			let btype = (CommonFuc.getRandomBySeed(this.randomSeed, this.curBlockNum) * 7 >> 0) + 1;
			console.log("jigsaw type=" + btype + " cur=" + this.curBlockNum + " seed=" + this.randomSeed);
			return btype;
		}
	}

	//死亡时调用
	protected onDead() {
		this.onResult(false);
	}

	public resetStates() {
		this.blocksCount = GlobalClass.CurrentStage.BricksList.length;
		this.nextTet = GlobalClass.CurrentStage.BricksList[0];
	}

	private createRayCheck(posy) {//这里的posy是距离下边的格子数
		this.rayHeight = this.height - posy * GlobalClass.GameInfoForConfig.blockUnitWidth - 4;
		this.showLaser(this.rayHeight);
	}

	private showLaser(posy) {
		var s = AnimationMgr.getInstance().getSkeleton(skeletonType.jiguang, this.width / 2 + 35, posy);
		this.laserShow = s.display;
		this.baseGroup.addChild(s.display);
		s.animation.play();
	}

	protected onPhysicsUpdate() {
		if (this.getCurBody() == null) {
			if (this.curBlockNum < this.blocksCount) {
				this.createNewBrick = true;
			}
		}
		this.checkRay();
	}

	private checkRay() {
		if (this.Highest <= this.rayHeight) {
			this.isChecked = true;
			this.onResult(false);
		}

	}

	protected onCurTetContact() {
		if (this.isChecked) return;
		if (this.curBlockNum == this.blocksCount) {//最后一块砖掉落 开始倒计时三秒
			/****最后一块砖，延迟一下，避免倒计时和结算同时出现 */
			egret.setTimeout(this.tryShow3CountDown, this, 100);
		}
	}

	protected jigsawGuideAni() {

	}

	private tryShow3CountDown() {
		if (this.isChecked) return;
		this.showStartAni(this.width / 2, this.height / 2 - 100, () => {
			if (!this.isRemoveFromStage) this.onResult(true);
		});
	}

	protected createPlatForm() {
		// Game.GameWorld.PhysicsWorld.createBox(0, this.height-40, this.width, 40, true);
		// this.GameBG1.visible = false;
		let vec, posx, posy;
		// GlobalClass.Game.isDebug = true;
		//  [-1, 0.5], [-1, 1.5], [0, -1.5], [0, -0.5], [0, 0.5], [0, 1.5], [1, -1.5], [1, -0.5], [1, 0.5]
		if (GlobalClass.Game.isDebug) {
			vec = [
				[-1, -0.5],[-1, 0.5], [-1, 1.5], [0, -1.5], [0, -0.5], [0, 0.5], [0, 1.5], [1, -1.5], [1, -0.5], [1, 0.5]
			];
			posx = 17;
			posy = 60;
		} else {
			vec = GlobalClass.CurrentStage.BaseShape[0]["shape_data"];
			posx = GlobalClass.CurrentStage.BaseShape[0]["x"];
			posy = GlobalClass.CurrentStage.BaseShape[0]["y"];
			posy = 64 - CommonFuc.getArrayYLength(vec) - 6;
		}

		let vec2s: Array<Box2D.Common.Math.b2Vec2> = [];
		for (let i = 0; i < vec.length; i++) {
			let pos = vec[i];
			let temvec: Box2D.Common.Math.b2Vec2 = new Box2D.Common.Math.b2Vec2(pos[0], pos[1]);
			vec2s.push(temvec);
		}
		Game.GameWorld.PhysicsWorld.createJigsawPlatForm2(this.m_world, posx, posy, vec2s, this.platformGroup);
		// this.platform = Game.GameWorld.PhysicsWorld.createJigsawPlatForm(this.m_world, posx, posy, vec2s, this.platformGroup);
		// this.originPlatFromHeight = this.platform.GetPosition().y;
		this.platFormHeight = CommonFuc.getArrayYLength(vec) * 2 + 6;
	}


	protected onFall() {
		if (GlobalClass.Game.GameMode == 1) {
			this.NPCMinusHeart();
		} else {
			this.rayHeight += 40;
			console.log("rayHeight=" + this.rayHeight);
			this.moveLaser();
			if (GlobalClass.Game.GameMode == 2) {//多人对战时平台也要检测
				let platHeight = 1280 - this.platFormHeight * 20;
				if (platHeight <= this.rayHeight) {
					this.isChecked = true;
					this.onResult(false);
				}
			}
		}
	}

	//显示答案
	private showSolution() {
		GlobalClass.Game.jigsawSolution = '[{"blockId":0,"blockType":1,"skin":0,"x":17.99952857876293,"y":52.020204732778254,"angle":0.000052265694462180194,"scale":1,"islocked":false,"isToFeezen":false,"isBindJoint":false,"isDisorder":false,"bodyJointsIdList":[],"isContacted":true,"isCurTet":false},{"blockId":1,"blockType":4,"skin":0,"x":15.99321919503245,"y":49.016208821369915,"angle":1.5703261809084106,"scale":1,"islocked":false,"isToFeezen":false,"isBindJoint":false,"isDisorder":false,"bodyJointsIdList":[],"isContacted":true,"isCurTet":false},{"blockId":2,"blockType":5,"skin":0,"x":20.006442229852293,"y":49.01694191927511,"angle":1.571497925925906,"scale":1,"islocked":false,"isToFeezen":false,"isBindJoint":false,"isDisorder":false,"bodyJointsIdList":[],"isContacted":true,"isCurTet":false},{"blockId":3,"blockType":7,"skin":0,"x":20.01423084840243,"y":45.01210470065424,"angle":1.5715522533032054,"scale":1,"islocked":false,"isToFeezen":false,"isBindJoint":false,"isDisorder":false,"bodyJointsIdList":[],"isContacted":true,"isCurTet":false},{"blockId":4,"blockType":7,"skin":0,"x":15.98630094329906,"y":45.01140760461007,"angle":4.711930496021216,"scale":1,"islocked":false,"isToFeezen":false,"isBindJoint":false,"isDisorder":false,"bodyJointsIdList":[],"isContacted":true,"isCurTet":false},{"blockId":5,"blockType":1,"skin":0,"x":18.001551643302466,"y":42.00589456699479,"angle":-0.00002535212591616255,"scale":1,"islocked":false,"isToFeezen":false,"isBindJoint":false,"isDisorder":false,"bodyJointsIdList":[],"isContacted":true,"isCurTet":false},{"blockId":6,"blockType":7,"skin":0,"x":23.021338523965735,"y":40.01063154715271,"angle":3.143343736333053,"scale":1,"islocked":false,"isToFeezen":false,"isBindJoint":false,"isDisorder":false,"bodyJointsIdList":[],"isContacted":true,"isCurTet":false},{"blockId":7,"blockType":7,"skin":0,"x":12.979144070184434,"y":40.00826270075902,"angle":3.1408139744617816,"scale":1,"islocked":false,"isToFeezen":false,"isBindJoint":false,"isDisorder":false,"bodyJointsIdList":[],"isContacted":true,"isCurTet":false},{"blockId":8,"blockType":6,"skin":0,"x":18.00291743588149,"y":39.00093536907907,"angle":-0.00004500614750074113,"scale":1,"islocked":false,"isToFeezen":false,"isBindJoint":false,"isDisorder":false,"bodyJointsIdList":[],"isContacted":true,"isCurTet":true}]';

		this.resetData = JSON.parse(GlobalClass.Game.jigsawSolution);
		// this.resetBlocks(this.resetData);
		this.changeCurrentList(this.resetData);

		this.updateSkin();
	}


	/**激光线移动缓动 */
	private moveLaser(delay: number = 300) {
		// console.log("moveLaser LaserHeight:", GlobalClass.CurrentStage.LaserHeight, "  laserShow.y:", this.laserShow.y, " this.rayHeight:", this.rayHeight);
		egret.Tween.removeTweens(this.laserShow);
		egret.Tween.get(this.laserShow).to({ y: this.rayHeight }, delay, egret.Ease.circOut);
	}

}