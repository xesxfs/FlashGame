

class AddBloodSkill extends SkillBase {
	//播放技能特效
	public showEffect(delegate:GameComponent){
		delegate.getNPC().addHeart();
	}

	//播放技能声音
	public playSound(){

	}
}


