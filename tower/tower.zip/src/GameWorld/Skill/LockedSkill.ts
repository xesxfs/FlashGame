

class LockedSkill extends SkillBase {
	//播放技能特效
	public showEffect(delegate:GameComponent){
		delegate.curTet.setLockRotate();
        BlockFactory.addBlockSkin(delegate.curTet, BlockSkinType.locked);
	}

	//播放技能声音
	public playSound(){

	}
}


