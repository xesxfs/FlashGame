class Laugh1Skill extends SkillBase {
	public constructor() {
		super();
	}

	//播放技能特效
	public showEffect(delegate: GameComponent) {
		ShakeEffect.Instance.shakeBody(delegate.platform, 10, 5, 200);
		let mc = MovieClipMgr.Instance.getMovieClip("laugh_skill", "laugh");
		delegate.baseGroup.addChild(mc);
		mc.y = delegate.Highest;
		mc.play(-1);
		egret.Tween.get(mc).wait(200 * 5).call(this.removeMc, this, [mc])
	}
	private removeMc(data: egret.MovieClip) {
		data.parent.removeChild(data);
		data.stop();
	}
}