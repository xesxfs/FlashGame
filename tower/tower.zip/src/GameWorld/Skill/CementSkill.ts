

class CementSkill extends SkillBase {
	//播放技能特效
	public showEffect(delegate:GameComponent){
		delegate.curTet.setToFreezen();
		BlockFactory.addBlockSkin(delegate.curTet, BlockSkinType.cement);
	}

	//播放技能声音
	public playSound(){
		
	}
}


