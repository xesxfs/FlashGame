

class SkillBase {
	private skillNumber: number;//技能代表数字
	//播放技能特效
	public showEffect(delegate: GameComponent) {

	}

	//播放技能声音
	public playSound() {

	}


}


