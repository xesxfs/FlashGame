

class IceSkill extends SkillBase {
	//播放技能特效
	public showEffect(delegate:GameComponent){
		delegate.curTet.friction = 0.5;
		BlockFactory.addBlockSkin(delegate.curTet, BlockSkinType.ice);
	}

	//播放技能声音
	public playSound() {

	}
}


