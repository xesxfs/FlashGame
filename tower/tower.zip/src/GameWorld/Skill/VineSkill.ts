

class VineSkill extends SkillBase {
	//播放技能特效
	public showEffect(delegate: GameComponent) {
		delegate.curTet.setBindJoint();
		BlockFactory.addBlockSkin(delegate.curTet, BlockSkinType.vine);
	}

	//播放技能声音
	public playSound() {

	}
}


