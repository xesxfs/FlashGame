

class SpeedUpSkill extends SkillBase {
	//播放技能特效
	public showEffect(delegate: GameComponent) {
		delegate.curTet.setFallSpeedMul(2);
		delegate.curTet.showEffect(AnimationMgr.getInstance().getSkeleton(skeletonType.suduxian));
	}

	//播放技能声音
	public playSound() {

	}
}


