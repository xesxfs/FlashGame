class Platform1Skill extends SkillBase {
	public constructor() {
		super();
	}

	//播放技能特效
	public showEffect(delegate: GameComponent) {
		let heighest = delegate.Highest;

		let py = (Math.floor(heighest / 40)) * 40;
		console.log("Platform1Skill:", py, "   heighest:", heighest);
		let px = delegate.width / 3;
		/**随机左右1/3位置 */
		(Math.random() >= 0.5) ? px = delegate.width - px : "";
		let count = 2;
		let plat = BlockFactory.createSinglePlatform(delegate.m_world, 20 * count, 20, px, py);
		let skin = BlockFactory.createSinglePlatformSkin(count);
		plat.SetUserData(skin);
		delegate.platformGroup.addChild(skin);
	}
}