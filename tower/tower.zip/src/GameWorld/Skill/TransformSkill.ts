

class TransformSkill extends SkillBase {
	//播放技能特效
	public showEffect(delegate: GameComponent) {
		let parent = delegate.curTet.parent;
		delegate.curTet.destory();
		delegate.getBrickList().remove(delegate.curTet);
		let blockXType = (CommonFuc.getRandomBySeed(delegate.getRandomSeed(), 0) * (BlockType.end - BlockType.X1 - 1) >> 0) + BlockType.X1;
		delegate.curTet = BlockFactory.getBlock(delegate.curTet.m_world, delegate.curTet.x, delegate.curTet.y, blockXType);
		parent.addChild(delegate.curTet);

	}

	//播放技能声音
	public playSound() {
	}
}


