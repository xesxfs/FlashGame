

class SuperCementSkill extends SkillBase {
	//播放技能特效
	public showEffect(delegate: GameComponent) {
		delegate.curTet.setToFreezen();
		BlockFactory.addBlockSkin(delegate.curTet, BlockSkinType.cement);
		delegate.skillMgr.addSysSKill([20101], [SkillCategory.Systems], SkillTriger.BlockNO, delegate.curBlockNum + 1);
		delegate.skillMgr.addSysSKill([20101], [SkillCategory.Systems], SkillTriger.BlockNO, delegate.curBlockNum + 2);
	}

	//播放技能声音
	public playSound() {

	}
}


