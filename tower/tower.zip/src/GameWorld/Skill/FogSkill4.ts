class Fog4Skill extends SkillBase {
	public constructor() {
		super();
	}
	//播放技能特效
	public showEffect(delegate: GameComponent) {
		let higest = delegate.Highest;
		let fogLine = (~~(higest / 40)) * 40;
		let waitDelay = 1000 * 6;
		for (let i = 0; i < 3; i++) {
			let mc = MovieClipMgr.Instance.getMovieClip("fog_skill", "fog");
			delegate.baseGroup.addChild(mc);
			mc.y = fogLine + i * 40;
			console.log("mc ", mc.y);
			mc.play(-1);
			egret.Tween.get(mc).wait(waitDelay).call(this.removeMc, this, [mc])
		}
	}


	private removeMc(data: egret.MovieClip) {
		data.parent && data.parent.removeChild(data);
		data.stop();
	}

	//播放技能声音
	public playSound() {

	}
}