// TypeScript file

class Laser3Skill extends SkillBase {
    public constructor() {
        super();
    }
    private needRemoveBlocks: Array<Block> = [];
    private delegate: GameComponent;
    //播放技能特效
    public showEffect(delegate: GameComponent) {
        this.delegate = delegate;
        let npc = delegate.getNPC();
        let offsize = 0;
        let npcPoint = new egret.Point(npc.x + offsize, npc.y + offsize);
        if (npcPoint.x <= this.delegate.width) {
            npcPoint.x += npc.width;
        }

        let blockList = delegate.getBrickList();
        let needRemoveCount = 3;
        let removeCount = 0;
        let laserMcDistance = 600;
        for (let i = blockList.length - 1; i >= 0; i--) {
            let block = blockList[i];
            if (delegate.curTet == block) continue;
            let blockPoint = new egret.Point(block.x, block.y);
            let distance = egret.Point.distance(npcPoint, blockPoint);
            let scaleX = distance / laserMcDistance;
            let angle = Trigonometric.angle(npcPoint, blockPoint);
            let mc = MovieClipMgr.Instance.getMovieClip("role_skill", "roleSkill");
            mc.scaleX = scaleX;
            mc.x = npcPoint.x;
            mc.y = npcPoint.y;
            mc.addEventListener(egret.Event.COMPLETE, this.mcComplete, this);
            mc.gotoAndPlay("jiguang", 1);
            delegate.addChild(mc);
            mc.rotation = angle;
            this.needRemoveBlocks.push(block);
            blockList.splice(i, 1);
            this.delegate.m_world.DestroyBody(block.getBody());
             this.playBlockBreak(block.x, block.y);
            removeCount++;
            if (removeCount >= needRemoveCount) {
                break;
            }
        }
    }

    private playBlockBreak(x: number, y: number) {
        let mc = MovieClipMgr.Instance.getMovieClip("block_break", "block_break");
        this.delegate.baseGroup.addChild(mc);
        mc.x = x;
        mc.y = y;
        mc.play(1);
        mc.addEventListener(egret.Event.COMPLETE, () => {
            mc.parent && mc.parent.removeChild(mc);
        }, this);
    }

    private mcComplete(e: egret.Event) {
        console.log("mc mcCompleteFunc")
        let target = e.target as egret.MovieClip;
        target.parent && target.parent.removeChild(target);
        target.removeEventListener(egret.Event.LOOP_COMPLETE, this.mcComplete, this);
        this.needRemoveBlocks.forEach((block) => {
            let body = block.getBody();
            body.GetUserData().parent && body.GetUserData().parent.removeChild(body.GetUserData());
        })
        this.needRemoveBlocks = [];
    }

}