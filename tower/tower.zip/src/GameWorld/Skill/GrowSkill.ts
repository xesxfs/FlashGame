

class GrowSkill extends SkillBase {
    //播放技能特效
    public showEffect(delegate: GameComponent) {
        delegate.curTet.setScale(2);
    }

    //播放技能声音
    public playSound() {

    }
}


