

class SkillFactory {

	public static getSkill(type: SkillType): SkillBase {
		let skill: SkillBase;
		let skillName = SkillType[type];
		var className = egret.getDefinitionByName(skillName+"Skill");
		skill = new className();
		return skill;
	}

	

}