

class GameSkillManager {

	public delegate: GameComponent;//监听的游戏层

	private skillDatas = [];//游戏中的技能信息

	private skillsArray = [[], []];//归类后的玩家使用的技能数组

	private systemSkillsArr = [[], []];//归类后的系统数组

	private canRenew = true;

	private nextHeight;//下一块砖块的触发高度

	private nextBrickNum;//下一块砖块的触发序号

	private currentSKillInfo = null;//当前触发的技能数据
	/***释放技能停止掉落时间 */
	private stopFallDely: number = 2000;

	private netTimer: NetTimer;

	private stopFallSpeedMul: number = 0;

	private skillAnimation: dragonBones.Armature;

	private skillLinesList: Array<SkillLineUI>;
	/**技能线参照高度 */
	public baseSkillLineHeight: number = 0;
	/***没有释放特效的技能 */
	private haveNotEffect = [
		SkillType.AddBlood,
		SkillType.Fog1, SkillType.Fog2, SkillType.Fog3, SkillType.Fog4,
		SkillType.Laugh1, SkillType.Laugh2, SkillType.Laugh3, SkillType.Laugh4,
		SkillType.Laser1, SkillType.Laser2, SkillType.Laser3, SkillType.Laser4,
		SkillType.Platform1, SkillType.Platform2, SkillType.Platform3, SkillType.Platform4,
		SkillType.Lightning
	]

	constructor(gameDelegate: GameComponent) {
		this.delegate = gameDelegate;
		this.skillLinesList = [];
		this.parseSkillData();
	}

	public initNpcSkill() {
		this.delegate.getNPC().addEventListener("onRoleSkillAction", this.onRoleSkillAction, this);
	}

	public parseSkillData() {
		if (GlobalClass.Game.isDebug) return;
		if (this.delegate != null) {
			let seatid = this.delegate.getSeatID();
			if (GlobalClass.CurrentStage.random_skills != null) {
				this.skillDatas = GlobalClass.CurrentStage.random_skills[seatid];
				if (this.skillDatas && this.skillDatas.length > 0) {
					this.initSkillData();
				}
			}
		}
	}


	//初始化技能参数，把不同的触发类型归到不同的数组
	private initSkillData() {
		this.skillsArray = [[], []]
		this.skillDatas.forEach(element => {
			let isSystem = false;
			element.skill_groups.forEach(skill => {
				isSystem = false;
				if (skill.skill_type == SkillCategory.Systems) {
					isSystem = true;
				}
			});
			if (isSystem) {
				this.systemSkillsArr[element["trigger_type"]].push(element);
			} else {
				this.skillsArray[element["trigger_type"]].push(element);
			}
		});
		this.sortSkillData();
		this.nextHeight = null;
		this.nextBrickNum = null;
		this.initSkillLines();
		// this.renewTargert();
	}

	private sortSkillData() {
		this.skillsArray.forEach(element => {
			element.sort((a, b) => {
				return a.trigger_args - b.trigger_args;
			});
		});

		this.systemSkillsArr.forEach(element => {
			element.sort((a, b) => {
				return a.trigger_args - b.trigger_args;
			});
		});

	}

	/*******初始化技能线****/
	private initSkillLines() {
		this.skillsArray[SkillTriger.Height].forEach((skill) => {
			let height = 1280 - skill.trigger_args * 40 - this.baseSkillLineHeight;
			let stype = [];
			let scategory = [];

			skill.skill_groups.forEach((skillData) => {
				stype.push(GlobalClass.SkillMatchCode[skillData.skill_number]);
				scategory.push(skillData.skill_type);
				// skillData.valid_times
			});
			this.addOneSkillLine(height, stype, scategory);
		});
		this.sortSkillLine();
	}

	/**增加一条技能线 */
	private addOneSkillLine(height: number, type: Array<SkillType>, category: Array<SkillCategory>) {
		let skillLine = new SkillLineUI();
		skillLine.type = type;
		skillLine.category = category;
		skillLine.y = height;
		skillLine.horizontalCenter = 0;
		this.delegate.baseGroup.addChild(skillLine);
		this.skillLinesList.push(skillLine);
	}

	private sortSkillLine() {
		this.skillLinesList.sort((a, b) => { return a.y - b.y });
	}

	//游戏层更新
	public onGameUpdate() {
		if (GlobalClass.Game.isDebug) return;
		let heightest = this.delegate.Highest;//获得当前高度
		if (heightest == 0) return;
		let currentbrick = this.delegate.curBlockNum;//获得已使用的砖块数
		this.checkSkillLine(heightest);

		// if (this.nextHeight && heightest <= this.nextHeight) {//到达触发条件 触发技能
		// 	this.currentSKillInfo = this.skillsArray[SkillTriger.Height].shift();
		// 	this.nextHeight = null;
		// 	this.renewTargert();
		// } else if (this.nextBrickNum && currentbrick >= this.nextBrickNum) {
		// 	this.currentSKillInfo = this.skillsArray[SkillTriger.BlockNO].shift();
		// 	this.nextBrickNum = null;
		// 	this.renewTargert();
		// }

		this.checkSystemSkill(heightest, currentbrick);
	}

	/***检查是否到达技能线 */
	private checkSkillLine(heightest: number) {
		if (this.skillLinesList.length > 0) {
			for (let i = this.skillLinesList.length - 1; i >= 0; i--) {
				let line = this.skillLinesList[i];
				if (line.pos >= heightest) {
					this.skillLinesList.pop();
					let ly = line.parent.localToGlobal(0, line.y).y;
					line.parent.removeChild(line);
					this.delegate.getSkillComponent().addSkillList(line.type, line.category, ly);
					continue;
				}
				break;
			}
		}
	}


	//更新目标值
	// private renewTargert() {
	// 	if (!this.nextHeight && this.skillsArray[SkillTriger.Height].length > 0) {
	// 		this.nextHeight = 1280 - this.skillsArray[SkillTriger.Height][0]["trigger_args"] * 40
	// 		console.log("skills :", this.nextHeight);
	// 	} else {
	// 		this.nextHeight = null;
	// 	}
	// 	if (this.skillsArray[SkillTriger.BlockNO].length > 0) {
	// 		this.nextBrickNum = this.skillsArray[SkillTriger.BlockNO][0]["trigger_args"];
	// 	} else {
	// 		this.nextBrickNum = null;
	// 	}
	// 	this.updateSkillLine();
	// 	this.updateSkillComponet();
	// }

	private isFirstGetSkill(): boolean {
		let Key = GlobalClass.CurrentUser.player_id + "getSkill";
		let step = egret.localStorage.getItem(Key);
		if (step == null) {
			step = "0";
		}
		if (step == "0") {
			return true;
		} else {
			return false;
		}
	}


	private checkSystemSkill(CurrentHeight, brinkNum) {
		let skillInfo = null;
		if (this.systemSkillsArr[SkillTriger.Height].length + this.systemSkillsArr[SkillTriger.BlockNO].length > 0) {
			if (this.systemSkillsArr[SkillTriger.Height].length > 0) {//高度触发数据
				let needHeight = 1280 - this.systemSkillsArr[SkillTriger.Height][0]["trigger_args"] * 40;
				if (CurrentHeight <= needHeight) {//到达触发条件
					skillInfo = this.systemSkillsArr[SkillTriger.Height].shift();
					console.log("skillInfo Height:", skillInfo)
					this.sendSkillInfo(skillInfo, brinkNum);
				}
			}
			if (this.systemSkillsArr[SkillTriger.BlockNO].length > 0) {//砖块序数触发数据
				let needNum = this.systemSkillsArr[SkillTriger.BlockNO][0]["trigger_args"];
				if (brinkNum >= needNum) {//到达触发条件
					skillInfo = this.systemSkillsArr[SkillTriger.BlockNO].shift();
					console.log("skillInfo BlockNO:", skillInfo)
					this.sendSkillInfo(skillInfo, brinkNum);
				}
			}
		}

	}

	private sendSkillInfo(skillInfo, brinkNum) {
		if (skillInfo != null) {
			let skill_groups = skillInfo["skill_groups"];
			for (let i = 0; i < skill_groups.length; i++) {
				/***有效数量 */
				let valid_times = skillInfo["skill_groups"][0]["valid_times"];
				if (valid_times && valid_times > 1) {
					let skill_number = skill_groups[i]["skill_number"];
					for (let i = 1; i < valid_times; i++) {
						this.addSysSKill([skill_number], [SkillCategory.Systems], SkillTriger.BlockNO, brinkNum + i);
					}
				}
				UserControl.getInstance().useSKill(GlobalClass.SkillMatchCode[skill_groups[i]["skill_number"]], SkillCategory.Systems, -1, this.delegate.getSeatID());
			}
		}
	}


	// private updateSkillLine() {
	// 	console.log("updateSkillLine.......", this.nextHeight);
	// 	if (this.delegate.getSkillLine() == null) {
	// 		return;
	// 	}
	// 	if (!this.nextHeight) {
	// 		this.delegate.getSkillLine().visible = false;
	// 	} else {
	// 		this.delegate.getSkillLine().visible = true;
	// 		this.delegate.getSkillLine().y = this.nextHeight;
	// 	}
	// }

	// public setSkillLineHeight(height: number) {
	// 	this.nextHeight = height;
	// 	this.delegate.getSkillLine().y = this.nextHeight;
	// 	console.log("setSkillLineHeight: ", this.nextHeight);
	// }


	public addSysSKill(skillNumbers: number[], skillCatalogys: SkillCategory[], trigerType: SkillTriger, trigger_args: number) {
		let skill_groups = [];
		let index = 0;
		skillNumbers.forEach(element => {
			let js = {
				skill_type: skillCatalogys[index],
				skill_number: skillNumbers[index],
			};
			index++;
			skill_groups.push(js);
		});

		let skill = {
			trigger_args: trigger_args,
			trigger_type: trigerType,
			skill_groups: skill_groups,
		}
		this.systemSkillsArr[trigerType].push(skill);
		this.sortSkillData();
	}

	/**最后一个参数暂时无用,等策划 */
	public addPlaySkill(skillNumbers: number[], skillCatalogys: SkillCategory[], trigger_args: number, trigerType: SkillTriger = SkillTriger.Height) {
		this.addOneSkillLine(trigger_args, skillNumbers, skillCatalogys);
		this.sortSkillLine();
	}


	//剩余玩家触发技能的个数
	public leftPlayerSKillCount(): number {
		// return this.skillsArray[SkillTriger.Height].length + this.skillsArray[SkillTriger.BlockNO].length;
		return this.skillLinesList.length;
	}

	//剩余系统触发技能的个数
	public leftSystemSKillCount(): number {
		return this.systemSkillsArr[SkillTriger.Height].length + this.systemSkillsArr[SkillTriger.BlockNO].length;
	}


	private showSkillAnimation(block: Block) {
		if (this.skillAnimation || !block) return;
		this.skillAnimation = AnimationMgr.getInstance().getSkeleton(skeletonType.jineng, block.width >> 1, block.height >> 1);
		block.addChild(this.skillAnimation.display);
		this.skillAnimation.addEventListener(dragonBones.AnimationEvent.LOOP_COMPLETE, () => {

			this.skillAnimation.animation.stop();
			AnimationMgr.getInstance().clenSkeleton(this.skillAnimation);
			this.skillAnimation = null;

		}, this);
	}

	public useSkill(skillID: SkillType, category: SkillCategory) {
		let seatid = this.delegate.getSeatID();
		if (GlobalClass.Game.GameMode == 1) {
			UserControl.getInstance().useSKill(skillID, category, seatid, seatid);
		} else {
			if (category == SkillCategory.Player) {//增益技能对自己释放
				UserControl.getInstance().useSKill(skillID, category, seatid, seatid);//当前只有两个玩家 座位号不是0就是1
			}
			if (category == SkillCategory.Systems) {//减益技能可对其他人释放
				UserControl.getInstance().useSKill(skillID, category, seatid, seatid ? 0 : 1);//当前只有两个玩家 座位号不是0就是1
			}
		}
	}



	//逻辑处理
	public onUseSkill(type: SkillType, category: SkillCategory, isGiver: boolean, isRecever: boolean) {

		if (category == SkillCategory.Systems) {
			console.log("onUseSkill:", type)
			let _self_ = this;
			var callBack = function (skillType) {
				// console.log("callBack:", skillType)
				// _self_.showSkillEffect(skillType)
			}
			this.delegate.debuffNpcCome(callBack,type);
			return;
		}
		/**发送和接受都是自己 */
		if (isGiver == isRecever && isGiver) {
			// this.showSkillAnimation(this.delegate.curTet);
			this.showSkillEffect(type);
			this.selfUse(type);
			return;
		}
		/***自己是发送者 */
		// if (isGiver) {
		// 	this.selfUse(type);
		// 	return;
		// }
		/**自己是接受者 */
		// if (isRecever) {
		// 	// this.showSkillAnimation(this.delegate.curTet);
		// 	this.showSkillEffect(type);
		// 	return;
		// }
	}

	public selfUse(type: SkillType) {
		if (type in SkillType) {
			this.delegate.getSkillComponent().onUseSkill(type);
		}
		SoundMgr.Instance.playEffect(SoundMgr.chooseEffect);
		this.checkUseSkillEffect(type) && (this.delegate.showBuffEffect());
		// WebSocketMgr.getInstance().SendOneceMsg(MsgID.GAME.OnUseSkill, JSON.stringify({}));
	}

	private checkUseSkillEffect(skillType: SkillType) {
		if (this.haveNotEffect.indexOf(skillType) >= 0) {
			return false;
		}
		return true;
	}

	private createNetTimer(dely: number) {
		if (this.netTimer) {
			this.netTimer.stop();
			this.netTimer = null;
		}
		// this.netTimer = new NetTimer(dely, 1, this.netTimerComplete, this);
		// this.netTimer.start();
		egret.setTimeout(this.netTimerComplete, this, dely)
		// this.delegate.startSkillTime();
	}

	private netTimerComplete() {
		console.log("netTimerComplete")
		this.netTimer = null;
		if (!this.delegate.curTet) return;
		this.delegate.curTet.resumFallSpeed();
		this.delegate.curTet.canControle = true;
		this.delegate.curTet.resetGravity();
		// this.delegate.stopSkillTime();
	}

	public showSkillEffect(type: SkillType) {
		console.log("showSkillEffect",type);
		// type = SkillType.Grow;
		if (!this.delegate.curTet) return;
		this.delegate.curTet.stopFall();
		this.delegate.curTet.setZeroGravity();
		this.createNetTimer(this.stopFallDely);
		this.delegate.curTet.canControle = false;
		let skill = SkillFactory.getSkill(type);
		skill.showEffect(this.delegate);
	}

	public packSkillMsg(): any {
		let js = {
			systemSkillsArr: this.systemSkillsArr,
			skillsArray: this.skillsArray,
		}
		return js;
	}

	public unpackSkillMsg(data) {
		this.systemSkillsArr = data["systemSkillsArr"];
		this.skillsArray = data["skillsArray"];
	}
	/**角色技能 */
	private onRoleSkillAction(e: egret.Event) {
		let type = e.data[0];
		let category = e.data[1];
		this.useSkill(type, category);
	}

}

enum SkillType {
	AddBlood,//加血
	Cement,//水泥
	Vine,//藤蔓
	SpeedUp, //加速
	Locked,//锁定
	Grow,//变大
	Disorder,//混乱
	Transform,//变形
	Ice,//冰块

	Fog1,
	Fog2,
	Fog3,
	Fog4,
	Laugh1,
	Laugh2,
	Laugh3,
	Laugh4,
	Laser1,
	Laser2,
	Laser3,
	Laser4,
	Platform1,
	Platform2,
	Platform3,
	Platform4,
	Lightning,
	SuperCement,//超级水泥
}

//技能类型
enum SkillCategory {
	Systems,//系统释放的 多人对战时为减益技能
	Player,//由玩家释放的 多人时为增益技能
}

/**技能触发类型 */
enum SkillTriger {
	/**高度 */
	Height,
	/**砖块序号 */
	BlockNO,
}