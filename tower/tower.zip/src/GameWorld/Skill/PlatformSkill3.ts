class Platform3Skill extends SkillBase {
	public constructor() {
		super();
	}

	//播放技能特效
	public showEffect(delegate: GameComponent) {
		let heighest = delegate.Highest;
		let py = (~~(heighest / 40)) * 40;
		let px = delegate.width / 3;
		/**随机左右1/3位置 */
		(Math.random() >= 0.5) ? px = delegate.width - px : "";
		let count = 4;
		let plat = BlockFactory.createSinglePlatform(delegate.m_world, 20 * count, 20, px, py);
		let skin = BlockFactory.createSinglePlatformSkin(count);
		plat.SetUserData(skin);
		delegate.platformGroup.addChild(skin);
	}
}