

class GameItemsManager {

	private delegate: GameComponent;//监听的游戏层

	constructor(gameDelegate: GameComponent) {
		if(GlobalClass.Game.isDebug)return;
		this.delegate = gameDelegate;
		this.init()
	}

	private init(){
		this.initItems();
	}

	public startUseItem(){
		let propsUI = this.delegate.getPropsUI();
		propsUI.startUse();
	}

	private initItems(){
		let a = GlobalClass.Game.currentPropInfos;
		let propsUI = this.delegate.getPropsUI();
		GlobalClass.Game.currentPropInfos.forEach(element => {
			propsUI.addProps(element["quantity"], 3, element["prop_number"]);
		});
	}

	//收到使用道具的消息
	public onUseMsg(pid:PropsID){
		pid = pid+300;
		let item = ItemFactory.getItem(pid);
		item.showEffect(this.delegate);
		WebSocketMgr.getInstance().SendOneceMsg(MsgID.GAME.UseProps,JSON.stringify({prop_number:pid,quantity:1}));
	}
}