

class SolutionMirrorItem {
	
	//播放道具特效
	public showEffect(delegate:GameComponent){
		let js = {
			stage:GlobalClass.CurrentStage.StageNumber,
		}
		WebSocketMgr.getInstance().SendOneceMsg(MsgID.GAME.GetJigsawSolution,JSON.stringify(js));
	}
	
	//播放道具声音
	public playSound(){

	}
}


