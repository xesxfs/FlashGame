

class ItemFactory {

	public static getItem(type: PropsID): ItemBase {
		let item: ItemBase;
		let skillName = PropsID[type];
		var className = egret.getDefinitionByName(skillName+"Item");
		item = new className();
		return item;
	}


}