

class CordialItem {
	
	//播放道具特效
	public showEffect(delegate:GameComponent){
		delegate.getNPC().addHeart();
	}
	
	//播放道具声音
	public playSound(){

	}
}


