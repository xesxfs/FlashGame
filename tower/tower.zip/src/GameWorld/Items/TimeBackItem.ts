

class TimeBackItem {

	//播放道具特效
	public showEffect(delegate: GameComponent) {
		delegate.backCdMove(5 * 1000);
	}

	//播放道具声音
	public playSound() {

	}
}


