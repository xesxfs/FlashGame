class BlocksRollDownComponent extends eui.Component {
	public constructor() {
		super();
	}

	
}