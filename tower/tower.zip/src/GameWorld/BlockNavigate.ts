class BlockNavigate {

	private drawSprite: egret.Sprite;
	private navObj: egret.DisplayObject;
	private bColor: number;
	private bAlpha: number = 0.5;
	private previousX: number = 0;
	private previousW: number = 0;
	private colors = [0x5df2e9, 0xf6d332, 0xf6d332];

	public constructor(drawSprite: egret.Sprite, gameMode: number = 0) {
		this.bColor = this.colors[gameMode];
		this.drawSprite = drawSprite;
	}

	public nav(navObj: egret.DisplayObject, parent: egret.DisplayObject) {
		this.navObj = navObj;
		if (!this.drawSprite || !this.navObj || !parent) return;
		let bounds = this.navObj.getTransformedBounds(parent);
		let tempx = bounds.topLeft.x;
		let tempW = bounds.width;
		/**宽度和位置不变不需要重新draw */
		if (this.previousW == tempW && this.previousX == tempx) return;
		this.drawSprite.graphics.clear();
		this.drawSprite.graphics.beginFill(this.bColor, this.bAlpha);
		this.drawSprite.graphics.drawRect(tempx, 0, tempW, parent.height);
		this.drawSprite.graphics.endFill();
		this.previousW = tempW;
		this.previousX = tempx;
	}

}