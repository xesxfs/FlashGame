/* 
	1、	生存玩法，每局有制定数量的砖块，玩家需要用完所砖块，并保持3秒；
	2、	玩家在累积砖块的过程中，每掉落一次砖块，玩家生命值减少1点，玩家生命值共3点；
	3、	砖块掉落时，两块砖之间与地面接触时间差少于1秒，则记为1次掉落，扣除1点血量。即如果5块砖同时掉落，只记为1次掉落。
	4、	该模式每关的砖块形状随机生成，砖块数量通过配置表配置

*/
class SurvivalGame extends GameComponent {

	public constructor(seatID = 0) {
		super(seatID);
		this.addEventListener(egret.Event.REMOVED_FROM_STAGE, this.onRemove, this);
	}

	private BrickQuantity: number;//砖块总数量
	private canMinusHeart = true;//当前是否可以减血
	private npcTimer: egret.Timer;
	private isRemoveFromStage: boolean = false;


	private onRemove() {
		this.isRemoveFromStage = true;
	}
	protected childrenCreated() {
		super.childrenCreated();
		this.nextBlockUI.visible = true;
		this.initStates();
		this.initTimer();
	}


	private usePropsAction(e: egret.Event) {

	}

	protected onPause() {

	}

	private initTimer() {
		this.npcTimer = new egret.Timer(1000, 1);
		this.npcTimer.addEventListener(egret.TimerEvent.TIMER_COMPLETE, () => {
			this.canMinusHeart = true;
		}, this);
	}

	public initStates() {
		this.BrickQuantity = GlobalClass.CurrentStage.BricksQuantity;
		if (GlobalClass.Game.isDebug) {
			this.BrickQuantity = 5;
		}
		this.curBlockNum = 0;
		this.nextBlockUI.showBlockNum(this.getLeftBricksNum());
	}

	protected onCreateTet() {
		if (this.getLeftBricksNum() > 0) {
			this.createNextBlock();
			this.nextBlockUI.showBlockNum(this.getLeftBricksNum());
		} else {
			this.nextBlockUI.showBlank();
		}
	}

	protected onPhysicsUpdate() {
		if (this.getCurBody() == null) {
			if (this.getLeftBricksNum() > 0) {
				this.createNewBrick = true;
			}
		}
	}

	protected haveNextBrick(): boolean {
		if (this.getLeftBricksNum() > 0) {
			return true;
		} else {
			return false;
		}
	}

	protected createPlatForm() {
		let vec = [
			[-2.5, 0], [-1.5, 0], [-.5, 0], [2.5, 0], [1.5, 0], [.5, 0],
			[-2.5, -1], [-1.5, -1], [2.5, -1], [1.5, -1], [.5, -1],
			[-2.5, 1], [-1.5, 1], [-.5, 1], [2.5, 1], [1.5, 1], [.5, 1]
		];

		let vec2s: Array<Box2D.Common.Math.b2Vec2> = [];
		for (let i = 0; i < vec.length; i++) {
			let pos = vec[i];
			let temvec: Box2D.Common.Math.b2Vec2 = new Box2D.Common.Math.b2Vec2(pos[0], pos[1]);
			vec2s.push(temvec);
		}
		let posx = 18;
		let posy = 64 - CommonFuc.getArrayYLength(vec) - 6 + this.getPlatformYShifting() * 2 / GlobalClass.GameInfoForConfig.blockUnitWidth;
		this.platform = Game.GameWorld.PhysicsWorld.createPlatForm(this.m_world, posx, posy, vec2s);
		this.platFormHeight = CommonFuc.getArrayYLength(vec) + 6;
	}

	/**override 所有body*/
	protected checkBody(body: Box2D.Dynamics.b2Body) {
		super.checkBody(body);
	}
	private isGuide = true
	protected onFall() {
		if (this.canMinusHeart) {
			this.canMinusHeart = false;
			let ctrl = KFControllerMgr.getCtl(PanelName.GamePanel) as GamePanelController;
			this.NPCMinusHeart();
			if (this.isGuide) {
				Guide.step501(ctrl);
				this.isGuide = false;
			}


		}
		this.npcTimer.reset();
		this.npcTimer.start();
	}

	protected onBlockRemove(block: Block) {
		this.onCurTetContact();
	}

	protected onDead() {
		this.npcTimer.stop();
		this.onResult(false);
	}
	//
	protected onCurTetContact() {
		if (this.curBlockNum == this.BrickQuantity) {//最后一块砖掉落 开始倒计时三秒
			this.showStartAni(this.width / 2, this.height / 2 - 100, () => {
				if (!this.isRemoveFromStage) this.onResult(true);
			});
		}
	}

	protected getPlatformXShifting(): number {
		return 0;
	}

	protected getPlatformYShifting(): number {
		return -15;
	}

	public getLeftBricksNum(): number {
		return this.BrickQuantity - this.curBlockNum;
	}

	public getCurrentState(): any {
		let js = super.getCurrentState();
		js["BrickQuantity"] = this.BrickQuantity;
		return js;
	}

	public resetState(data) {
		super.resetState(data);
		this.BrickQuantity = this.resetData["BrickQuantity"];
	}

	protected resetUI() {
		super.resetUI();
		this.nextBlockUI.showBlockNum(this.getLeftBricksNum());
	}
}