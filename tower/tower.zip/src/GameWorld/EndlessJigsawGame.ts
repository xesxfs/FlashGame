/****
 * 无尽拼图
 */

class EndlessJigsawGame extends GameComponent {

	public constructor(seatID = 0) {
		super(seatID);
		this.initData();
	}

	protected partAdded(partName: string, instance: any): void {
		super.partAdded(partName, instance);

	}

	/***当前回合砖块总数量 */
	private curBlocksCount = 0;
	/***当前回合已使用砖块数量 */
	private curUsedBlockCount = 0;
	// /***激光线高度 */
	// private rayHeight: number;
	/***激光线显示对象 */
	// private laserShow: any;
	/**当前回合数 */
	protected currentRound: number = 1;
	/**是否接触到激光线 */
	private isChecked: boolean = false;
	/**最高度(砖块&平台) */
	private allHeight: number = 1280;
	/***是否更新到一回合数据*/
	private isUpdateNext: boolean = false;
	/** 是否得到下一回合数据*/
	private isGetNextUpdata: boolean = false;
	/***激光线偏移 */
	private laserOffset: number = 2;



	protected childrenCreated() {
		super.childrenCreated();
		this.registerEvent();
		this.initView();
	}
	public destroy() {
		this.removeEvent();
		super.destroy();
	}

	protected onSkeletonLoaded() {
		console.log("onSkeletonLoaded ");
		this.createLaser();
		this.moveLaser();
	}

	private registerEvent() {
		var eventName = MsgID.getMsgEvent(MsgID.CLIENT.EndlessNextLevel);
		var funName = "on" + eventName;
		NetEventMgr.getInstance().addEventListener(eventName, this[funName], this);
	}

	private removeEvent() {
		var eventName = MsgID.getMsgEvent(MsgID.CLIENT.EndlessNextLevel);
		var funName = "on" + eventName;
		NetEventMgr.getInstance().removeEventListener(eventName, this[funName], this);
	}

	/**创建激光 */
	private createLaser() {
		if (this.laserShow) return;
		let posy = this.rayHeight;
		var s = AnimationMgr.getInstance().getSkeleton(skeletonType.jiguang, this.width / 2 + 35, posy);
		this.laserShow = s.display;
		this.baseGroup.addChild(s.display);
		s.addEventListener(dragonBones.AnimationEvent.LOOP_COMPLETE, () => {
		}, this);
		s.animation.play();

	}
	public reBorn() {
		this.rayHeight = this.allHeight;
		this.moveLaser();
		this.gameIsOver = false;
	}

	// private createEndSprite() {
	// 	this.endSprite = new egret.Sprite();
	// 	this.endSprite.graphics.beginFill(0xfff98);
	// 	this.endSprite.graphics.drawRect(0, 0, this.width, 2);
	// 	this.endSprite.graphics.endFill();
	// 	this.endSprite.y = this.allHeight;
	// 	this.baseGroup.addChild(this.endSprite)
	// }

	private initView() {
		this.scoreUI.visible = true;
		this.nextBlockUI.showBlockNum(this.curBlocksCount - this.curUsedBlockCount);
	}

	private initData() {
		this.curBlocksCount = GlobalClass.CurrentStage.BricksQuantity;
		this.curUsedBlockCount = 0;
		/**激光线高度**/
		this.rayHeight = this.height - (GlobalClass.CurrentStage.LaserHeight * GlobalClass.GameInfoForConfig.blockUnitWidth) - this.laserOffset;
		console.log("Laser: ", GlobalClass.CurrentStage.LaserHeight, " rayHeight: ", this.rayHeight)
	}

	private initNextData() {
		this.curBlocksCount = GlobalClass.CurrentStage.BricksQuantity;
		this.curUsedBlockCount = 0;
		/**激光基准线,当前砖块最高点 */
		let rayHeightOffset = 1280 - this.Highest;

		/**多少砖块 */
		let curBlockheigh = Math.ceil(rayHeightOffset / GlobalClass.GameInfoForConfig.blockUnitWidth);
		/**激光线高度**/
		this.rayHeight = this.height - ((GlobalClass.CurrentStage.LaserHeight + curBlockheigh) * GlobalClass.GameInfoForConfig.blockUnitWidth) - this.laserOffset;
		console.log("initNextData Laser: ", GlobalClass.CurrentStage.LaserHeight, " rayHeight: ", this.rayHeight, " rayHeightOffset:", rayHeightOffset, " curBlockheigh: ", curBlockheigh)
	}


	protected onCreateTet() {
		this.usedTet();
	}

	private usedTet() {
		if (this.curUsedBlockCount <= this.curBlocksCount) {
			this.curUsedBlockCount++;
			this.createNextBlock();
			this.nextBlockUI.showBlockNum(this.curBlocksCount - this.curUsedBlockCount);
			if (this.curUsedBlockCount == this.curBlocksCount) {
				//倒数第一块砖，开始请求下一回合数据
				this.getNextRoundData();
			}
		}
	}


	protected onCurTetContact() {
		if (this.isChecked) return;
		if (this.curUsedBlockCount >= this.curBlocksCount) {
			this.isUpdateNext = true;
		}
		this.scoreUI.addScore();
	}

	protected onBlockRemove(b: Block) {
		this.onCurTetContact();
	}

	/**更新下一回合数据 */
	private updateNext() {
		console.log("updateNext-------")
		this.initNextData();
		this.nextBlockUI.showBlockNum(this.curBlocksCount - this.curUsedBlockCount);
		this.moveLaser();
		this.createNextPlatForm();
		this.updateNextSkill();
		this.isUpdateNext = false;
		this.isGetNextUpdata = false;
	}

	/***更新下一回合技能数据 */
	private updateNextSkill() {
		let height = 1280 - this.Highest;
		let curBlockheigh = Math.ceil(height / GlobalClass.GameInfoForConfig.blockUnitWidth) * GlobalClass.GameInfoForConfig.blockUnitWidth;
		this.skillMgr.baseSkillLineHeight = curBlockheigh;
		this.skillMgr.parseSkillData();
	}

	private createNextPlatForm() {
		let vec, posx, posy;
		vec = GlobalClass.CurrentStage.BaseShape[0]["shape_data"];
		posx = GlobalClass.CurrentStage.BaseShape[0]["x"];
		let height = 1280 - this.Highest;
		let curBlockheigh = Math.ceil(height / GlobalClass.GameInfoForConfig.blockUnitWidth) * 2;
		posy = 64 - curBlockheigh - (64 - GlobalClass.CurrentStage.BaseShape[0]["y"]);
		// console.log("createNextPlatForm:", height, posy);
		let vec2s: Array<Box2D.Common.Math.b2Vec2> = [];
		for (let i = 0; i < vec.length; i++) {
			let pos = vec[i];
			let temvec: Box2D.Common.Math.b2Vec2 = new Box2D.Common.Math.b2Vec2(pos[0], pos[1]);
			vec2s.push(temvec);
		}
		let newPlatHeight = CommonFuc.getArrayYLength(vec);
		this.platform = Game.GameWorld.PhysicsWorld.createJigsawPlatForm(this.m_world, posx, posy, vec2s, this.platformGroup);
		this.allHeight = (posy - newPlatHeight) * 20;
		// this.endSprite.y = this.allHeight;
		/***********************************新底座厚度******************砖块高度**********************新底座中心点距离最高砖块距离****************新底座厚底***********************/
		// this.allHeight = 1280 - (newPlatHeight * 2 + curBlockheigh + (64 - GlobalClass.CurrentStage.BaseShape[0]["y"]) - newPlatHeight) * 20;
		// console.log("createNextPlatForm   newPlatHeight: ", newPlatHeight, "  curBlockheigh:", curBlockheigh, " BaseShapeY:", (64 - GlobalClass.CurrentStage.BaseShape[0]["y"]), " posy:", posy)
		console.log("createNextPlatForm   allheight: ", this.allHeight, "  posy:", posy, " curBlockheigh:", curBlockheigh, " newPlatHeight:", newPlatHeight)
	}

	protected onPhysicsUpdate() {
		/***先检查激光线,再进行下一关卡更新，不然会出现最后一块砖超过激光线的同时激光线往上移动*/
		this.checkLaser();
		if (this.isChecked) return
		this.checkUpdateNext();
	}

	private checkUpdateNext() {
		if (!this.isUpdateNext || !this.isGetNextUpdata) return;
		this.updateNext()
	}

	/**检查是否接触到激光线 */
	private checkLaser() {
		if (this.isChecked) return;
		let temp = this.allHeight;
		this.GetBricksHigh();
		// console.log("........checkRay..........allHeight:", temp, " rayHeight: ", this.rayHeight, " Highest: ", this.Highest);
		if (this.allHeight > this.Highest) temp = this.Highest;
		if (temp < this.rayHeight) {
			this.isChecked = true;
			console.log("........checkRay..........allHeight:", this.allHeight, " : Highest:", this.Highest, " : ray: ", this.rayHeight);
			this.onResult(false);
		}
	}

	private on1006_event(event: egret.Event): void {
		console.log("on1006_event");
		if (this.gameIsOver) return;
		this.currentRound++;
		this.isGetNextUpdata = true;
	}
	/**请求下一回合数据 */
	private getNextRoundData() {
		let js = {
			score: this.scoreUI.score,
			round: this.currentRound
		};
		WebSocketMgr.getInstance().SendOneceMsg(MsgID.GAME.EndlessJigsawInfo, JSON.stringify(js));
	}

	protected haveNextBrick(): boolean {
		if (this.curUsedBlockCount < this.curBlocksCount) {
			return true;
		} else {
			return false;
		}
	}

	public getusedBricksNum(): number {
		return this.curBlockNum;
	}

	protected onFall(body: Box2D.Dynamics.b2Body) {
		// this.NPCMinusHeart();
		// this.platFormMove();
		this.rayHeight += 40;
		this.moveLaser();
		let block = body.GetUserData() as Block;
		block && block.isContacted && this.scoreUI.subScore();
		if (block == this.curTet) {
			if (this.curUsedBlockCount >= this.curBlocksCount) {
				this.isUpdateNext = true;
			}

		}

	}

	/**激光线移动缓动 */
	private moveLaser(delay: number = 300) {
		// console.log("moveLaser LaserHeight:", GlobalClass.CurrentStage.LaserHeight, "  laserShow.y:", this.laserShow.y, " this.rayHeight:", this.rayHeight);
		egret.Tween.removeTweens(this.laserShow);
		egret.Tween.get(this.laserShow).to({ y: this.rayHeight }, delay, egret.Ease.circOut);
	}

	protected createPlatForm() {
		// Game.GameWorld.PhysicsWorld.createBox(0, this.height-40, this.width, 40, true);

		let vec, posx, posy;

		if (GlobalClass.Game.isDebug) {
			vec = [
				[-2.5, -5.5], [2.5, -5.5],
				[-2.5, -4.5], [2.5, -4.5],
				[-2.5, -3.5], [2.5, -3.5],
				[-2.5, -2.5], [2.5, -2.5],
				[-2.5, -1.5], [2.5, -1.5],
				[-2.5, -0.5], [2.5, -0.5],
				[-2.5, 0.5], [2.5, 0.5],
				[-2.5, 1.5], [2.5, 1.5],
				[-2.5, 2.5], [-0.5, 2.5], [0.5, 2.5], [1.5, 2.5], [2.5, 2.5],
				[-2.5, 3.5], [-1.5, 3.5], [-0.5, 3.5], [0.5, 3.5], [1.5, 3.5], [2.5, 3.5],
				[-2.5, 4.5], [-1.5, 4.5], [-0.5, 4.5], [0.5, 4.5], [1.5, 4.5], [2.5, 4.5],
				[-2.5, 5.5], [-1.5, 5.5], [-0.5, 5.5], [0.5, 5.5], [1.5, 5.5], [2.5, 5.5],
			];
			posx = 18;
			posy = 48;
		} else {
			vec = GlobalClass.CurrentStage.BaseShape[0]["shape_data"];
			posx = GlobalClass.CurrentStage.BaseShape[0]["x"];
			posy = GlobalClass.CurrentStage.BaseShape[0]["y"];
		}

		posy = 64 - CommonFuc.getArrayYLength(vec) - 6;

		let vec2s: Array<Box2D.Common.Math.b2Vec2> = [];
		for (let i = 0; i < vec.length; i++) {
			let pos = vec[i];
			let temvec: Box2D.Common.Math.b2Vec2 = new Box2D.Common.Math.b2Vec2(pos[0], pos[1]);
			vec2s.push(temvec);
		}

		this.platform = Game.GameWorld.PhysicsWorld.createJigsawPlatForm(this.m_world, posx, posy, vec2s, this.platformGroup);
		this.platFormHeight = CommonFuc.getArrayYLength(vec) + 3;
		this.allHeight = 1280 - (this.platFormHeight * 40);
		// this.createEndSprite();
		console.log("createPlatForm allHeight:", this.allHeight, " platFormHeight", this.platFormHeight);
	}

}