class SpeedGame extends GameComponent {

	public constructor(seatID = 0) {
		super(seatID);
	}
	private limitTime: number = 3 * 60 * 1000;
	/**稳定3秒 */
	private stableTime: number = 3 * 1000;
	private isTimeOut: boolean;
	private isChecked: boolean;
	private check3DateTimer: DateTimer;
	private isStarted: boolean = false;
	/***是否创建砖块 */
	private isCreateBlock: boolean = true;

	protected childrenCreated() {
		super.childrenCreated();
		this.rayCheck.visible = true;
		this.check3DateTimer = new DateTimer(1000, 3);
		this.check3DateTimer.addEventListener(egret.TimerEvent.TIMER, this.on3TimerHandler, this);
		this.check3DateTimer.addEventListener(egret.TimerEvent.TIMER_COMPLETE, this.on3TimerComplete, this);
		this.rayCheck.y = this.height - GlobalClass.CurrentStage.TargetHeight * 40;

		if (GlobalClass.Game.GameMode == 2) {
			GlobalClass.CurrentStage.LimitTime = 300;
		}
		// if (GlobalClass.Game.GameMode == 1) {
		//单人玩法有限制时间
		this.limitTime = GlobalClass.CurrentStage.LimitTime * 1000;
		this.coundDownUI.initTime(this.limitTime, this.rayCheck.y);
		// this.cdPerDistance = (this.coundDownUI.y - this.rayCheck.y) / this.limitTime;
		this.coundDownUI.visible = true;
		this.coundDownUI.setTimeOutCall(this.onTimerComplete, this);
		// }
	}

	public beginFirst(nextStep: Function, thisObj: any) {
		if (this.rayCheck.y <= 0) {
			this.overViewScene(this.rayCheck.y - 400, () => { nextStep.call(thisObj) });
		} else {
			nextStep.call(thisObj);
		}
	}

	private startCountDown() {
		if (!this.isPause) {
			// this.startCdMove();
			this.coundDownUI.startCoundDown();
		}
	}

	protected onStart() {
		this.isStarted = true;
		this.resetStates();
		this.startCountDown();
	}

	public resetStates() {
		this.isTimeOut = false;
		this.isChecked = false;
	}

	/**时间倒流 */
	public backCdMove(time: number) {
		this.coundDownUI.addTime(time);
		this.coundDownUI.startCoundDown();
	}

	/**暂停 */
	protected onPause() {
		if (!this.isStarted) return;
		if (this.isPause) {
			// this.stopCdMove();
			this.coundDownUI.pause();
		} else {
			// this.startCdMove();
			this.coundDownUI.resume();
		}
	}

	protected onUpdateSkin() {
		this.coundDownUI.onUpdate();
	}

	protected onPhysicsUpdate() {
		if (this.checkSucceed() != null) {
			/***最后检查一下 */
			this.isChecked = this.checkEndRay();
			if (this.isChecked) this.onResult(this.checkSucceed());
			return;
		}
		this.checkRay();
	}

	public onResult(bSucceed: boolean, notSure = false) {
		super.onResult(bSucceed, notSure);
		this.coundDownUI.pause();
	}
	/**倒计时key */
	private second3Key: number = null;
	/*检测终点线逻辑*/
	private checkRay() {
		/**没有到终点线，没有超时 */
		if (!this.isChecked && !this.isTimeOut) {
			/**没有在3秒倒计时中，到达终点，开始3倒计时 */
			if (!this.second3Key && this.checkEndRay()) {
				this.second3Key = 1;
				this.showEndAni(this.width / 2, this.height / 2, true);
				this.check3DateTimer.reset();
				this.check3DateTimer.start();
				this.isCreateBlock = false;
				this.coundDownUI.pause();
			}
		}
	}
	/**3秒倒计时每秒检查 */
	private on3TimerHandler(e: egret.TimerEvent) {
		let isChecked;
		/**倒计时检查失败 */
		if (!(isChecked = this.second3Check())) {
			this.check3DateTimer.stop();
			this.check3DateTimer.reset();
			this.second3Key = null;
			/**移除倒计时 */
			this.showEndAni(this.width / 2, this.height / 2, isChecked);
			this.isCreateBlock = true;
			this.coundDownUI.resume();
		}
	}
	/**接触到终点后，3秒倒计时结束 */
	private on3TimerComplete(e: egret.TimerEvent) {
		this.isChecked = true;
	}

	private endAni: dragonBones.Armature;
	/***显示倒计时 */
	private showEndAni(posx, posy, isShow: boolean) {
		if (isShow) {
			if (this.endAni) {
				return;
			}
			this.endAni = AnimationMgr.getInstance().getSkeleton(skeletonType.daojishi, posx, posy);
			this.addChild(this.endAni.display);
			this.endAni.addEventListener(dragonBones.AnimationEvent.COMPLETE, () => {
				this.endAni.display && this.endAni.display.parent && this.removeChild(this.endAni.display);
				this.endAni.animation.stop();
			}, this);
			this.endAni.animation.play(null, 1);

		} else {
			if (this.endAni) {
				this.endAni.display.parent && this.removeChild(this.endAni.display);
				this.endAni.animation.stop();
				this.endAni = null;
			}
		}
	}

	protected haveNextBrick(): boolean {
		return this.isCreateBlock;
	}
	/**是否接触到终点线 */
	public checkEndRay(): boolean {
		return this.rayCheck.check(this.Highest);
	}
	/**超时 */
	private onTimerComplete(e: egret.TimerEvent) {
		this.isTimeOut = true;
		console.log("onTimerComplete");
		if (GlobalClass.Game.GameMode == 1) {//单人游戏，直接判负，多人游戏，需比较高度后判负
			this.onResult(false);
		} else if (GlobalClass.Game.GameMode == 2) {
			this.onResult(false, true);
		}
	}

	/***true 成功，false 失败 ，null 继续 */
	private checkSucceed(): boolean {
		let succeed = null;
		// if (this.isTimeOut) {
		// 	succeed = false;
		// }
		if (!this.isTimeOut && this.isChecked) {
			succeed = true;
		}
		return succeed;
	}

	/**3秒倒计时检查 */
	private second3Check(): boolean {
		return this.rayCheck.check(this.Highest);
	}

	protected createPlatForm() {
		let vec = [
			[-2.5, -1.5], [0.5, -1.5],
			[-2.5, -0.5], [-1.5, -0.5], [-0.5, -0.5], [0.5, -0.5], [1.5, -0.5], [2.5, -0.5],
			[-2.5, 0.5], [-1.5, 0.5], [-0.5, 0.5], [0.5, 0.5], [1.5, 0.5], [2.5, 0.5],
			[-2.5, 1.5], [-1.5, 1.5], [-0.5, 1.5], [0.5, 1.5], [1.5, 1.5], [2.5, 1.5],
		];
		let vec2s: Array<Box2D.Common.Math.b2Vec2> = [];
		for (let i = 0; i < vec.length; i++) {
			let pos = vec[i];
			let temvec: Box2D.Common.Math.b2Vec2 = new Box2D.Common.Math.b2Vec2(pos[0], pos[1]);
			vec2s.push(temvec);
		}
		let posx = 18;
		let posy = 64 - CommonFuc.getArrayYLength(vec) - 6 + this.getPlatformYShifting() * 2 / GlobalClass.GameInfoForConfig.blockUnitWidth;
		this.platform = Game.GameWorld.PhysicsWorld.createPlatForm(this.m_world, posx, posy, vec2s);
		this.platFormHeight = CommonFuc.getArrayYLength(vec) * 2 + 6;
		this.coundDownUI.y = this.height - (this.getPlatFromTopHeight() * 20);
		console.log("platFormHeight:+++", this.platFormHeight, "  Y:", this.coundDownUI.y);
	}

	public startSkillTime() {
		this.coundDownUI.pause();
	}

	public stopSkillTime() {
		this.coundDownUI.resume();
	}



	protected getPlatformXShifting(): number {
		return 0;
	}

	protected getPlatformYShifting(): number {
		return -10;
	}


}