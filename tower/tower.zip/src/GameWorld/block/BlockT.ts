class BlockT extends Block {


	public blockType: BlockType = BlockType.T;

	protected getVec(): Array<number[]> {
		return [[0, .5], [0, -.5], [-1, -.5], [1, -.5]];
	}
}