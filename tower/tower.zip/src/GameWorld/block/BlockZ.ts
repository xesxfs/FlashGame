class BlockZ extends Block {
	// public initBody() {
	// 	super.initBody();
	// }
	public blockType: BlockType = BlockType.Z;

	protected getVec(): Array<number[]> {
		return [[0, .5], [0, -.5], [-1, -.5], [1, .5]];
	}
}