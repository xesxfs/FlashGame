class BlockI extends Block {


	public blockType: BlockType = BlockType.I;

	protected getVec(): Array<number[]> {
		return [[-0.5, 0], [-1.5, 0], [0.5, 0], [1.5, 0]];
	}
}