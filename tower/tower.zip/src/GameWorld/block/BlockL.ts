class BlockL extends Block {

	public blockType: BlockType = BlockType.L;

	protected getVec(): Array<number[]> {
		return [[-1, -0.5], [-1, 0.5], [0, -0.5], [1, -0.5]];
	}
}