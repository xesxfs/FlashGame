class BlockX2 extends Block {
	// public initBody() {
	// 	this.blockType = BlockType.X2;
	// 	super.initBody();
	// }
	public blockType: BlockType= BlockType.X2;

	protected getVec(): Array<any> {
		return [[[-1, 0], [0, -1.], [1, 0]], [[-2, 1], [-2, 0], [2, 0], [2, 1]]];
	}
}