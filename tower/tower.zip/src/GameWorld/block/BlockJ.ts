class BlockJ extends Block {

	public blockType: BlockType = BlockType.J;

	protected getVec(): Array<number[]> {
		return [[0, -0.5], [-1, -0.5], [1, -0.5], [1, 0.5]];
	}
}