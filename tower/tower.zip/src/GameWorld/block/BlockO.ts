class BlockO extends Block {

	public blockType: BlockType = BlockType.O;

	protected getVec(): Array<number[]> {
		return [[-0.5, -0.5], [-0.5, 0.5], [0.5, -0.5], [0.5, 0.5]];
	}
}