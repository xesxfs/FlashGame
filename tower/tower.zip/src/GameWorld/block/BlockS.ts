class BlockS extends Block {

	public blockType: BlockType = BlockType.S;

	protected getVec(): Array<number[]> {
		return [[0, 0.5], [0, -0.5], [-1, 0.5], [1, -0.5]];
	}
}