class Block extends egret.Sprite {

	private mBody: Box2D.Dynamics.b2Body;
	/**掉落速度 */
	public fallSpeed = 5;
	/**原始速度 */
	private originFallSpeed = 5;

	private scale: number = 1;

	private netTimer: NetTimer;

	//砖块图形
	public blockBitMap: egret.Bitmap;

	private blockSkinType: BlockSkinType;

	private bodyJoints: Array<Box2D.Dynamics.b2Body> = [];

	private blockId: number = 0;

	public blockType: BlockType;

	public friction: number = 1;

	public isCurTet: boolean = false;//是否是当前正在掉落的砖块

	public m_world: Box2D.Dynamics.b2World;

	private skinSprite: egret.Sprite;

	private beforeSprite: egret.Sprite;

	private backSprite: egret.Sprite;

	private effects: Array<dragonBones.Armature> = [];

	//是否可以操作
	public canControle: boolean = true;
	//总共18个格子，36个半格
	private curNum;//当前所在格子序号
	private TarNum;//将要移动到的格子序号
	private moving: boolean = false;//正在移动
	private isLockRotate: boolean = false;//锁定旋转	
	public isToFreezen: boolean = false;//是否要石化(水泥技能)
	public isBindJoint: boolean = false;//是否绑定关节
	public isDisorder: boolean = false;//混乱
	public isContacted: boolean = false;//是否已经碰撞过
	private isStopFall: boolean = false;//是否停止下落
	/**下落速度倍数 */
	private fallSpeedMul: number = 1;
	/***是否开始绑定关节 */
	private isStartJoin: boolean = false;
	/***是否已经重建 */
	private isRebuild: boolean = false;
	/***随机种子 */
	private seed: number;
	public constructor(world) {
		super();
		this.beforeSprite = new egret.Sprite();
		this.skinSprite = new egret.Sprite();
		this.backSprite = new egret.Sprite();
		this.addChild(this.backSprite);
		this.addChild(this.skinSprite);
		this.addChild(this.beforeSprite);
		this.m_world = world;
		this.originFallSpeed = 5 * GlobalClass.GameInfoForConfig.worldUpdateRate / 60;
		this.fallSpeed = this.originFallSpeed;

	}

	public getSkinSprite(): egret.Sprite {
		return this.skinSprite;
	}

	public showEffect(eff: dragonBones.Armature, rotation: number = 90) {
		this.effects.push(eff);
		this.beforeSprite.addChild(eff.display);
		eff.display.x = this.blockBitMap.width / 2;
		eff.display.y = this.blockBitMap.height / 2;
		this.beforeSprite.anchorOffsetX = this.blockBitMap.width / 2;
		this.beforeSprite.anchorOffsetY = this.blockBitMap.height / 2;
		eff.display.rotation = rotation;
		eff.animation.play();
	}

	public cleanEffect() {
		this.effects.forEach((eff) => {
			AnimationMgr.getInstance().clenSkeleton(eff);
		});
		this.effects = [];
	}

	/**缩放 只针对多边形；静态刚体不能放大 */
	public setScale(scale: number) {
		if (this.scale == scale) return;
		this.scale = scale;
		this.scaleX = scale;
		this.scaleY = scale;
		this.scaleBody(scale);
	}

	private scaleBody(scale: number) {
		if (!this.mBody || this.mBody.GetType() == Box2D.Dynamics.b2Body.b2_staticBody) return;
		for (var fixTure = this.mBody.GetFixtureList(); fixTure; fixTure = fixTure.GetNext()) {
			var shapes = fixTure.GetShape();
			if (shapes instanceof Box2D.Collision.Shapes.b2PolygonShape) {
				for (let i = 0; i < shapes.GetVertices().length; i++) {
					let vec = shapes.GetVertices()[i];
					vec.Multiply(scale);
				}
			}
		}
	}

	/**是否有debuff */
	public haveDebuff(): boolean {
		return (this.isDisorder ||
			this.isLockRotate ||
			this.scale > 1 ||
			this.fallSpeedMul > 1 || this.blockType >= BlockType.X1 || this.blockSkinType == BlockSkinType.ice);
	}

	public setBlockID(blockID) {
		this.blockId = blockID;
	}

	public stopFall() {
		this.isStopFall = true;
		this.fallSpeed = 0;
		// this.fallSpeedMul = 0;
		this.mBody.SetLinearVelocity(new Box2D.Common.Math.b2Vec2(0, 0));
		this.mBody.SetAwake(false);
	}

	public resetState() {
		this.curNum = 18;
		this.resumFallSpeed();
	}

	/**设置掉落速度倍数 */
	public setFallSpeedMul(fallSpeedMul: number) {
		this.fallSpeedMul = fallSpeedMul;
		this.fallSpeed = this.originFallSpeed * this.fallSpeedMul;
	}

	/**还原掉落速度 */
	public resumFallSpeed() {
		this.isStopFall = false;
		this.fallSpeed = this.originFallSpeed * this.fallSpeedMul;
		// this.fallSpeedMul = 1;
		this.mBody.SetAwake(true);
	}

	/**锁定变形 */
	public setLockRotate(bLock: boolean = true) {
		this.isLockRotate = bLock;
	}

	public setFriction() {
		for (var fix = this.mBody.GetFixtureList(); fix; fix = fix.GetNext()) {
			fix.SetFriction(this.friction);
		}
	}


	/**设置混乱 */
	public setDisorder(bDisorder: boolean = true) {
		this.isDisorder = bDisorder;
		if (this.isDisorder) {
			this.netTimer = new NetTimer(this.randDelyTime(), 1, this.timeToRotate, this);
			this.netTimer.start();
		}
	}
	/**混乱定时旋转 */
	private timeToRotate() {
		if (this.isDisorder) {
			/**忽略锁定旋转 */
			this.toRotate(false);
			this.setDisorder();
		}
	}

	//第一次碰撞
	public onFirstContact() {
		/**有水泥技能 石化 */
		// if (this.isToFreezen) {
		// 	this.setZeroGravity();
		// }
		this.isContacted = true;
		this.setDisorder(false);
	}

	public setToFreezen() {
		this.isToFreezen = true;
	}

	public setBindJoint() {
		this.isBindJoint = true;
	}

	//随机1到3秒
	private randDelyTime(): number {
		let dely = ((CommonFuc.getRandomBySeed(this.seed, 0) * 1000 * 2) >> 0) + 1000;
		return dely;
	}

	/**旋转 每次+90度*/
	public toRotate(bLock: boolean = this.isLockRotate) {
		if (!this.mBody) return;
		if (bLock) return;
		this.mBody.SetAngularVelocity(Math.PI / 2 * 60);
		this.beforeSprite.rotation -= 90;
	}

	private setRotate(angle: number) {
		this.mBody.SetAngle(angle);
		this.updateSkin();
	}

	/**设置0重力,摆脱全局重力影响，修改了物理引擎代码在 b2Island.prototype.Solve 方法里面*/
	public setZeroGravity() {
		this.mBody["m_selfGraveity"] = new Box2D.Common.Math.b2Vec2(0, 0);
	}
	/**重新受到全局重力影响 */
	public resetGravity() {
		this.mBody["m_selfGraveity"] = null;
		this.mBody.SetAwake(true);
	}

	//初始化砖块 
	public initBody(offsize: number) {
		// var vec = this.getVec();
		// let vec2s: Array<Box2D.Common.Math.b2Vec2> = [];
		// for (let i = 0; i < vec.length; i++) {
		// 	let pos = vec[i];
		// 	let temvec: Box2D.Common.Math.b2Vec2 = new Box2D.Common.Math.b2Vec2(pos[0], pos[1]);
		// 	vec2s.push(temvec);
		// }
		if (egret.getOption("offsize")) {
			offsize = parseInt(egret.getOption("offsize"))
		}
		this.mBody = Game.GameWorld.PhysicsWorld.createBlock(this.m_world, 0, 0, 0, this.getVec(), false, offsize, this.blockType >= BlockType.X1);
		this.mBody.SetLinearDamping(0);
		this.setZeroGravity();
		this.mBody.SetUserData(this);
		this.mBody.SetBullet(true);
		this.curNum = 18;//中心点
		// this.filters = [new egret.GlowFilter(16711680, 0.66, 13, 13)];
	}

	// public initBody2(offsize: number){
	// 	this.initBody(offsize);
	// }



	public setSkin(skinStr: string, blockSkinType: BlockSkinType) {
		this.blockSkinType = blockSkinType;
		let texture = RES.getRes(skinStr)
		this.blockBitMap && this.blockBitMap.parent.removeChild(this.blockBitMap);
		this.blockBitMap = new egret.Bitmap(texture)
		this.skinSprite.addChild(this.blockBitMap);
		// this.rotation = this.mBody.GetAngle();
		this.skinSprite.anchorOffsetX = this.blockBitMap.width / 2;
		this.skinSprite.anchorOffsetY = this.blockBitMap.height / 2;
		this.updateSkin();
	}

	/***叠加皮肤 */
	public addSkin(skinStr: string) {
		let texture = RES.getRes(skinStr);
		let skinBitMap = new egret.Bitmap(texture);
		this.skinSprite.addChild(skinBitMap);
		this.updateSkin();
	}

	public setPosition(vec: Box2D.Common.Math.b2Vec2) {
		vec.Multiply(1 / GlobalClass.GameInfoForConfig.factor);
		this.mBody.SetPosition(vec);
		this.updateSkin();
	}

	/**更新砖块皮肤位置角度*/
	private updateSkin() {
		var body = this.mBody;
		body.GetUserData().x = body.GetPosition().x * GlobalClass.GameInfoForConfig.factor;
		body.GetUserData().y = body.GetPosition().y * GlobalClass.GameInfoForConfig.factor;
		body.GetUserData().rotation = body.GetAngle() * 180 / Math.PI;
	}

	public show(thisObj: egret.DisplayObjectContainer) {
		thisObj.addChild(this);
	}

	public rebuildBlock(bSensor: boolean = false) {
		if (!this.mBody) return;
		this.isRebuild = true;
		this.m_world.DestroyBody(this.mBody);
		let userData = this.mBody.GetUserData();
		let pos = this.mBody.GetPosition().Copy();
		let angle = this.mBody.GetAngle();

		if (bSensor) {
			this.mBody = Game.GameWorld.PhysicsWorld.createBlock(this.m_world, 0, 0, angle, this.getVec(), false, 0, this.blockType >= BlockType.X1);
			this.scaleBody(this.scale);
			this.mBody.SetAwake(false);
		} else {
			/**静态刚体,主要用于石化技能 */
			/**静态刚体，进行放大会出现异常抖动；所以先放大，后转换成静态刚体 */
			this.mBody = Game.GameWorld.PhysicsWorld.createBlock(this.m_world, 0, 0, angle, this.getVec(), false, 0, this.blockType >= BlockType.X1);
			let offPos = GlobalClass.GameInfoForConfig.blockOffsize / GlobalClass.GameInfoForConfig.factor / 2;
			pos.Add(new Box2D.Common.Math.b2Vec2(0, -offPos));
			this.scaleBody(this.scale);
			this.convertStatic();
		}

		this.mBody.SetPosition(pos);
		// this.mBody.SetLinearDamping(0);
		this.mBody.SetUserData(userData);
		this.setFriction();
		this.bindJoint();
		this.cleanEffect();
		console.log("rebuildBlock");
	}


	public destory() {
		if (this.m_world.IsLocked()) {
			console.log("world is islocked")
			return
		}
		if (this.mBody) this.m_world.DestroyBody(this.mBody);
		this.parent && this.parent.removeChild(this);
		this.cleanEffect();
	}


	public convertStatic() {
		this.stopFall();
		this.mBody.SetAwake(false);
		this.mBody.SetType(Box2D.Dynamics.b2Body.b2_staticBody);
	}

	private bindJoint() {
		for (let i = 0; i < this.bodyJoints.length; i++) {
			let bodyB = this.bodyJoints[i];
			this.bindOneJoint(bodyB);
		}
	}

	private bindOneJoint(bodyB: Box2D.Dynamics.b2Body) {
		var jointDef: Box2D.Dynamics.Joints.b2WeldJointDef = new Box2D.Dynamics.Joints.b2WeldJointDef();
		jointDef.Initialize(this.mBody, bodyB, this.mBody.GetWorldCenter());
		bodyB.GetWorld().CreateJoint(jointDef);
		let blockB = bodyB.GetUserData() as Block;
		blockB && BlockFactory.addBlockSkin(blockB, BlockSkinType.vine)

	}


	public addJoinBody(bodyB: Box2D.Dynamics.b2Body) {
		if (!this.isBindJoint) return;
		/***避免重复 */
		if (this.bodyJoints.indexOf(bodyB) < 0) {
			this.bodyJoints.push(bodyB);
			/***如果已经重建了，需要独自添加，不然会在rebuild的时候统一绑定 */
			if (this.isRebuild) {
				this.bindOneJoint(bodyB);
			}
		}

		if (!this.isStartJoin) {
			/***大概3帧内的所有碰撞都会绑定关节 */
			egret.setTimeout(() => {
				this.isBindJoint = false;
			}, this, 200);

		}
		this.isStartJoin = true;
	}

	protected getVec(): Array<number[]> {
		return [];
	}

	public getBody(): Box2D.Dynamics.b2Body {
		return this.mBody;
	}

	public setBody(body: Box2D.Dynamics.b2Body) {
		this.mBody = body;
	}

	public update() {
		if (!this.mBody) return;
		if (this.moving) {
			this.moving = false;
			let pos = this.mBody.GetPosition().Copy();
			let targetX = this.curNum * GlobalClass.GameInfoForConfig.blockUnitWidth / 2;
			this.mBody.SetPosition(new Box2D.Common.Math.b2Vec2(targetX / GlobalClass.GameInfoForConfig.factor, pos.y));
		}
		/**重新设定原始速度 */
		this.mBody.SetAngularVelocity(0);
		this.mBody.SetLinearVelocity(new Box2D.Common.Math.b2Vec2(0, this.fallSpeed));
	}

	private isblink = false;//当前正在瞬移 瞬移的时候 y方向没有下降的速度 只有左右两边的方向
	//posx为格数  每次移动半格  速度为 宽度/2*posx/转换比例*60
	public move(controlType: BlockControlType, posX: number, posY: number) {
		// console.log("posX=" + posX + " posY=" + posY + "type=" + controlType);
		if (!this.mBody || controlType == BlockControlType.Rotation) return;
		let velocity = this.getBody().GetLinearVelocity().Copy();
		let ratio = GlobalClass.GameInfoForConfig.worldUpdateRate / GlobalClass.GameInfoForConfig.factor;
		switch (controlType) {
			case BlockControlType.Left:
				if (!this.canMoveLeft()) {
					return;
				}
				this.curNum -= posX;
				if (this.curNum < 0) {
					posX = this.curNum - 0;
					this.curNum = 0;
				}
				velocity.x = -GlobalClass.GameInfoForConfig.blockUnitWidth / 2 * posX * ratio;//一次移动半格，即为20 时间为1/60 再乘以转换比例30
				break;
			case BlockControlType.Right:
				if (!this.canMoveRight()) {
					return;
				}
				this.curNum += posX;
				if (this.curNum > 36) {
					posX = 36 - this.curNum;
					this.curNum = 36;
				}
				velocity.x = GlobalClass.GameInfoForConfig.blockUnitWidth / 2 * posX * ratio;
				break;
			case BlockControlType.Down:
				if (posY >= 50) {
					this.fallSpeed *= 20;
				} else {
					velocity.y += 1 * posY * 2;
				}
				break;
			case BlockControlType.Up:
				break;
			case BlockControlType.BlinkLeft:
				this.isblink = true;
				this.curNum -= 2;
				if (this.curNum < 0) {
					this.curNum = 0;
				}
				velocity.x = -GlobalClass.GameInfoForConfig.blockUnitWidth / 2 * 2 * ratio;
				velocity.y = 0;
				break;
			case BlockControlType.BlinkRight:
				this.isblink = true;
				this.curNum += 2;
				if (this.curNum > 36) {
					this.curNum = 36;
				}
				velocity.x = GlobalClass.GameInfoForConfig.blockUnitWidth / 2 * 2 * ratio;
				velocity.y = 0;
				break;
			case BlockControlType.Stop:
				velocity.y = 0;
				break;
			case BlockControlType.Resume:
				velocity.y = this.fallSpeed;
				break;
		}
		this.toMove(velocity);
	}

	public toMove(velocity: Box2D.Common.Math.b2Vec2) {
		this.getBody().SetLinearVelocity(velocity);
		this.moving = true;
	}

	private canMoveLeft(): boolean {
		return this.curNum > 0 && this.fallSpeed == (this.originFallSpeed * this.fallSpeedMul);
	}

	private canMoveRight(): boolean {
		return this.curNum < 36 && this.fallSpeed == (this.originFallSpeed * this.fallSpeedMul);
	}

	public changeSkin(controlType: BlockControlType, posX: number, posY: number) {
		var body = this.mBody;
		let img = body.GetUserData();
		let x = img.x;
		let y = img.y;
		let rot = img.rotation;
		switch (controlType) {
			case BlockControlType.Left:
				x -= posX * GlobalClass.GameInfoForConfig.blockUnitWidth / 2;
				break;
			case BlockControlType.Left:
				x -= posX * GlobalClass.GameInfoForConfig.blockUnitWidth / 2;
				break;
			case BlockControlType.Right:
				x += posX * GlobalClass.GameInfoForConfig.blockUnitWidth / 2;
				break;
			case BlockControlType.Down:

				break;
			case BlockControlType.Rotation:
				rot += 90;
				break;
			case BlockControlType.BlinkLeft:
				x -= GlobalClass.GameInfoForConfig.blockUnitWidth;
				break;
			case BlockControlType.BlinkRight:
				x += GlobalClass.GameInfoForConfig.blockUnitWidth;
				break;
			case BlockControlType.Empty:
				y += 2.5;
				break;
		}
		img.x = x;
		img.y = y;
		img.rotation = rot;
	}

	public changeStates(controlType: BlockControlType, posX: number, posY: number) {
		if (!this.canControle) return
		if (controlType == BlockControlType.Rotation) {
			this.toRotate();
		} else {
			this.move(controlType, posX, posY);
		}
	}

	public setSeed(randomSeed) {
		this.seed = randomSeed;
	}

	//如果isAll为true，则返回所有的状态描述  否则只返回x,y位置数据
	public pack(isAll = true): Object {
		let bodyJointsId = [];
		this.bodyJoints.forEach((body: Box2D.Dynamics.b2Body) => {
			let block = body.GetUserData() as Block;
			bodyJointsId.push(block.blockId);
		})

		if (isAll) {
			let pdata = {
				blockId: this.blockId,
				blockType: this.blockType,
				skin: this.blockSkinType,
				x: this.mBody.GetPosition().x,
				y: this.mBody.GetPosition().y,
				angle: this.mBody.GetAngle(),
				scale: this.scale,
				islocked: this.isLockRotate,
				isToFeezen: this.isToFreezen,
				isBindJoint: this.isBindJoint,
				isDisorder: this.isDisorder,
				bodyJointsIdList: bodyJointsId,
				isContacted: this.isContacted,
				isCurTet: this.isCurTet,
				fallSpeed: this.fallSpeed,
			}
			return pdata;
		} else {
			let pdata = {
				blockType: this.blockType,
				x: this.mBody.GetPosition().x,
				y: this.mBody.GetPosition().y,
				angle: this.mBody.GetAngle(),
			}
			return pdata;
		}


	}

	public getBlockID(): number {
		return this.blockId;
	}

	public unpack(data: any) {
		this.blockId = data.blockId;
		this.blockType = data.blockType;
		this.blockSkinType = data.skin;
		this.mBody.SetPositionAndAngle(new Box2D.Common.Math.b2Vec2(data.x, data.y), data.angle);
		this.isLockRotate = data.islocked;
		this.isToFreezen = data.isToFeezen;
		this.isBindJoint = data.isBindJoint;
		this.isDisorder = data.isDisorder;
		this.isContacted = data.isContacted;
		this.bodyJoints = data.bodyJointsIdList;
		this.scale = data.scale;
		this.isCurTet = data.isCurTet;
		this.fallSpeed = data.fallSpeed;
		this.resetUI();
		this.updateSkin();
		if (this.isCurTet) {
			this.setZeroGravity();

		} else {
			this.mBody.SetLinearVelocity(new Box2D.Common.Math.b2Vec2(0, 0));
			this.mBody.SetAngularVelocity(0);
			/**重新受到重力作用 */
			this.resetGravity();
			this.mBody.SetBullet(false);
		}
	}

	public checkSame(block: Block): boolean {
		if (this.blockId != block.blockId) { return false; }
		if (this.blockType != block.blockType) { return false; }
		if (this.blockSkinType != block.blockSkinType) { return false; }
		if (this.mBody.GetPosition().y != block.mBody.GetPosition().y) { return false; }
		if (this.mBody.GetPosition().x != block.mBody.GetPosition().x) { return false; }
		if (this.scale != block.scale) { return false; }
		if (this.mBody.GetAngle() != block.mBody.GetAngle()) { return false; }
		if (this.isLockRotate != block.isLockRotate) { return false; }
		if (this.isBindJoint != block.isBindJoint) { return false; }

		if (this.isToFreezen != block.isToFreezen) { return false; }
		if (this.isDisorder != block.isDisorder) { return false; }
		if (this.isContacted != block.isContacted) { return false; }
		if (this.isCurTet != block.isCurTet) { return false; }

		if (this.bodyJoints.length != block.bodyJoints.length) { return false; }
		let jointNum = this.bodyJoints.length;
		for (let i = 0; i < jointNum; i++) {
			if (this.bodyJoints[i] != block.bodyJoints[i]) {
				return false;
			}
		}
		return true;
	}
	private resetUI() {
		BlockFactory.setBlockSkin(this, this.blockSkinType);
	}
}

enum BlockControlType {
	Right,
	Left,
	Down,
	Up,
	Rotation,
	BlinkLeft,//向左瞬移
	BlinkRight,//向右瞬移
	Stop,
	Resume,
	Empty,//空帧
}