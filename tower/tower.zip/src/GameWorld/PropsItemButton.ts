class PropsItemButton extends eui.Button implements eui.UIComponent {
	public constructor(pcount: number, ccount: number, type: PropsID) {
		super();
		this.Count = pcount;
		this.canUseCount = ccount;
		this.propsType = type;
		this.skinName = "PropsItemButtonSkin";
	}

	/**总数 */
	private Count: number;
	/**可以使用的数量 */
	private canUseCount: number;
	/**物品类型Id */
	public propsType: PropsID;
	private countInfoBitLab: eui.BitmapLabel;

	private Icon:eui.Image;
	private animationGroup:eui.Group;

	protected partAdded(partName: string, instance: any): void {
		super.partAdded(partName, instance);
	}

	protected childrenCreated(): void {
		super.childrenCreated();
		this.updateUI();
		this.addEventListener("touchTap", this.onPropsClick, this);
	}

	private onPropsClick(){
		this.iconAni();
		if(this.Count>0&&this.canUseCount>0){
			let pid = this.propsType-300;
			UserControl.getInstance().useItem(pid);
			this.canUseCount--;
			this.Count--;
			GlobalClass.Game.currentPropInfos.forEach(element => {
				if(element["prop_number"]==this.propsType){
					element["quantity"] --;
				}
			});
			this.updateNum();
		}else{//道具数量不足
			if(this.Count<=0){
				KFControllerMgr.getCtl(PanelName.GamePanel).showToast("道具数量不足");
			}
			if(this.canUseCount<=0){
				KFControllerMgr.getCtl(PanelName.GamePanel).showToast("道具使用数量超过上限");
			}
		}
	}

	private iconAni(){
		this.Icon.rotation
		egret.Tween.get(this.Icon).to({rotation:-15},200).to({rotation:0},200).to({rotation:15},200).to({rotation:0},200).call(function (){
		},this);
	}

	private updateUI() {
		this.initBG();
		this.Icon.source = "CommonAtlas_json.Img_itemB"+this.propsType;
		this.updateNum();
	}

	private updateNum(){
		this.countInfoBitLab.text = this.Count + "/" + this.canUseCount;
	}

	private initBG(){
		let Ani = AnimationMgr.getInstance().getSkeleton(skeletonType.daoju);
		Ani.animation.play();
		Ani.display.x = this.width/2;
		Ani.display.y = this.height/2;
		this.animationGroup.addChild(Ani.display);
	}

	

}