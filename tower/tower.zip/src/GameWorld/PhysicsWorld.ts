module Game {
	export module GameWorld {
		export class PhysicsWorld {

			public static createBlock(m_world: Box2D.Dynamics.b2World, posX: number, posY: number, angle: number, vecs: Array<any>, isStatic: boolean = false, offsize: number = 0, isXBlock: boolean = false): Box2D.Dynamics.b2Body {
				let body;
				if (!isXBlock) {
					let tvec2s: Array<Box2D.Common.Math.b2Vec2> = [];
					for (let i = 0; i < vecs.length; i++) {
						let pos = vecs[i];
						let temvec: Box2D.Common.Math.b2Vec2 = new Box2D.Common.Math.b2Vec2(pos[0], pos[1]);
						tvec2s.push(temvec);
					}
					body = this.createNormalBlock(m_world, posX, posY, angle, tvec2s, isStatic, offsize);
				} else {
					let tvec2s: Array<Array<Box2D.Common.Math.b2Vec2>> = [];
					for (let i = 0; i < vecs.length; i++) {
						let ttvec = vecs[i];
						let temp = [];
						for (let j = 0; j < ttvec.length; j++) {
							let pos = ttvec[j];
							temp.push(new Box2D.Common.Math.b2Vec2(pos[0] * (GlobalClass.GameInfoForConfig.blockUnitWidth - offsize) / GlobalClass.GameInfoForConfig.factor, pos[1] * (GlobalClass.GameInfoForConfig.blockUnitWidth - offsize) / GlobalClass.GameInfoForConfig.factor));
						}
						tvec2s.push(temp);
					}
					body = this.createXBlock(m_world, posX, posY, angle, tvec2s, isStatic, offsize)
				}
				return body;
			}

			public static createNormalBlock(m_world: Box2D.Dynamics.b2World, posX: number, posY: number, angle: number, vecs: Array<Box2D.Common.Math.b2Vec2>, isStatic: boolean = false, offsize: number) {
				var bodyDef = new Box2D.Dynamics.b2BodyDef();
				bodyDef.position = new Box2D.Common.Math.b2Vec2(posX / GlobalClass.GameInfoForConfig.factor, posY / GlobalClass.GameInfoForConfig.factor);
				bodyDef.angle = angle;
				if (isStatic) {
					bodyDef.type = Box2D.Dynamics.b2Body.b2_staticBody;
				} else {
					bodyDef.type = Box2D.Dynamics.b2Body.b2_dynamicBody;
				}
				var body = m_world.CreateBody(bodyDef);
				for (let i = 0; i < vecs.length; i++) {
					var poly = new Box2D.Collision.Shapes.b2PolygonShape();
					var scaleSize = (GlobalClass.GameInfoForConfig.blockUnitWidth - offsize) / 2 / GlobalClass.GameInfoForConfig.factor;
					var scaleSize2 = (GlobalClass.GameInfoForConfig.blockUnitWidth) / 2 / GlobalClass.GameInfoForConfig.factor;
					vecs[i].x *= scaleSize2 * 2;
					vecs[i].y *= scaleSize2 * 2;
					poly.SetAsOrientedBox(scaleSize, scaleSize, vecs[i]);
					var desity = 1.0;
					var fixture = body.CreateFixture2(poly, desity);
					fixture.SetFriction(1);
					fixture.SetRestitution(0);
				}

				return body;
			}

			public static createXBlock(m_world: Box2D.Dynamics.b2World, posX: number, posY: number, angle: number, vecs: Array<Array<Box2D.Common.Math.b2Vec2>>, isStatic: boolean = false, offsize: number) {
				var bodyDef = new Box2D.Dynamics.b2BodyDef();
				bodyDef.position = new Box2D.Common.Math.b2Vec2(posX / GlobalClass.GameInfoForConfig.factor, posY / GlobalClass.GameInfoForConfig.factor);
				bodyDef.angle = angle;
				if (isStatic) {
					bodyDef.type = Box2D.Dynamics.b2Body.b2_staticBody;
				} else {
					bodyDef.type = Box2D.Dynamics.b2Body.b2_dynamicBody;
				}
				var body = m_world.CreateBody(bodyDef);
				for (let i = 0; i < vecs.length; i++) {
					let bodyShape = new Box2D.Collision.Shapes.b2PolygonShape();
					bodyShape.SetAsVector(vecs[i]);
					var desity = 1.0;
					var fixture = body.CreateFixture2(bodyShape, desity);
					fixture.SetFriction(1);
					fixture.SetRestitution(0);
				}
				return body
			}

			public static createBox(m_world: Box2D.Dynamics.b2World, posX: number, posY: number, w: number, h: number, isStatic: boolean = false): Box2D.Dynamics.b2Body {
				var bodyDef = new Box2D.Dynamics.b2BodyDef();
				bodyDef.position.Set(posX / GlobalClass.GameInfoForConfig.factor, posY / GlobalClass.GameInfoForConfig.factor);
				bodyDef.type = Box2D.Dynamics.b2Body.b2_dynamicBody;
				if (isStatic) {
					bodyDef.type = Box2D.Dynamics.b2Body.b2_staticBody;
				}
				var body = m_world.CreateBody(bodyDef);
				var poly = new Box2D.Collision.Shapes.b2PolygonShape();
				poly.SetAsBox(w / GlobalClass.GameInfoForConfig.factor, h / GlobalClass.GameInfoForConfig.factor);
				var fixtureDef = new Box2D.Dynamics.b2FixtureDef();
				fixtureDef.density = 3;
				fixtureDef.friction = 1;
				fixtureDef.restitution = 0;
				fixtureDef.shape = poly;
				body.CreateFixture(fixtureDef);
				return body;
			}

			//这里的posX和posY为半格的距离，左上第一个格子为0，0 ，右下为36,64
			public static createPlatForm(m_world: Box2D.Dynamics.b2World, posX: number, posY: number, vecs: Array<Box2D.Common.Math.b2Vec2>, skinName = ""): Box2D.Dynamics.b2Body {
				var bodyDef = new Box2D.Dynamics.b2BodyDef();
				let pX = GlobalClass.GameInfoForConfig.blockUnitWidth / 2 * posX;
				let pY = GlobalClass.GameInfoForConfig.blockUnitWidth / 2 * posY;
				bodyDef.position = new Box2D.Common.Math.b2Vec2(pX / GlobalClass.GameInfoForConfig.factor, pY / GlobalClass.GameInfoForConfig.factor);

				bodyDef.type = Box2D.Dynamics.b2Body.b2_staticBody;
				var body = m_world.CreateBody(bodyDef);
				for (let i = 0; i < vecs.length; i++) {
					var poly = new Box2D.Collision.Shapes.b2PolygonShape();
					var scaleSize = (GlobalClass.GameInfoForConfig.blockUnitWidth - 1) / 2 / GlobalClass.GameInfoForConfig.factor;
					var scaleSize2 = (GlobalClass.GameInfoForConfig.blockUnitWidth) / 2 / GlobalClass.GameInfoForConfig.factor;
					vecs[i].x *= scaleSize2 * 2;
					vecs[i].y *= scaleSize2 * 2;
					poly.SetAsOrientedBox(scaleSize, scaleSize, vecs[i]);
					let fix = body.CreateFixture2(poly, 3);
					fix.SetFriction(1);
					fix.SetRestitution(0);
				}

				if (skinName != "") {
					let mSprite = new egret.Sprite();
					let skin = new egret.Bitmap(RES.getRes(skinName));
					mSprite.addChild(skin);
					mSprite.rotation = body.GetAngle();
					body.SetUserData(mSprite);
					mSprite.anchorOffsetX = skin.width / 2;
					mSprite.anchorOffsetY = skin.height / 2;
				}

				return body;
			}

			public static createJigsawPlatForm2(m_world: Box2D.Dynamics.b2World, posX: number, posY: number, vecs: Array<Box2D.Common.Math.b2Vec2>, display: egret.DisplayObjectContainer) {

				let w = GlobalClass.GameInfoForConfig.blockUnitWidth;
				let h = GlobalClass.GameInfoForConfig.blockUnitWidth;
				let topVecs = this.getPlatformTop(vecs);
				let topSkin = "Game_json.Img_platformblock01";
				let bottomSKin = "Game_json.Img_platformblock02";
				for (let i = 0; i < vecs.length; i++) {
					let skin: egret.Bitmap;
					if (topVecs[vecs[i].x] == vecs[i].y) {//使用顶部纹理
						skin = new egret.Bitmap(RES.getRes(topSkin));
					} else {
						skin = new egret.Bitmap(RES.getRes(bottomSKin));
					}
					let pX = GlobalClass.GameInfoForConfig.blockUnitWidth * (posX / 2 + vecs[i].x);
					let pY = GlobalClass.GameInfoForConfig.blockUnitWidth * (posY / 2 + vecs[i].y);
					skin.anchorOffsetX = skin.width / 2;
					skin.anchorOffsetY = skin.height / 2;
					let body = this.createBox(m_world, pX, pY, 20, 20, true);
					body.SetUserData(skin);
					display.addChild(skin);
				}

			}

			//创建拼图模式的底座 body的生成方式和原始的底座一样,但拼图的纹理由小块纹理拼接而成,头部为一种纹理,剩下为第二种纹理
			public static createJigsawPlatForm(m_world: Box2D.Dynamics.b2World, posX: number, posY: number, vecs: Array<Box2D.Common.Math.b2Vec2>, display) {
				var bodyDef = new Box2D.Dynamics.b2BodyDef();
				let pX = GlobalClass.GameInfoForConfig.blockUnitWidth / 2 * posX;
				let pY = GlobalClass.GameInfoForConfig.blockUnitWidth / 2 * posY;
				bodyDef.position = new Box2D.Common.Math.b2Vec2(pX / GlobalClass.GameInfoForConfig.factor, pY / GlobalClass.GameInfoForConfig.factor);

				bodyDef.type = Box2D.Dynamics.b2Body.b2_staticBody;
				var body = m_world.CreateBody(bodyDef);

				let topVecs = this.getPlatformTop(vecs);
				let mSprite = new egret.Sprite();
				let topSkin = "Game_json.Img_platformblock01";
				let bottomSKin = "Game_json.Img_platformblock02";

				for (let i = 0; i < vecs.length; i++) {
					let skin;
					if (topVecs[vecs[i].x] == vecs[i].y) {//使用顶部纹理
						skin = new egret.Bitmap(RES.getRes(topSkin));

					} else {
						skin = new egret.Bitmap(RES.getRes(bottomSKin));
					}
					mSprite.addChild(skin);

					var poly = new Box2D.Collision.Shapes.b2PolygonShape();
					// var scaleSize = (GlobalClass.GameInfoForConfig.blockUnitWidth - 1) / 2 / GlobalClass.GameInfoForConfig.factor;
					var scaleSize2 = (GlobalClass.GameInfoForConfig.blockUnitWidth) / 2 / GlobalClass.GameInfoForConfig.factor;

					vecs[i].x *= scaleSize2 * 2;
					vecs[i].y *= scaleSize2 * 2;
					poly.SetAsOrientedBox(scaleSize2, scaleSize2, vecs[i]);
					let fix = body.CreateFixture2(poly, 3);
					fix.SetFriction(1);
					fix.SetRestitution(0);

					skin.x = vecs[i].x * GlobalClass.GameInfoForConfig.factor;
					skin.y = vecs[i].y * GlobalClass.GameInfoForConfig.factor;
					skin.anchorOffsetX = skin.width / 2;
					skin.anchorOffsetY = skin.height / 2;
				}

				mSprite.rotation = body.GetAngle();
				body.SetUserData(mSprite);
				// mSprite.anchorOffsetX = mSprite.width / 2;
				// mSprite.anchorOffsetY = mSprite.height / 2;
				mSprite.cacheAsBitmap = true;
				display.addChild(mSprite);

				return body;
			}

			public static getPlatformTop(datas) {
				let outData = {};
				datas.forEach(element => {
					if (outData[element.x] == null || outData[element.x] > element.y) {
						outData[element.x] = element.y;
					}
				});
				return outData;
			}
		}


	}
}

