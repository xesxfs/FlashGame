
/*
    1.该类主要用作控制信息的接收和发送，每一秒钟发送15次信息 信息为UserControMSG格式的数据，如果无用户操作则发送空包
    2.每收到一次数据才发送一次数据
    3.在三个时间周期内没收到数据，则通知游戏暂停
    4.如果一次收到多个数据，则放入收入到的消息列表中，合并其中的空白包后，通知渲染层面快进更新
    5.如果一个周期内有多个操作数据，则放入发送消息队列中，依次发送
*/


class UserControl {
    private receivedDataList: Array<Array<MSGBase>>;//收到的操作数据队列
    private sendDataList: Array<MSGBase>;//发送的操作数据队列
    private stayDataList = {};//因丢帧而暂时不处理，保存起来的帧数据
    private heart: egret.Timer;//采样，每秒15次采集客户端的数据
    private delayTime = 0;//已延时的数据接收周期，超过三个周期无数据，则通知游戏进行等待重连

    private lostFrameNum;

    private static instance: UserControl;
    private haveStarted = false;
    private isSuppling = false;//正在补帧中

    private netReceiveList = [];

    private ringBuffer = [];//环形缓冲

    private supplyNumPerNet = 3;//每一次网络帧，本地需要补充多少次空帧

    private currentBlockIndex = 0;//对战时记录当前操作是针对哪一块砖块，避免上一块砖块的操作影响到下一块砖块

    public static getInstance(): UserControl {
        if (this.instance == null) {
            this.instance = new UserControl();
            this.instance.init();
        }
        return this.instance;
    }

    private init() {
        this.initData();
        this.heart = new egret.Timer(GlobalClass.GameInfoForConfig.controlRate, 0);
        this.heart.addEventListener(egret.TimerEvent.TIMER, this.collectCtlMsg, this);
        NetEventMgr.getInstance().addEventListener("100304_event", this.on100304_event, this);
        NetEventMgr.getInstance().addEventListener("100309_event", this.on100309_event, this);
    }

    private initData() {
        this.receivedDataList = new Array();
        this.sendDataList = new Array();
        this.netReceiveList = new Array();
        this.stayDataList = {};
        this.lostFrameNum = 0;
    }

    private on100304_event(event: egret.Event): void {
        let msg: MSGBase = <MSGBase>event.data;
        let data = msg.getData();
        let js = this.unpackMSG(data);
        this.receiveMSG(js["frameNum"], js["Msg"], false);
        // console.log("on100304_event num=" + js["frameNum"] + " time=" + egret.getTimer());
    }

    private on100309_event(event: egret.Event): void {
        let msg: MSGBase = <MSGBase>event.data;
        let data = msg.getData();
        //返回的数据格式为 [每帧数据长度，帧数据，帧数据，帧数据，帧数据，帧数据 ]
        data.position = 0;
        let len = data.length;
        let frameLen = data.readInt();
        let dataNum = Math.floor((len - 4) / frameLen);
        for (let i = 0; i < dataNum; i++) {
            let tempData: egret.ByteArray = new egret.ByteArray();
            let dataLen = frameLen / 4;
            for (let j = 0; j < dataLen; j++) {
                tempData.writeInt(data.readInt());
            }

            tempData.position = 0;
            let ff = tempData.readInt();

            let js = this.unpackMSG(tempData);
            this.stayDataList[js["frameNum"]] = js["Msg"];
        }
    }

    private unpackMSG(data): Object {
        data.position = 0;
        let len = data.length;
        let dataNum = Math.floor(len / 4) - 1;
        let frameNum = data.readInt();
        let userDatas = [];
        let actionmsg: MSGBase = new MSGBase();
        for (let i = 0; i < dataNum; i++) {
            actionmsg.getData().writeInt(data.readInt());
        }
        let js = { frameNum: frameNum, Msg: actionmsg };
        return js;
    }

    private gameHaveStart = false;
    public gameStart() {
        if (this.gameHaveStart) {
            return;
        }
        this.initData();
        this.gameHaveStart = true;
        // this.lastReceiveFrameNum = 0;
        GlobalClass.Game.currentNetFrameNum = 0;
        this.cycleMsgCount = 0;
        this.isSuppling = false;
        this.waitforCheck = false;

        console.log("gameStart");
        egret.startTick(this.localFrameStep, this);
        if (GlobalClass.Game.GameMode == 2) {
            this.heart.start();
        }
    }

    public startCollectTouch() {
        this.haveStarted = true;
    }

    public gameEnd() {
        console.log("gameEnd");
        GameTouchListener.getInstance().colletMsg(false);
        this.haveStarted = false;
        this.gameHaveStart = false;
        if (GlobalClass.Game.GameMode == 2) {
            this.heart.stop();
        }

        egret.stopTick(this.localFrameStep, this);
        // NetEventMgr.getInstance().addEventListener("100304_event", this.on100304_event, this);
        // NetEventMgr.getInstance().addEventListener("100309_event", this.on100309_event, this);
    }

    public gamePause() {
        // this.heart.stop();
        egret.stopTick(this.localFrameStep, this);
    }

    public gameResume() {
        // this.heart.start();
        egret.startTick(this.localFrameStep, this);
    }

    private localFrameStep(timeStamp: number): boolean {
        if (!this.haveStarted) {
            return false;
        }
        if (GlobalClass.Game.GameMode == 2) {//多人游戏 每隔四帧等待一次网络帧
        } else {
            this.collectCtlMsg();
        }
    }

    //暂停收集操作信息 清空已有的操作列表
    public fobideCollect() {
        this.clearActionList();
        this.heart.stop();
    }

    public startCollect() {
        this.heart.start();
    }

    public clearActionList() {
        GameTouchListener.getInstance().colletMsg(false);
        GameTouchListener.getInstance().touchEnd();
        this.sendDataList = [];
    }

    private collectCtlMsg() {
        if (!this.waitforCheck) {
            GameTouchListener.getInstance().colletMsg(true);
            this.sendMSGTOSever();
        }
    }

    //检测是否有帧的丢失
    private checkFrameState(newFrame): boolean {
        // console.log("new=" + newFrame + " currentNetFrameNum=" + GlobalClass.Game.currentNetFrameNum);
        if (newFrame == GlobalClass.Game.currentNetFrameNum) {
            return true;
        } else {//
            return false;
        }
    }

    private cycleMsgCount;//多人对战消息每周期发四次后，等校验后才能继续发送
    private waitforCheck = false;
    private sendMSGTOSever() {
        //如果是多人模式，则发送网络请求，否则发送客户端内的消息通知
        //单人玩法时候直接返回,多人游戏发送到服务器
        let msg: MSGBase;
        if (this.sendDataList.length > 0) {
            msg = this.sendDataList.shift();
        } else {//发送空白帧
            msg = new EmptyMSG();
        }
        if (GlobalClass.Game.GameMode == 2) {//多人模式上报服务器，但是在本地先模拟行为，等待网络帧返回后校正            
            if (msg.getType() != PlayerMSGType.Empty) {//不发空白帧
                if (!this.waitforCheck) {
                    WebSocketMgr.getInstance().SendOneceMsgByByte(MsgID.GAMEPlay.GameOperate, msg.getData());
                    KFControllerMgr.getCtl(PanelName.GamePanel).updateMoveInstans(msg);
                    // this.cycleMsgCount ++;
                    // if(this.cycleMsgCount==4){
                    //     this.waitforCheck = true;
                    // }
                }
            }

        } else {
            this.receiveMSG(GlobalClass.Game.currentNetFrameNum, msg, true);
        }
    }

    public stopWait() {
        console.log("stopWait");
        this.waitforCheck = false;
        this.cycleMsgCount = 0;
    }

    //接受并处理玩家的操作数据包 //封装成json 数组
    public receiveMSG(frameNum, data: MSGBase, isLocal: boolean) {

        //判断补帧是否结束
        if (this.isSuppling && GlobalClass.Game.localFrameNum == frameNum) {
            if (this.isSuppling) {
                this.isSuppling = false;
                KFControllerMgr.getCtl(PanelName.GamePanel).onSuppling(this.isSuppling);
                this.stayDataList = {};
                GlobalClass.Game.currentNetFrameNum = frameNum;
                console.log("补帧结束");
            }
        }

        if (!this.isSuppling && this.checkFrameState(frameNum)) {//检测是否要补帧

            let outData = MSGBase.unpackMSG(data.getData());
            this.receivedDataList.push(outData);
            if (!isLocal) {
                //  this.lastReceiveFrameNum = frameNum;
                GlobalClass.Game.currentNetFrameNum++;
            }
            this.lostFrameNum = 0;//帧数正常，丢帧数归零
        }
        else {//向服务器补帧 从最后接到的帧开始，到最新的帧
            this.stayDataList[frameNum] = data;
            if (!this.isSuppling) {//第一次发现丢帧
                this.supplyData(frameNum);
                console.log("帧啦~,补帧中");
            }
        }
    }

    public supplyData(lastFrame) {
        this.isSuppling = true;
        KFControllerMgr.getCtl(PanelName.GamePanel).onSuppling(this.isSuppling);
        let lastNum = 0;
        if (GlobalClass.Game.isReloadGame) {
            // lastNum = GlobalClass.Game.lasteSupplyFrameNum;
            lastNum = GlobalClass.Game.localFrameNum;
        } else {
            lastNum = GlobalClass.Game.currentNetFrameNum;
        }
        let js = { first_frame: lastNum, last_frame: lastFrame };
        WebSocketMgr.getInstance().SendOneceMsg(MsgID.GAMEPlay.RequireFrameData, JSON.stringify(js));
    }

    private supplyIndex = -1;
    public getOneMSG(): any {
        if (this.isSuppling) {
            // console.log("isSuppling framenum1=" + GlobalClass.Game.localFrameNum);
            let data;
            let finalData;
            if (this.supplyIndex == -1) {
                data = this.stayDataList[GlobalClass.Game.localFrameNum];
            } else {
                data = new EmptyMSG();
            }
            if (data != null) {
                if (this.supplyIndex == -1) {
                    // console.log("isSuppling framenum=" + GlobalClass.Game.localFrameNum);
                    GlobalClass.Game.localFrameNum++;
                }

                this.supplyIndex++;
                if (this.supplyIndex == this.supplyNumPerNet) {
                    this.supplyIndex = -1;
                }
                data = MSGBase.unpackMSG(data.getData());
            }
            return data;
        } else {
            let data;
            if (GlobalClass.Game.GameMode == 2) {
                if (this.supplyIndex == -1) {
                    data = this.receivedDataList.shift();
                } else {
                    data = MSGBase.unpackMSG(new EmptyMSG().getData());
                }
                if (data != null) {
                    if (this.supplyIndex == -1) {
                        GlobalClass.Game.localFrameNum++;
                    }

                    this.supplyIndex++;
                    if (this.supplyIndex == this.supplyNumPerNet) {
                        this.supplyIndex = -1;
                    }
                }
            } else {
                data = this.receivedDataList.shift();
            }
            return data;
        }
    }

    public MSGConut(): number {
        return this.receivedDataList.length;
    }

    public useItem(itemID: PropsID) {
        let msg = new ItemMSG();
        msg.parseData(itemID);
        this.sendDataList.push(msg);
    }

    public useSKill(skillID: SkillType, category: SkillCategory, giverSeatID: number, receiverSeatID: number) {
        let msg = new SkillMSG();
        msg.parseData(skillID, giverSeatID, receiverSeatID, category);
        this.sendDataList.push(msg);
    }

    //type 为5时为停止掉落  为6时为恢复掉落
    public userMove(type: number, posx: number, posy: number) {
        if (GlobalClass.Game.GameMode == 2) {//如果是多人游戏，要限制发送消息的次数
            GameTouchListener.getInstance().colletMsg(false);
        }
        // GameTouchListener.getInstance().colletMsg(false);
        let msg = new MoveMSG();
        msg.parseData(type, posx, posy,this.currentBlockIndex);
        this.sendDataList.push(msg);
    }

    public getBLockIndex():number{
        return this.currentBlockIndex;
    }

    public BlockChange(){
        this.currentBlockIndex++;
        if(this.currentBlockIndex>=8){
            this.currentBlockIndex = 0;
        }
     
    }
    
}