class GameTouchListener{

    private tDateTimer;
    private delegatePanel:KFPanel;
    private static instance: GameTouchListener;
    public static getInstance(): GameTouchListener {
        if(this.instance == null) {
            this.instance = new GameTouchListener();
            this.instance.init();
        }
        return this.instance;
    }

    public addListener(panel:KFPanel){
        this.delegatePanel = panel;
        // this.delegatePanel.addEventListener(egret.TouchEvent.TOUCH_BEGIN, this.onTouchBegin, this); 
        // this.delegatePanel.addEventListener(egret.TouchEvent.TOUCH_MOVE, this.onTouchMove, this); 
        // this.delegatePanel.addEventListener(egret.TouchEvent.TOUCH_CANCEL, this.onTouchCancel, this); 
        // this.delegatePanel.addEventListener(egret.TouchEvent.TOUCH_END, this.onTouchEnd, this); 
        
        this.delegatePanel.addEventListener(egret.TouchEvent.TOUCH_BEGIN, this.onTouchBegin, this); 
        this.delegatePanel.addEventListener(egret.TouchEvent.TOUCH_MOVE, this.onTouchMove, this); 
        this.delegatePanel.addEventListener(egret.TouchEvent.TOUCH_CANCEL, this.onTouchCancel, this); 
        this.delegatePanel.addEventListener(egret.TouchEvent.TOUCH_END, this.onTouchEnd, this); 
    }

    public removerlistener(panel:KFPanel){
        this.delegatePanel.removeEventListener(egret.TouchEvent.TOUCH_BEGIN, this.onTouchBegin, this); 
        this.delegatePanel.removeEventListener(egret.TouchEvent.TOUCH_MOVE, this.onTouchMove, this); 
        this.delegatePanel.removeEventListener(egret.TouchEvent.TOUCH_CANCEL, this.onTouchCancel, this); 
        this.delegatePanel.removeEventListener(egret.TouchEvent.TOUCH_END, this.onTouchEnd, this); 
        this.delegatePanel = null;
    }

    
    private beginX;
    private beginY;
    private haveMove = false;
    private onTouchBegin(evt:egret.TouchEvent){
        if(!this.startCollet){
            return;
        }
        // console.log("onTouchBegin x ="+evt.stageX+" y="+evt.stageY+" touchID="+evt.touchPointID);
        this.beginX = evt.stageX;
        this.beginY = evt.stageY;
        this.isTouchBegin = true;
        this.haveMove = false;
    }

    private xratio = 20;
    private yratio = 5;
    private init(){
        
        // this.xratio = GlobalClass.GameInfoForConfig.blockUnitWidth/2;
         
    }
    private onTouchMove(evt:egret.TouchEvent){
        // console.log("onTouchMove x ="+evt.stageX+" y="+evt.stageY+" touchID="+evt.touchPointID);
        // if(!this.startCollet||!this.isTouchBegin){
        //     return;
        // }
        if(!this.startCollet||!this.isTouchBegin){
            return;
        }
        this.moveHandler(evt.stageX,evt.stageY);
    }

    private onTouchCancel(evt:egret.TouchEvent){
        // console.log("onTouchCancel x ="+evt.stageX+" y="+evt.stageY);
    }

    private onTouchEnd(evt:egret.TouchEvent){
        // console.log("onTouchEnd x ="+evt.stageX+" y="+evt.stageY);
        if( evt.target instanceof eui.Button){
             return;
        }

        if(!this.startCollet||!this.isTouchBegin){
            return;
        }
        
        // console.log("onTouchEnd2 x ="+evt.stageX+" y="+evt.stageY);
        //如果没有经过移动，则当做旋转操作 经过移动操作，则当做move处理
        if(!this.haveMove){
            // console.log("onTouchEnd objChange");
            UserControl.getInstance().userMove(BlockControlType.Rotation,0,0);

        }else{
            this.moveHandler(evt.stageX,evt.stageY);
        }
        this.beginX = 0;
        this.beginY = 0;
        
    }


    private moveHandler(endX,endY){
        let delx = endX - this.beginX;
        let dely = endY - this.beginY;
        let type = 0;
        let absX = Math.abs(delx);
        let absY = Math.abs(dely);
        let maxDelx = this.xratio *3;
        if(absX<this.xratio&&absY<this.yratio){
            return;
        }

        if(absX*0.5>absY&&absX>=this.xratio){
            if(delx>0){
                type = BlockControlType.Right;
            }else{
                type = BlockControlType.Left;
            }
            if(delx>maxDelx){
                delx = maxDelx;
            }

            // this.beginX = endX;
            this.beginX = this.beginX+delx;
        }else{
            if(dely>0){
                type = BlockControlType.Down;
                this.beginY = endY;
            }
        }

        this.beginX = endX;
        this.beginY = endY;

        let posx = Math.floor(Math.abs(delx)/this.xratio);
        // let posy = Math.floor(Math.abs(dely)/this.yratio);
        let posy = Math.floor(absY);

        this.haveMove = true;
        UserControl.getInstance().userMove(type,posx,posy);
    }

    private startCollet = false;
    public colletMsg(isStart){
        this.startCollet = isStart;
    }

    private isTouchBegin = false;
    public touchEnd(){
        this.isTouchBegin = false;
    }
}