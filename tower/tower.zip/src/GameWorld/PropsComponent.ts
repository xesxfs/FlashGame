class PropsComponent extends eui.Component implements eui.UIComponent {
	public constructor() {
		super();
	}
	private taps: number = 80;
	private propsUI = [];
	private canUseItem = false;


	protected childrenCreated(): void {
		super.childrenCreated();
	}

	public startUse(){
		this.canUseItem = true;
		this.propsUI.forEach(element => {
			element.touchEnabled = true;
		});
	}

	public addProps(pcount: number, ccuse: number, ppId: PropsID) {
		let ppBtn = new PropsItemButton(pcount, ccuse, ppId);
		this.addChild(ppBtn);
		ppBtn.x = (this.numChildren - 1) * ppBtn.width + this.numChildren * this.taps;
		this.propsUI[ppId] = ppBtn;
	}
	public static PropsAction = "OnPropsAction";

	private mMgr:GameItemsManager = null;
	public setMgr(mgr:GameItemsManager){
		this.mMgr = mgr;
	}		
}



