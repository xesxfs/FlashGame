class BrickArrayComponent extends eui.Component {


	public constructor() {
		super();
	}

	private BrickArray: eui.Group;

	public childrenCreated() {
		if (GlobalClass.Game.isDebug) {
			return;
		}
		if (GlobalClass.Game.GameMode == 3) return;
		if (GlobalClass.CurrentStage.StageType == GameMode.jigsaw&&GlobalClass.Game.GameMode==1) {//只有单人玩法是有固定的序列
			GlobalClass.CurrentStage.BricksList.forEach(element => {
				let imgName = BlockFactory.getSourceByBlockType(element);
				let img = new eui.Image(imgName);
				// if (element == BlockType.I) {
				// 	img.scaleX = 0.9;
				// }
				img.scaleX = 0.7;
				img.scaleY = 0.7;
				this.BrickArray.addChild(img);
			});
		}

	}

	public reduce() {
		this.BrickArray.numChildren && this.BrickArray.removeChildAt(0);
	}

}

