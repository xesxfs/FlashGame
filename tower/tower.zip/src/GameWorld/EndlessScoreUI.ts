class EndlessScoreUI extends eui.Component implements eui.UIComponent {
	public constructor() {
		super();
	}

	private _score: number = 0;
	private scoreBitLab: eui.BitmapLabel;

	protected partAdded(partName: string, instance: any): void {
		super.partAdded(partName, instance);
	}


	protected childrenCreated(): void {
		super.childrenCreated();
	}

	public get score() {
		return this._score;
	}

	public set score(score: number) {
		this._score = score;
		this.scoreBitLab.text = this._score.toString();
	}

	public subScore(score: number = 1) {
		this.score -= score
	}

	public addScore(score: number = 1) {
		this.score += score;
	}


}