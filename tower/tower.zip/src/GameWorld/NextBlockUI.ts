class NextBlockUI extends eui.Component {
	public constructor() {
		super();
	}
	private showBlockImg: eui.Image;
	private nextBlockSprite;
	private blockNum:eui.BitmapLabel;


	protected childrenCreated() {
		this.blockNum.visible = false;
	}

	public showBlock(block: BlockType) {
		this.showBlockImg.visible = false;
		this.showBlockImg.source = BlockFactory.getSourceByBlockType(block);
		this.showBlockImg.visible = true;
		
	}

	public showBlockNum(num){
		this.blockNum.text = num +"";
		this.blockNum.visible = true;
	}

	public showBlank(){
		// this.blockNum.text = "";
		this.blockNum.visible = false;
		this.showBlockImg.visible = false;
	}

	public blink(){
		egret.Tween.get(this.blockNum, { loop: true }).to({ scaleY: 1.2,scaleX: 1.2 }, 500).to({ scaleY: 1,scaleX: 1 }, 500);
	}

	public stopBlink(){
		egret.Tween.removeTweens(this.blockNum);
	}
}