class CountDownUI extends eui.Component {
	public constructor() {
		super();
		this.skinName = "CountDownUISkin";
	}

	public childrenCreated() {
	}

	private showTimeBLab: eui.BitmapLabel;
	private cdTimer: DateTimer;
	private netTimer: NetTimer;//如果是多人对战，则使用网络帧计时
	public limitTime: number = 60 * 13 * 1000 + 1000 * 6;
	private timeOutCall: Function;
	private thisObj: any;
	private mTarget: number;
	/**倒计时每毫秒移动的距离 */
	private cdPerDistance: number;

	private haveStart = false;

	public initTime(mSecond: number, target: number) {
		let timeStr = CommonFuc.formatTime(mSecond);
		this.showTimeBLab.text = timeStr;
		this.limitTime = mSecond;
		this.mTarget = target;
		this.cdPerDistance = (this.y - this.mTarget) / this.limitTime;
	}

	public setTimeOutCall(call: Function, thisObj: any) {
		this.timeOutCall = call;
		this.thisObj = thisObj;
	}

	/***开始计时 time 毫秒 */
	public startCoundDown() {
		if (GlobalClass.Game.GameMode == 1) {//单人使用本地时间计时
			this.cdTimer = new DateTimer(100, (this.limitTime / 100) >> 0);
			let timeStr = CommonFuc.formatTime(this.limitTime);
			this.showTimeBLab.text = timeStr;
			this.cdTimer.addEventListener(egret.TimerEvent.TIMER, this.onTimerHandler, this);
			this.cdTimer.addEventListener(egret.TimerEvent.TIMER_COMPLETE, this.onTimerComplete, this);
			this.cdTimer.reset();
			this.cdTimer.start();
		} else if (GlobalClass.Game.GameMode == 2) {
			if (this.netTimer) {
				this.netTimer.stop();
				this.netTimer = null;
			}
			this.netTimer = new NetTimer(100, (this.limitTime / 100) >> 0, this.onTimerComplete, this, this.onTimerHandler);
			this.netTimer.start();
		}
		this.haveStart = true;
		this.startCdMove();
	}

	private onTimerHandler(e: egret.TimerEvent) {
		if (GlobalClass.Game.GameMode == 1) {
			this.limitTime -= 100;

		} else if (GlobalClass.Game.GameMode == 2) {
			this.limitTime -= 1000 / 60;
		}
		if (this.limitTime < 0) {
			this.limitTime = 0;
		}
		let timeStr = CommonFuc.formatTime(this.limitTime);
		this.showTimeBLab.text = timeStr;
	}

	private onTimerComplete(e: egret.TimerEvent) {

		this.limitTime = 0;
		let timeStr = CommonFuc.formatTime(this.limitTime);
		this.showTimeBLab.text = timeStr;

		if (GlobalClass.Game.GameMode == 1) {
			this.timeOutCall && (this.timeOutCall.call(this.thisObj));
		} else if (GlobalClass.Game.GameMode == 2) {
			this.netTimer = null;
			this.timeOutCall && (this.timeOutCall.call(this.thisObj));
		}
	}

	public pause() {
		if (!this.cdTimer) return;
		this.cdTimer.stop();
		this.cdTimer.removeEventListener(egret.TimerEvent.TIMER, this.onTimerHandler, this);
		this.cdTimer.removeEventListener(egret.TimerEvent.TIMER_COMPLETE, this.onTimerComplete, this);
		this.cdTimer = null;
		this.stopCdMove();
	}

	public resume() {
		this.startCoundDown();
	}

	public addTime(subTime: number) {
		this.limitTime += subTime;
		this.pause();
		this.y += (this.cdPerDistance * subTime);
		this.initTime(this.limitTime, this.mTarget);
	}

	public startCdMove() {
		this.stopCdMove();
		egret.Tween.get(this).to({ y: this.mTarget }, this.limitTime);
	}

	public stopCdMove() {
		egret.Tween.removeTweens(this);
	}

	public onUpdate() {
		if (GlobalClass.Game.GameMode == 2) {//多人要检测网络帧是否连续到达，不到达则要停止时间线的上移
			let leftDistance = this.cdPerDistance * this.limitTime;
			if (leftDistance > this.y - this.mTarget) {
				this.stopCdMove();
			} else {
				if (this.haveStart) {
					this.startCdMove();
				}
			}
		}
	}
}