/**
 * 无尽生存
 * 
 */
class EndlessSurvivalGame extends GameComponent {
	public constructor() {
		super();
	}

	protected partAdded(partName: string, instance: any): void {
		super.partAdded(partName, instance);
	}


	protected childrenCreated(): void {
		super.childrenCreated();
		this.start();
	}


	private initView() {
		this.scoreUI.visible = true;
		this.skillComponent.visible = true;
	}

	private canMinusHeart = true;//当前是否可以减血
	private npcTimer: egret.Timer;
	private pSkillCount: number = 1;
	private perPlaySkillTarget: number = 20;
	private sSkillCount: number = 1;
	private randPlaySkills = [SkillType.AddBlood, SkillType.Cement, SkillType.Vine,]
	private randSysSkils = [SkillType.SpeedUp, SkillType.Locked, SkillType.Grow, SkillType.Disorder, SkillType.Transform, SkillType.Ice]
	public start() {
		this.initTimer();
		this.initView();
		this.initSkill();
	}
	/********************************************************************************************* ***************/

	private initTimer() {
		this.npcTimer = new egret.Timer(1000, 1);
		this.npcTimer.addEventListener(egret.TimerEvent.TIMER_COMPLETE, () => {
			this.canMinusHeart = true;
		}, this);
	}


	protected onCreateTet() {
		super.onCreateTet();
	}

	protected onPhysicsUpdate() {
		this.checkAndAddSkill();
	}

	private initSkill() {
		this.addRandPlaySkill(this.pSkillCount * this.perPlaySkillTarget);
		this.addRandSysSkill(5);
	}

	public reBorn() {
		this.getNPC().addHeart();
		this.getNPC().addHeart();
		this.getNPC().addHeart();
		this.gameIsOver = false;
	}

	/**添加随机主动技能 */
	private addRandPlaySkill(blockHeight: number) {
		blockHeight = 1280 - blockHeight * 40;
		this.pSkillCount++;
		let temp = this.randPlaySkills.concat();
		let firstSkillId = Math.floor(Math.random() * temp.length) >> 0;
		temp.splice(firstSkillId, 1);
		firstSkillId = this.randPlaySkills[firstSkillId];
		let secondSkillId = Math.floor(Math.random() * temp.length) >> 0;
		secondSkillId = temp[secondSkillId];
		this.skillMgr.addPlaySkill([firstSkillId, secondSkillId], [SkillCategory.Player, SkillCategory.Player], blockHeight);
	}
	/**添加随机系统技能 */
	private addRandSysSkill(blockNo: number) {
		this.sSkillCount++;
		let skill = Math.floor(Math.random() * this.randSysSkils.length);
		skill = this.randSysSkils[skill];
		this.skillMgr.addSysSKill([GlobalClass.getSkillNOByType(skill)], [SkillCategory.Systems], SkillTriger.BlockNO, blockNo);
	}

	protected createPlatForm() {
		let vec = [
			[-2.5, 0], [-1.5, 0], [-.5, 0], [2.5, 0], [1.5, 0], [.5, 0],
			[-2.5, -1], [-1.5, -1], [2.5, -1], [1.5, -1], [.5, -1],
			[-2.5, 1], [-1.5, 1], [-.5, 1], [2.5, 1], [1.5, 1], [.5, 1]
		];

		let vec2s: Array<Box2D.Common.Math.b2Vec2> = [];
		for (let i = 0; i < vec.length; i++) {
			let pos = vec[i];
			let temvec: Box2D.Common.Math.b2Vec2 = new Box2D.Common.Math.b2Vec2(pos[0], pos[1]);
			vec2s.push(temvec);
		}
		let posx = 18;
		let posy = 64 - CommonFuc.getArrayYLength(vec) - 6 + this.getPlatformYShifting() * 2 / GlobalClass.GameInfoForConfig.blockUnitWidth;
		this.platform = Game.GameWorld.PhysicsWorld.createPlatForm(this.m_world, posx, posy, vec2s);
		this.platFormHeight = CommonFuc.getArrayYLength(vec) + 6;
	}

	protected haveNextBrick(): boolean {
		return true;
	}

	/**检查是否要添加技能 */
	private checkAndAddSkill() {
		if (this.skillMgr.leftPlayerSKillCount() <= 0) {
			this.addRandPlaySkill(this.pSkillCount * this.perPlaySkillTarget)
		}

		if (this.skillMgr.leftSystemSKillCount() <= 0) {
			this.addRandSysSkill(this.curBlockNum + this.scoreMatchSkill());
		}

	}
	/**分数配对技能 */
	private scoreMatchSkill(): number {
		let score = this.scoreUI.score;
		let matchId = 0;
		let matchRangge = [[0, 5], [6, 10], [11, 15], [16, NaN]]
		// let match = [1, 1, 1, 1];
		let match = [50, 35, 25, 25]
		for (let i = 0; i < matchRangge.length; i++) {
			let min = matchRangge[i][0];
			let max = matchRangge[i][1];
			if (this.isInRange(score, min, max)) {
				matchId = i;
				break;
			}
		}

		return match[matchId];
	}

	private isInRange(vale: number, min: number, max?: number): boolean {
		if (!max) return vale >= min;
		return vale >= min && vale <= max;
	}

	protected onFall(body: Box2D.Dynamics.b2Body) {
		if (this.canMinusHeart) {
			this.canMinusHeart = false;
			this.NPCMinusHeart();
		}
		this.npcTimer.reset();
		this.npcTimer.start();
		let block = body.GetUserData() as Block;
		block && block.isContacted && this.scoreUI.subScore();
	}

	protected onDead() {
		this.npcTimer.stop();
		this.onResult(false);
	}

	protected onCurTetContact() {
		this.curTet && !this.curTet.isContacted && this.scoreUI.addScore();
	}

	protected getPlatformXShifting(): number {
		return 0;
	}

	protected getPlatformYShifting(): number {
		return -15;
	}



}