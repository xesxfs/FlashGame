class RayCheck extends eui.Component {
	public input: Box2D.Collision.b2RayCastInput;
	public output: Box2D.Collision.b2RayCastOutput;

	public constructor() {
		super();
		this.input = new Box2D.Collision.b2RayCastInput();
		this.output = new Box2D.Collision.b2RayCastOutput();
		// eui.Binding.bindHandler(this, ["x"], this.resetRay, this);
		// eui.Binding.bindHandler(this, ["y"], this.resetRay, this);
	}


	/***组件位置有修改,需要重新调用改方法 */
	public resetRay() {

		let factor = GlobalClass.GameInfoForConfig.factor;
		let start = new Box2D.Common.Math.b2Vec2();
		start.x = this.x;
		start.y = this.y + this.height;

		let end = new Box2D.Common.Math.b2Vec2();
		end.x = this.width;
		end.y = this.y + this.height;

		// console.log("resetRay~~~~~~~", start.x, start.y, end.x, end.y)

		start.Multiply(1 / factor)
		end.Multiply(1 / factor);

		this.input.p1 = start;
		this.input.p2 = end;

	}

	public check(higest: number): boolean {
		if (higest < this.y) {
			return true
		}
		return false;
	}

}