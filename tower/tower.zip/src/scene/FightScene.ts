/**
 *
 * @author 
 *
 */
class FightScene extends KFScene{
	public constructor() {
    	super();
	}
	
	protected init(){
        this.TAG = "LoginScene";
	}
	
    public onAddToStage() {
		super.onAddToStage();
		KFControllerMgr.getCtl(PanelName.GamePanel).show();
    }
}
