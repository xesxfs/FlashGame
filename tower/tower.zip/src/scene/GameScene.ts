/**
 *
 * @author 
 *
 */
class GameScene extends KFScene{
	public constructor() {
    	super();
	}
	
	protected init(){		
        this.TAG = "GameScene";
	}
	
    public onAddToStage() {
		super.onAddToStage();
		if(GlobalClass.Game.GameMode==1){
			KFControllerMgr.getCtl(PanelName.LevelChoosePanel).show();
		}else if(GlobalClass.Game.GameMode==2){
			KFControllerMgr.getCtl(PanelName.RoleChoosePanel).show();
		}else if(GlobalClass.Game.GameMode==3){
			KFControllerMgr.getCtl(PanelName.EndlessPanel).show();
		}
    }
}
