/**
 *
 * @author 
 *
 */
class AwakeScene extends KFScene{
	public constructor() {
    	super();
	}
	
	protected init(){
        this.TAG = "StartScene";
	}
	
    public onAddToStage() {
		super.onAddToStage();
        KFControllerMgr.getCtl(PanelName.StartPanel).show();
    }
}
