
class DeFaultSDK extends KFChannel{
	 private timer:egret.Timer;

	constructor() {
		super();
		this.AutoLogin = false;
	}

    protected sdkSerial():string{
        if(DeviceUtils.IsAndroid)
        {
            return "000049-101-158";
        }else if(DeviceUtils.IsIos){
            return "000050-101-158";
        }else{
            return "000049-101-158";
        }
	}
    
    protected Login(data){
	}

	protected Pay(data){
	}

	 private timerComFunc(){
    }

}
