
class WanBaSDK extends KFChannel{

    private WanBaAppid = "1106159363";

    private openid ="F7A935CD3D614CD84392AB05819D2190";
    private openKey = "EA6941A923AE8793EC9457C8F85E3DE7";
    private platform = "1";
    private data ;
    //{"appid":"1106159363","openid":"F7A935CD3D614CD84392AB05819D2190","openkey":"EA6941A923AE8793EC9457C8F85E3DE7"}}
	constructor() {
		super();
        if(CommonFuc.getWanbaPlatform()=="-1"){
            this.AutoLogin = false;
        }else{
            this.AutoLogin = true;
        }
        this.parsePayInfoText();
	}

    public parsePayInfoText(){
        RES.addEventListener( RES.ResourceEvent.CONFIG_COMPLETE, this.onConfigComplete, this ); 
        RES.addEventListener( RES.ResourceEvent.CONFIG_LOAD_ERROR, this.onConfigLoadErr, this ); 
        RES.getResByUrl("resource/channelConfig/wanba/payInfo.json",this.onConfigComplete,this,RES.ResourceItem.TYPE_JSON);
    }


    private onConfigComplete(event:RES.ResourceEvent):void {
        this.data = event;
    }

    private onConfigLoadErr(event:RES.ResourceEvent):void {
        console.log("onConfigLoadErr");
    }

	protected sdkSerial():string{
        if(DeviceUtils.IsAndroid)
        {
            return "000060-101-158";
        }else if(DeviceUtils.IsIos){
            return "000060-101-158";
        }else{
            return "000060-101-158";
        }
	}
    
    protected Login(data){
		CommonFuc.getOpenKey((jsObj)=>{
            console.log("getOpenKey="+JSON.stringify(jsObj));
             if(jsObj ["code"] == 0){//登录成功
                 let appid = jsObj["data"]["appid"];
                 let openid = jsObj["data"]["openid"];
                 let openkey = jsObj["data"]["openkey"];
                 console.log("appid="+appid);
                 console.log("openid="+openid);
                 console.log("openkey="+openkey);
                 GlobalClass.UserInfo.openid = openid;
                 this.openid = openid;
                 this.openKey = openkey;
                 this.platform = CommonFuc.getWanbaPlatform();
                 var Through = {openid: openid,nickename:appid,accesstoken:openkey};
                 var jobj = {Code: 200,ErrorStr:"登录成功",Through:JSON.stringify(Through)};
                 DeviceUtils.LoginMsg3rd(JSON.stringify(jobj));
            }else{
                KFControllerMgr.showTips("登录失败");
            }
        });
	}

	protected Pay(jsData){
        let data = jsData["data"];
        var jd = JSON.parse(data);
        if(jd["Code"]!="200"){
            KFControllerMgr.showTips(LocalizationMgr.getText("支付失败"));
            return;
        }
        let mes = jd["Value"] ;
        let orderNO = mes["OrderNo"];
        let notifyURL = mes["NotifyUrl"];
        let PID = mes["ProID"]; 
        let score = Math.floor(Number(mes["OrderMoney"])*10) ;
        let itemID = this.data[PID];
        
        //
        // NetEventMgr.getInstance().clientMsg(MsgID.Client.PayOver,"1");
        // let js = {
            // openid:this.openid,
            // zoneid:this.platform ,
            // billno:orderNO,
            // itemid:itemID,
            // openkey:this.openKey,
            // count:"1",
        //     qua:score+""
        // };
        // console.log("wanbajs="+JSON.stringify(js));
        // this.notifyGS(notifyURL,js);

		window['wanbaPay'](score,(result)=>{
			if(result==1){//succ
				NetEventMgr.getInstance().clientMsg(MsgID.CLIENT.PayOver,"1");
                let js = {
                        openid:this.openid,
                        zoneid:this.platform ,
                        billno:orderNO,
                        itemid:itemID,
                        openkey:this.openKey,
                        count:"1",
                        qua:score+""
                    };
                this.notifyGS(notifyURL,js);
			}else if(result==2){//cancel
				NetEventMgr.getInstance().clientMsg(MsgID.CLIENT.PayOver,"6001");
			}else{//fail
				NetEventMgr.getInstance().clientMsg(MsgID.CLIENT.PayOver,"0");
			}
		});
	}

    private notifyGS(url,postData){
         var request = new egret.HttpRequest();
        request.responseType = egret.HttpResponseType.TEXT;
        //设置为 POST 请求
        console.log("url="+url);
        var bodyContent = "";
        for(let key in postData){
            bodyContent+= key+"="+postData[key]+"&";
        }
        let body= bodyContent.substr(0,bodyContent.length-1);
        var request = new egret.HttpRequest();
        request.responseType = egret.HttpResponseType.TEXT;
        request.open(url,egret.HttpMethod.POST);
        //设置响应头
        request.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
        //发送参数
        request.send(body);

        request.addEventListener(egret.IOErrorEvent.IO_ERROR,(event:egret.IOErrorEvent) => {
            console.log("ServiceWS post error : "+event.data);
        },this);
        
        request.addEventListener(egret.Event.COMPLETE,(event: egret.IOErrorEvent)=>{
            var request = <egret.HttpRequest>event.currentTarget;
            console.log("post data : "+(<string>request.response));
            if(request.response==null||request.response==""){
                console.log("no result");
                return;
            }
            try{

            }catch(err){
            }
        },this);
    }
}
