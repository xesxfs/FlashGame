
class NativeSDK extends KFChannel{
	 private timer:egret.Timer;

	constructor() {
		super();
		this.AutoLogin = false;
	}

    protected sdkSerial():string{
        return GlobalClass.GameInfoForConfig.UniqueSerial;
	}
    
    protected Login(js){
        let data = JSON.stringify(js);
        //  PluginEvent.executePluginsEvents(data);
	}

	protected Pay(js){
        // let data = JSON.stringify(js);
        // PluginEvent.executePluginsEvents(data);
	}


}
