/**
 *
 * @author 
 *
 */
class KFChannel {
	protected AutoLogin:boolean = false;
	constructor() {
	}

	protected Login(data) {

	}

	protected Pay(data) {

	}


	protected exit() {

	}

	protected sdkSerial():string{
		return "";
	}
	

	public SDKPay(data){
		// let js = {data:data,payType:payType,PID:PID};
		// this.Pay(js);
		this.Pay(data);
	}

	public SDKLogin(data){
		this.Login(data);
	}

	public SDKExit(){
		this.exit();
	}
	
	// private index = 0;
	public isAutoLogin():boolean{
		// if(this.index<2){
		// 	this.index++;
		// 	return false;
		// }
		return this.AutoLogin;
	}

	public getUniqueSerial():string{
		return this.sdkSerial();
	}
}
