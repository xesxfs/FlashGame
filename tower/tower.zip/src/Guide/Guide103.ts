class Guide103 extends eui.Component {
	public storyBox: GuideStoryBox;
	public storyNpc: eui.Image;
	private typeWrite: Typewriting;
	private story1: string = `左右滑动，移动砖块`;
	private sotry2: string = `点击空白位置，旋转砖块`;
	private sotry3: string = `按住屏幕下拉，使砖块加速下落`;
	public leftArrow: eui.Image;
	public rightArrow: eui.Image;
	public downArrow: eui.Image;
	public finger: eui.Image;
	public block: eui.Image;

	public callFunc: Function;


	public constructor() {
		super();
		this.percentWidth = 100;
		this.percentHeight = 100;
		this.skinName = "Guide103Skin"
		this.typeWrite = new Typewriting();
	}
	public childrenCreated() {
		this.storyBox.setArrow(StoryBoxArrow.RDown);
		this.storyBox.visible = false;
		this.leftArrow.visible = false;
		this.rightArrow.visible = false;
		this.downArrow.visible = false;
		this.block.visible = true;
		this.finger.visible = false;
		this.focus();
		this.loadFingerAni();
	}

	public startStory() {
		let originX = this.block.x;
		let originY = this.block.y;
		let beginX = 0;
		let beginY = 0;
		let fingerX = this.finger.x;
		let fingerY = this.finger.y;

		this.storyBox.visible = true;
		var _self_ = this;
		this.typeWrite.init(this.story1, this.storyBox.storyLab);
		let isBegin: boolean = false;
		let isMove: boolean = false;
		let curCount = 0;
		let touchCount = 0;
		let isMoveDown = false;
		this.addEventListener("touchMove", () => { isMove = true }, this);


		var step2Click = function () {
			_self_.addEventListener("touchBegin", touchBegin, _self_);
			_self_.addEventListener("touchEnd", touchEnd, _self_);
			touchCount = 1;
			_self_.addEventListener("touchMove", touchMove, _self_);
			_self_.playFinger(true);

		}

		var step2 = function () {
			_self_.typeWrite.init(_self_.sotry2, _self_.storyBox.storyLab);
			_self_.typeWrite.endCall = step3Click
			_self_.typeWrite.start();
			touchCount = 1;

			_self_.removeEventListener("touchBegin", touchBegin, _self_);
			_self_.removeEventListener("touchEnd", touchEnd, _self_);
			_self_.removeEventListener("touchMove", touchMove, _self_);
			_self_.block.x = originX;
			_self_.stopFinger();
			_self_.finger.x = fingerX;
			_self_.finger.y = fingerY;
			_self_.finger.visible = false;
			_self_.initAni();
		}

		var step3Click = function () {
			_self_.addEventListener("touchTap", touchTap, _self_);
		}

		var step3 = function () {
			_self_.removeEventListener("touchTap", touchTap, _self_);
			_self_.typeWrite.init(_self_.sotry3, _self_.storyBox.storyLab);
			_self_.typeWrite.endCall = step4Click
			_self_.typeWrite.start();
			_self_.stopHandAni();
		}

		var step4Click = function () {
			touchCount = 1;
			_self_.addEventListener("touchBegin", touchBegin, _self_);
			_self_.addEventListener("touchEnd", touchEnd, _self_);
			_self_.addEventListener("touchMove", touchMove, _self_);
			_self_.playFinger(false);
			isMoveDown = true;
		}

		var step4 = function () {
			_self_.removeEventListener("touchBegin", touchBegin, _self_);
			_self_.removeEventListener("touchEnd", touchEnd, _self_);
			_self_.removeEventListener("touchMove", touchMove, _self_);
			_self_.addEventListener("touchTap", () => {
				_self_.parent.removeChild(_self_);
				_self_.callFunc && _self_.callFunc();
			}, _self_);
		}

		var touchBegin = function (e: egret.TouchEvent) {
			isMove = false;
			isBegin = true;
			beginX = e.localX;
			beginY = e.localY;
		}

		var touchEnd = function (e: egret.TouchEvent) {
			if (isBegin && isMove) {
				curCount++
				isBegin = false;
				isMove = false;
			}
			if (curCount >= 1 && !isMoveDown) {
				step2();
				curCount = 0;
			}

			if (curCount >= 1 && isMoveDown) {
				step4();
				curCount = 0;
			}
		}

		var touchTap = function (e: egret.TouchEvent) {
			curCount++;
			_self_.block.rotation += 90;
			if (curCount >= 2) {
				curCount = 0;
				step3();
				_self_.block.rotation = 0;
			}
		}

		var touchMove = function (e: egret.TouchEvent) {
			if (!isMoveDown) {
				let moveX = 2;
				if (beginX > e.localX) { moveX *= -1; }
				_self_.block.x += moveX;
			} else {
				let moveY = 2;
				if (e.localY > beginY)
					_self_.block.y += moveY;
			}
			beginX = e.localX;
			beginY = e.localY;
		}

		this.typeWrite.endCall = step2Click;
		this.typeWrite.start();
	}


	private playFinger(isLR: boolean) {
		egret.Tween.removeTweens(this.finger);
		this.finger.visible = true;
		let originX = this.finger.x;
		let originY = this.finger.y;
		if (isLR) {
			this.leftArrow.visible = true;
			this.rightArrow.visible = true;
			egret.Tween.get(this.finger, { loop: true }).
				to({ x: originX + this.rightArrow.width }, 800).to({ x: originX }, 0).
				to({ x: originX - this.rightArrow.width }, 800).to({ x: originX }, 0);
		} else {
			this.downArrow.visible = true;
			egret.Tween.get(this.finger, { loop: true }).
				to({ y: originY + this.downArrow.height }, 800).to({ y: originY }, 0);
		}
	}

	private stopFinger() {
		egret.Tween.removeTweens(this.finger);
		this.leftArrow.visible = false;
		this.rightArrow.visible = false;
		this.downArrow.visible = false;
	}

	private stopHandAni() {
		egret.Tween.removeTweens(this.finger);
		if (this.fingerAni) {
			AnimationMgr.getInstance().clenSkeleton(this.fingerAni);
			this.fingerAni = null;
		}
	}

	private fingerAni;
	private Factory;
	private loadFingerAni() {
		RES.removeEventListener(RES.ResourceEvent.GROUP_COMPLETE, this.loadFingerAni, this);
		let skeName = "finger_ske_json";
		let texName = "finger_tex_json";
		let pngName = "finger_tex_png";
		this.Factory = new dragonBones.EgretFactory();
		this.Factory.addDragonBonesData(dragonBones.DataParser.parseDragonBonesData(RES.getRes(skeName)));
		this.Factory.addTextureAtlasData(new dragonBones.EgretTextureAtlas(RES.getRes(pngName), RES.getRes(texName)));
	}

	private initAni() {
		this.fingerAni = this.Factory.buildArmature("Armature");
		this.fingerAni.animation.play();
		dragonBones.WorldClock.clock.add(this.fingerAni);
		this.fingerAni.animation.timeScale = 0.5;
		var clip = this.fingerAni.display;
		this.addChild(clip);
		clip.x = this.finger.x + 65;
		clip.y = this.finger.y + 50;
	}


	private focus() {
		let bg = Guide.drawBg();
		let r = 1280 / 2;
		let circle = Guide.drawCircle(0, 0, r);
		circle.x = this.block.x + 50;
		circle.y = this.block.y + 60;
		circle.anchorOffsetX = circle.x;
		circle.anchorOffsetY = circle.y;
		let rw = (this.block.width >> 1) + 30;
		let scale = rw / r;
		let drawt = Guide.drawTexture(bg, circle);
		this.addChildAt(drawt, 0);
		egret.Tween.get(circle, {
			onChange: () => {
				drawt = Guide.drawTexture(bg, circle);
				this.removeChildAt(0);
				this.addChildAt(drawt, 0);
			}, onChangeObj: this
		}).to({ scaleX: scale, scaleY: scale }, 1000).call(() => { this.startStory(); });
	}
}