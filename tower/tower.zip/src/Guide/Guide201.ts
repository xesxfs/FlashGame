class Guide201 extends eui.Component {
	public storyBox: GuideStoryBox;
	public storyNpc: eui.Image;
	private typeWrite: Typewriting;
	private story1: string = `看来你已经掌握了所有诀窍，现在要开始真正的考验了！`;
	private sotry2: string = `注意！目前是垒得高模式，将考验你的速度`;
	private sotry3: string = `你需要在规定时间内`;
	private story4: string = `达到终点线`;
	public leftArrow: eui.Image;
	public rightArrow: eui.Image;
	public downArrow: eui.Image;
	public finger: eui.Image;
	public callFunc: Function;
	public localGame: GameComponent;

	public constructor() {
		super();
		this.percentWidth = 100;
		this.percentHeight = 100;
		this.skinName = "Guide201Skin"
		this.typeWrite = new Typewriting();
	}
	public childrenCreated() {
		this.addChildAt(Guide.drawBg(), 0);
		this.storyBox.setArrow(StoryBoxArrow.LDown);
		this.startStory();
	}

	public startStory() {
		var _self_ = this;
		this.typeWrite.init(this.story1, this.storyBox.storyLab);

		var step2Click = function () {
			_self_.addEventListener("touchTap", step2, _self_);
		}
		var step2 = function () {
			_self_.typeWrite.init(_self_.sotry2, _self_.storyBox.storyLab);
			_self_.typeWrite.endCall = step3Click
			_self_.typeWrite.start();
			_self_.removeEventListener("touchTap", step2, _self_);
		}
		var step3Click = function () {
			_self_.addEventListener("touchTap", step3, _self_);
		}
		var step3 = function () {
			_self_.removeEventListener("touchTap", step3, _self_);

			_self_.storyNpc.visible = false;
			_self_.focus(1, step4Click);

			_self_.typeWrite.init(_self_.sotry3, _self_.storyBox.storyLab);
			_self_.typeWrite.endCall = null
			_self_.typeWrite.start();
		}

		var step4Click = function () {
			_self_.addEventListener("touchTap", step4, _self_);
		}
		var step4 = function () {
			_self_.removeEventListener("touchTap", step4, _self_);
			_self_.focus(2, end);
			_self_.typeWrite.init(_self_.story4, _self_.storyBox.storyLab);
			_self_.typeWrite.endCall = null
			_self_.typeWrite.start();
		}

		var end = function () {
			_self_.addEventListener("touchTap", () => {
				_self_.parent.removeChild(_self_);
				_self_.callFunc && _self_.callFunc();
			}, _self_);
		}

		this.typeWrite.endCall = step2Click;
		this.typeWrite.start();
	}

	private bg: egret.Sprite;
	public focus(step: number, callFunc?: Function) {
		let bg: egret.Sprite;
		let rect: egret.Sprite;
		let scale;
		let drawt;
		if (step == 1) {
			this.bg = bg = Guide.drawBg();
			rect = Guide.drawRoundRect(0, 0, 720, 1280);
			let cw = this.localGame.coundDownUI.height + 20;
			let cy = this.localGame.coundDownUI.y - 30;
			scale = cw / 1280;
			console.log("cw: ", cw, "  cy: ", cy);
			drawt = Guide.drawTexture(bg, rect);
			this.storyBox.y = cy - 200;
			egret.Tween.get(rect, {
				onChange: () => {
					drawt = Guide.drawTexture(bg, rect);
					this.removeChildAt(0);
					this.addChildAt(drawt, 0);
				}, onChangeObj: this
			}).wait(1).to({ scaleY: scale, y: cy }, 800).call(() => {
				callFunc && callFunc();
			});


		} else if (step == 2) {

			bg = this.bg;
			rect = this.bg.getChildAt(0) as egret.Sprite;
			scale = 130 / 1280;
			let ry = this.localGame.rayCheck.y - 40;
			this.storyBox.y = ry - 200;
			drawt = Guide.drawTexture(bg, rect);
			egret.Tween.get(rect, {
				onChange: () => {
					drawt = Guide.drawTexture(bg, rect);
					this.removeChildAt(0);
					this.addChildAt(drawt, 0);
				}, onChangeObj: this
			}).wait(1).to({ y: ry }, 200).call(() => {
				callFunc && callFunc();
			});

		}

	}


}