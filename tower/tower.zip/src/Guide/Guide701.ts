class Guide701 extends eui.Component {
	public storyBox: GuideStoryBox;
	private typeWrite: Typewriting;
	private story1: string = `这里是你需要用完的所有砖块。`;
	private story2: string = `砖块堆砌千万不要碰到激光线。`;
	public callBack: Function;
	public localGame: GameComponent;
	public constructor() {
		super();
				this.percentWidth = 100;
		this.percentHeight = 100;
		this.skinName = "Guide701Skin"
		this.typeWrite = new Typewriting();
	}
	public childrenCreated() {
		this.storyBox.setArrow(StoryBoxArrow.LDown);
		this.storyBox.visible = false;

		this.startStory();
	}

	public startStory() {
		var _self_ = this;
		this.typeWrite.init(this.story1, this.storyBox.storyLab);
		var step2Click = function () {
			_self_.addEventListener("touchTap", step2, _self_);
		}
		var step2 = function () {
			_self_.removeEventListener("touchTap", step2, _self_);
			_self_.focus2(end);
			_self_.typeWrite.init(_self_.story2, _self_.storyBox.storyLab);
			_self_.typeWrite.endCall = null;
			_self_.typeWrite.start();

		}
		var step1 = function () {
			_self_.typeWrite.endCall = step2Click;
			_self_.typeWrite.start();
			_self_.storyBox.visible = true;
		}

		var end = function () {
			_self_.addEventListener("touchTap", () => {
				_self_.parent.removeChild(_self_);
				_self_.callBack && _self_.callBack();
			}, _self_);
		}
		this.focus1(step1);
	}


	public focus1(callFunc?: Function) {
		let bg: egret.Sprite;
		let rect: egret.Sprite;
		let drawt;
		bg = Guide.drawBg();
		rect = Guide.drawRoundRect(0, 0, 720, 1280);
		rect.y = 540;
		rect.anchorOffsetY = rect.y;
		let scaley = 730 / 1280;
		let scalex = 200 / 720;
		drawt = Guide.drawTexture(bg, rect);
		this.addChildAt(drawt, 0);
		egret.Tween.get(rect, {
			onChange: () => {
				drawt = Guide.drawTexture(bg, rect);
				this.removeChildAt(0);
				this.addChildAt(drawt, 0);
			}, onChangeObj: this
		}).wait(1).to({ scaleY: scaley, scaleX: scalex }, 1000).call(() => {
			callFunc && callFunc();
		});
	}



	public focus2(callFunc?: Function) {
		let ly = this.localGame.laserShow.y
		this.storyBox.y = ly - 200;
		let bg: egret.Sprite;
		let rect: egret.Sprite;
		let drawt;
		bg = Guide.drawBg();
		rect = Guide.drawRoundRect(0, 0, 720, 1280);
		rect.y = ly;
		rect.anchorOffsetY = rect.y;
		let scaley = 150 / 1280;

		drawt = Guide.drawTexture(bg, rect);
		this.addChildAt(drawt, 0);
		egret.Tween.get(rect, {
			onChange: () => {
				drawt = Guide.drawTexture(bg, rect);
				this.removeChildAt(0);
				this.addChildAt(drawt, 0);
			}, onChangeObj: this
		}).wait(1).to({ scaleY: scaley }, 1000).call(() => {
			callFunc && callFunc();
		});
	}
}