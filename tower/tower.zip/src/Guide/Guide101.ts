class Guide101 extends eui.Component {
	public storyBox: GuideStoryBox;
	public storyNpc: eui.Image;
	private typeWrite: Typewriting;
	private story1: string = `欢迎加入星际联盟舰队，我们将为联盟的子民寻找新的生机。`;
	private sotry2: string = `首先，你必须学会联盟最先进的方块建筑技术`;
	public callBack: Function;
	public constructor() {
		super();
		this.percentWidth = 100;
		this.percentHeight = 100;
		this.skinName = "Guide101Skin"
		this.typeWrite = new Typewriting();
	}
	public childrenCreated() {
		// this.storyBox.lbg.visible = true;
		// this.storyBox.rbg.visible = false;
		this.storyBox.setArrow(StoryBoxArrow.LDown);
		this.startStory();
	}

	public startStory() {
		var _self_ = this;
		this.typeWrite.init(this.story1, this.storyBox.storyLab);

		var step2Click = function () {
			_self_.addEventListener("touchTap", step2, _self_);
		}
		var step2 = function () {
			_self_.typeWrite.init(_self_.sotry2, _self_.storyBox.storyLab);
			_self_.typeWrite.endCall = step3Click
			_self_.typeWrite.start();
			_self_.removeEventListener("touchTap", step2, _self_);
		}
		var step3Click = function () {
			_self_.addEventListener("touchTap", step3, _self_);
		}
		var step3 = function () {
			_self_.removeEventListener("touchTap", step3, _self_);
			_self_.parent.removeChild(_self_);
			_self_.callBack && _self_.callBack();
		}

		this.typeWrite.endCall = step2Click;
		this.typeWrite.start();
	}
}