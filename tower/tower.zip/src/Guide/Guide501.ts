class Guide501 extends eui.Component {
	public storyBox: GuideStoryBox;
	private typeWrite: Typewriting;
	private story1: string = `你只有3次机会。`;
	public callBack: Function;
	public constructor() {
		super();
				this.percentWidth = 100;
		this.percentHeight = 100;
		this.skinName = "Guide501Skin"
		this.typeWrite = new Typewriting();
	}
	public childrenCreated() {
		this.storyBox.setArrow(StoryBoxArrow.RUp);
		this.storyBox.visible = false;

		this.startStory();
	}

	public startStory() {
		var _self_ = this;
		this.typeWrite.init(this.story1, this.storyBox.storyLab);
		var step2Click = function () {
			_self_.addEventListener("touchTap", step2, _self_);
		}
		var step2 = function () {
			_self_.removeEventListener("touchTap", step2, _self_);
			_self_.parent.removeChild(_self_);
			_self_.callBack && _self_.callBack();
		}
		var step1 = function () {
			_self_.typeWrite.endCall = step2Click;
			_self_.typeWrite.start();
			_self_.storyBox.visible = true;
		}
		this.focus(step1);
	}


	public focus(callFunc?: Function) {
		let bg: egret.Sprite;
		let rect: egret.Sprite;
		let drawt;
		bg = Guide.drawBg();
		rect = Guide.drawRoundRect(0, 0, 720, 1280);
		rect.x = 720;
		rect.y = 900;
		rect.anchorOffsetX = 720;
		rect.anchorOffsetY = 900;
		let scaley = 300 / 1280;
		let scalex = 200 / 720;
		drawt = Guide.drawTexture(bg, rect);
		this.addChildAt(drawt, 0);
		egret.Tween.get(rect, {
			onChange: () => {
				drawt = Guide.drawTexture(bg, rect);
				this.removeChildAt(0);
				this.addChildAt(drawt, 0);
			}, onChangeObj: this
		}).wait(1).to({ scaleY: scaley, scaleX: scalex }, 1000).call(() => {
			callFunc && callFunc();
		});


	}
}