class Guide801 extends eui.Component {
	public storyBox: GuideStoryBox;
	private typeWrite: Typewriting;
	private story1: string = `哼哼哼~这是我的地盘！`;
	private story2: string = `哼哼~害怕了吧！
我告诉你，被改造后的砖块是无法丢弃的！。`;
	public callBack: Function;
	public localGame: GameComponent;
	public constructor() {
		super();
				this.percentWidth = 100;
		this.percentHeight = 100;
		this.skinName = "Guide801Skin"
		this.typeWrite = new Typewriting();
	}
	public childrenCreated() {
		this.storyBox.setArrow(StoryBoxArrow.LDown);
		this.storyBox.visible = false;
		this.startStory();
	}

	public startStory() {
		var _self_ = this;
		var step2Click = function () {
			_self_.addEventListener("touchTap", step2, _self_);
		}
		var step2 = function () {
			_self_.removeEventListener("touchTap", step2, _self_);
			_self_.typeWrite.init(_self_.story2, _self_.storyBox.storyLab);
			_self_.typeWrite.endCall = endClick;
			_self_.typeWrite.start();
		}
		var step1 = function () {
			_self_.typeWrite.init(_self_.story1, _self_.storyBox.storyLab);
			_self_.typeWrite.endCall = step2Click;
			_self_.typeWrite.start();
			_self_.storyBox.visible = true;
		}

		var endClick = function () {
			_self_.addEventListener("touchTap", end, _self_);
		}

		var end = function () {
			_self_.parent.removeChild(_self_);
			_self_.callBack && _self_.callBack();

		}
		this.focus1(step1);
	}


	public focus1(callFunc?: Function) {
		let bg = Guide.drawBg();
		let r = 1280 / 2;
		let circle = Guide.drawCircle(0, 0, r);
		circle.x = this.localGame.debuffNpc.display.x + 20;
		circle.y = this.localGame.debuffNpc.display.y;
		circle.anchorOffsetX = circle.x;
		circle.anchorOffsetY = circle.y;
		let rw = (this.localGame.debuffNpc.display.width >> 1) + 40;
		let scale = rw / r;
		let drawt = Guide.drawTexture(bg, circle);
		this.addChildAt(drawt, 0);
		egret.Tween.get(circle, {
			onChange: () => {
				drawt = Guide.drawTexture(bg, circle);
				this.removeChildAt(0);
				this.addChildAt(drawt, 0);
			}, onChangeObj: this
		}).to({ scaleX: scale, scaleY: scale }, 1000).call(() => { callFunc && callFunc(); });
	}
}