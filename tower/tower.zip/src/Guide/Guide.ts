
class Guide {
	public constructor() {

	}

	public static init() {
		this.renderTexture = new egret.RenderTexture();
	}

	private static renderTexture: egret.RenderTexture;

	public static step101To102(panel: egret.DisplayObjectContainer, call: Function) {
		if (this.checkGuideStep(1)) { call(); return; };
		let bg = this.drawBg();
		let guide = new Guide101();
		guide.callBack = () => { this.saveGuideStep(1); call(); };
		panel.addChild(guide);
		guide.addChildAt(bg, 0);
	}


	public static step103To105(panel: egret.DisplayObjectContainer, callFunc?: Function) {
		if (this.checkGuideStep(2)) { callFunc(); return; };
		let guide = new Guide103();
		guide.callFunc = () => { this.saveGuideStep(2); callFunc(); };
		panel.addChild(guide);
	}

	public static step201To204(ctr: KFController, callFunc?: Function) {
		if (this.checkGuideStep(3)) { callFunc(); return; };
		let panel: egret.DisplayObjectContainer = ctr.mPanel;
		let localGame = (ctr as GamePanelController).localGame;
		let guide = new Guide201();
		guide.localGame = localGame;
		guide.callFunc = () => { this.saveGuideStep(3); callFunc(); }
		panel.addChild(guide);
	}

	public static step401(ctr: KFController, callFunc?: Function) {
		if (this.checkGuideStep(4)) { callFunc(); return; };
		let panel: egret.DisplayObjectContainer = ctr.mPanel;
		let localGame = (ctr as GamePanelController).localGame;
		let guide = new Guide401();
		guide.callBack = () => { this.saveGuideStep(4); callFunc(); };
		panel.addChild(guide);
	}

	public static step501(ctr: KFController, callFunc?: Function) {
		if (this.checkGuideStep(5)) { return; };
		(ctr as GamePanelController).pause();
		let panel: egret.DisplayObjectContainer = ctr.mPanel;
		let localGame = (ctr as GamePanelController).localGame;
		let guide = new Guide501();
		guide.callBack = () => {
			this.saveGuideStep(5);
			(ctr as GamePanelController).resume();
		};
		panel.addChild(guide);
	}

	public static step701(ctr: KFController, callFunc?: Function) {
		if (this.checkGuideStep(7)) { callFunc(); return; };
		let panel: egret.DisplayObjectContainer = ctr.mPanel;
		let localGame = (ctr as GamePanelController).localGame;
		let guide = new Guide701();
		guide.localGame = localGame;
		guide.callBack = () => { callFunc(); this.saveGuideStep(7) };
		panel.addChild(guide);
	}

	public static step801(localGame: GameComponent, callFunc?: Function) {
		if (this.checkGuideStep(8)) { callFunc(); return; };
		let ctrl = KFControllerMgr.getCtl(PanelName.GamePanel) as GamePanelController;
		ctrl.pause();
		let guide = new Guide801();
		guide.localGame = localGame;
		guide.callBack = () => { ctrl.resume(); callFunc();this.saveGuideStep(8) };
		ctrl.mPanel.addChild(guide);
	}

	public static drawCircle(x: number, y: number, r: number): egret.Sprite {
		let circle = new egret.Sprite();
		circle.graphics.beginFill(0x000000, 1);
		circle.graphics.drawCircle(x, y, r);
		circle.graphics.endFill();
		return circle;
	}

	public static drawRoundRect(x: number, y: number, w: number, h: number): egret.Sprite {
		let rect = new egret.Sprite();
		rect.graphics.beginFill(0x000000, 1);
		rect.graphics.drawRoundRect(x, y, w, h, 2);
		rect.graphics.endFill();
		return rect;
	}

	public static drawBg(): egret.Sprite {
		let bgs = new egret.Sprite();
		bgs.graphics.beginFill(0x000000, 0.5);
		bgs.graphics.drawRect(0, 0, egret.MainContext.instance.stage.stageWidth, egret.MainContext.instance.stage.stageHeight);
		bgs.graphics.endFill();
		return bgs;
	}

	public static drawTexture(container: egret.Sprite, erase: egret.Sprite): egret.Bitmap {
		// container.removeChildren();
		erase.blendMode = egret.BlendMode.ERASE;
		container.addChild(erase);
		this.renderTexture.drawToTexture(container);
		let bitmap = new egret.Bitmap();
		bitmap.texture = this.renderTexture;
		return bitmap;
	}

	public static checkGuideStep(step: number): boolean {
		return !!this.getByte(GlobalClass.CurrentUser.guide_status, step);
	}

	public static saveGuideStep(step: number) {
		let guide_status = GlobalClass.CurrentUser.guide_status = this.setByte(GlobalClass.CurrentUser.guide_status, step);
		WebSocketMgr.getInstance().SendOneceMsg(MsgID.HALL.GetGuideStep, JSON.stringify({ guide_status: guide_status }));
	}

	public static getByte(data: number, offsize: number): number {
		return data >> offsize & 1;
	}

	public static setByte(data: number, offsize: number): number {
		return data | (1 << offsize)
	}

}
