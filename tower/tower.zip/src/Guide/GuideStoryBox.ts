class GuideStoryBox extends eui.Component {
	public rbg: eui.Image;
	public lbg: eui.Image;
	public upr: eui.Image;
	public upl: eui.Image;

	public storyLab: eui.Label;

	public constructor() {
		super();
	}

	public childrenCreated() {
	}

	public setArrow(arrow: StoryBoxArrow) {
		for (let i = 0; i < 4; i++) {
			this.getChildAt(i).visible = (i == arrow);
		}

	}

}
enum StoryBoxArrow {
	RDown,
	LDown,
	RUp,
	LUp
}